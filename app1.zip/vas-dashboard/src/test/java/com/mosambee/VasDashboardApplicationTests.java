package com.mosambee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VasDashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
