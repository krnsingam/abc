
(function($) {

	// IT HIGHLIGHTS SELECTED ITEMS IN SIDEBAR AND OPEN MENU
	var url = window.location;
	var location = window.location.href;
	
	$('ul.nav-sidebar a').removeClass('active').parent().siblings()
			.removeClass('menu-open');
	/*
	 * find active element add active class ,if it is inside treeview element,
	 * expand its elements and select treeview
	 */
	$('ul.nav-sidebar a').filter(function() {
		if(wordInString("api-password-config")){
			$("#listApi").addClass('active').closest(".has-treeview").addClass('menu-open').find("> a");
		}
		else if(wordInString("dashboard/transaction")){
			if(wordInString("dashboard/transaction/transaction-report-view")){
				console.log("Condition removed");
			}else{
			$("#txn").addClass('active').closest(".has-treeview").addClass('menu-open').find("> a");}
		}
		else if(wordInString("merchant-specific")){
			$("#merspc").addClass('active').closest(".has-treeview").addClass('menu-open').find("> a");
		}
		else if(wordInString("/user")){
			$("#user").addClass('active').closest(".has-treeview").addClass('menu-open').find("> a");
		}
		else if(wordInString("/merchants")){
			$("#insert-bqr").addClass('active').closest(".has-treeview").addClass('menu-open').find("> a");
		}
		return this.href == url;
	}).addClass('active').closest(".has-treeview").addClass('menu-open').find(
			"> a").addClass('active');

	function wordInString(word){
		  return new RegExp( '\\b' + word + '\\b', 'i').test(location);
	}	
})(jQuery);
	
var contexturi = $('#contexturi').attr('content');


