
$(document).ready(function () {
	var myContextPath = $("#app_context_path").attr('content');
	console.log(myContextPath);
	
	$("#first-search").hide();

    // Numeric only control handler
    jQuery.fn.ForceNumericOnly =
        function () {
            return this.each(function () {
                $(this).keydown(function (e) {
                    var key = e.charCode || e.keyCode || 0;
                    // allow backspace, tab, delete, enter, arrows, numbers and
                    // keypad numbers ONLY
                    // home, end, period, and numpad decimal
                    return (
                        key == 8 ||
                        key == 9 ||
                        key == 13 ||
                        key == 46 ||
                        key == 110 ||
                        key == 190 ||
                        (key >= 35 && key <= 40) ||
                        (key >= 48 && key <= 57) ||
                        (key >= 96 && key <= 105));
                });
            });
        };


    // No special char control handler
    function isValid(str) {
        return !/[~`!@#$%\^&*()+=\-\[\]\\'.;,/{}|\\":<>\?]/g.test(str);
    }

    // DataTable
    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    var postdata = {};


    // Data Table ajax call and storing the value in table.
    var table = $('#table_id').DataTable({
        "processing": true,
        "serverSide": true,
/*
 * "scrollY": $(document).height() - 400,
 */     "scrollCollapse": true,
        "paging": true,
        "createdRow": function (row, data, index) {
            var info = table.page.info();
            $('td', row).eq(0).html(index + 1 + info.page * info.length);
        },
        "dom": 
        	"<'row'<'col-sm-12 col-md-12'l>>" +
			"<'row'<'col-sm-12'tr>>" +
			"<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
        
        "ajax": {
            "url": myContextPath+"/merchant-specific/merchant-key-view",
            "contentType": "application/json",
            "type": "POST",
            "timeout":"60000",
            "data": function (d) {

                postdata.dataTable = d;
                postdata.merchant = $("#merchantname").val();
                postdata.merchantKey = $('#merchantkey').val();
                postdata.merchantCode = $('#merchantcode').val();

                return JSON.stringify(postdata);
            },
            "beforeSend": function (request) {
                request.setRequestHeader(header, token);
            },
            "error": function (xhr, error, code) {

                if (error === 'parsererror' || error === 'timeout') {
                    window.location.href = myContextPath + "/login?invalid";
                }
            }
        },
        "columns": [

            { "data": 'srno' },
            { "data": 'merchant' },
            { "data": 'merchantCode' },
            { "data": 'merchantKey' },
            { "data" : "merchKeyId",
                "searchable": false,
                "orderable":false,
                "render": function (data, type, row) {
                      console.log($('#is_admin'));
                      if($('#is_admin').val() !== undefined){
                    	  return '<button type="button" title="Update" class="actionClass btn btn-primary btn-xs mx-auto d-block" data-toggle="modal" data-target="#modal-default" id="update"><i class="fa fa-edit"></i></button>';
                      }else{
                    	  $("#role").hide();
                    	  return "";
                      }
                }         
            }
        ],
        "order": [[0, "desc"]]
    });

    // to download the product bin detail
    $("#download").on("click", function () {
    	
    	$(".validationAlert").html("");
    	
    	if($.trim($("#merchantname").val()) != ''){
		  	
	        if($("#merchantname").val().length>100)
	        {
	        	$("#mch_error").html("Max 100 characters is allowed");
	    		return false;
	        }
	             
    	}
    	
    	if($.trim($("#merchantcode").val()) != ''){
		  	
	        if($("#merchantcode").val().length>20)
	        {
	        	$("#code_error").html("Max 20 characters is allowed");
	    		return false;
	        }
	             
    	}
    	
    	if($.trim($("#merchantkey").val()) != ''){
		  	
	        if($("#merchantkey").val().length>500)
	        {
	        	$("#key_error").html("Max 500 characters is allowed");
	    		return false;
	        }
	             
    	}
        
    });

 // to update merchant mapping
    $("#table_id tbody").on("click", "#update", function () {
    	var data = table.row($(this).parents("tr")).data();
        console.log(data['merchKeyId']);
        var merchKeyId = data['merchKeyId'];
        $form = $("<form action='"+myContextPath+"/merchant-specific/update-key-from-list' method='post'></form>");
        $form.append("<input type='_csrf' name='_csrf' value='" + $("#_csrf").attr('content') + "'>");
        $form.append("<input type='text' name = 'merchKeyId' value='" + merchKeyId + "'>");
        $('body').append($form);
       	$form.submit();
    
    });
    
    // to search the product bin detail
    $("#search").on("click", function () {
    	
    	$(".validationAlert").html("");
    	
    	if($.trim($("#merchantname").val()) != ''){
		  	
	        if($("#merchantname").val().length>100)
	        {
	        	$("#mch_error").html("Max 100 characters is allowed");
	    		return false;
	        }
	             
    	}
    	
    	if($.trim($("#merchantcode").val()) != ''){
		  	
	        if($("#merchantcode").val().length>20)
	        {
	        	$("#code_error").html("Max 20 characters is allowed");
	    		return false;
	        }
	             
    	}
    	
    	if($.trim($("#merchantkey").val()) != ''){
		  	
	        if($("#merchantkey").val().length>500)
	        {
	        	$("#key_error").html("Max 500 characters is allowed");
	    		return false;
	        }
	             
    	}
    	
    	$("#first-search").show();
        $('#table_id').dataTable().fnFilter();

    });

    $(".numeric-only").ForceNumericOnly();

    $(".no-special-char").keypress(function (event) {
        var character = String.fromCharCode(event.keyCode);
        return isValid(character);
    });
    // For dropdown
    $('.select2').select2();
});