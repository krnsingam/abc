$(document).ready(function () {
	$(".autocomplete").hide();
	var myContextPath = $("#app_context_path").attr('content');
	console.log(myContextPath);
	
	//Headers and token
	  var token = $('#_csrf').attr('content');
	  var header = $('#_csrf_header').attr('content');
	
	$.validator.addMethod("AlphaNumericWithSpaceValidation", function (value, element) {
		return this.optional(element) || /^[a-zA-Z\d]+((\s)*[a-zA-Z\d])*$/.test(value);
	}, 'Special character not allowed!');
	
	$.validator.addMethod("EmailValidation", function (value, element) {
	
		return this.optional(element) || /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/.test(value);
	}, 'This is not valid email');

	$.validator.addMethod("URLValidation", function (value, element) {
		return this.optional(element) || /^(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})$/.test(value);
	}, 'This is not valid url');

	$("#createAPIGroup").validate({
		onClick : true,

		errorElement: 'span',
		errorClass: 'help-block error-border',
		
		highlight: function (element, errorClass, validClass) {

			$(element).closest('.form-group').addClass("has-error");
			$(element).closest('.form-control').addClass("error-border");

		},
		unhighlight: function (element, errorClass, validClass) {
			$(element).closest('.form-group').removeClass("has-error");
			$(element).closest('.form-control').removeClass("error-border");

		},
	rules : {
		merchantName : {
			required : true,
			AlphaNumericWithSpaceValidation :false,
			maxlength : 100 
		},
		classPath : {
			required : true,
			maxlength : 150 
		},
		url : {
			maxlength : 500
		}
		
		},

		messages:
		{

		}
	});
	
	  // to view merchant details
    $("#merchantName").keyup(function () {

    	if ( event.which != 38 ||  event.which != 40 || event.which != 2) {
    	    
	    	var html ="";
	        $.ajax({
	            url: myContextPath+'/merchant-specific/merchant-name',
	            contentType: "application/json",
	            type: "POST",
	            data: JSON.stringify({ merchId : 0,  merchantNameCode : $("#merchantName").val()}),
	            dataType: 'json',
	            beforeSend: function (request) {
	                request.setRequestHeader(header, token);
	            }, success: function (result) {
	
	                html = '<ul class="pl-2" id="list" >';
	
	            	$.each(result, function(k, v) {
	                   //console.log(v);
	                   html +='<li class="liststyletype" data-id='+v.merchId+'>'+v.merchantNameCode+'</li>';
	                });
	            	
	            	html += '</ul>';
	            	
	            	$("#autoCompleteData").html(html).show();
	            	
	            	$(".autocomplete").show();
	            	$("#autoComp").addClass("mb-0");
	            }
	        });
    	}

    });
    
    $(document).on('click','#list li',function(){
    	document.getElementById("merchantnameVal").value=$(this).data('id');
        document.getElementById("merchantName").value=this.outerText;
        $("#autoCompleteData").hide();
    });
   

});

$(document).ready(function () {
	  $( "#message" ).fadeOut( 2000 );
	  
	  $(".no-special-char").keypress(function (event) {
	        var character = String.fromCharCode(event.keyCode);
	        return isValid(character);
	    });
	  
	  // No special char control handler
	    function isValid(str) {
	        return !/[~`!@#$%\^&*()+=\[\]\\';/{}|\\":<>\?]/g.test(str);
	    }
});
