$(document).ready(function () {
	
	$("#blockDate").datepicker({
		format: 'dd-mm-yyyy',
		autoclose: true,
		endDate:'+d'
	});
	
	$("#expiryDate").datepicker({
		format: 'dd-mm-yyyy',
		autoclose: true,
		endDate:'+d'
	});
	
	$('#card-alerts').show();
	$("#card-alerts").alert();
	window.setTimeout(function () {
		$("#card-alerts").hide();
	}, 2000);
	
    $(document).on( "click", ".userstatusChange",function(e) {
    	e.preventDefault();
	    var groupId = $(this).data("id");
		$("#userId").val(groupId);
		$("#userStatusModal").modal('show');       
    });
	
    // DataTable
    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    // getting contextPath
    var myContextPath=$("#app_context_path").attr('content') ;



    var table = $('#table_id').DataTable({
        "processing": true,
        "serverSide": true,
        //"scrollY": $(document).height() - 400,
        "scrollCollapse": true,
        "paging": true,
        "dom": 
        	"<'row'<'col-sm-12 col-md-12'l>>" +
			"<'row'<'col-sm-12'tr>>" +
			"<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
        "ajax": {
            "headers": {

            },
            "url": myContextPath + "/user/mobile-blocked-users",
            "contentType": "application/json",
            "type": "POST",
            "timeout":"60000",
            "data": function (d) {
            	var startTime="";
            	var endTime="";
            	if($.trim($("#blockDate").val()) != ""){
            		let d = $("#blockDate").val().split("-");
            		startTime = d[2]+"-"+d[1]+"-"+d[0];
            	}
            	
            	if($.trim($("#expiryDate").val()) != ""){
            		let e = $("#expiryDate").val().split("-");
            		endTime = e[2]+"-"+e[1]+"-"+e[0];
            	}
            	var postdata ={};
            	postdata.dtRequest = d;
				postdata.username = $('#username').val();
				postdata.firstName = $('#firstName').val();
				postdata.email = $('#email').val();
				postdata.blockDate = startTime;
				postdata.expiryDate = endTime;
				
                return JSON.stringify(postdata);
            },
            "beforeSend": function (request) {
            	$("#search").attr('disabled',true);
                request.setRequestHeader(header, token);
            },
            "complete": function( settings, json ) {
            	$("#search").attr('disabled',false);
            },
            "error": function (xhr, error, code) {

                if (error === 'parsererror' || error === 'timeout') {
                    window.location.href = contexturi + "/login?invalid";
                }
            }
        },
        "columns": [
            { "data": 'userName' },
            { "data": 'firstName' },
            { "data": 'email' },
            { "data": 'blockDate' },
            { "data": 'expireDate' },
            {
	        	"data": "id",
	        	"render": function (data, type, row, meta) {
	        		 console.log($('#is_admin'));
	        		if($('#is_admin').val() !== undefined){
	        		    return '<div  class="custom-control pl-0"><button data-id="'+row.id+'" class="btn btn-xs btn-primary userstatusChange" id="customSwitch1'+row.id+'" value="Enable">Enable</button></div>';
	        		}else{
                  	  	$("#role").hide();
                  	  	return "";
                    }
	        	}
            },

        ]
    });

    // Apply the search
    table.columns().every(function () {
        var that = this;

        $('input', this.footer()).on('keyup change clear', function () {
            if (that.search() !== this.value) {
                that
                    .search(this.value)
                    .draw();
            }
        });
    });
});



$("#confirmBlock").click(function(){
	updateBlockedUserStatus('confirm');
});

$("#confirmCLose").click(function(){
	updateBlockedUserStatus('close');
});


function updateBlockedUserStatus(action){
	
	if(action == 'close'){
		$("#userStatusModal").modal('hide'); 
		return false;
	}
	
	if($.trim($("#comment").val()) != ""){
		 $("#cover-spin").show();
		 $.ajax({
	     	url: contexturi+"/user/mobile-unblock-users",
	     	headers: {
	     		    'X-CSRF-TOKEN':$('#_csrf').attr('content'),
	     	},
	     	type: "POST",
	     	data:{ mUserId :$("#userId").val(),comment : $("#comment").val()  },
	     	success: function(result){
	     		if(result == true){
	     			console.log('User status updated succesfully');
	     		}
	     		$("#cover-spin").hide();
	            $("#userStatusModal").modal('hide');
	            window.location.reload();
	         },
	         error:function(xhr, error, code) {
	
	             if (error === 'parsererror') {
	                 window.location.href = +contexturi+"/login?invalid";
	             }
	             
	         }
	      });
	 }else{
		 $("#userStatusModal").modal('hide');
	 }
}




$("#search").on("click", function (event) {
	event.preventDefault();
$(".validationAlert").text("");
	
	var alphaNumregx = /^[A-Za-z0-9@.]+$/;
	var nameRegex = /^[A-Za-z]+$/;
	var emailRegex = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
	
   if($.trim($("#username").val()) != ""){
		
		if($("#username").val().length > 100){
			$("#username_error").text("Please enter valid username");
			return false;
		}
		
		if(!alphaNumregx.test($.trim($("#username").val()))){
			$("#username_error").text("Please enter valid username");
			return false;
		}
	}
   
   if($.trim($("#firstName").val()) != ""){
		
		if($("#firstName").val().length > 25){
			$("#firstName_error").text("Please enter valid first name");
			return false;
		}
		
		if(!nameRegex.test($.trim($("#firstName").val()))){
			$("#firstName_error").text("Please enter valid first name");
			return false;
		}
	}
   
   if($.trim($("#email").val()) != ""){
		
		if($("#email").val().length > 100){
			$("#email_error").text("Please enter valid email");
			return false;
		}
		
		if(!emailRegex.test($.trim($("#email").val()))){
			$("#email_error").text("Please enter valid email");
			return false;
		}
	}
	
	
	if($.trim($("#blockDate").val()) != ""){
	    var blockDate = $("#blockDate").val();
    	date2 = blockDate.split('-');
    	 $("#blockDate2").val(date2[2]+"-"+date2[1]+"-"+date2[0]);
	}
	
	if($.trim($("#expiryDate").val()) != ""){
		var expiryDate = $("#expiryDate").val();
		date3 = expiryDate.split('-');
		$("#expiryDate2").val(date3[2]+"-"+date3[1]+"-"+date3[0]);
	}

	
	$('#table_id').dataTable().fnFilter();
});


















