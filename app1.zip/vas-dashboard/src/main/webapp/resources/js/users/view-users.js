var checkUpdate = false;
$(document).ready(function () {
	
	$("#confirmBlock").click(function(){
		updateUserStatus('confirm');
	});

	$("#confirmClose").click(function(){
	    
		$("#userStatusModal").modal('hide');
		
//	    if($("#"+$("#statusId").val()).is(":checked")){
//	    	$("#"+$("#statusId").val()).prop('checked',false);
//		}else {
//			$("#"+$("#statusId").val()).prop('checked',true);
//		}
	    
	});

	$("#userStatusModal").on('hide.bs.modal', function () {
		console.log(checkUpdate);
		if(!checkUpdate){
			if($("#"+$("#statusId").val()).is(":checked")){
		    	$("#"+$("#statusId").val()).prop('checked',false);
			}else {
				$("#"+$("#statusId").val()).prop('checked',true);
			}
		}
		checkUpdate = false;
		$("#comment").val('');
	});

	$('#card-alerts').show();
	$("#card-alerts").alert();
	window.setTimeout(function () {
		$("#card-alerts").hide();
	}, 2000);
    // DataTable
    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    // getting contextPath
    var myContextPath=$("#app_context_path").attr('content') ;
    
    $(document).on( "click", ".userstatusChange",function() {
	    var status = ($(this).is(':checked')==true)?1:0;        
	    var groupId = $(this).data("id");
		$("#userStatus").val(status);
		$("#userId").val(groupId);
		$("#statusId").val(this.id);
		$("#userStatusModal").modal('show');       
    });


    var table = $('#table_id').DataTable({
        "processing": true,
        "serverSide": true,
        //"scrollY": $(document).height() - 400,
        "scrollCollapse": true,
        "paging": true,
        "dom": 
        	"<'row'<'col-sm-12 col-md-12'l>>" +
			"<'row'<'col-sm-12'tr>>" +
			"<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
        "ajax": {
            "headers": {

            },
            "url": myContextPath + "/user/list",
            "contentType": "application/json",
            "type": "POST",
            "timeout":"60000",
            "data": function (d) {
            	var postdata ={};
            	postdata.dtRequest = d;
				postdata.username = $('#username').val();
				postdata.status = $('#status').val();
				postdata.role = $('#roleName').val();
                return JSON.stringify(postdata);
            },
            "beforeSend": function (request) {
            	$("#search").attr('disabled',true);
                request.setRequestHeader(header, token);
            },
            "complete": function( settings, json ) {
            	$("#search").attr('disabled',false);
            },
            "error": function (xhr, error, code) {
                if (error === 'parsererror' || error === 'timeout') {

                    window.location.href = myContextPath + "/login?invalid";
                }
            }
        },
        "columns": [
            { "data": 'username' },
            {
            	"data": "status",
            	"render": function (data, type, row, meta) {
            		
            		if (data != "" || data != null) {
            		    if(row.status == 1){
            		    	data = "Activate";
            		    }else{	
            			    data ="De-Activated";
            		    }
            		}
            		return data;
            	}
            },
            { "data": 'roleName' },
            {
            	"data": "status",
            	"render": function (data, type, row, meta) {
	            	if($('#is_admin').val() !== undefined){
	            		if (data != "" || data != null) {
	            		    if(row.status == 1){
	            		    	data = '<div  class="custom-control custom-switch toggle-switch"><input type="checkbox" data-id="'+row.id+'" class="custom-control-input userstatusChange toggle-input" id="customSwitch1'+row.id+'" checked><label class="custom-control-label toggle-label" for="customSwitch1'+row.id+'"   data-target="#myModal2" ></label></div>';
	            		    }else{	
	            			    data = '<div  class="custom-control custom-switch toggle-switch"><input type="checkbox" data-id="'+row.id+'" class="custom-control-input userstatusChange toggle-input" id="customSwitch1'+row.id+'"><label class="custom-control-label toggle-label" for="customSwitch1'+row.id+'"   data-target="#myModal2" ></label></div>';
	            		    }
	            		}
	            		return data;
	            	}else{
	              	  $("#role").hide();
	            	  return "";
	            	}
            	}
            },
            {
            	"data": "id",
            	"render": function (data, type, row, meta) {
            		if($('#is_admin').val() !== undefined){
            			return '<button type="button" class="btn btn-xs btn-primary" title="Edit" data-id="'+row.id+'" onclick="updateUser(this)"><i class="fa fa-edit"></i></button>';
            		}else{
                  	  $("#roles").hide();
                  	  return "";
                    }
            	}
            },
        ]
    });

    // Apply the search
    table.columns().every(function () {
        var that = this;

        $('input', this.footer()).on('keyup change clear', function () {
            if (that.search() !== this.value) {
                that
                    .search(this.value)
                    .draw();
            }
        });
    });
});



function updateUser(t){
	$("#userId").val($(t).data('id'));
	$("#userBin").submit();
}




function updateUserStatus(action){

	if(action == 'close'){        
		return false;
	}
	 
	 
	     $("#cover-spin").show();
		 $.ajax({
	     	url: contexturi+"/user/update-user-status",
	     	headers: {
	     		    'X-CSRF-TOKEN':$('#_csrf').attr('content'),
	     	},
	     	type: "POST",
	     	data:{ status :$("#userStatus").val(),userId : $("#userId").val()  },
	     	success: function(result){
                
	     		checkUpdate = true;
	     		$("#cover-spin").hide();
	            $("#userStatusModal").modal('hide');
	            $("#comment").val('');
	            if(result == true){
	     			$("#userSuccess").show().fadeOut(3000);
	     		}else{
	     			$("#userFailed").show().fadeOut(3000);
	     		}

	         },
	         error:function(xhr, error, code) {
	
	             if (error === 'parsererror') {
	                 window.location.href = +contexturi+"/login?invalid";
	             }
	             
	         }
	      });
	 
}

$("#createUser").click(function(e){
	e.preventDefault();
	if(validateUserForm()){
		$("#createUser").attr("disabled",true);
		$("#createNewUser").submit();
	}
});

$("#updateUser").click(function(e){

	e.preventDefault();
	if(validateUserForm()){
		$("#updateUser").attr("disabled",true);
		$("#updateCurrentUser").submit();
	}
})


function validateUserForm(){
   
	var response = true;
	var emailRegex = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,10}\b$/i;
	var nameRegex = /^[a-zA-Z]*$/;
	
	$(".validationAlert").text("");
	
	if($.trim($("#email").val()) == ""){
		$("#email_alert").text("Please enter Email");
		response = false;
	}
	
	if($.trim($("#email").val()) != ""){
		if(!emailRegex.test($("#email").val())){
			$("#email_alert").text("Please enter valid Email");
			response = false;
		}
	}
	
	if($.trim($("#firstName").val()) == ""){
		$("#firstName_alert").text("Please enter first name");
		response = false;
	}
	
	if($("#firstName").val() != ""){
		if(!nameRegex.test($("#firstName").val())){
			$("#firstName_alert").text("Please enter valid first name.");
			response = false;
		}
	}
	
	if($.trim($("#lastName").val()) == ""){
		$("#lastName_alert").text("Please enter last name");
		response = false;
	}
	
	if($("#lastName").val() != ""){
		if(!nameRegex.test($("#lastName").val())){
			$("#lastName_alert").text("Please enter valid last name.");
			response = false;
		}
	}
	
	
	return  response;
}



$("#search").on("click", function (event) {
	event.preventDefault();
	$(".validationAlert").text("");
	var alphaNumregx = /^[A-Za-z0-9@.]+$/;
	
	if($.trim($("#username").val()) != ""){
		
		if($("#username").val().length > 50){
			$("#username_error").text("Please enter valid user name");
			return false;
		}
		
		if(!alphaNumregx.test($.trim($("#username").val()))){
			$("#username_error").text("Please enter valid user name");
			return false;
		}
	}

	$('#table_id').dataTable().fnFilter();
});


















