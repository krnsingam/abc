$(document).ready(function(){
	
	// Datepicker Implementation
	var date = new Date(),
	yr = date.getFullYear(),
	month = date.getMonth() + 1,
	day = date.getDate(),
	todayDate = day + '-' + month + '-' + yr;
	
	$("#fromdate").val(todayDate);
	$("#todate").val(todayDate);
	
	var maxDate;
	var minDate;
	
	//from date
	$("#fromdate").datepicker({
		format: 'dd-mm-yyyy',
		autoclose: true,
	}).click('changeDate',function (selected){
		minDate = moment(todayDate, 'DD-MM-YYYY').subtract(20, 'years').format('DD-MM-YYYY');
		maxDate = todayDate;
		$('#fromdate').datepicker('setStartDate',minDate);
		$('#fromdate').datepicker('setEndDate', maxDate);
	});
	
	//to date
	$("#todate").datepicker({
		format: 'dd-mm-yyyy',
		autoclose: true,
	}).click('changeDate',function (selected){
		var maxDate = todayDate;
		var minDate = $("#fromdate").val();
		$('#todate').datepicker('setStartDate', minDate);
		$('#todate').datepicker('setEndDate', maxDate);
	});
	// End Datepicker Implementation
	
	
	/////////Start DataTable implementation////////
	
    //hide data-table while page is rendering for the first time 	
	$("#table_body").hide();
	
	 var token = $('#_csrf').attr('content');
	 var header = $('#_csrf_header').attr('content');
	 
	 // getting contextPath
	 var myContextPath=$("#app_context_path").attr('content') ;
	
	 //data to be post on search
	 var postdata = {};
	 
	 // Data Table ajax call and storing the value in table
	    var table = $('#network_message_table').DataTable({
	        "processing": true,
	        "serverSide": true,
	        "scrollCollapse": true,
	        "paging": true,
	        "dom":
	            "<'row'<'col-sm-12 col-md-12'l>>" +
	            "<'row'<'col-sm-12'tr>>" +
	            "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
	        "ajax": {
	            "url": myContextPath + "/networkmessages/networkmessages-list",
	            "contentType": "application/json",
	            "type": "POST",
	            "data": function (d) {

	                postdata.dtRequest = d;
	                postdata.userId = $("#userId").val();
	                postdata.fromDate = $("#fromdate").val();
	                postdata.toDate = $('#todate').val();
	                return JSON.stringify(postdata);
	            },
	            "beforeSend": function (request) {
	                request.setRequestHeader(header, token);
	            },
	            "error": function (xhr, error, code) {

					if (error === 'parsererror') {
						window.location.href = myContextPath + "/login?invalid";
					}
				}
	        },
	        "columns": [

	            { "data": 'userName' },
	            { "data": 'terminalId' },
	            { "data": 'processingCode' },
	            {
	            	"data": "messageType",
	            	"render": function (data, type, row, meta) {
	            		
	            		if (data != "" || data != null) {
	            		    if(row.messageType == 1){
	            		    	data = "TMK1 Download";
	            		    }else if(row.messageType == 2){
	            		    	data = "TMK2 Download";
	            		    }else if(row.messageType == 3){
	            		    	data = "Logon";
	            		    }else if(row.messageType == 4){
	            		    	data = "Initialization";
	            		    }else {	
	            			    data =" ";
	            		    }
	            		}
	            		return data;
	            	}
	            },
	            { "data": 'responseCode' },
	            { "data": 'hsmResponseCode' },
	            { "data": 'date' },
	            
	        ],
	        "order": [[0, "asc"]]
	    });
	
	    //on search , showing the data in table
	    $("#search").on("click",function (event) {
	 
	    	var alphanumericRegex = /^[a-zA-Z0-9]+$/;

	    	var start = $("#fromdate").datepicker("getDate");
	    	var end = $("#todate").datepicker("getDate");
	    	
	    	days = (end - start) / (1000 * 60 * 60 * 24);

	    	$("#userId_error").html("");
	    	
	    	if ($.trim($("#userId").val()) == "") {

	    		$("#30days_error").text("");
				$("#exceeddays_error").text("");
				$("#todate_error").text("");
				$("#userId_error").text("Please enter UserId");
				$("#fromdate_error").text("");
				return false;
				
			}else if(!alphanumericRegex.test($("#userId").val())){
				
				$("#30days_error").text("");
				$("#exceeddays_error").text("");
				$("#todate_error").text("");
	    		$("#userId_error").text("Please enter valid userId");
	    		$("#fromdate_error").text("");
	    		return false;
	    		
	    	}else if ($.trim($("#fromdate").val()) == '') {

	    		$("#30days_error").text("");
				$("#exceeddays_error").text("");
				$("#todate_error").text("");
				$("#userId_error").text("");
				$("#fromdate_error").text("Please select fromdate");
				return false;
				
			} else if (Math.round(days) > 90) {

				$("#fromdate_error").text("");
				$("#exceeddays_error").text("");
				$("#todate_error").text("");
				$("#userId_error").text("");
				$("#30days_error").text("Please select dates between 30 days");				
				return false;
				
			}  else if ($.trim($("#todate").val()) == '') {
				
				$("#30days_error").text("");
				$("#exceeddays_error").text("");
				$("#fromdate_error").text("");
				$("#userId_error").text("");
				$("#todate_error").text("Please select todate ");
				return false;
				
			} else if (start > end) {
				
				$("#fromdate_error").text("");
				$("#todate_error").text("");
				$("#30days_error").text("");
				$("#userId_error").text("");
				$("#exceeddays_error").text("please select todate more than fromDate ");
				return false;
				
			} else {
				
				$("#30days_error").text("");
				$("#exceeddays_error").text("");
				$("#fromdate_error").text("");
				$("#userId_error").text("");
				$("#todate_error").text("");
			}
	    	
	    	$("#table_body").show();
			$('#network_message_table').dataTable().fnFilter();
	    });
	    /////////End DataTable implementation////////
	    
	    
	    // to download the networkmessages excel data
	    $("#download").on("click", function () {
	    
	    	var alphanumericRegex = /^[a-zA-Z0-9]+$/;

	    	var start = $("#fromdate").datepicker("getDate");
	    	var end = $("#todate").datepicker("getDate");
	    	
	    	days = (end - start) / (1000 * 60 * 60 * 24);

	    	$("#userId_error").text("");
	    	
	    	if ($.trim($("#userId").val()) == "") {

	    		$("#30days_error").text("");
				$("#exceeddays_error").text("");
				$("#todate_error").text("");
				$("#userId_error").text("Please enter UserId");
				$("#fromdate_error").text("");
				return false;
				
			}else if(!alphanumericRegex.test($("#userId").val())){
				
				$("#30days_error").text("");
				$("#exceeddays_error").text("");
				$("#todate_error").text("");
	    		$("#userId_error").text("Please enter valid userId");
	    		$("#fromdate_error").text("");
	    		return false;
	    		
	    	}else if ($.trim($("#fromdate").val()) == '') {

	    		$("#30days_error").text("");
				$("#exceeddays_error").text("");
				$("#todate_error").text("");
				$("#userId_error").text("");
				$("#fromdate_error").text("Please select fromdate");
				return false;
				
			} else if (Math.round(days) > 90) {

				$("#fromdate_error").text("");
				$("#exceeddays_error").text("");
				$("#todate_error").text("");
				$("#userId_error").text("");
				$("#30days_error").text("Please select dates between 30 days");				
				return false;
				
			}  else if ($.trim($("#todate").val()) == '') {
				
				$("#30days_error").text("");
				$("#exceeddays_error").text("");
				$("#fromdate_error").text("");
				$("#userId_error").text("");
				$("#todate_error").text("Please select todate ");
				return false;
				
			} else if (start > end) {
				
				$("#fromdate_error").text("");
				$("#todate_error").text("");
				$("#30days_error").text("");
				$("#userId_error").text("");
				$("#exceeddays_error").text("please select todate more than fromDate ");
				return false;
				
			} else {
				
				$("#30days_error").text("");
				$("#exceeddays_error").text("");
				$("#fromdate_error").text("");
				$("#userId_error").text("");
				$("#todate_error").text("");
			}
	        $("#networkmessages_form").submit();

	    });
		// end of download 

	    //time for alert error message to be shown
	    setTimeout(function () {
			$(".alert").alert('close');
		}, 4000);
	    
});