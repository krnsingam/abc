$(document).ready(function () {
	var myContextPath = $("#app_context_path").attr('content');
	console.log(myContextPath);
	
	$("#first-search").hide();
	$('#card-alerts').show();
	$("#card-alerts").alert();
    // Numeric only control handler
    jQuery.fn.ForceNumericOnly =
        function () {
            return this.each(function () {
                $(this).keydown(function (e) {
                    var key = e.charCode || e.keyCode || 0;
                    // allow backspace, tab, delete, enter, arrows, numbers and
                    // keypad numbers ONLY
                    // home, end, period, and numpad decimal
                    return (
                        key == 8 ||
                        key == 9 ||
                        key == 13 ||
                        key == 46 ||
                        key == 110 ||
                        key == 190 ||
                        (key >= 35 && key <= 40) ||
                        (key >= 48 && key <= 57) ||
                        (key >= 96 && key <= 105));
                });
            });
        };


    // No special char control handler
    function isValid(str) {
        return !/[~`!@#$%\^&*()+=\[\]\\'.;,/{}|\\":<>\?]/g.test(str);
    }

    // DataTable
    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    var postdata = {};

    // Data Table ajax call and storing the value in table.
    var table = $('#table_id').DataTable({
        "processing": true,
        "serverSide": true,
/*
 * "scrollY": $(document).height() - 400,
 */     "scrollCollapse": true,
        "paging": true,
        "createdRow": function (row, data, index) {
            var info = table.page.info();
            $('td', row).eq(0).html(index + 1 + info.page * info.length);
        },
        "dom": 
        	"<'row'<'col-sm-12 col-md-12'l>>" +
			"<'row'<'col-sm-12'tr>>" +
			"<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
        "ajax": {
            "url": myContextPath+"/acquirer/acquirer-view",
            "contentType": "application/json",
            "type": "POST",
            "timeout":"60000",
            "data": function (d) {

                postdata.dataTable = d;
                postdata.acquirer = $('#acquirer').val();
                postdata.matcode = $('#matCode').val();
                return JSON.stringify(postdata);
            },
            "beforeSend": function (request) {
                request.setRequestHeader(header, token);
            },
            "error": function (xhr, error, code) {

                if (error === 'parsererror' || error === 'timeout') {
                    window.location.href = myContextPath + "/login?invalid";
                }
            }
        },
        "columns": [
        	{ "data": 'srNo' },
            { "data": 'acquirer' },
            { "data": 'matcode' }
           
        ],
        "order": [[0, "asc"]]
    });
    
    // to search the product bin detail
    $("#search").on("click", function () {
    	$(".validationAlert").html(" ");
    	
    	$("#first-search").show();
        $('#table_id').dataTable().fnFilter();

    });

    $(".numeric-only").ForceNumericOnly();

    $(".no-special-char").keypress(function (event) {
        var character = String.fromCharCode(event.keyCode);
        return isValid(character);
    });
    
    setTimeout(function () {
		$(".alert").alert('close');
	}, 2000);
    
    // For dropdown
    $('.select2').select2();
});
