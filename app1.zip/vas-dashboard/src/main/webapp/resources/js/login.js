$(document).ready(function () {

    $("#loggedout").alert();
    window.setTimeout(function () {
        $("#loggedout").alert('close');
    }, 2000);

    $("#expired").alert();
    window.setTimeout(function () {
        $("#expired").alert('close');
    }, 2000);

    $("#invalidated").alert();
    window.setTimeout(function () {
        $("#invalidated").alert('close');
    }, 2000);

    $("#invalid").alert();
    window.setTimeout(function () {
        $("#invalid").alert('close');
    }, 2000);

    $('#password-updated').alert();
    window.setTimeout(function () {
        $("#password-updated").alert('close');
    }, 2000);
    
    $('#user-blocked').alert();
    window.setTimeout(function () {
        $("#user-blocked").alert('close');
    }, 2000);
    
    $('#many-attempts').alert();
    window.setTimeout(function () {
        $("#many-attempts").alert('close');
    }, 2000);

    // jQuery validation starts here
    $(function () {

        // Initializing the form validation on the forgot-password form
        $("form[name='f']").validate({

            // Specifying the validation rules
            rules: {
                username: { // forgot-password has input field with `name` attribute
                    required: true, // It must be required
                    email: true
                },
                password: {
                    required: true, // It must be required
                    minlength: 5,
                    maxlength: 15,
                }
            },

            messages: { // Validation error messages
                username: {
                    required: "Please provide username / email address",
                    email: "Please provide email address"
                },
                password: {
                    required: "Please provide password",
                    minlength: "Minimum length for password is 5",
                    maxlength: "Maximum length for password is 15"
                }
            },

            // This function is called when the form has passed all the validation rules.
            submitHandler: function (form) {
                form.submit(); // Submitting the form, as form is now valid.
                var normalButton = document.getElementById('normal-button');
                var loaderButton = document.getElementById('loader-button');

                normalButton.classList.add("d-none");
                loaderButton.classList.remove("d-none");
            }

        });

    });

    // jQuery validation ends here

});

