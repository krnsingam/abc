$(document)
		.ready(
				function() {

					// No special char control handler
					function isValid(str) {
						return !/[~`!@#$%\^&*()+=\-\[\]\\'.;,/{}|\\":<>\?]/g
								.test(str);
					}

					

					// DataTable
					var token = $('#_csrf').attr('content');
					var header = $('#_csrf_header').attr('content');
					// getting contextPath
					var myContextPath = $("#app_context_path").attr('content');

					// calling datatable request function
					var postdata = {};

				

					// to fetch the enquiry reporting list
					var table = $('#bqr-list-table')
							.DataTable(
									{
										"processing" : true,
										"serverSide" : true,
										"scrollCollapse" : true,
										"paging" : true,
										"createdRow" : function(row, data,
												index) {
											var info = table.page.info();
											$('td', row).eq(0).html(
													index + 1 + info.page
															* info.length);
										},
										"dom" : "<'row'<'col-sm-12 col-md-12'l>>"
												+ "<'row'<'col-sm-12'tr>>"
												+ "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
										"ajax" : {
											"url" : myContextPath
													+ "/merchants/bqr-merchants-list",
											"contentType" : "application/json",
											"type" : "POST",
											"timeout":"60000",
											"data" : function(d) {

												postdata.dtRequest = d;
												postdata.acquirer = $(
														'#acquirer').val();
												postdata.merchantId = $('#merchantId')
														.val();
												postdata.terminalId = $('#terminalId').val();
												
												
														
												return JSON.stringify(postdata);

											},
											"beforeSend" : function(request) {
												request.setRequestHeader(
														header, token);
											},
											"error" : function(xhr, error, code) {

												if (error === 'parsererror' || error === 'timeout' || error === 'error') {
													window.location.href = myContextPath
															+ "/login?invalid";
												}
											}
										},
										"columns" : [

												{
													"data" : 'serialNo'
												},
												{
													"data" : 'acquirer'
												},
												{
													"data" : 'merchantId'
												},
												{
													"data" : 'terminalId'
												},
												{
													"data" : 'ifscAccountNo'
												},
												{
													"data" : 'qrMerchantName'
												},
												{
													"data" : 'status'
												},
												//{"data" : 'id'},
											
												
												 { "data" : "id",
									                "searchable": false,
									                "orderable":false,
									                "render": function (data, type, row) {
									                      console.log($('#is_admin'));
									                      if($('#is_admin').val() !== undefined){
									                    	  return '<button type="button" class="actionClass btn btn-xs btn-primary" title="Edit" data-id="edit"><i class="fa fa-edit" ></i></button>';
									                      }else{
									                    	  $("#role").hide();
									                    	  return "";
									                      }
									                }         
									            }

										],
										"order" : [ [ 0, "desc" ] ]
									});

					// on search reload the form
					$("#search")
							.on(
									"click",
									function(event) {
										$("#merchantId_error").html("");
										$("#terminalId_error").html("");
										$(".validationALert").html("");
										
										// validating merchantId length
										if ($.trim($("#merchantId").val()) != '') {

											if ($("#merchantId").val().length > 100
													|| $("#merchantId").val().length < 1) {
												$("#merchantId_error")
														.html(
																"Please enter valid length(minlength=1 and maxlength=100)");
												return false;
											}}
											
										// validating terminalID length and valid
										// input
										if ($.trim($("#terminalId").val()) != '') {

											if ($("#terminalId").val().length > 30
													|| $("#terminalId").val().length < 8) {
												$("#terminalId_error")
														.html(
																"Please enter valid length(minlength=8 and maxlength=30)");
												return false;
											}

											
										}
										
										$('#bqr-list-table').dataTable()
												.fnFilter();
									});
					
					
					
					 $("#bqr-list-table").on("click", "[data-id='edit']", function () {
					        var data = table.row($(this).parents("tr")).data();
					        console.log(data['id']);
					        $('#id').val(data['id']);
					        $('#edit-form').submit();

					    });
										
					// calling special character function
					$(".no-special-char").keypress(function(event) {
						var character = String.fromCharCode(event.keyCode);
						return isValid(character);
					});

					setTimeout(function() {
						$(".alert").alert('close');
					}, 4000);

					// For issuer dropdown
					$('.select2').select2();
				});