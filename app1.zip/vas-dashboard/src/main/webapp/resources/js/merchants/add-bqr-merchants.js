$(document).ready(function () {
	
	
    
	 // No special char control handler
		function isValid(str) {
			return !/[~`!@#$%\^&*()+=\-\[\]\\'.;,/{}|\\":<>\?]/g
					.test(str);
		}
		

		// calling special character function
		$(".no-special-char").keypress(function(event) {
			var character = String.fromCharCode(event.keyCode);
			return isValid(character);
		});

	$.validator.addMethod("AlphaNumericWithSpaceValidation", function (value, element) {
		return this.optional(element) || /^[a-zA-Z\d]+((\s)*[a-zA-Z\d])*$/.test(value);
	}, 'Special character not allowed!');
	
	$.validator.addMethod("AlphaNumericWithSpacialCharactersValidation", function (value, element) {
		return this.optional(element) || /[a-zA-Z0-9~`!@#$%\^&*()+=\-\[\]\\'.;,/{}|\\":<>\?]/g.test(value);
	}, ' Space not allowed !');
	
	$.validator.addMethod("AlphaNumericWithOutSpaceValidation", function (value, element) {
		return this.optional(element) || /^[a-zA-Z0-9]*$/.test(value);
	}, 'Space not allowed between characters!');



	$("#addBqrMerchants").validate({
		onClick : true,

		errorElement: 'span',
		errorClass: 'help-block error-border',
		
		highlight: function (element, errorClass, validClass) {

			$(element).closest('.form-group').addClass("has-error");
			$(element).closest('.form-control').addClass("error-border");

		},
		unhighlight: function (element, errorClass, validClass) {
			$(element).closest('.form-group').removeClass("has-error");
			$(element).closest('.form-control').removeClass("error-border");

		},
	rules : {
		merchantId : {
			required : true,
			AlphaNumericWithOutSpaceValidation : true,
			maxlength : 100,
			minlength : 1
		},
		terminalId : {
			required : true,
			AlphaNumericWithOutSpaceValidation :true,
			maxlength : 30 ,
			minlength : 8
		},
				
		visaNetworkId1 : {
			required : true,
			AlphaNumericWithOutSpaceValidation :true,
			maxlength : 45,
			minlength : 1
		},
		
		visaNetworkId2 : {
			
			AlphaNumericWithOutSpaceValidation : true,
			maxlength : 45,
			minlength : 1,
			
		},
					
		masterCardNetworkId1 : {
			maxlength : 45,
			required : true,
			AlphaNumericWithOutSpaceValidation :true,
			minlength : 1
			
		},
		
		masterCardNetworkId2 : {
			maxlength : 45,
			AlphaNumericWithOutSpaceValidation : true,
			minlength : 1
		},
		
		npciNetworkId1 : {
			required :true,
			maxlength : 45,
			AlphaNumericWithOutSpaceValidation : true,
			minlength : 1
		},
		
		npciNetworkId2 : {
			maxlength : 45,
			AlphaNumericWithOutSpaceValidation : true,
			minlength : 1
		},
		
		referenceTag09 : {
			maxlength : 45,
			AlphaNumericWithOutSpaceValidation : true,
			minlength : 1
		},
		referenceTag10: {
			maxlength : 45,
			AlphaNumericWithOutSpaceValidation : true,
			minlength : 1
		},
		ifscAccountNo: {
			maxlength : 45,
			AlphaNumericWithOutSpaceValidation : true,
			minlength : 1,
			required : true
		},
		amexNetworkId1: {
			maxlength : 45,
			AlphaNumericWithOutSpaceValidation : true,
			minlength : 1,
			
		},
		amexNetworkId2: {
			maxlength : 45,
			AlphaNumericWithOutSpaceValidation : true,
			minlength : 1,
			
		},
		merchantCategoriesCode: {
			maxlength : 4,
			AlphaNumericWithOutSpaceValidation : true,
			minlength : 2,
			required : true
			
		},
		currencyCode: {
			maxlength : 3,
			AlphaNumericWithOutSpaceValidation : true,
			minlength : 1,
			required : true
			
		},
		countryCode: {
			maxlength : 2,
			AlphaNumericWithOutSpaceValidation : true,
			minlength : 1,
			required : true
			
		},
		qrMerchantName: {
			maxlength : 23,
			AlphaNumericWithSpaceValidation : true,
			minlength : 2,
			required : true
			
		},
		merchantCity: {
			maxlength : 15,
			AlphaNumericWithSpaceValidation : true,
			minlength : 2,
			required : true
			
		},
		postalCode: {
			maxlength : 10,
			AlphaNumericWithOutSpaceValidation : true,
			minlength : 2,
			required : true
			
		},
		acquirer: {	
			AlphaNumericWithSpaceValidation : true,	
			required : true
			
		},
		status: {			
			AlphaNumericWithOutSpaceValidation : true,			
			required : true
			
		},
		
		tipIndicator: {			
			AlphaNumericWithOutSpaceValidation : true,			
			required : true
			
		},
		smsFlag: {	
			AlphaNumericWithOutSpaceValidation : true,	

			required : true
			
		}				
		},

		messages:
		{
			
			
		}
	});

});

$(document).ready(function () {
	  $( "#message" ).fadeOut( 2000 );
	  
	  setTimeout(function() {
			$(".alert").alert('close');
		}, 4000);

		// For issuer dropdown
		$('.select2').select2();
	  
	 
			
		// calling special character function
		$(".no-special-char").keypress(function(event) {
			var character = String.fromCharCode(event.keyCode);
			return isValid(character);
		});
});
