$(document).ready(function () {
	// No special char control handler
	function isValid(str) {
		return !/[~`!@#$%\^&*()+=\-\[\]\\'.;,/{}|\\":<>\?]/g.test(str);
	}

 // Datepicker Implementation
	var date = new Date(),
		yr = date.getFullYear(),
		month = date.getMonth() + 1,
		day = date.getDate(),
		todayDate = day + '-' + month + '-' + yr;

	$("#fromdate").val(todayDate);
	$("#todate").val(todayDate);

	var date_input = $('input[name="date"]'); // our date input has the name
	// "date"
	var container = $('.bootstrap-iso form').length > 0 ? $('.bootstrap-iso form').parent() : "body";
	date_input.datepicker({
		format: 'dd-mm-yyyy',
		container: container,
		todayHighlight: false,
		autoclose: true,
	})

	var maxDate;
	var minDate;
	$("#fromdate").datepicker({
		format: 'dd-mm-yyyy',
		autoclose: true,
	}).click('changeDate', function (selected) {

		// moment js used to convert and date value from toDate
		minDate = moment(todayDate, 'DD-MM-YYYY').subtract(20, 'years').format('DD-MM-YYYY');
		maxDate = todayDate;
		$('#fromdate').datepicker('setStartDate', minDate);
		$('#fromdate').datepicker('setEndDate', maxDate);
	});

	$("#todate").datepicker({
		format: 'dd-mm-yyyy',
		autoclose: true,
	}).click('changeDate', function (selected) {
		var maxDate = todayDate;
		var minDate = $("#fromdate").val();
		$('#todate').datepicker('setStartDate', minDate);
		$('#todate').datepicker('setEndDate', maxDate);
	});
	// End Datepicker Implementation

    // to download MID
    $("#download").on("click", function () {
    	$("#tempMid_error").html("");
    	$("#tempTid_error").html("");
    	$(".validationALert").html("");
		// if todate is null then set one month back date

    	var start = $("#fromdate").datepicker("getDate");
		var end = $("#todate").datepicker("getDate");
		days = (end - start) / (1000 * 60 * 60 * 24);
		if ($.trim($("#fromdate").val()) == '') {
			$("#30days_error").html("");
			$("#exceeddays_error").html("");
			$("#todate_error").html("");
			$("#fromdate_error").html("Please select fromdate");
			return false;
		}
		else if (Math.round(days) > 90) {
			$("#fromdate_error").html("");
			$("#exceeddays_error").html("");
			$("#todate_error").html("");
			$("#30days_error").html("Please select days less or equal to 90 ");
			return false;
		}
		else if ($.trim($("#todate").val()) == '') {
			$("#30days_error").html("");
			$("#exceeddays_error").html("");
			$("#fromdate_error").html("");
			$("#todate_error").html("Please select todate ");
			return false;
		}
		else if
			(start > end) {
			$("#fromdate_error").html("");
			$("#todate_error").html("");
			$("#30days_error").html("");
			$("#exceeddays_error").html("please select todate more than fromDate ");
			return false;
		}
		else {
			$("#30days_error").html("");
			$("#exceeddays_error").html("");
			$("#fromdate_error").html("");
			$("#todate_error").html("");
		}
	
		// validating tempMid length and valid input
		if ($.trim($("#tempMid").val()) != '') {

			if ($("#tempMid").val().length > 32 || $("#tempMid").val().length < 4) {
				$("#tempMid_error").html("Please enter valid input(min size=4,max size=32)");
				return false;
			}
		}		
		// validating tempTid length and valid input
		if ($.trim($("#tempTid").val()) != '') {

			if ($("#tempTid").val().length > 30 || $("#tempTid").val().length < 8) {
				$("#tempTid_error").html("Please enter valid input(min size=8,max size=30)");
				return false;
			}
		}
			
    });
    // end of download page

  //REMOVING ALERT MESSAGE
	setTimeout(function () {
		$(".alert").alert('close');
	}, 4000);
	
	//calling special character function
	$(".no-special-char").keypress(function (event) {
		var character = String.fromCharCode(event.keyCode);
		return isValid(character);
	});

});