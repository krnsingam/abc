$(document)
		.ready(
				function() {

					// No special char control handler
					function isValid(str) {
						return !/[~`!@#$%\^&*()+=\-\[\]\\'.;,/{}|\\":<>\?]/g
								.test(str);
					}

					// to hide the datatable default
					$("#enquiry_table").hide();

					// DataTable
					var token = $('#_csrf').attr('content');
					var header = $('#_csrf_header').attr('content');
					// getting contextPath
					var myContextPath = $("#app_context_path").attr('content');

					// calling datatable request function
					var postdata = {};

					// Datepicker Implementation
					var date = new Date(), yr = date.getFullYear(), month = date
							.getMonth() + 1, day = date.getDate(), todayDate = day
							+ '-' + month + '-' + yr;

					$("#fromdate").val(todayDate);
					$("#todate").val(todayDate);

					var date_input = $('input[name="date"]'); // our date
					// input has the
					// name
					// "date"
					var container = $('.bootstrap-iso form').length > 0 ? $(
							'.bootstrap-iso form').parent() : "body";
					date_input.datepicker({
						format : 'dd-mm-yyyy',
						container : container,
						todayHighlight : false,
						autoclose : true,
					})

					var maxDate;
					var minDate;
					$("#fromdate").datepicker({
						format : 'dd-mm-yyyy',
						autoclose : true,
					}).click(
							'changeDate',
							function(selected) {

								// moment js used to convert and date value from
								// toDate
								minDate = moment(todayDate, 'DD-MM-YYYY')
										.subtract(20, 'years').format(
												'DD-MM-YYYY');
								maxDate = todayDate;
								$('#fromdate').datepicker('setStartDate',
										minDate);
								$('#fromdate')
										.datepicker('setEndDate', maxDate);
							});

					$("#todate").datepicker({
						format : 'dd-mm-yyyy',
						autoclose : true,
					}).click('changeDate', function(selected) {
						var maxDate = todayDate;
						var minDate = $("#fromdate").val();
						$('#todate').datepicker('setStartDate', minDate);
						$('#todate').datepicker('setEndDate', maxDate);
					});
					// End Datepicker Implementation

					// to fetch the enquiry reporting list
					var table = $('#enquiry-table-id')
							.DataTable(
									{
										"processing" : true,
										"serverSide" : true,
										"scrollCollapse" : true,
										"paging" : true,
										"createdRow" : function(row, data,
												index) {
											var info = table.page.info();
											$('td', row).eq(0).html(
													index + 1 + info.page
															* info.length);
										},
										"dom" : "<'row'<'col-sm-12 col-md-12'l>>"
												+ "<'row'<'col-sm-12'tr>>"
												+ "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
										"ajax" : {
											"url" : myContextPath
													+ "/enquiry-reporting/enquiry",
											"contentType" : "application/json",
											"type" : "POST",
											"timeout":"60000",
											"data" : function(d) {

												postdata.dtRequest = d;
												postdata.fromDate = $(
														'#fromdate').val();
												postdata.toDate = $('#todate')
														.val();
												postdata.id = $('#id').val();
												postdata.cardBin = $('#cardBin')
														.val();
												postdata.issuer = $('#issuer')
														.val();
												return JSON.stringify(postdata);

											},
											"beforeSend" : function(request) {
												request.setRequestHeader(
														header, token);
											},
											"error" : function(xhr, error, code) {

												if (error === 'parsererror' || error === 'timeout' || error === 'error') {
													window.location.href = myContextPath
															+ "/login?invalid";
												}
											}
										},
										"columns" : [

												{
													"data" : 'serialNo'
												},
												{
													"data" : 'id'
												},
												{
													"data" : 'issuer'
												},
												{
													"data" : 'merchantRefNo'
												},
												{
													"data" : 'bankRefNo'
												},
												{
													"data" : 'cardBin'
												},
												{
													"data" : 'amount'
												},
												{
													"data" : 'cardTypeId'
												},
												{
													"data" : 'status'
												},
												{
													"data" : 'createdTime'
												},
												{
													"defaultContent" : '<button type="button" title="View" class="btn btn-primary btn-xs mx-auto d-block" data-toggle="modal" data-target="#modal-default" id="view"><i class="fa fa-eye" ></i></button>'
												},

										],
										"order" : [ [ 0, "desc" ] ]
									});

					// on search reload the form
					$("#search")
							.on(
									"click",
									function(event) {
										$("#cardbin_error").html("");
										$("#enid_error").html("");
										$(".validationALert").html("");
										// if todate is null then set one month
										// back date

										var start = $("#fromdate").datepicker(
												"getDate");
										var end = $("#todate").datepicker(
												"getDate");
										days = (end - start)
												/ (1000 * 60 * 60 * 24);
										if ($.trim($("#fromdate").val()) == '') {
											$("#30days_error").html("");
											$("#exceeddays_error").html("");
											$("#todate_error").html("");
											$("#fromdate_error").html(
													"Please select From Date");
											return false;
										} else if (Math.round(days) > 90) {
											$("#fromdate_error").html("");
											$("#exceeddays_error").html("");
											$("#todate_error").html("");
											$("#30days_error")
													.html(
															"Please select days less or equal to 90 ");
											return false;
										} else if ($.trim($("#todate").val()) == '') {
											$("#30days_error").html("");
											$("#exceeddays_error").html("");
											$("#fromdate_error").html("");
											$("#todate_error").html(
													"Please select To Date ");
											return false;
										} else if (start > end) {
											$("#fromdate_error").html("");
											$("#todate_error").html("");
											$("#30days_error").html("");
											$("#exceeddays_error")
													.html(
															"Please select To Date more than From Date ");
											return false;
										} else {
											$("#30days_error").html("");
											$("#exceeddays_error").html("");
											$("#fromdate_error").html("");
											$("#todate_error").html("");
										}

										var numbers = /^[-+]?[0-9]+$/;

										// validating cardBin length
										if ($.trim($("#cardBin").val()) != '') {

											if ($("#cardBin").val().length > 8
													|| $("#cardBin").val().length < 6) {
												$("#cardbin_error")
														.html(
																"Please enter valid length(minlength=6 and maxlength=8)");
												return false;
											}
											// validating cardBin valid input
											if (!$("#cardBin").val().match(
													numbers)) {
												$("#cardbin_error")
														.html(
																"Only numbers are allowed");
												return false;
											}
										}
										// validating enquiryId length and valid
										// input
										if ($.trim($("#id").val()) != '') {

											if ($("#id").val().length > 19
													|| $("#id").val().length < 1) {
												$("#enid_error")
														.html(
																"Please enter valid length(minlength=1 and maxlength=19)");
												return false;
											}

											if (!$("#id").val().match(numbers)) {
												$("#enid_error")
														.html(
																"Only numbers are allowed");
												return false;
											}
										}
										$("#enquiry_table").show();
										$('#enquiry-table-id').dataTable()
												.fnFilter();
									});

					// to view detail of enquiry reporting detail on click view
					$("#enquiry-table-id tbody")
							.on(
									"click",
									"#view",
									function() {
										var data = table.row(
												$(this).parents("tr")).data();
										$
												.ajax({
													url : myContextPath
															+ "/enquiry-reporting/view-detail",
													async : false,
													contentType : "application/json",
													type : "GET",
													data : {
														id : data['id']
													},
													dataType : 'json',
													beforeSend : function(
															request) {
														request
																.setRequestHeader(
																		header,
																		token);
													},

													success : function(result) {
														$('#es')
																.html(
																		"Eligibility status")
																.show();
														$('#et')
																.html(
																		"Eligibility time")
																.show();
														$('#er')
																.html(
																		"Eligibility response code")
																.show();
														$('#oc')
																.html(
																		"Order confirmation status")
																.show();
														$('#oct')
																.html(
																		"Order confirmation time")
																.show();
														$('#mrn')
																.html(
																		"Merchant reference no")
																.show();

														$('#id1').html(
																result.id);
														$('#cardBin1').html(
																result.cardBin);
														$('#issuer1').html(
																result.issuer);
														$('#status').html(
																result.status);
														$('#amount').html(
																result.amount);
														$('#cardType')
																.html(
																		result.cardTypeId);
														$('#estatus')
																.html(
																		result.eligibilityStatus)
																.show();
														$('#etime')
																.html(
																		result.checkEligibilityTime)
																.show();
														$('#erescode')
																.html(
																		result.orderConfirmationRespondCode)
																.show();
														$('#ordcnfsts')
																.html(
																		result.orderConfirmationStatus)
																.show();
														$('#ordcnftime')
																.html(
																		result.createdTime)
																.show();
														$('#merrefno')
																.html(
																		result.merchantRefNo)
																.show();
														$("#modal-default")
																.show();
														if (result.cardTypeId == "Credit") {
															console
																	.log(result.cardTypeId);
															$('#estatus')
																	.html(
																			result.eligibilityStatus)
																	.hide();
															$('#etime')
																	.html(
																			result.checkEligibilityTime)
																	.hide();
															$('#erescode')
																	.html(
																			result.orderConfirmationRespondCode)
																	.hide();
															$('#ordcnfsts')
																	.html(
																			result.orderConfirmationStatus)
																	.hide();
															$('#ordcnftime')
																	.html(
																			result.createdTime)
																	.hide();
															$('#merrefno')
																	.html(
																			result.merchantRefNo)
																	.hide();
															$('#es').html("")
																	.hide();
															$('#et').html("")
																	.hide();
															$('#er').html("")
																	.hide();
															$('#oc').html("")
																	.hide();
															$('#oct').html("")
																	.hide();
															$('#mrn').html("")
																	.hide();
															$("#modal-default")
																	.show();
														}
													}
												});
									});
					// end of view detail

					// to download the enquiry-repoting detail
					$("#download")
							.on(
									"click",
									function() {
										$("#cardbin_error").html("");
										$("#enid_error").html("");
										// datepicker validation for one month
										var start = $("#fromdate").datepicker(
												"getDate");
										var end = $("#todate").datepicker(
												"getDate");
										days = (end - start)
												/ (1000 * 60 * 60 * 24);
										if ($.trim($("#fromdate").val()) == '') {
											$("#30days_error").html("");
											$("#exceeddays_error").html("");
											$("#todate_error").html("");
											$("#fromdate_error").html(
													"Please select From Date");
											return false;
										} else if (Math.round(days) > 90) {
											$("#fromdate_error").html("");
											$("#exceeddays_error").html("");
											$("#todate_error").html("");
											$("#30days_error")
													.html(
															"Please select days less or equal to 90 ");
											return false;
										} else if ($.trim($("#todate").val()) == '') {
											$("#30days_error").html("");
											$("#exceeddays_error").html("");
											$("#fromdate_error").html("");
											$("#todate_error").html(
													"Please select To Date ");
											return false;
										} else if (start > end) {
											$("#fromdate_error").html("");
											$("#todate_error").html("");
											$("#30days_error").html("");
											$("#exceeddays_error")
													.html(
															"Please select To Date more than From Date ");
											return false;
										} else {
											$("#30days_error").html("");
											$("#exceeddays_error").html("");
											$("#fromdate_error").html("");
											$("#todate_error").html("");

										}

										var numbers = /^[-+]?[0-9]+$/;

										// validating cardBin length
										if ($.trim($("#cardBin").val()) != '') {

											if ($("#cardBin").val().length > 8
													|| $("#cardBin").val().length < 6) {
												$("#cardbin_error")
														.html(
																"Please enter valid length(minlength=6 and maxlength=8)");
												return false;
											}
											// validating cardBin valid input
											if (!$("#cardBin").val().match(
													numbers)) {
												$("#cardbin_error")
														.html(
																"Only numbers are allowed");
												return false;
											}
										}
										// validating enquiryId length and valid
										// input
										if ($.trim($("#id").val()) != '') {

											if ($("#id").val().length > 19
													|| $("#id").val().length < 1) {
												$("#enid_error")
														.html(
																"Please enter valid length(minlength=1 and maxlength=19)");
												return false;
											}

											if (!$("#id").val().match(numbers)) {
												$("#enid_error")
														.html(
																"Only numbers are allowed");
												return false;
											}
										}
										$("#enquiry-form").submit();

									});

					// end of download page

					// calling special character function
					$(".no-special-char").keypress(function(event) {
						var character = String.fromCharCode(event.keyCode);
						return isValid(character);
					});

					setTimeout(function() {
						$(".alert").alert('close');
					}, 4000);

					// For issuer dropdown
					$('.select2').select2();

				});

