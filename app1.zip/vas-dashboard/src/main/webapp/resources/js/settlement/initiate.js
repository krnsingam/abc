$(document).ready(function(){
	$('#card-alerts').hide();
	$("#card-alerts2").hide();
	$("#card-alerts").alert();
	
	$("#initiate").click(function(){
		startSettlement();
	});

});

function startSettlement(){
	 
	 var result = true;
	 
	 $(".validationAlert").text("");
	
	 if($.trim($("#time").val()) == ""){
		 $("#time_alert").text("Please select time.");
		 result = false;
	 }
	 
	 if($.trim($("#comments").val()) == ""){
		 $("#comments_alert").text("Please enter 5 char in comment box.");
		 result = false;
	 }
	 
	 if($.trim($("#comments").val()) != ""){
		 if($.trim($("#comments").val()).length < 5){
			 $("#comments_alert").text("Please enter 5 char in comment box.");
			 result = false;
		 }
	 }
	 
	 if(result){
		 
		 var iniateSettlementData = {
				 time :$("#time").val(),
				 reason : $("#comments").val() 
		 };
		 
		 $.ajax({
	     	url: contexturi+"/settlement/initiate-settlement",
	     	headers: {
     		    'X-CSRF-TOKEN':$('#_csrf').val(),
         	},
	     	type: "POST",
	     	dataType: "json",
	     	data:JSON.stringify(iniateSettlementData),
	     	contentType: 'application/json',
	     	success: function(result){

	     		$('#card-alerts').show();
	     		window.setTimeout(function () {
	     			$("#card-alerts").hide();
	     		}, 2000);
	         },
	         error:function(xhr, error, code) {

		         if(xhr.status == 400){
		        	 if(typeof xhr.responseJSON.errors != "undefined"){
		     		      $("#card-msg").text(xhr.responseJSON.errors[0].defaultMessage);
		        	 }else{
		        		  $("#card-msg").text("Unable to process yur request please try after some time.");
		        	 }
		     	 }
		         		     		
	             if (error === 'parsererror') {
	                 window.location.href = contexturi+"/login?invalid";
	             } 
	             
	     		 $('#card-alerts2').show();
	     		 window.setTimeout(function () {
	     			$("#card-alerts2").hide();
	     		 }, 2000);
	             
	         }
	      });
	 }
}