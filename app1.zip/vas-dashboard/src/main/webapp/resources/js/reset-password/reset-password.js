$(document).ready(function () {
	
	
	setTimeout(function() {
		$(".alert").alert('close');
	}, 4000);

    // jQuery validation starts here
    $(function () {

        // Initializing the form validation on the forgot-password form
        $("form[name='f']").validate({

            // Specifying the validation rules
            rules: {
                newPassword: { // forgot-password has input field with `name` attribute
                    required: true, // It must be required
                    minlength: 8,  
                    maxlength: 15
                }, 
                confirmNewPassword: {
                    required: true, // It must be required
                    minlength: 8, 
                    maxlength: 15,
                    equalTo: '#newPassword'
                }
            },

            messages: { // Validation error messages
                newPassword: {
                    required: "Please provide new password", 
                    minlength: "Minimum length for new password is 8",
                    maxlength: "Maximum length for new password is 15"
                }, 
                confirmNewPassword: {
                    required: "Please provide confirm new password",
                    minlength: "Minimum length for confirm new password is 8",
                    maxlength: "Maximum length for confirm new password is 15",
                    equalTo: "Please enter the same password again"
                }
            },

            // This function is called when the form has passed all the validation rules.
            submitHandler: function (form) {
                form.submit(); // Submitting the form, as form is now valid.
                var normalButton = document.getElementById('normal-button');
                var loaderButton = document.getElementById('loader-button');

                normalButton.classList.add("d-none");
                loaderButton.classList.remove("d-none");
            }

        });

    });

    // jQuery validation ends here

});
