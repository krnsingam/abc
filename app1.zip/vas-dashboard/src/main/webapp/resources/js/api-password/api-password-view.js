
$(document).ready(function () {

    $("#first-search").hide();

    // No special char control handler
    function isValid(str) {
        return !/[~`!#$%\^&*()+=\[\]\\';,/{}|\\":<>\?]/g.test(str);
    }

    // DataTable
    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    // getting contextPath
	var myContextPath=$("#app_context_path").attr('content') ;
    var postdata = {};

    // Data Table ajax call and storing the value in table.
    var table = $('#table_id').DataTable({
        "processing": true,
        "serverSide": true,
/*
 * "scrollY": $(document).height() - 400,
 */     "scrollCollapse": true,
        "paging": true,
        "createdRow": function (row, data, index) {
            var info = table.page.info();
            $('td', row).eq(0).html(index + 1 + info.page * info.length);
        },
        "dom":
            "<'row'<'col-sm-12 col-md-12'l>>" +
            "<'row'<'col-sm-12'tr>>" +
            "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
        "ajax": {
            "url": myContextPath + "/api-password/view",
            "contentType": "application/json",
            "type": "POST",
            "data": function (d) {

                postdata.dataTable = d;
                postdata.businessName = $('#businessname').val();
                postdata.merchantCode = $('#merchantCode').val();
                postdata.apiPassword = $('#apiPassword').val();
                return JSON.stringify(postdata);
            },
            "beforeSend": function (request) {
                request.setRequestHeader(header, token);
            },
            "error": function (xhr, error, code) {

				if (error === 'parsererror') {
					window.location.href = myContextPath + "/login?invalid";
				}
			}
        },
        "columns": [
        	{ "data": 'srNumber' },
            { "data": 'businessName' },
            { "data": 'merchantCode' },
            { "data": 'apiPassword' },
            { "defaultContent": '<button type="button" title="View" class="btn btn-primary btn-xs mx-auto d-block" data-toggle="modal" data-target="#modal-default" id="edit"><i class="fa fa-edit"></i></button>' }
        ],
        "order": [[0, "desc"]]
    });
  
    // REMOVING ALERT AFTER DELAY OF 4 SECONDS.
 	setTimeout(function () {
 		$(".alert").alert('close');
 	}, 4000);  

    // to search the product bin detail
    $("#search").on("click", function () {
        $(".validationAlert").html(" ");

        if ($.trim($("#binval").val()) != '') {
            if ($("#binval").val().length > 8 || $("#binval").val().length < 6) {
                $("#binval_error").html("Please enter valid length(min length=6 and max length=8)");
                return false;
            }
            if (!$("#binval").val().match(numbers)) {
                $("#binval_error").html("Only Numbers are allowed");
                return false;
            }
        }

        $("#first-search").show();
        $('#table_id').dataTable().fnFilter();

    });

    // to view transaction detail
    $("#table_id tbody").on("click", "#edit", function () {
    	 var data = table.row($(this).parents("tr")).data();
         console.log(data['id']);
         $('#id').val(data['id']);
         $('#editApi').submit();
    });

    $(".no-special-char").keypress(function (event) {
        var character = String.fromCharCode(event.keyCode);
        return isValid(character);
    });
      
    // For dropdown
    $('.select2').select2();
});