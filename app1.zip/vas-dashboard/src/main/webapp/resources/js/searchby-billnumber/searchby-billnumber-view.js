$(document).ready(function(){
	
	/////////Start DataTable implementation////////
	
    //hide data-table while page is rendering for the first time 	
	$("#table_body").hide();
	
	 var token = $('#_csrf').attr('content');
	 var header = $('#_csrf_header').attr('content');
	 
	 // getting contextPath
	 var myContextPath=$("#app_context_path").attr('content') ;
	
	 //data to be post on search
	 var postdata = {};
	 
	 // Data Table ajax call and storing the value in table
	    var table = $('#billnumber_transaction_table').DataTable({
	        "processing": true,
	        "serverSide": true,
	        "scrollCollapse": true,
	        "paging": true,
	        "dom":
	            "<'row'<'col-sm-12 col-md-12'l>>" +
	            "<'row'<'col-sm-12'tr>>" +
	            "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
	        "ajax": {
	            "url": myContextPath + "/searchbybillnumber/billnumber-transaction-list",
	            "contentType": "application/json",
	            "type": "POST",
	            "timeout":"60000",
	            "data": function (d) {

	                postdata.dtRequest = d;
	                postdata.billNumber = $("#billnumber").val();
	                return JSON.stringify(postdata);
	            },
	            "beforeSend": function (request) {
	                request.setRequestHeader(header, token);
	            },
	            "error": function (xhr, error, code) {

					if (error === 'parsererror') {
						window.location.href = myContextPath + "/login?invalid";
					}
				}
	        },
	        "columns": [

	            { "data": 'userName' },
	            { "data": 'txnType' },
	            { "data": 'terminalId' },
	            { "data": 'cardNumber' },
	            { "data": 'rrn' },
	            { "data": 'amount' },
	            { "data": 'txnTime' }, 
	            { "data": 'responseCode' },
	            { "data": 'authCode' },
	            { "data": 'status' },
	            {
	            	"data": "settlementStatus",
	            	"render": function (data, type, row, meta) {
	            		
	            		if (data != "" || data != null) {
	            		    if(row.settlementStatus == 2){
	            		    	data = "Settled";
	            		    }else{	
	            			    data ="Unsettled";
	            		    }
	            		}
	            		return data;
	            	}
	            },
	            {
	            	"data": "transactionId",
	            	"render": function (data, type, row, meta) {
	            		return '<button type="button" class="btn btn-xs btn-primary showTransactionReceipt" data-transactionid="'+row.transactionId+'" title="View"><i class="fa fa-eye " ></i></button>';
	            	}
	            },	        ],
	        "order": [[0, "asc"]]
	    });
	
	    //on search , showing the data in table
	    $("#search").on("click",function (event) {
	  
	    	event.preventDefault();
	    	$("#billnumber_error").text(" ");
	    	var alphanumericRegex = /^[a-zA-Z0-9]+$/;
	    	
	    	var billNumber = $("#billnumber").val();
	    

	    	if ($.trim($("#billnumber").val()) == '') {
				$("#billnumber_error").text("Please enter bill number");
				return false;	
			}
	    	
	    	if($.trim($("#billnumber").val()) != ""){
	    		if(!alphanumericRegex.test($("#billnumber").val())){
	    			$("#billnumber_error").text("Please enter valid bill number");
	    			return false;
	    		}
	    	}
	    	
	    	$("#table_body").show();
			$('#billnumber_transaction_table').dataTable().fnFilter();
	    });
	
	    /////////End DataTable implementation////////
	
	/////showing transaction receipt
	    $(document).on('click','.showTransactionReceipt',function(){	
	    	
	      	 var txnId = $(this).data('transactionid');
	      	 
	      	 $.ajax({
	   	     	url: myContextPath+"/transaction/get-transaction-data-id",
	   	     	headers: {
	   	     		    'X-CSRF-TOKEN':$('#_csrf').attr('content'),
	   	     	},
	   	     	type: "POST",
	   	     	data:{ tranId : txnId  },
	   	     	success: function(result){

	                   $("#receipt-data").html(result);
	                   $("#exampleModal").modal('show');
	   	         },
	   	         error:function(xhr, error, code) {
	   	
	   	             if (error === 'parsererror') {
	   	                 window.location.href = +contexturi+"/login?invalid";
	   	             }
	   	             
	   	         }
	   	      });
	      	 
	      });
	    
	});
	