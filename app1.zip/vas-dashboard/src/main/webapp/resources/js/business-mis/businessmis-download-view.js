$(document).ready(function(){
	
	// Datepicker Implementation
	var date = new Date(),
	yr = date.getFullYear(),
	month = date.getMonth() + 1,
	day = date.getDate(),
	todayDate = day + '-' + month + '-' + yr;
	
	$("#fromdate").val(todayDate);
	$("#todate").val(todayDate);
	
	var maxDate;
	var minDate;
	
	//activation request date
	$("#fromdate").datepicker({
		format: 'dd-mm-yyyy',
		autoclose: true,
	}).click('changeDate',function (selected){
		minDate = moment(todayDate, 'DD-MM-YYYY').subtract(20, 'years').format('DD-MM-YYYY');
		maxDate = todayDate;
		$('#fromdate').datepicker('setStartDate',minDate);
		$('#fromdate').datepicker('setEndDate', maxDate);
	});
	
	//to date
	$("#todate").datepicker({
		format: 'dd-mm-yyyy',
		autoclose: true,
	}).click('changeDate',function (selected){
		var maxDate = todayDate;
		var minDate = $("#fromdate").val();
		$('#todate').datepicker('setStartDate', minDate);
		$('#todate').datepicker('setEndDate', maxDate);
	});
	// End Datepicker Implementation
	
	$("#downloadBuinessMIS").click(function(e){
		e.preventDefault();
		if(validateBuinessMISDownloadForm()){
			$("#downloadCurrentBusinessMIS").submit();
		}
	});
		
		function validateBuinessMISDownloadForm(){
	 
			var response = true;

	    	$(".validationAlert").text("");
	    	
	    	var start = $("#fromdate").datepicker("getDate");
	    	var end = $("#todate").datepicker("getDate");
	    	
	    	days = (end - start) / (1000 * 60 * 60 * 24);

	    	if ($('select[name="acquirer"]').val() == "") {
				$("#acquirer_error").text("Please select Acquirer");
				response = false;	
			} 
	    	
	    	if ($.trim($("#fromdate").val()) == '') {

				$("#fromdate_error").text("Please select from date");
				response = false;
				
			}else if (Math.round(days) > 90) {

				$("#30days_error").text("Please select dates between 30 days");				
				response = false;
				
			}
	    	
	    	if ($.trim($("#todate").val()) == '') {
				
				$("#todate_error").text("Please select to date");
				response = false;
				
			}else if (start > end) {
				
				$("#exceeddays_error").text("please select todate more than fromDate ");
				response = false;
				
			}
	    	return  response;
	    };	    
	    
	   /* // to download the networkmessages excel data
	    $("#download").on("click", function () {
	    
	    	var alphanumericRegex = /^[a-zA-Z0-9]+$/;

	    	var start = $("#fromdate").datepicker("getDate");
	    	var end = $("#todate").datepicker("getDate");
	    	
	    	days = (end - start) / (1000 * 60 * 60 * 24);

	    	$("#userId_error").text("");
	    	
	    	if ($.trim($("#userId").val()) == "") {

	    		$("#30days_error").text("");
				$("#exceeddays_error").text("");
				$("#todate_error").text("");
				$("#userId_error").text("Please enter UserId");
				$("#fromdate_error").text("");
				return false;
				
			}else if(!alphanumericRegex.test($("#userId").val())){
				
				$("#30days_error").text("");
				$("#exceeddays_error").text("");
				$("#todate_error").text("");
	    		$("#userId_error").text("Please enter valid userId");
	    		$("#fromdate_error").text("");
	    		return false;
	    		
	    	}else if ($.trim($("#fromdate").val()) == '') {

	    		$("#30days_error").text("");
				$("#exceeddays_error").text("");
				$("#todate_error").text("");
				$("#userId_error").text("");
				$("#fromdate_error").text("Please select fromdate");
				return false;
				
			} else if (Math.round(days) > 90) {

				$("#fromdate_error").text("");
				$("#exceeddays_error").text("");
				$("#todate_error").text("");
				$("#userId_error").text("");
				$("#30days_error").text("Please select dates between 30 days");				
				return false;
				
			}  else if ($.trim($("#todate").val()) == '') {
				
				$("#30days_error").text("");
				$("#exceeddays_error").text("");
				$("#fromdate_error").text("");
				$("#userId_error").text("");
				$("#todate_error").text("Please select todate ");
				return false;
				
			} else if (start > end) {
				
				$("#fromdate_error").text("");
				$("#todate_error").text("");
				$("#30days_error").text("");
				$("#userId_error").text("");
				$("#exceeddays_error").text("please select todate more than fromDate ");
				return false;
				
			} else {
				
				$("#30days_error").text("");
				$("#exceeddays_error").text("");
				$("#fromdate_error").text("");
				$("#userId_error").text("");
				$("#todate_error").text("");
			}
	        $("#networkmessages_form").submit();

	    });
		// end of download 
*/
	    //time for alert error message to be shown
	    setTimeout(function () {
			$(".alert").alert('close');
		}, 4000);
	    
	 // For acquirer dropdown
		$('.select2').select2();
});