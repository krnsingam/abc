$(document).ready(function(){
	
	// Datepicker Implementation
	var date = new Date(),
	yr = date.getFullYear(),
	month = date.getMonth() + 1,
	day = date.getDate(),
	todayDate = day + '-' + month + '-' + yr;
	
	$("#activationrequestdate").val(todayDate);
	$("#activationconfirmationdate").val(todayDate);
	
	var maxDate;
	var minDate;
	
	//activation request date
	$("#activationrequestdate").datepicker({
		format: 'dd-mm-yyyy',
		autoclose: true,
	}).click('changeDate',function (selected){
		minDate = moment(todayDate, 'DD-MM-YYYY').subtract(20, 'years').format('DD-MM-YYYY');
		maxDate = todayDate;
		$('#activationrequestdate').datepicker('setStartDate',minDate);
		$('#activationrequestdate').datepicker('setEndDate', maxDate);
	});
	
	//to date
	$("#activationconfirmationdate").datepicker({
		format: 'dd-mm-yyyy',
		autoclose: true,
	}).click('changeDate',function (selected){
		var maxDate = todayDate;
		var minDate = $("#activationrequestdate").val();
		$('#activationconfirmationdate').datepicker('setStartDate', minDate);
		$('#activationconfirmationdate').datepicker('setEndDate', maxDate);
	});
	// End Datepicker Implementation
	
	$("#updateBuinessMIS").click(function(e){
		e.preventDefault();
		if(validateBuinessMISForm()){
			$("#updateBuinessMIS").attr("disabled",true);
			$("#updateCurrentBusinessMIS").submit();
		}
	});
		
		function validateBuinessMISForm(){
	 
			var response = true;
	    	var alphanumericRegex = /^[a-zA-Z0-9]+$/;

	    	$(".validationAlert").text("");
	    	
	    	var start = $("#activationrequestdate").datepicker("getDate");
	    	var end = $("#activationconfirmationdate").datepicker("getDate");
	    	
	    	days = (end - start) / (1000 * 60 * 60 * 24);
	
	    	if ($.trim($("#userNumber").val()) == "") {

				$("#userNumber_error").text("Please enter User Number");
				response = false;
				
			}else if(!alphanumericRegex.test($("#userNumber").val())){
				
	    		$("#userNumber_error").text("Please enter valid User Number");
	    		response = false;
	    		
	    	}else if ($.trim($("#activationrequestdate").val()) == '') {

				$("#activationrequestdate_error").text("Please select activation request date");
				response = false;
				
			} else if (Math.round(days) > 90) {

				$("#30days_error").text("Please select dates between 30 days");				
				response = false;
				
			}  else if ($.trim($("#activationconfirmationdate").val()) == '') {
				
				$("#activationconfirmationdate_error").text("Please select activation confirmation date");
				response = false;
				
			} else if (start > end) {
				
				$("#exceeddays_error").text("please select todate more than fromDate ");
				response = false;
				
			}
	    	return  response;
	    };	    
	    
	  	//time for alert error message to be shown
	    setTimeout(function () {
			$(".alert").alert('close');
		}, 4000);
	    
});