$(document).ready(function () {
	
	$('#card-alerts').show();
	$("#card-alerts").alert();
    
	setTimeout(function () {
		$(".alert").alert('close');
	}, 2000);
	
	
    // DataTable
    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    var postdata = {};
    
    // Data Table ajax call and storing the value in table.
    var table = $('#acquirer-table-id').DataTable({
        "processing": true,
        "serverSide": true,
        "scrollCollapse": true,
        "paging": true,
        "createdRow": function (row, data, index) {
            var info = table.page.info();
            $('td', row).eq(0).html(index + 1 + info.page * info.length);
        },
        "dom": 
        	"<'row'<'col-sm-12 col-md-12'l>>" +
			"<'row'<'col-sm-12'tr>>" +
			"<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
        
        "ajax": {
            "url": "/dashboard/adminacquirer/list-acquirer",
            "contentType": "application/json",
            "type": "POST",
            "data": function (d) {

                return JSON.stringify(d);
            },
            "beforeSend": function (request) {
                request.setRequestHeader(header, token);
            },
            "error": function (xhr, error, code) {

                if (error === 'parsererror' || error === 'timeout' || error === 'error') {
                    window.location.href = myContextPath + "/login?invalid";
                }
            }
        },
        "columns": [
        	{ "data": 'srNo' , width: '20px'},
        	{ "data": 'name' , width: '100px'},
            { "data": function (data, type, dataToSet) 
        		{
                	return "ZMK: " + data.zmk + "<br/> <br/> ZPK: " + data.zpk + "<br/> <br/> ZEK: " + data.zek;
        		} , width: '350px' 
        	},
            
            { "data": 'tipPercent' },
            { "data": 'currencyCode' },
            { "data": 'decimalAmountLength' , width: '30px' },
            { "data": 'serverTimeInMin' , width: '30px' },
            { "data": 'mobileNoLength' , width: '30px' },
            { "defaultContent": '<button type="button" title="Edit" class="btn btn-primary btn-xs mx-auto d-block" data-toggle="modal" data-target="#modal-default" id="update"><i class="fa fa-edit"></i></button>' }
        ],
        "order": [[0, "asc"]]
    });
    
   
    // to EDIT or UPDATE SBI Details
    $("#acquirer-table-id tbody").on("click", "#update", function () {
    	var data = table.row($(this).parents("tr")).data();
        console.log(data['acqId']);
        var acqId = data['acqId'];
        $form = $("<form action='/dashboard/adminacquirer/list-acquirer-edit' method='post'></form>");
        $form.append("<input type='hidden' name='_csrf' value='" + $("#_csrf").attr('content') + "'>");
        $form.append("<input type='hidden' name = 'acqId' value='" + acqId + "'>");
        $('body').append($form);
       	$form.submit();
    
    });
    
});
