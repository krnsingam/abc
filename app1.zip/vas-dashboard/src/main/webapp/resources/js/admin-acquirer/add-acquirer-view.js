$(document).ready(function() {
	
	jQuery.validator.addMethod("numberValidation", function (value, element) {
	    return this.optional(element) || /^[0-9]*$/.test(value);
	}, 'Please Enter Only Numeric Value!');
	
	
	jQuery.validator.addMethod("AlphaNumeric", function (value, element) {
	    return this.optional(element) || /^[ A-Za-z0-9]*$/.test(value);
	}, 'Special Character Not Allowed!');
	
	jQuery.validator.addMethod("AllLetter", function (value, element) {
	    return this.optional(element) || /^[ A-Z a-z]*$/.test(value);
	}, 'Please Enter Only Alphabets !');
	
	jQuery.validator.addMethod("vpaValidation", function (value, element) {
	    return this.optional(element) || /^[ A-Za-z0-9_.@]*$/.test(value);
	}, 'Invalid character found!');
	
	jQuery.validator.addMethod("decimalValidation", function (value, element) {
		console.log(value)
		if(value == ''){
			return true;
		}
		if(value > 0 && value <= 100.00){
			return this.optional(element) || /^[0-9]+(\.[0-9]{1,2})?$/.test(value);	
		}
	},'Number(1 to 100) with 2 decimal places\!');
	
	jQuery("#addAcquirerDetails").validate({
	onClick:false,
	rules : {
		name : {
			required : true,
			maxlength:50,
			AllLetter :true,
		},
		zmk : {
			required : true,
			maxlength:50,
			AlphaNumeric :true,
		},
		zpk : {
			required : true,
			maxlength:50,
			AlphaNumeric :true,
		},
		zek : {
			required : true,
			maxlength:50,
			AlphaNumeric :true,
		},
		tipPercent : {
			required : true,
			maxlength:5,
			decimalValidation :true,
		},
		decimalAmountLength : {
			
			maxlength:2,
			numberValidation :true,
		},
		serverTimeInMin : {
			
			maxlength:3,
			numberValidation :true,
		},
		mobileNoLength : {
			
			maxlength:2,
			numberValidation :true,
		}
	},
	errorPlacement: function(error, element) {		         
          error.insertAfter(element);	         
    }

	});
});