$(document).ready(function(){
    
	$(document).on('click', '#searchBusinessName li' ,function() {
	   	    	
	   	 $("#merchantName").val(this.outerText);
	   	 $("#container2").hide();
	
	});
	$("#searchBusinessName").hide();
    
    $("#search").click(function(e){
    	e.preventDefault();
   
    	$(".validationAlert").text("");
    	if($('input[name="txnType"]:checked').val() === undefined){
    		$("#search_alert").text("Please select transaction type");
	    	return false;
    	}
    	
	    if (Date.parse($("#transactionDateFrom").val()) > Date.parse($("#transactionDateTo").val())) {
	    	$("#transactionDateFrom_alert").text("Invalid Date Range! From Date cannot be after To Date!");
            return false;
	    }
     	
	    setDate();
     
    });
    
    
    $(document).on('keyup','#merchantName',function(){	
    	$("#searchBusinessName").html("");	
     	 $.ajax({
  	     	url: contexturi+"/transaction/get-merchant",
  	     	headers: {
  	     		    'X-CSRF-TOKEN':$('#_csrf').attr('content'),
  	     	},
  	     	type: "POST",
  	     	data:{ name : $(this).val()  },
  	     	success: function(result){
   	     		var searchBusinessNameHtml ="";
   	     	if(result.length){
	 	        result.forEach(function(item){
	 	        	searchBusinessNameHtml +="<li class='liststyletype'>"+item+"</li>";
	   	     	});
	 	       $("#searchBusinessName").html(searchBusinessNameHtml).show();
   	         }else{
	     		 $("#searchBusinessName").hide();
	     		}
   	     		 	        
  	         },
  	         error:function(xhr, error, code) {
  	
  	             if (error === 'parsererror' || error === 'timeout') {
  	                 window.location.href = +contexturi+"/login?invalid";
  	             }
  	             
  	         }
  	      });
     	 
     });
	
    $(document).on('click','.showTransactionList',function(){	
    	
   	 var txnId = $(this).data('transactionid');
   	 
   	 $.ajax({
	     	url: contexturi+"/transaction/get-transaction-data-id",
	     	headers: {
	     		    'X-CSRF-TOKEN':$('#_csrf').attr('content'),
	     	},
	     	type: "POST",
	     	data:{ tranId : txnId  },
	     	success: function(result){

                $("#receipt-data").html(result);
                $("#exampleModal").modal('show');
	         },
	         error:function(xhr, error, code) {
	
	             if (error === 'parsererror') {
	                 window.location.href = +contexturi+"/login?invalid";
	             }
	             
	         }
	      });
   	 
   });
	
	$("#transactionDateFrom").datepicker({
		format: 'dd-mm-yyyy',
		autoclose: true,
		endDate:'+d'
	});
	
	$("#transactionDateTo").datepicker({
		format: 'dd-mm-yyyy',
		autoclose: true,
		endDate:'+d'
	});
    
    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    	
	 var table = $('#table_id').DataTable({
	        "processing": true,
	        "serverSide": true,
	        //"scrollY": $(document).height() - 400,
	        "scrollCollapse": true,
	        "paging": true,
	        "dom": "Brtip",
		    "buttons": [
                   'excel'
		            
		    ],
	        "ajax": {
	            "headers": {

	            },
	            "url": contexturi + "/transaction/get-transaction-list-data",
	            "contentType": "application/json",
	            "type": "POST",
	            "timeout":"60000",
	            "data": function (d) {
	         
	            	
	            	var postdata ={};
	            	postdata.dtRequest = d;
	            	postdata.userId = $("#userId").val();
					postdata.merchantName = $("#merchantName").val();
					postdata.transactionId = $("#transactionId").val();
					postdata.rrn = $('#rrn').val();
					postdata.authCode = $("#authCode").val();
					postdata.maskedCardNumber = $("#maskedCardNumber").val();
					postdata.cardHolderName = $("#cardHolderName").val();
					postdata.acquirer = $("#acquirer").val();
					postdata.mid = $("#mid").val();
					postdata.tid = $("#tid").val();
					postdata.txnType = $('input[name="txnType"]:checked').val();
					postdata.transactionDateFrom = $("#transactionDateFrom").val();
					postdata.transactionDateTo = $("#transactionDateTo").val();
	                return JSON.stringify(postdata);
	            },
	            "beforeSend": function (request) {
	            	$("#search").attr('disabled',true);
	                request.setRequestHeader(header, token);
	            },
	            "complete": function( settings, json ) {
	            	$("#search").attr('disabled',false);

	            },
	            "error": function (xhr, error, code) {

	                if (error === 'parsererror' || error === 'timeout') {
	                    window.location.href = contexturi + "/login?invalid";
	                }
	            }
	        },
	        "columns": [
	        	{ "data": "transactionId"},
	        	{ "data": "type"},
	        	{ "data": "terminalId"},
	            { "data": 'userName' },
	            { "data": 'cardNumber' },
	            { "data": 'rrn' },
	            { "data": 'amt' },
	            {
	            	"data": "txnDate",
	            	"render": function (data, type, row, meta) {
                         var newDate  = data.split(" ");
                         if(newDate[0] !== undefined){
                             return newDate[0];
                         }else{
                        	 return "";
                         }
	            	}
	            },
	            {
	            	"data": "txnDate",
	            	"render": function (data, type, row, meta) {
                         var newDate  = data.split(" ");
                         if(newDate[1] !== undefined){
                             return newDate[1];
                         }else{
                        	 return "";
                         }
	            	}
	            },
	            { "data": 'responseCode' },
	            { "data": 'authCode' },
	            { "data": 'status' },
	            {
	            	"data": "settleStatus",
	            	"render": function (data, type, row, meta) {
	            		   if(data == 1){
	            			   return 'Un-Settled';
	            		   }else{
	            			   return 'Settled';
	            		   }
	            	}
	            },
	            {
	            	"data": "transactionId",
	            	"render": function (data, type, row, meta) {
	            		return '<button type="button" class="btn btn-xs btn-primary showTransactionList" data-transactionid="'+row.transactionId+'" title="Edit"  ><i class="fa fa-eye " ></i></button>';
	            	}
	            },
	        ],

	    });

	    // Apply the search
	    table.columns().every(function () {
	        var columns = this;

	        $('input', this.footer()).on('keyup change clear', function () {
	            if (columns.search() !== this.value) {
	            	columns
	                    .search(this.value)
	                    .draw();
	            }
	        });
	    });
	    
	   
});


function setDate(){

	$("#transactionSearch").submit();
}

function parseDate(str) {
    var mdy = str.split('-');
    return new Date(mdy[2], mdy[0]-1, mdy[1]);
}

function datediff(first, second) {
    // Take the difference between the dates and divide by milliseconds per day.
    // Round to nearest whole number to deal with DST.
    return Math.round((second-first)/(1000*60*60*24));
}















