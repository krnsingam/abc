$(document).ready(function(){
	
	$(".settlement-view").click(function(){
	
	      $("#userId_view").val($("#userId").val());	
	      $("#merchantName_view").val($("#merchantName").val());
	      $("#transactionId_view").val($("#transactionId").val());
	      $("#rrn_view").val($("#rrn").val());
	      $("#authCode_view").val($("#authCode").val());
	      $("#maskedCardNumber_view").val($("#maskedCardNumber").val());
	      $("#cardHolderName_view").val($("#cardHolderName").val());
	      $("#transactionDateFrom_view").val($("#transactionDateFrom").val());
	      $("#transactionDateTo_view").val($("#transactionDateTo").val());
	      $("#acquirer_view").val($("#acquirer").val());
	      $("#mid_view").val($("#mid").val());
	      $("#tid_view").val($("#tid").val());
	      $("#txnType_view").val($(this).data("txntype"));
	      
	     $("#txnView").submit();
	});
	
	$(".settlement-download").click(function(){
      
		
	      $("#userId_download").val($("#userId").val());	
	      $("#merchantName_download").val($("#merchantName").val());
	      $("#transactionId_download").val($("#transactionId").val());
	      $("#rrn_download").val($("#rrn").val());
	      $("#authCode_download").val($("#authCode").val());
	      $("#maskedCardNumber_download").val($("#maskedCardNumber").val());
	      $("#cardHolderName_download").val($("#cardHolderName").val());
	      $("#transactionDateFrom_download").val($("#transactionDateFrom").val());
	      $("#transactionDateTo_download").val($("#transactionDateTo").val());
	      $("#acquirer_download").val($("#acquirer").val());
	      $("#mid_download").val($("#mid").val());
	      $("#tid_download").val($("#tid").val());
	      $("#txnType_download").val($(this).data("txntype"));
	      $("#txnDOwnload").submit();
	});
	
    $(document).on('click', '#searchBusinessName li' ,function() {
    	
        $("#merchantName").val(this.outerText);
        $("#container2").hide();

     }); 

    $("#search").click(function(e){
    	e.preventDefault();
    	$(".validationAlert").text("");
    	
    	if($('input[name="txnType"]:checked').val() === undefined){
    		$("#search_alert").text("Please select transaction type");
	    	return false;
    	}
    	
		var start = $("#transactionDateFrom").datepicker("getDate");
	    var end = $("#transactionDateTo").datepicker("getDate");
	    var days = (end - start)/ (1000 * 60 * 60 * 24);
	    if (Math.round(days) > 90){
	    	$("#transactionDateFrom_alert").text("Please select days less or equal to 90");
	    	return false;
	    }
	    if (Date.parse($("#transactionDateFrom").val()) > Date.parse($("#transactionDateTo").val())) {
	    	$("#transactionDateFrom_alert").text("Invalid Date Range! From Date cannot be after To Date!");
            return false;
	    }
    	setDate();
    });
    
    
	$("#searchBusinessName").hide();
	var date = new Date();
	var today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
	
	$("#transactionDateFrom").datepicker({
		format: 'dd-mm-yyyy',
		autoclose: true,
		endDate:'+d'
	});
	
	$("#transactionDateTo").datepicker({
		format: 'dd-mm-yyyy',
		autoclose: true,
		endDate:'+d'
	});
	
	if($.trim($("#transactionDateFrom").val()) == "" || $.trim($("#transactionDateFrom").val()) == "undefined"){
		$( '#transactionDateFrom' ).datepicker( 'setDate', today );
	}
	
	if($.trim($("#transactionDateTo").val()) == "" || $.trim($("#transactionDateTo").val()) == "undefined"){
		$( '#transactionDateTo' ).datepicker( 'setDate', today );
	}
	

	
	
    $(document).on('keyup','#merchantName',function(){	
    	 $("#searchBusinessName").html("");	 
      	 $.ajax({
   	     	url: contexturi+"/transaction/get-merchant",
   	     	headers: {
   	     		    'X-CSRF-TOKEN':$('#_csrf').attr('content'),
   	     	},
   	     	type: "POST",
   	     	data:{ name : $(this).val()  },
   	     	success: function(result){
   	     		var searchBusinessNameHtml ="";
   	     		if(result.length){
		 	        result.forEach(function(item){
		 	        	searchBusinessNameHtml +="<li class='liststyletype'>"+item+"</li>";
		   	     	});
		 	        $("#searchBusinessName").html(searchBusinessNameHtml).show();
   	     		}else{
   	     		 $("#searchBusinessName").hide();
   	     		}
   	         },
   	         error:function(xhr, error, code) {
   	
   	             if (error === 'parsererror' || error === 'timeout') {
   	                 window.location.href = +contexturi+"/login?invalid";
   	             }
   	             
   	         }
   	      });
      	
      });
    
});


function setDate(){
		$("#transactionSearch").submit();
}























