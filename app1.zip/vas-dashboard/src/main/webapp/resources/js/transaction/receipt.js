$(document).ready(function(){
	 $("#send_email,#sms,#sendEmail,#sendSms").hide();
	 
	 $(".smsClick").click(function(){
		 $("#send_email").val("");
		 $(".validationAlert").text();
		 $("#sms").show();
		 $("#sendSms").show();
		 $("#send_email").hide();
		 $("#sendEmail").hide();
	 });
	 
	 $(".emailClick").click(function(){
		 $("#sms").val("");
		 $(".validationAlert").text();
		 $("#send_email").show();
		 $("#sms").hide();
		 $("#sendEmail").show();
		 $("#sendSms").hide();
	 });
	 
});

$(document).on('click','#sendEmail',function(e){	
 
 e.preventDefault();

 $(".validationAlert").text("");
 
 var emailRegex =  /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,8}/igm;
 
 if($.trim($("#send_email").val()) == ""){
	 $("#email_alert").text("Please enter email");
	 return false;
 }

 if($.trim($("#send_email").val()) != ""){
	 if(!emailRegex.test($.trim($("#send_email").val()))){
		 $("#email_alert").text("Please enter valid email");
		 return false;
	 }
 }
 
 $.ajax({
     	url: contexturi+"/transaction/send-email",
     	headers: {
     		    'X-CSRF-TOKEN':$('#_csrf').attr('content'),
     	},
     	type: "POST",
     	data:{ tranId : $("#tranId").val()  ,email : $("#send_email").val() },
        beforeSend: function() {
            $("#sendEmail").val('Sending').attr('disabled',true);
        },
     	success: function(result){
     		 $("#sendEmail").val('Submit').attr('disabled',false);
     		$("#exampleModal").modal('hide');
     		if(result){
     			$("#emailSuccess").show();
     		}else{
     			$("#emailFail").show();
     		}
     		setTimeout(function(){ $("#emailSuccess,#emailFail").hide();}, 3000);
         },
         error:function(xhr, error, code) {
        	 $("#sendEmail").val('Submit').attr('disabled',false);
             if (error === 'parsererror') {
                 window.location.href = +contexturi+"/login?invalid";
	             }
	             
	         }
	      });
   	 

 });

$(document).on('click','#sendSms',function(e){	

	 e.preventDefault();
	 
	 $(".validationAlert").text("");
	 
	 var mobileRegex = /^[789]\d{9}$/;
	 
	 if($.trim($("#sms").val()) == ""){
		 $("#sms_alert").text("Please enter mobile number");
		 return false;
	 }
	 
	 if($.trim($("#sms").val()) != ""){
	     if(!mobileRegex.test($.trim($("#sms").val()))){
			 $("#sms_alert").text("Please enter valid 10 digit mobile number");
			 return false;
	     }
	 }
	 
	 $.ajax({
	     	url: contexturi+"/transaction/send-sms",
	     	headers: {
	     		    'X-CSRF-TOKEN':$('#_csrf').attr('content'),
	     	},
	     	type: "POST",
	     	data:{ tranId : $("#tranId").val()  ,sms : $("#sms").val() },
	        beforeSend: function() {
	            $("#sendSms").val('Sending').attr('disabled',true);
	        },
	     	success: function(result){
	            $("#sendSms").val('Submit').attr('disabled',false);
	     		$("#exampleModal").modal('hide');
	     		if(result){
	     			$("#smsmSuccess").show();
	     		}else{
	     			$("#smsFail").show();
	     		}
	     		setTimeout(function(){ $("#smsmSuccess,#smsFail").hide();}, 3000);
	         },
	         error:function(xhr, error, code) {
	        	 $("#sendSms").val('Submit').attr('disabled',false);
	             if (error === 'parsererror') {
	                 window.location.href = +contexturi+"/login?invalid";
		             }
		             
		         }
		      });
	   	 

	 });