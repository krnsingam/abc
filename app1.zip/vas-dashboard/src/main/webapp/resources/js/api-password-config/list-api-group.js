$(document).ready(function () {

    // DataTable
    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    var myContextPath = $("#app_context_path").attr('content');
   
    var table = $('#listAPIGroup').DataTable({
        "processing": true,
        "serverSide": true,
        // "scrollY": $(document).height() - 400,
        "scrollCollapse": true,
        "paging": true,
        "createdRow": function (row, data, index) {
            var info = table.page.info();
            $('td', row).eq(0).html(index + 1 + info.page * info.length);
        },

        autoWidth: false,

        "dom":
            "<'row'<'col-sm-12 col-md-12'l>>" +
            "<'row'<'col-sm-12'tr>>" +
            "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
        "ajax": {
            "url": myContextPath + "/api-password-config/list-api-group",
            "contentType": "application/json",
            "type": "POST",
            "timeout":"60000",
            "data": function (d) {
                return JSON.stringify(d);
            },
            "beforeSend": function (request) {
                request.setRequestHeader(header, token);
            },
            "error": function (xhr, error, code) {

                if (error === 'parsererror' || error === 'timeout' || error === 'error') {
                    window.location.href = myContextPath + "/login?invalid";
                }
            }
        },

        "columns": [
            { "data": 'serialNo' },
            { "data": 'apiDivisionName' },
            {
                "data": "apiDivisionCode",
                "render": function (data, type, row, meta) {
                    if (row['midCount'] > 0) {
                        data = '<a class="ruleDetails" href="#" data-programCode=' + row.id + '>' + data + '</a>';
                    }
                    return data;
                }
            },
           
            { "data": 'apiPassword' },
            { "data": 'apiURL1', width: '300px' },
            { "data": 'divisionStatus' }, 
            { "data" : "id",
                "searchable": false,
                "orderable":false,
                "render": function (data, type, row) {
                      console.log($('#is_admin'));
                      if($('#is_admin').val() !== undefined){
                    	  return '<button type="button" class="actionClass btn btn-xs btn-primary" title="Edit" data-id="edit"><i class="fa fa-edit" ></i></button>';
                      }else{
                    	  $("#role").hide();
                    	  return "";
                      }
                }         
            }
                 
        ],
        "order": [[0, "desc"]]
    });

    $(document.body).on('click', '.ruleDetails', function () {
        var data = table.row($(this).parents("tr")).data();
        $("#programCodeData").val(data['id']);
        $("#ruleDetails").submit();

    });


    // Apply the search
    table.columns().every(function () {
        var that = this;
        $('input,select', this.footer()).on('keyup change clear', function () {
            if (that.search() !== this.value) {
                that
                    .search(this.value)
                    .draw();
            }
        });
    });
    

    table.on('order.dt search.dt', function () {
           	table.column(0, { search: 'applied', order: 'applied' }).nodes().each(function (cell, i) {
               	cell.innerHTML = i + 1;
           });
       	}).draw();

    table.on('order.dt search.dt', function () {
        	table.column(0, { search: 'applied', order: 'applied' }).nodes().each(function (cell, i) {
            	cell.innerHTML = i + 1;
        	});
    	}).draw();

    $("#listAPIGroup").on("click", "[data-id='edit']", function () {
        var data = table.row($(this).parents("tr")).data();
        console.log(data['id']);
        $('#id').val(data['id']);
        $('#editApi').submit();

    });

});

$(document).ready(function () {

    $(".no-special-char").keypress(function (event) {
        var character = String.fromCharCode(event.keyCode);
        return isValid(character);
    });

    // No special char control handler
    function isValid(str) {
        return !/[~`#$%\^&*()+\[\]\\';,/{}|\\"<>\?]/g.test(str);
    }
});
