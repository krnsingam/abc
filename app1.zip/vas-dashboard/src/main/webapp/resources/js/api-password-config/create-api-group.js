$(document)
		.ready(
				function() {

					$.validator.addMethod("AlphaNumericWithSpaceValidation",
							function(value, element) {
								return this.optional(element)
										|| /^[a-zA-Z\d]+((\s)*[a-zA-Z\d])*$/
												.test(value);
							}, 'Special character not allowed!');

					$.validator
							.addMethod(
									"AlphaNumericWithSpacialCharactersValidation",
									function(value, element) {
										return this.optional(element)
												|| /[a-zA-Z0-9~`!@#$%\^&*()+=\-\[\]\\'.;,/{}|\\":<>\?]/g
														.test(value);
									}, ' Space not allowed !');

					$.validator.addMethod("AlphaNumericWithOutSpaceValidation",
							function(value, element) {
								return this.optional(element)
										|| /^[a-zA-Z0-9]*$/.test(value);
							}, 'Space not allowed between characters!');

					$.validator
							.addMethod(
									"EmailValidation",
									function(value, element) {
										return this.optional(element)
												|| /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/
														.test(value);
									}, 'Please enter valid email');

					$.validator
							.addMethod(
									"URLValidation",
									function(value, element) {
										return this.optional(element)
												|| /^(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})$/
														.test(value);
									}, 'This is not valid url');

					$("#createAPIGroup")
							.validate(
									{
										onClick : true,

										errorElement : 'span',
										errorClass : 'help-block error-border',

										highlight : function(element,
												errorClass, validClass) {

											$(element).closest('.form-group')
													.addClass("has-error");
											$(element).closest('.form-control')
													.addClass("error-border");

										},
										unhighlight : function(element,
												errorClass, validClass) {
											$(element).closest('.form-group')
													.removeClass("has-error");
											$(element)
													.closest('.form-control')
													.removeClass("error-border");

										},
										rules : {
											apiDivisionName : {
												required : true,
												AlphaNumericWithSpaceValidation : true,
												maxlength : 150
											},
											apiDivisionCode : {
												required : true,
												AlphaNumericWithOutSpaceValidation : true,
												maxlength : 45,
												minlength : 3
											},

											apiPassword : {
												AlphaNumericWithOutSpaceValidation : false,
												maxlength : 45
											},

											apiURL1 : {
												maxlength : 250,
												URLValidation : true
											},

											apiURL2 : {
												required : function(element) {
													if ($("#flag").val() == 0) {
														return true;
													} else {
														return false;
													}
												},
												EmailValidation : true
											},

											divisionRef1 : {
												maxlength : 45,
												AlphaNumericWithSpacialCharactersValidation : false
											},

											divisionRef2 : {
												maxlength : 45,
												AlphaNumericWithSpacialCharactersValidation : false
											},

											divisionRef3 : {
												maxlength : 45,
												AlphaNumericWithSpacialCharactersValidation : false
											},

											divisionRef4 : {
												maxlength : 45,
												AlphaNumericWithSpacialCharactersValidation : false
											}

										},

										messages : {
											divisionRef1 : {
												maxlength : "Please enter valid divisionRef1 No(maximum length is allowed 45)"
											},
											divisionRef2 : {
												maxlength : "Please enter valid divisionRef2 No(maximum length is allowed 45)"
											},
											divisionRef3 : {
												maxlength : "Please enter valid divisionRef3 No(maximum length is allowed 45)"
											},
											divisionRef4 : {
												maxlength : "Please enter valid divisionRef4 No(maximum length is allowed 45)"
											}
										}
									});

				});

$(document).ready(function() {
	$("#message").fadeOut(2000);

	$(".no-special-char").keypress(function(event) {
		var character = String.fromCharCode(event.keyCode);
		return isValid(character);
	});

	// No special char control handler
	function isValid(str) {
		return !/[~`!@#$%\^&*()+=\-\[\]\\'.;,/{}|\\":<>\?]/g.test(str);
	}
});
