$(document).ready(function () {

    var id = $('#id').val();
    console.log(id);
    var postdata = {};
    // DataTable
    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    // getting contextPath
    var myContextPath=$("#app_context_path").attr('content') ;

    var table = $('#table_view').DataTable({
        "processing": true,
        "serverSide": true,
        //"scrollY": $(document).height() - 400,
        "scrollCollapse": true,
        "paging": true,
        "createdRow": function (row, data, index) {
            var info = table.page.info();
            $('td', row).eq(0).html(index + 1 + info.page * info.length);
        },

        autoWidth: false,

        "dom": 
        	"<'row'<'col-sm-12 col-md-12'l>>" +
			"<'row'<'col-sm-12'tr>>" +
			"<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
        
        "ajax": {
            "url": myContextPath + "/api-password-config/mid-tid-next",
            "contentType": "application/json",
            "type": "POST",
            "timeout":"60000",
            "data": function (d) {
                postdata.dtRequest = d;
                postdata.id = id;
                return JSON.stringify(postdata);
            },
            "beforeSend": function (request) {
                request.setRequestHeader(header, token);
            },
            "error": function (xhr, error, code) {

                if (error === 'parsererror' || error === 'timeout' || error === 'error') {
                    window.location.href = myContextPath + "/login?invalid";
                }
            }
        },
        "columns": [
            { "data": 'serialNo' },
            { "data": 'mid' },
            { "data": 'divCode' },
            { "data": 'tid' },
        ],
        "order": [[0, "desc"]]
    });

    // Apply the search
    table.columns().every(function () {
        var that = this;

        $('input,select', this.footer()).on('keyup change clear', function () {
            if (that.search() !== this.value) {
                that
                    .search(this.value)
                    .draw();
            }
        });

    });

    table.on('order.dt search.dt', function () {
        table.column(0, { search: 'applied', order: 'applied' }).nodes().each(function (cell, i) {
            cell.innerHTML = i + 1;
        });
    }).draw();

    $(".no-special-char").keypress(function (event) {
        var character = String.fromCharCode(event.keyCode);
        return isValid(character);
    });

    // No special char control handler
    function isValid(str) {
        return !/[~`#$%\^&*()+\[\]\\';,/{}|\\"<>\?]/g.test(str);
    }

});

