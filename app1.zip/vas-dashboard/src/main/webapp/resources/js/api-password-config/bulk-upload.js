$(document).ready(function() {

	// THIS BLOCK IS RESPONSIBLE FOR DISPLAYING THE FILE NAME AFTER PICKING THE
	// FILE.
	$('.custom-file-input').on('change', function() {
		let fileName = $(this).val().split('\\').pop();
		$(this).next('.custom-file-label').addClass("selected").html(fileName);
	});

	// REMOVING ALERT AFTER DELAY OF 4 SECONDS.
	setTimeout(function() {
		$(".alert").alert('close');
	}, 4000);

});

$("#program-bulk-upload").validate({
	onClick : true,

	errorElement : 'div',
	errorClass : 'help-block error-border',

	highlight : function(element, errorClass, validClass) {
		$(element).closest('.form-group').addClass("has-error");
		$(element).closest('.form-control').addClass("error-border");

	},
	unhighlight : function(element, errorClass, validClass) {
		$(element).closest('.form-group').removeClass("has-error");
		$(element).closest('.form-control').removeClass("error-border");

	},
	rules : {
		file : {
			required : true
		}
	},
	messages : {
		file : {
			required : "Please Select Valid Excel File"
		}
	}
});
