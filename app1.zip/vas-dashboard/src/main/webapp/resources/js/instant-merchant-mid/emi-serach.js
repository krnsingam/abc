$(document).ready(function () {
	// No special char control handler
	function isValid(str) {
		return !/[~`!@#$%\^&*()+=\-\[\]\\'.;,/{}|\\":<>\?]/g.test(str);
	}
    // to hide the datatable default
    $("#emi_table").hide();

    // DataTable
    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    // getting contextPath
	var myContextPath=$("#app_context_path").attr('content') ;

    // calling datatable request function
    var postdata = {};


    // Datepicker Implementation
    var date = new Date(),
        yr = date.getFullYear(),
        month = date.getMonth() + 1,
        day = date.getDate(),
        todayDate = day + '-' + month + '-' + yr;

    $("#fromdate").val(todayDate);
    $("#todate").val(todayDate);

    var date_input = $('input[name="date"]'); // our date input has the name
    // "date"
    var container = $('.bootstrap-iso form').length > 0 ? $('.bootstrap-iso form').parent() : "body";
    date_input.datepicker({
        format: 'dd-mm-yyyy',
        container: container,
        todayHighlight: false,
        autoclose: true,
    })

    var maxDate;
    var minDate;
    $("#fromdate").datepicker({
        format: 'dd-mm-yyyy',
        autoclose: true,
    }).click('changeDate', function (selected) {

        // moment js used to convert and date value from toDate
        minDate = moment(todayDate, 'DD-MM-YYYY').subtract(20, 'years').format('DD-MM-YYYY');
        maxDate = todayDate;
        $('#fromdate').datepicker('setStartDate', minDate);
        $('#fromdate').datepicker('setEndDate', maxDate);

    });

    $("#todate").datepicker({
        format: 'dd-mm-yyyy',
        autoclose: true,
    }).click('changeDate', function (selected) {
        var maxDate = todayDate;
        var minDate = $("#fromdate").val();
        $('#todate').datepicker('setStartDate', minDate);
        $('#todate').datepicker('setEndDate', maxDate);
    });
    // End Datepicker Implementation

    // to fetch the emi search reporting list
    console.log($("#fromdate").val(), $('#todate').val());
    $('#emi-table-id').DataTable({
        "processing": true,
        "serverSide": true,
        "scrollCollapse": true,
        "paging": true,
        "dom": 
        "<'row'<'col-sm-12 col-md-12'l>>" +
        "<'row'<'col-sm-12'tr>>" +
        "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
    
        "ajax": {
            "url": myContextPath + "/emi-bulk-upload/emi-search",
            "contentType": "application/json",
            "type": "POST",
            "timeout":"60000",
            "data": function (d) {

                postdata.dtRequest = d;
                postdata.fromDate = $('#fromdate').val();
                postdata.toDate = $('#todate').val();
                postdata.acquirer = $('#acquirer').val();
                postdata.mid = $('#mid').val();
                postdata.tid = $('#tid').val();
                postdata.credit = $('#credit').val();
                postdata.debit = $('#debit').val();
                return JSON.stringify(postdata);

            },
            "beforeSend": function (request) {
                request.setRequestHeader(header, token);
            },
            "error": function (xhr, error, code) {

                if (error === 'parsererror' || error === 'timeout' || error === 'error') {
                    window.location.href = myContextPath + "/login?invalid";
                }
            }
        },
        "columns": [
            { "data": 'acquirer' },
            { "data": 'mid' },
            { "data": 'tid' },
            { "data": 'credit' },
            { "data": 'debit' },
            { "data": 'createdTime' },

        ],
        "order": [[0, "desc"]]
    });

    // on search reload the form
    $("#search").on("click", function (event) {
        $(".validationALert").html("");
        $("#mid_error").html("");
        $("#tid_error").html("");
        // validate fromDate and toDate for one month
        var start = $("#fromdate").datepicker("getDate");
        var end = $("#todate").datepicker("getDate");
        days = (end - start) / (1000 * 60 * 60 * 24);
        if ($.trim($("#fromdate").val()) == '') {
            $("#30days_error").html("");
            $("#exceeddays_error").html("");
            $("#todate_error").html("");
            $("#fromdate_error").html("Please select From Date");
            return false;
        }
        else if (Math.round(days) > 90) {
            $("#fromdate_error").html("");
            $("#exceeddays_error").html("");
            $("#todate_error").html("");
            $("#30days_error").html("Please select days less or equal to 90 ");
            return false;
        }
        else if ($.trim($("#todate").val()) == '') {
            $("#30days_error").html("");
            $("#exceeddays_error").html("");
            $("#fromdate_error").html("");
            $("#todate_error").html("Please select To Date ");
            return false;
        }
        else if
            (start > end) {
            $("#fromdate_error").html("");
            $("#todate_error").html("");
            $("#30days_error").html("");
            $("#exceeddays_error").html("Please select To Date more than From Date ");
            return false;
        }
        else {
            $("#30days_error").html("");
            $("#exceeddays_error").html("");
            $("#fromdate_error").html("");
            $("#todate_error").html("");
        }       
      
               // validating mid length and valid input
        if ($.trim($("#mid").val()) != '') {

            if ($("#mid").val().length > 19 || $("#mid").val().length < 1) {
                $("#mid_error").html("");
                return false;
            }
        }
        
        // validating mid length and valid input
        if ($.trim($("#tid").val()) != '') {

            if ($("#tid").val().length > 16 || $("#tid").val().length < 8) {
                $("#tid_error").html("");
                return false;
            }
        }

        $("#emi_table").show();
        $('#emi-table-id').dataTable().fnFilter();
    });
    
         // caling validation on datePicker for  download button
         $('#download').click(function(){   	 
        	 $(".validationALert").html("");
             // validate fromDate and toDate for one month
             var start = $("#fromdate").datepicker("getDate");
             var end = $("#todate").datepicker("getDate");
             days = (end - start) / (1000 * 60 * 60 * 24);
             if ($.trim($("#fromdate").val()) == '') {
                 $("#30days_error").html("");
                 $("#exceeddays_error").html("");
                 $("#todate_error").html("");
                 $("#fromdate_error").html("Please select From Date");
                 return false;
             }
             else if (Math.round(days) > 90) {
                 $("#fromdate_error").html("");
                 $("#exceeddays_error").html("");
                 $("#todate_error").html("");
                 $("#30days_error").html("Please select days less or equal to 90 ");
                 return false;
             }
             else if ($.trim($("#todate").val()) == '') {
                 $("#30days_error").html("");
                 $("#exceeddays_error").html("");
                 $("#fromdate_error").html("");
                 $("#todate_error").html("Please select To Date ");
                 return false;
             }
             else if
                 (start > end) {
                 $("#fromdate_error").html("");
                 $("#todate_error").html("");
                 $("#30days_error").html("");
                 $("#exceeddays_error").html("Please select To Date more than From Date ");
                 return false;
             }
             else {
                 $("#30days_error").html("");
                 $("#exceeddays_error").html("");
                 $("#fromdate_error").html("");
                 $("#todate_error").html("");
             }             
             
     		
 	     // validating mid length and valid input
 	        if ($.trim($("#tid").val()) != '') {

 	            if ($("#tid").val().length > 16 || $("#tid").val().length < 8) {
 	                $("#tid_error").html("");
 	                return false;
 	            }
 	        } 	        
 	         // validating mid length and valid input
 	        if ($.trim($("#mid").val()) != '') {

 	            if ($("#mid").val().length > 19 || $("#mid").val().length < 1) {
 	                $("#mid_error").html("");
 	                return false;
 	            }
 	        }
             $("#emi-search").submit();
        	 
     	});
      
    // For issuer dropdown
    $('.select2').select2();
    
 // REMOVING ALERT AFTER DELAY OF 4 SECONDS.
	setTimeout(function () {
		$(".alert").alert('close');
	}, 4000);
				
			//calling special character function
			$(".no-special-char").keypress(function (event) {
				var character = String.fromCharCode(event.keyCode);
				return isValid(character);
			});
});