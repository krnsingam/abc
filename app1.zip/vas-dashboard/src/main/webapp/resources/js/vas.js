
$(document).ready(function () {
    $("#brandname").select2({
        placeholder: "Select a Brand name",
        allowClear: true
    });
    $("#binno").select2({
        placeholder: "Select Bin no",
        allowClear: true
    });
    $("#domainname").select2({
        placeholder: "Select Domain name",
        allowClear: true
    });

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({
        timePicker: true,
        timePickerIncrement: 30,
        locale: {
            format: 'MM/DD/YYYY hh:mm A'
        }
    })

    $('#exampleInputFile').on('change', function () {
        //get the file name
        var fileName = $(this).val();
        //replace the "Choose a file" label
        $(this).next('.custom-file-label').html(fileName);
    })
    $('#exampleInputFile1').on('change', function () {
        //get the file name
        var fileName = $(this).val();
        //replace the "Choose a file" label
        $(this).next('.custom-file-label').html(fileName);
    })
    $('#exampleInputFile2').on('change', function () {
        //get the file name
        var fileName = $(this).val();
        //replace the "Choose a file" label
        $(this).next('.custom-file-label').html(fileName);
    })
    $('#exampleInputFile3').on('change', function () {
        //get the file name
        var fileName = $(this).val();
        //replace the "Choose a file" label
        $(this).next('.custom-file-label').html(fileName);
    })

    document.querySelectorAll(
        'input[type=radio][name=r2]').forEach((elem) => {
            elem.addEventListener('click', allowUncheck);
            // only needed if elem can be pre-checked
            elem.previous = elem.checked;
        });

    function allowUncheck(e) {
        if (this.previous) {
            this.checked = false;
        }
        // need to update previous on all elements of this group
        // (either that or store the id of the checked element)
        document.querySelectorAll(
            `input[type=radio][name=${this.name}]`).forEach((elem) => {
                elem.previous = elem.checked;
            });
    }

    //Next and previous button
    jQuery('body').on('click', '#btnNext', function () {
        var next = jQuery('.nav-pills > .active').next('li');
        if (next.length) {
            next.find('a').trigger('click');
        } else {
            $('.nav-pills > .nav-item > .active').parent().next('li').find('a').trigger('click');
        }
    });

    jQuery('body').on('click', '#btnPrevious', function () {
        var prev = jQuery('.nav-pills > .active').prev('li')
        if (prev.length) {
            prev.find('a').trigger('click');
        } else {
            $('.nav-pills > .nav-item > .active').parent().prev('li').find('a').trigger('click');
        }
    });

    //End

    //start of tree view

    var myData = [
        {
            id: 0,
            title: 'Apple '
        }, {
            id: 1,
            title: 'Samsung',
            subs: [
                {
                    id: 10,
                    title: 'Laptop',
                    subs: [
                        {
                            id: 21,
                            title: 'white',
                        },
                        {
                            id: 22,
                            title: 'grey',
                        }
                    ]
                }, {
                    id: 11,
                    title: 'Tab'
                }, {
                    id: 12,
                    title: 'Mobile'
                }
            ]
        }, {
            id: 2,
            title: 'Google +'
        },
        // more data here
    ];

    var instance = $('#example').comboTree({
        source: myData,
        isMultiple: true,
        // selected: ['0'],
        cascadeSelect: true



    });

    instance.getSelectedItemsTitle();
    instance.getSelectedItemsId();
    // instance.destroy();

    //end of tree view
});

function valueChanged() {
    if ($('#emi').is(":checked"))
        $(".emibox").show();
    else if ($('#nonemi').is(":checked")) {
        $(".emibox").hide();

    }
}

function addRow() {
    $(".emibox").show();
    if ($('#nonemi').is(":checked")) {
        $(".emibox").hide();


    }

    document.querySelector('#content').insertAdjacentHTML(
        'afterbegin',


        `<div class="col-sm-4 emibox">
                      
                      <div class="form-group " >
                          <label>Select Issuer</label>
                          <select class="form-control select2" style="width: 100%;">
                            <option selected="selected">HDFC Bank</option>
                            <option>Kotak Bank</option>
                            <option>ICICI Bank</option>
                            <option>AXIS Bank</option>
  
                          </select>
                        </div>
  
  
  
                       
  
                  </div>
                  <div class="col-sm-4 emibox">

                      <div class="form-group" >
                          <label for="mccCode">Tenure</label>
                          <input type="text" class="form-control" id="mccCode" placeholder="Enter Tenure" style="width: 100%;">
                        </div>
                  </div>
                  <div class="col-sm-4 emibox">
                      <div class="form-group " >
                          <label for="mccCode">ROI</label>
                          <input type="text" class="form-control" id="mccCode" placeholder="Enter ROI" style="width: 100%;">
                        </div>
                  </div>


                  <div class="col-sm-4 mb-3 mb-sm-0 emibox">
                          <label for="minamount">Min Transaction Amount</label>
                          <input class="form-control" placeholder="Min amount" type="number" name="minamount"
                            required="required">
                        </div>

                        <div class="col-sm-4 mb-3 mb-sm-0 emibox">
                          <label for="minamount">Max Transaction Amount</label>
                          <input class="form-control" placeholder="Max amount" type="number" name="maxamount"
                            required="required">
                        </div>

                  <div class="col-sm-4 emibox">
                    <br>
                      <input type="button"  class="btn btn-primary " style="margin-top:8px;padding-left:11px;width:100%;margin-bottom:18px;" onclick="addRow()"value="Add">

                </div>`
    )
}

$(function(){
    $("#footerContent").load("footer.html"); 
    $("#sidebarContent").load("sidebar.html"); 

    

  });




