
$(document).ready(function () {

    $("#first-search").hide();

    // No special char control handler
    function isValid(str) {
        return !/[~`!@#$%\^&*()+=\-\[\]\\';,/{}|\\":<>\?]/g.test(str);
    }

    // DataTable
    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    // getting contextPath
    var myContextPath = $("#app_context_path").attr('content');
    var postdata = {};

    // Datepicker Implementation
    var date = new Date(),
        yr = date.getFullYear(),
        month = date.getMonth() + 1,
        day = date.getDate(),
        todayDate = day + '-' + month + '-' + yr;

    $("#fromdate").val(todayDate);
    $("#todate").val(todayDate);

    var date_input = $('input[name="date"]'); // our date input has the name
    // "date"
    var container = $('.bootstrap-iso form').length > 0 ? $('.bootstrap-iso form').parent() : "body";
    date_input.datepicker({
        format: 'dd-mm-yyyy',
        container: container,
        todayHighlight: false,
        autoclose: true,
    })

    var maxDate;
    var minDate;
    $("#fromdate").datepicker({
        format: 'dd-mm-yyyy',
        autoclose: true,
    }).click('changeDate', function (selected) {

        // moment js used to convert and date value from toDate
        minDate = moment(todayDate, 'DD-MM-YYYY').subtract(20, 'years').format('DD-MM-YYYY');
        maxDate = todayDate;
        // $("#todate").val("");
        $('#fromdate').datepicker('setStartDate', minDate);
        $('#fromdate').datepicker('setEndDate', maxDate);

    });

    $("#todate").datepicker({
        format: 'dd-mm-yyyy',
        autoclose: true,
    }).click('changeDate', function (selected) {
        var maxDate;
        var minDate;

        minDate = $("#fromdate").val();
        maxDate = todayDate;
        $('#todate').datepicker('setStartDate', minDate);
        $('#todate').datepicker('setEndDate', maxDate);
    });
    // End Datepicker Implementation

    // Data Table ajax call and storing the value in table.
    var table = $('#table_id').DataTable({
        "processing": true,
        "serverSide": true,
/*
 * "scrollY": $(document).height() - 400,
 */     "scrollCollapse": true,
        "paging": true,
        "dom":
            "<'row'<'col-sm-12 col-md-12'l>>" +
            "<'row'<'col-sm-12'tr>>" +
            "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
        "ajax": {
            "url": myContextPath + "/transaction/transaction-report-view",
            "contentType": "application/json",
            "type": "POST",
            "timeout":"60000",
            "data": function (d) {

                postdata.dataTable = d;
                postdata.fromDate = $("#fromdate").val();
                postdata.toDate = $('#todate').val();
                postdata.status = $('#statu').val();
                postdata.emiStatus = "";
                postdata.authCode = $('#athcode').val();
                postdata.binValue = $('#binval').val();
                postdata.txnRefNo = $('#txnno').val();
                postdata.txnAmount = $('#txnamt').val();
                postdata.issuer = $('#issue').val();
                return JSON.stringify(postdata);
            },
            "beforeSend": function (request) {
                request.setRequestHeader(header, token);
            },
            "error": function (xhr, error, code) {


				if (error === 'parsererror' || error === 'timeout' || error === 'error') {
					window.location.href = myContextPath + "/login?invalid";
				}
			}

        },
        "columns": [

            { "data": 'enquiryId' },
            { "data": 'txnRefNo' },
            { "data": 'authCode' },
            { "data": 'rrn' },
            { "data": 'txnAmount' },
            { "data": 'binValue' },
            { "data": 'cardType' },
            { "data": 'issuer' },
            { "data": 'status' },
            { "data": 'settlementStatus'},
            { "data": 'txnTime' },
            { "data": 'emiConverted' },
            { "defaultContent": '<button type="button" title="View" class="btn btn-primary btn-xs mx-auto" data-toggle="modal" data-target="#modal-default" id="view"><i class="fa fa-eye"></i></button><button id="loader-button" class="d-none btn btn-primary" type="button" disabled><span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span></button>' }
        ],
        "order": [[0, "desc"]]
    });

    // to download the product bin detail
    $("#download").on("click", function () {
        $(".validationAlert").html(" ");
        var start = $("#fromdate").datepicker("getDate");
        var end = $("#todate").datepicker("getDate");
        var days = (end - start) / (1000 * 60 * 60 * 24);
        if ($.trim($("#fromdate").val()) == '') {
            $("#30days_error").html("");
            $("#exceeddays_error").html("");
            $("#todate_error").html("");
            $("#fromdate_error").html("Please select From Date");
            return false;
        }
        else if (Math.round(days) > 90) {
            $("#fromdate_error").html("");
            $("#exceeddays_error").html("");
            $("#todate_error").html("");
            $("#30days_error").html("Please select days less or equal to 90 ");
            return false;
        }
        else if ($.trim($("#todate").val()) == '') {
            $("#30days_error").html("");
            $("#exceeddays_error").html("");
            $("#fromdate_error").html("");
            $("#todate_error").html("Please select To Date ");
            return false;
        }
        else if
            (start > end) {
            $("#fromdate_error").html("");
            $("#todate_error").html("");
            $("#30days_error").html("");
            $("#exceeddays_error").html("Please select To Date more than From Date ");
            return false;
        }
        else {
            $("#30days_error").html("");
            $("#exceeddays_error").html("");
            $("#fromdate_error").html("");
            $("#todate_error").html("");
        }
        var numbers = /^[-+]?[0-9.]+$/;
        if ($.trim($("#txnno").val()) != '') {
            if (!$("#txnno").val().match(numbers)) {
                $("#txn_error").html("Only Numbers are allowed");
                return false;
            }
        }

        if ($.trim($("#binval").val()) != '') {
            if ($("#binval").val().length > 8 || $("#binval").val().length < 6) {
                $("#binval_error").html("Please enter valid length(min length=6 and max length=8)");
                return false;
            }

            if (!$("#binval").val().match(numbers)) {
                $("#binval_error").html("Only Numbers are allowed");
                return false;
            }
        }

        if ($.trim($("#athcode").val()) != '') {
            if (!$("#athcode").val().match(numbers)) {
                $("#athcode_error").html("Only Numbers are allowed");
                return false;
            }
        }

        if ($.trim($("#txnamt").val()) != '') {
            if (!$("#txnamt").val().match(numbers)) {
                $("#txnamt_error").html("Only Numbers are allowed");
                return false;
            }
        }
        $("#searchForm").submit();

    });
	// end of download page 
    // REMOVING ALERT AFTER DELAY OF 4 SECONDS.
    setTimeout(function () {
        $(".alert").alert('close');
    }, 4000);

    // to search the product bin detail
    $("#search").on("click", function () {
        $(".validationAlert").html(" ");
        var start = $("#fromdate").datepicker("getDate");
        var end = $("#todate").datepicker("getDate");
        var days = (end - start) / (1000 * 60 * 60 * 24);
        if ($.trim($("#fromdate").val()) == '') {
            $("#30days_error").html("");
            $("#exceeddays_error").html("");
            $("#todate_error").html("");
            $("#fromdate_error").html("Please select From Date");
            return false;
        }
        else if (Math.round(days) > 90) {
            $("#fromdate_error").html("");
            $("#exceeddays_error").html("");
            $("#todate_error").html("");
            $("#30days_error").html("Please select days less or equal to 90 ");
            return false;
        }
        else if ($.trim($("#todate").val()) == '') {
            $("#30days_error").html("");
            $("#exceeddays_error").html("");
            $("#fromdate_error").html("");
            $("#todate_error").html("Please select To Date ");
            return false;
        }
        else if
            (start > end) {
            $("#fromdate_error").html("");
            $("#todate_error").html("");
            $("#30days_error").html("");
            $("#exceeddays_error").html("Please select To Date more than From Date");
            return false;
        }
        else {
            $("#30days_error").html("");
            $("#exceeddays_error").html("");
            $("#fromdate_error").html("");
            $("#todate_error").html("");
        }

        var numbers = /^[-+]?[0-9.]+$/;

        if ($.trim($("#txnno").val()) != '') {
            if (!$("#txnno").val().match(numbers)) {
                $("#txn_error").html("Only Numbers are allowed");
                return false;
            }
        }

        if ($.trim($("#binval").val()) != '') {
            if ($("#binval").val().length > 8 || $("#binval").val().length < 6) {
                $("#binval_error").html("Please enter valid length(min length=6 and max length=8)");
                return false;
            }
            if (!$("#binval").val().match(numbers)) {
                $("#binval_error").html("Only Numbers are allowed");
                return false;
            }
        }

        if ($.trim($("#athcode").val()) != '') {
            if (!$("#athcode").val().match(numbers)) {
                $("#athcode_error").html("Only Numbers are allowed");
                return false;
            }
        }

        if ($.trim($("#txnamt").val()) != '') {
            if (!$("#txnamt").val().match(numbers)) {
                $("#txnamt_error").html("Only Numbers are allowed");
                return false;
            }
        }
        $("#first-search").show();
        $('#table_id').dataTable().fnFilter();

    });

    // to view transaction detail
    $("#table_id tbody").on("click", "#view", function () {
        var data = table.row($(this).parents("tr")).data();
        var normalButton = document.getElementById('view');
        var loaderButton = document.getElementById('loader-button');

        normalButton.classList.add("d-none");
        loaderButton.classList.remove("d-none");
        $.ajax({
        	
            url: myContextPath + '/transaction/transaction-reportdetail',
            contentType: "application/json",
            type: "GET",
            data: { txnId: data['id'] },
            dataType: 'json',
            beforeSend: function (request) {
                request.setRequestHeader(header, token);
            }, success: function (result) {
            	 

                $('#enquiry').html(result.enquiryId);
                $('#txnrefno').html(result.txnRefNo);
                $('#auth').html(result.authCode);
                $('#rrn').html(result.rrn);
                $('#amt').html("Rs. " + result.txnAmount);
                $('#bin').html(result.binValue);
                $('#crdType').html(result.cardType);
                $('#isu').html(result.issuer);
                $('#stat').html(result.status);
                $('#emiamt').html("Rs. " + result.emiAmount);
                $('#inrate').html(result.interestRate);
                $('#tenure').html(result.tenure + " months");
                $('#txnTime').html(result.txnTime);
                $('#emiconverted').html(result.emiConverted);
                $('#comment').html(result.comment);

                normalButton.classList.remove("d-none");
                loaderButton.classList.add("d-none");
                $('#modal-default').html(output).modal('show');
             
                
            }
        });
    });

    $(".no-special-char").keypress(function (event) {
        var character = String.fromCharCode(event.keyCode);
        return isValid(character);
    });

    // For dropdown
    $('.select2').select2();
});