$(document).ready(function () {

    // DataTable
    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    // getting contextPath
    var myContextPath=$("#app_context_path").attr('content') ;

    var table = $('#table_id').DataTable({
        "processing": true,
        "serverSide": true,
        //"scrollY": $(document).height() - 400,
        "scrollCollapse": true,
        "paging": true,
        "dom": `
        	"<'row'<'col-sm-12 col-md-12'l>>" +
			"<'row'<'col-sm-12'tr>>" +
			"<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
        `,
        "ajax": {
            "headers": {

            },
            "url": myContextPath + "/program/view-active",
            "contentType": "application/json",
            "type": "POST",
            "timeout":"60000",
            "data": function (d) {
                return JSON.stringify(d);
            },
            "beforeSend": function (request) {
                request.setRequestHeader(header, token);
            },
            "error": function (xhr, error, code) {

                if (error === 'parsererror' || error === 'timeout' || error === 'error') {
                    window.location.href = myContextPath + "/login?invalid";
                }
            }
        },
        "columns": [
            { "data": 'programName' },
            { "data": 'programCode' },
            { "data": 'programPriority' },
            { "data": 'programStartTime' },
            { "data": 'programEndTime' },
            { "data": 'programDescription' }
        ]
    });

    // Apply the search
    table.columns().every(function () {
        var that = this;

        $('input', this.footer()).on('keyup change clear', function () {
            if (that.search() !== this.value) {
                that
                    .search(this.value)
                    .draw();
            }
        });
    });
});
//validation for numeric input search field
function isNumber(event) {
    var keycode = event.keyCode;
    if (keycode > 47 && keycode < 57) {
        return true;
    }
    return false;
}