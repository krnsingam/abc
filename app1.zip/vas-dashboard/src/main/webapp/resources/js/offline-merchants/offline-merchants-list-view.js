$(document).ready(function(){
	
	
	/////////Start DataTable implementation////////
	
    //hide data-table while page is rendering for the first time 	
	$("#merchant_table_body").hide();
	$("#merchant_terminal_table_body").hide();
	$("#setBulkOfflineKey").hide();
	$("#setOfflineKey").hide();
	
	 var token = $('#_csrf').attr('content');
	 var header = $('#_csrf_header').attr('content');
	 
	 // getting contextPath
	 var myContextPath=$("#app_context_path").attr('content') ;
	 console.log(myContextPath);
	
	 //data to be post on search
	 var postdata = {};
	 
	 // Data Table ajax call and storing the value in table
	    var table = $('#merchant_table').DataTable({
	    	"processing": true,
	        "serverSide": true,
	        "scrollCollapse": true,
	        "paging": true,
	        "dom": "Brtip",
		    "buttons": [
                   'excel'
		            
		    ],
	        "ajax": {
	            "url": myContextPath + "/offlinemerchants/offline-merchants-list",
	            "contentType": "application/json",
	            "type": "POST",
	            "timeout":"60000",
	            "data": function (d) {
	            	postdata.dtRequest = d;
	                postdata.merchantName = $("#merchantName").val();
	                postdata.merchantCode = $("#merchantCode").val();
	                return JSON.stringify(postdata);
	            },
	            "beforeSend": function (request) {
	                request.setRequestHeader(header, token);
	            },
	            "error": function (xhr, error, code) {

					if (error === 'parsererror') {
						window.location.href = myContextPath + "/login?invalid";
					}
				}
	        },
	        "columns": [

	        	 { "data": "merchantId",
		            "render": function (data, type, row, meta) {
		            	return '<input type="radio" name="merchantId" value="'+row.merchantId+'" />';
		            }
		         },
	            { "data": 'merchantName' },
	            { "data": 'noOfTerminals' },
	            { "data": "merchantId",
		            "render": function (data, type, row, meta) {
		            	return '<button type="button" class="btn btn-xs btn-primary showTerminalList" data-merchantid="'+row.merchantId+'" title="View"><i class="fa fa-eye " ></i></button>';
		            }
		         },
	        ],
	        "order": [[1, "asc"]]
	    });
	    
	    $('#setBulkOfflineKey').click(function(event){
	        
	    	if ($("input:radio[name=merchantId]").is(":checked")) 
	    	{
	    		event.preventDefault();
	    		var merchantId = $("input:radio[name=merchantId]:checked").val();
	            $form = $("<form action='"+myContextPath+"/offlinemerchants/set-bulk-offline-key' method='post'></form>");
	            $form.append("<input type='_csrf' name='_csrf' value='" + $("#_csrf").attr('content') + "'>");
	            $form.append("<input type='hidden' name = 'merchantId' value='" + merchantId + "'>");
	            $('body').append($form);
	            $form.submit();
	    	}
	    	else
	    	{
	    		bootbox.dialog({
 			       message : '<div class="text-danger text-center">Please select merchant</div>',
 					closeButton: true
 				});
	    	}
	    });
	
	    // Data Table ajax call and storing the value in table
		 var table = $('#merchant_terminal_table').DataTable({
		    	"processing": true,
		        "serverSide": true,
		        "scrollCollapse": true,
		        "paging": true,
		        "dom": "Brtip",
			    "buttons": [
	                   'excel'
			            
			    ],
		        "ajax": {
		            "url": myContextPath + "/offlinemerchants/offline-merchant-terminal-list",
		            "contentType": "application/json",
		            "type": "POST",
		            "timeout":"60000",
		            "data": function (d) {
		            	postdata.dtRequest = d;
		                postdata.merchantId = $("#merchantId").val();
		                return JSON.stringify(postdata);
		            },
		            "beforeSend": function (request) {
		                request.setRequestHeader(header, token);
		            },
		            "error": function (xhr, error, code) {

						if (error === 'parsererror') {
							window.location.href = myContextPath + "/login?invalid";
						}
					}
		        },
		        "columns": [

		       	 { "data": "terminalId",
		       		"render": function (data, type, row, meta) {
	            		
	            		if (data != "" || data != null) {
	            		    if(row.offlineKey == null){
	            		    	data = '<input type="radio" name="terminalId" value="'+row.terminalId+'"/>';
	            		    }else{	
	            			    data ="";
	            		    }
	            		}
	            		return data;
		       		}
		       	 },
			         { "data": 'terminalId' },
			         { "data": 'userId' },
			         { "data": 'offlineKey' },      
		       ],
		        "order": [[1, "asc"]]
		    });

		 $(document).on('click','.showTerminalList',function(){	

			var  merchantId= $(this).data('merchantid')
		   	$("#merchantId").val(merchantId);
		   	$("#merchant_table_body").hide();
		 	$("#terminal_table_body").hide();
		 	$("#setBulkOfflineKey").hide();
	    	$("#merchant_terminal_table_body").show();
			$('#merchant_terminal_table').dataTable().fnFilter();
			$("#setOfflineKey").show();
	     
	      });
	    
	    
	    //on search , showing the data in table
	    $("#searchByMerchant").on("click",function (event) {
	 
	    	var alphanumericRegex = /^[a-zA-Z0-9]+$/;
	    	$("#userId_error").text("");
			$("#terminalId_error").text("");
	    	
	    	if ($.trim($("#merchantName").val()) == "" && $.trim($("#merchantCode").val()) == "") {
	    		
	    			bootbox.dialog({
	    			       message : '<div class="text-danger text-center">Please enter Merchant name or Merchant Code</div>',
	    					closeButton: true
	    				});
	   
				$("#merchantCode_error").text("");
				return false;
				
			}else if($.trim($("#merchantCode").val()) != "" && !alphanumericRegex.test($("#merchantCode").val())){
			
				$("#merchantCode_error").text("Please enter valid merchant code");
	    		return false;
	    		
	    	}else {
	    		$("#merchantCode_error").text("");
			}
	    	
	    	$("#merchant_terminal_table_body").hide();
	    	$("#terminal_table_body").hide();
	    	$("#setOfflineKey").hide();
	    	$("#merchant_table_body").show();
			$('#merchant_table').dataTable().fnFilter();
			$("#setBulkOfflineKey").show();
			
	    });
	   
	/////////End DataTable implementation////////

	    //time for alert error message to be shown
	    setTimeout(function () {
			$(".alert").alert('close');
		}, 4000);
	    
});