$(document).ready(function(){
	
	$("#terminal_table_body").hide();
	
	 var token = $('#_csrf').attr('content');
	 var header = $('#_csrf_header').attr('content');
	 
	 // getting contextPath
	 var myContextPath=$("#app_context_path").attr('content') ;
	 
	 //data to be post on search
	 var postdata = {};
	 
	 // Data Table ajax call and storing the value in table
	 var table = $('#terminal_table').DataTable({
	    	"processing": true,
	        "serverSide": true,
	        "scrollCollapse": true,
	        "paging": true,
	        "dom": "Brtip",
		    "buttons": [
                   'excel'
		            
		    ],
	        "ajax": {
	            "url": myContextPath + "/offlinemerchants/offline-terminal-list",
	            "contentType": "application/json",
	            "type": "POST",
	            "timeout":"60000",
	            "data": function (d) {
	            	postdata.dtRequest = d;
	                postdata.userId = $("#userId").val();
	                postdata.terminalId = $("#terminalId").val();
	                return JSON.stringify(postdata);
	            },
	            "beforeSend": function (request) {
	                request.setRequestHeader(header, token);
	            },
	            "error": function (xhr, error, code) {

					if (error === 'parsererror') {
						window.location.href = myContextPath + "/login?invalid";
					}
				}
	        },
	        "columns": [

	        	 { "data": "terminalId",
			       	"render": function (data, type, row, meta) {
		            		
		            if (data != "" || data != null) {
		            	if(row.offlineKey == null){
		            		  data = '<input type="radio" name="terminalId" value="'+row.terminalId+'" />';
		            	 }else{	
		            		 	data ="";
		            		   }
		            	}
		            	return data;
			       	}
			     },     
			     { "data": 'terminalId' },
		         { "data": 'userId' },
		         { "data": 'offlineKey' },      
	       ],
	        "order": [[1, "asc"]]
	    });
		
	    //on searchbymerchant, showing the data in table
    $("#searchByTerminal").on("click",function (event) {
 
    	var alphanumericRegex = /^[a-zA-Z0-9]+$/;
    	var digitRegex = /^[0-9]+$/;
    	
    	$("#merchantCode_error").text("");

    	if ($.trim($("#userId").val()) == "" && $.trim($("#terminalId").val()) == "") {
    		
    			bootbox.dialog({
    			       message : '<div class="text-danger text-center">Please enter UserId or TerminalId</div>',
    					closeButton: true
    				});
   
    			$("#userId_error").text("");
    			$("#terminalId_error").text("");
    	    	return false;
			
		}else if($.trim($("#userId").val()) != "" && !alphanumericRegex.test($("#userId").val())){
		
			$("#userId_error").text("Please enter valid UserId");
			$("#terminalId_error").text("");
    		return false;
    		
    	}else if($.trim($("#terminalId").val()) != "" && !digitRegex.test($("#terminalId").val())){
		
			$("#userId_error").text("");
			$("#terminalId_error").text("Please enter valid TerminalId");
    		return false;
    		
    	} else {
    		
    		$("#userId_error").text("");
			$("#terminalId_error").text("");			
		}
    	
    	$("#merchant_table_body").hide();
    	$("#merchant_terminal_table_body").hide();
    	$("#merchant_table_body").hide();
    	$("#terminal_table_body").show();
		$('#terminal_table').dataTable().fnFilter();
		$("#setOfflineKey").show();
    });
    
    $('#setOfflineKey').click(function(event){
        
    	if ($("input:radio[name=terminalId]").is(":checked")) 
    	{
    		event.preventDefault();
    		var terminalId = $("input:radio[name=terminalId]:checked").val();
            $form = $("<form action='"+myContextPath+"/offlinemerchants/set-offline-key' method='post'></form>");
            $form.append("<input type='_csrf' name='_csrf' value='" + $("#_csrf").attr('content') + "'>");
            $form.append("<input type='hidden' name = 'terminalId' value='" + terminalId + "'>");
            $('body').append($form);
            $form.submit();
    	}
    	else
    	{
    		bootbox.dialog({
			       message : '<div class="text-danger text-center">Please select terminal user</div>',
					closeButton: true
				});
    	}
    });
});