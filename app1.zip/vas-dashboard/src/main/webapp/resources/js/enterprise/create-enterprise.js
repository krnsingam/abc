$(document).ready(function () {

	var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
	 var myContextPath = $("#app_context_path").attr('content');
	
	$.validator.addMethod("AlphaNumericWithSpaceValidation", function (value, element) {
		return this.optional(element) || /^[a-zA-Z\d]+((\s)*[a-zA-Z\d])*$/.test(value);
	}, 'Special character not allowed!');
	
	$.validator.addMethod("AlphaNumericWithSpacialCharactersValidation", function (value, element) {
		return this.optional(element) || /[a-zA-Z0-9~`!@#$%\^&*()+=\-\[\]\\'.;,/{}|\\":<>\?]/g.test(value);
	}, ' Space not allowed !');
	
	$.validator.addMethod("MobileValidation", function (value, element) {
		return this.optional(element) || /^(\+\d{1,3}[- ]?)?\d{10}$/.test(value);
	}, ' Not a Mobile number !');
	
	$.validator.addMethod("AlphaNumericWithOutSpaceValidation", function (value, element) {
		return this.optional(element) || /^[a-zA-Z0-9]*$/.test(value);
	}, 'Space not allowed between characters!');
	
	$.validator.addMethod("EmailValidation", function (value, element) {	
		return this.optional(element) || /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/.test(value);
	}, 'Please enter valid email');

	$.validator.addMethod("URLValidation", function (value, element) {
		return this.optional(element) || /^(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})$/.test(value);
	}, 'This is not valid url');

	$("#createAPIGroup").validate({
		onClick : true,

		errorElement: 'span',
		errorClass: 'help-block error-border',
		
		highlight: function (element, errorClass, validClass) {

			$(element).closest('.form-group').addClass("has-error");
			$(element).closest('.form-control').addClass("error-border");

		},
		unhighlight: function (element, errorClass, validClass) {
			$(element).closest('.form-group').removeClass("has-error");
			$(element).closest('.form-control').removeClass("error-border");

		},
	rules : {
		name : {
			required : true,
			AlphaNumericWithSpaceValidation :true,
			maxlength : 150 
		},
		mobile : {
			MobileValidation :true,
			maxlength : 20 
		},
		landmark : {
			AlphaNumericWithOutSpaceValidation :false,
			maxlength : 100
		},
		address1 : {
			required : true,
			maxlength : 250
		},
		addressL2 : {
			maxlength : 250
		},
		pin : {
			required : true,
			maxlength : 10
		},
		country : {
			required : true,
		},
		state : {
			required : true,
		},
		city : {
			required : true,
		}
		}	
	});
	
    $("#country").change(function () {
    	
    	var html ="";
    	 $.ajax({
	            url: myContextPath+'/enterprise/state',
	            contentType: "application/json",
	            type: "POST",
	            data: JSON.stringify({ id : this.value}),
	            dataType: 'json',
	            beforeSend: function (request) {
	                request.setRequestHeader(header, token);
	            }, success: function (result) {
	            	$.each(result, function(k, v) {
		                   html +=' <option id="stateid" value="'+v.id+'"> '+v.name+' </option>';
		                });
	            	$("#state").html(html).show();
	            }
	        });

    });
	  // to view state details
    $("#state").change(function () {
    	
    	var html ="";
	        $.ajax({
	            url: myContextPath+'/enterprise/city',
	            contentType: "application/json",
	            type: "POST",
	            data: JSON.stringify({ id : this.value}),
	            dataType: 'json',
	            beforeSend: function (request) {
	                request.setRequestHeader(header, token);
	            }, success: function (result) {
	            	$.each(result, function(k, v) {
		                   html +=' <option id="stateid" value="'+v.id+'"> '+v.name+' </option>';
		                });
	            	$("#city").html(html).show();
	            }
	        });
    
    });
    
    

});

$(document).ready(function () {
	  $( "#message" ).fadeOut( 2000 );
	  
	  $(".no-special-char").keypress(function (event) {
	        var character = String.fromCharCode(event.keyCode);
	        return isValid(character);
	    });
	  
	  // No special char control handler
	    function isValid(str) {
	        return !/[~`!@#$%\^&*()+=\-\[\]\\'.;,/{}|\\":<>\?]/g.test(str);
	    }
});
