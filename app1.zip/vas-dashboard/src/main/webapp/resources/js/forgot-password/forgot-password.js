$(document).ready(function () {

    // Responsible for closing the alert for forgot password
    $("#forgot-password").alert();
    window.setTimeout(function () {
        $("#forgot-password").alert('close');
    }, 1000);


    // jQuery validation starts here
    $(function () {

        // Initializing the form validation on the forgot-password form
        $("form[name='f']").validate({

            // Specifying the validation rules
            rules: {
                username: { // forgot-password has input field with `name` attribute
                    required: true, // It must be required
                    email: true // email must be validated by the built in `email` rule
                }
            },

            messages: { // Validation error messages
                username: {
                    required: "Please provide email address",
                    email: "Please enter a valid email address"
                }
            },

            // This function is called when the form has passed all the validation rules.
            submitHandler: function (form) {
                form.submit(); // Submitting the form, as form is now valid.
                var normalButton = document.getElementById('normal-button');
                var loaderButton = document.getElementById('loader-button');

                normalButton.classList.add("d-none");
                loaderButton.classList.remove("d-none");
            }

        });

    });

    // jQuery validation ends here

});
