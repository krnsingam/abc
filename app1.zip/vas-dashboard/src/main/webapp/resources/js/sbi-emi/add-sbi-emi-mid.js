$(document).ready(function() {
	
	// $('html, body').animate({ scrollTop: 0 }, 'fast');
	 
	jQuery.validator.addMethod("numberValidation", function (value, element) {
	    return this.optional(element) || /^[0-9]*$/.test(value);
	}, 'Please Enter Only Numeric Value!');
	
	
	jQuery.validator.addMethod("AlphaNumeric", function (value, element) {
	    return this.optional(element) || /^[ A-Za-z0-9]*$/.test(value);
	}, 'Special Character Not Allowed!');
	
	jQuery.validator.addMethod("AllLetter", function (value, element) {
	    return this.optional(element) || /^[ A-Z a-z]*$/.test(value);
	}, 'Please Enter Only Character !');
	
	jQuery.validator.addMethod("vpaValidation", function (value, element) {
	    return this.optional(element) || /^[ A-Za-z0-9_.@]*$/.test(value);
	}, 'Invalid character found!');
	
	jQuery.validator.addMethod("decimalValidation", function (value, element) {
		console.log(value)
		if(value == ''){
			return true;
		}
		if(value > 0 && value <= 100.00){
			return this.optional(element) || /^[0-9]+(\.[0-9]{1,2})?$/.test(value);	
		}
	},'Number(1 to 100) with 2 decimal places\!');
	
	jQuery("#addMidDetails").validate({
	onClick:false,
	rules : {
		mPosMerchantId : {
			required : true,
			maxlength:45,
			AlphaNumeric :true,
		},
		merchantName : {
			required : true,
			maxlength:45,
			AlphaNumeric :true,
		},
		merchantCity : {
			required : true,
			maxlength:45,
			AllLetter :true,
		}
	},
	errorPlacement: function(error, element) {		         
          error.insertAfter(element);	         
    }

	});
});