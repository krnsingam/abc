$(document).ready(function () {
	
	$("#dataTableBody").hide();
	$('#card-alerts').show();
	$("#card-alerts").alert();
    
	setTimeout(function () {
		$(".alert").alert('close');
	}, 2000);
	
	 // No special char control handler
    function isValid(str) {
        return !/[~`!@#$%\^&*()+=\[\]\\'.;,/{}|\\":<>\?]/g.test(str);
    }
    
    $(".no-special-char").keypress(function (event) {
        var character = String.fromCharCode(event.keyCode);
        return isValid(character);
    });
	
    // DataTable
    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    var postdata = {};
    
    // Data Table ajax call and storing the value in table.
    var table = $('#sbi-table-id').DataTable({
        "processing": true,
        "serverSide": true,
        "scrollCollapse": true,
        "paging": true,
        "createdRow": function (row, data, index) {
            var info = table.page.info();
            $('td', row).eq(0).html(index + 1 + info.page * info.length);
        },
        "dom": 
        	"<'row'<'col-sm-12 col-md-12'l>>" +
			"<'row'<'col-sm-12'tr>>" +
			"<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
        
        "ajax": {
            "url": "/dashboard/sbi-emi/sbi-emi-mid-tid-list",
            "contentType": "application/json",
            "type": "POST",
            "data": function (d) {

                postdata.dataTableParameters = d;
                postdata.merchantId = $('#merchantId').val();
                postdata.terminalId = $('#terminalId').val();
                postdata.type = $('#type').val();
                
                return JSON.stringify(postdata);
            },
            "beforeSend": function (request) {
                request.setRequestHeader(header, token);
            }
        },
        "columns": [
        	{ "data": 'srNo' },
            { "data": 'mposMerchantCode' },
            { "data": 'sbiMerchantCode' },
            { "data": 'merchantName' },
            { "data": 'merchantCity' },
            { "data": 'status' },
            { "data": 'setupFileStatus' },
            { "defaultContent": '<button type="button" title="Edit" class="btn btn-primary btn-xs mx-auto d-block" data-toggle="modal" data-target="#modal-default" id="update"><i class="fa fa-edit"></i></button>' }
        ],
        "order": [[0, "asc"]]
    });
    
    // search function
    $("#search").on("click", function () {
    	
    	$(".validationAlert").html(" ");
    	
    	if($.trim($("#merchantId").val()) != ''){
		  	
	        if($("#merchantId").val().length>50)
	        {
	        	$("#merchantId_error").html("Maximum 50 characters is allowed");
	    		return false;
	        }
	             
    	}
    	
    	if($.trim($("#terminalId").val()) != ''){
		  	
	        if($("#terminalId").val().length>50)
	        {
	        	$("#terminalId_error").html("Maximum 50 characters is allowed");
	    		return false;
	        }
	             
    	}
    	
    	var selectedType=$( "#type" ).val();
    	
    	if(selectedType==1){
        	$("#dataTableBody").show();
            $('#sbi-table-id').dataTable().fnFilter();
            $("#dataTableBodyTid").hide();
        }
    	
    });
    
    // to EDIT or UPDATE SBI Details
    $("#sbi-table-id tbody").on("click", "#update", function () {
    	var data = table.row($(this).parents("tr")).data();
        console.log(data['sbiId']);
        var sbiId = data['sbiId'];
        $form = $("<form action='/dashboard/sbi-emi/sbi-emi-mid-tid-edit' method='post'></form>");
        $form.append("<input type='hidden' name='_csrf' value='" + $("#_csrf").attr('content') + "'>");
        $form.append("<input type='hidden' name = 'sbiId' value='" + sbiId + "'>");
        $form.append("<input type='hidden' name = 'type' value='1'>");
        $('body').append($form);
       	$form.submit();
    
    });
    
    // For dropdown
   // $('.select2').select2();
    
});
