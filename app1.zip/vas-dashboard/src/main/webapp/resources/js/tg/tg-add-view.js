$(document).ready(function () {
	
	$("#addTg").click(function(e){
		e.preventDefault();
		if(validateTgForm()){
			$("#addTg").attr("disabled",true);
			$("#addNewTg").submit();
		}
	});

	$("#updateTg").click(function(e){

		e.preventDefault();
		if(validateTgForm()){
			$("#updateTg").attr("disabled",true);
			$("#updateCurrentTg").submit();
		}
	})


	function validateTgForm(){
	   
		var response = true;
		var ipv4Regex = /^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/;
		var digitRegex = /^[0-9]+$/;
		var urlRegex = /^(http|https)?:\/\/[a-zA-Z0-9-\.]+\.[a-z]{2,4}/;
		
		$(".validationAlert").text("");
		
		if($.trim($("#tgName").val()) == ""){
			$("#tgName_error").text("Please enter Tg Name");
			response = false;
		}
		
		if($.trim($("#ipAddress").val()) == ""){
			$("#ipAddress_error").text("Please enter Ip Address");
			response = false;
		}
		
		if($.trim($("#ipAddress").val()) != ""){
			if(!ipv4Regex.test($("#ipAddress").val())){
				$("#ipAddress_error").text("Please enter valid Ip Address");
				response = false;
			}
		}
		
		if($.trim($("#port").val()) == ""){
			$("#port_error").text("Please enter Port");
			response = false;
		}
		
		if($.trim($("#port").val()) != ""){
			if(!digitRegex.test($("#port").val())){
				$("#port_error").text("Please enter valid Port");
				response = false;
			}
		}
		
		if($.trim($("#url").val()) == ""){
			$("#url_error").text("Please enter Url");
			response = false;
		}
		
		if($.trim($("#url").val()) != ""){
			if(!urlRegex.test($("#url").val())){
				$("#url_error").text("Please enter valid Url");
				response = false;
			}
		}
		
		if($.trim($("#testIpAddress").val()) == ""){
			$("#testIpAddress_error").text("Please enter Test Ip Address");
			response = false;
		}
		
		if($.trim($("#testIpAddress").val()) != ""){
			if(!ipv4Regex.test($("#testIpAddress").val())){
				$("#testIpAddress_error").text("Please enter valid Test Ip Address");
				response = false;
			}
		}
		
		if($.trim($("#testPort").val()) == ""){
			$("#testPort_error").text("Please enter Test Port");
			response = false;
		}
		
		if($.trim($("#testPort").val()) != ""){
			if(!digitRegex.test($("#port").val())){
				$("#testPort_error").text("Please enter valid Test Port");
				response = false;
			}
		}
		
		if($.trim($("#testUrl").val()) != ""){
			if(!urlRegex.test($("#testUrl").val())){
				$("#testUrl_error").text("Please enter valid Test Url");
				response = false;
			}
		}
		return  response;
	}
	
	setTimeout(function() {
		$(".alert").alert('close');
	}, 4000);

	
});