$(document).ready(function () {
	
	 var token = $('#_csrf').attr('content');
	 var header = $('#_csrf_header').attr('content');
	    // getting contextPath
	 var myContextPath=$("#app_context_path").attr('content') ;
	 
	 var table = $('#tg_table').DataTable({
		   "processing": true,
	        "serverSide": true,
	        "scrollCollapse": true,
	        "paging": true,
	        "dom":
	            "<'row'<'col-sm-12 col-md-12'l>>" +
	            "<'row'<'col-sm-12'tr>>" +
	            "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
	        "ajax": {
	            "url": myContextPath + "/tg/tg-listing",
	            "contentType": "application/json",
	            "type": "POST",
	            "timeout":"60000",
	            "data": function (d) {
                  var postdata = {};
	                postdata.dtRequest = d;
	                return JSON.stringify(postdata);
	            },
	            "beforeSend": function (request) {
	                request.setRequestHeader(header, token);
	            },
	            "error": function (xhr, error, code) {

					if (error === 'parsererror') {
						window.location.href = myContextPath + "/login?invalid";
					}
				}
	        },
	        "columns": [
	            { "data": 'tgName' },
	            { "data": 'ipAddress' },
	            { "data": 'port' },
	            { "data": 'url' },
	            {
	            	"data": "status",
	            	"render": function (data, type, row, meta) {
	            		
	            		if (data != "" || data != null) {
	            		    if(row.status == 'A'){
	            		    	data = "Activate";
	            		    }else{	
	            			    data ="De-Activated";
	            		    }
	            		}
	            		return data;
	            	}
	            },
	            {
	            	"data": "tgId",
	            	"render": function (data, type, row, meta) {
	            		return '<button type="button" class="btn btn-xs btn-primary editTg" title="Edit" data-tgid="'+row.tgId+'"><i class="fa fa-edit"></i></button>';
	            	}
	            },
	        ],	        "order": [[0, "asc"]]
    
    });
	 
	 $(document).on('click','.editTg',function(){	

			var  tgId= $(this).data('tgid')
			 $form = $("<form action='"+myContextPath+"/tg/edit-tg' method='post'></form>");
            $form.append("<input type='_csrf' name='_csrf' value='" + $("#_csrf").attr('content') + "'>");
            $form.append("<input type='hidden' name = 'tgId' value='" + tgId + "'>");
            $('body').append($form);
            $form.submit();
	      });

});