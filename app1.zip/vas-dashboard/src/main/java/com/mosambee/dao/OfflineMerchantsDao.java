package com.mosambee.dao;

import java.util.List;

import com.mosambee.bean.OfflineKeyBean;
import com.mosambee.bean.OfflineMerchantTerminalSearchBean;
import com.mosambee.bean.OfflineMerchantsListBean;
import com.mosambee.bean.OfflineMerchantsSearchBean;
import com.mosambee.bean.OfflineTerminalListBean;
import com.mosambee.bean.OfflineTerminalSearchBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.dao.impl.OfflineMerchantsDaoImpl;

/**
 * OfflineMerchantsDao is specification for {@link OfflineMerchantsDaoImpl}
 * @author mariam.siddique
 * @version 1.0
 * @since 01-April-2020 */

public interface OfflineMerchantsDao {

	DataTablesResponse<OfflineMerchantsListBean> getOfflineMerchantsList(OfflineMerchantsSearchBean dtRequest , String orderingColumnName);

	DataTablesResponse<OfflineTerminalListBean> getOfflineTerminalList(OfflineTerminalSearchBean searchBean , String orderingColumnName);
	
	DataTablesResponse<OfflineTerminalListBean> getOfflineMerchantTerminalList(OfflineMerchantTerminalSearchBean searchBean , String orderingColumnName);
	
	List<OfflineKeyBean> getMerchantsTerminalForOfflineKeySet(long merchantId);
	
	void bulkUpdateOfflineKey(long merchantId, long tableTerminalId, String offlineKey, long createdUserId);
	
	int updateOfflineKey(String terminalId,String offlineKey, long createdUserId);
}
