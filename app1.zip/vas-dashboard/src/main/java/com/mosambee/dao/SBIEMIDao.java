package com.mosambee.dao;

import java.util.Map;

import com.mosambee.bean.AddSbiDetailsMidBean;
import com.mosambee.bean.EditSbiDetailsBean;
import com.mosambee.bean.AddSbiDetailsTidBean;
import com.mosambee.bean.SBIEMIListBean;
import com.mosambee.bean.SBIEMISearchDataTableBean;
import com.mosambee.bean.datatables.DataTablesResponse;

public interface SBIEMIDao {

	String addSBITransaction(AddSbiDetailsMidBean sbiFormBean, long userId);

	String addSBITransactionWithTid(AddSbiDetailsTidBean bean, Long userId);

	DataTablesResponse<SBIEMIListBean> getSBITransactionList(SBIEMISearchDataTableBean dtRequest,
			String orderingColumnName, Map<String, String> searchMap);

	EditSbiDetailsBean getSBIDetailsToEdit(long type, long sbiId);

	String updateSBITransactionList(long type, long sbiId, EditSbiDetailsBean addBeanData);

} 
