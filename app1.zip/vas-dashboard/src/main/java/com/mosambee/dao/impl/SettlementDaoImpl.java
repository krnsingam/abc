package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;

import org.springframework.stereotype.Repository;

import com.mosambee.bean.SettlementBean;
import com.mosambee.bean.SettlementDataTableCrudBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.constants.DateConstants;
import com.mosambee.dao.SettlementDao;

import lombok.extern.log4j.Log4j2;

/**
 * SettlementDaoImpl is used to load the settlement details.
 * 
 * @author rahul.mishra
 * @version 1.0
 * @since 28-02-2020
 */

@Log4j2
@Repository("settlementDao")
public class SettlementDaoImpl implements SettlementDao{
    
	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;
	
	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;

	@Autowired
	@Qualifier("slaveSecurityAndLicenseTemplate")
	private JdbcTemplate slaveSecurityAndLicenseTemplate;

	@Autowired
	@Qualifier("masterSecurityAndLicenseTemplate")
	private JdbcTemplate masterSecurityAndLicenseTemplate;
	
	/**
	 * getSettlementList(...) is responsible for getting the settlement list,
	 * corresponding to the coming data-tables request. Here we have three
	 * parameters, first is the actual {@link SettlementDataTableCrudBean}, second one is the
	 * orderingColumnName in which ordering is going to happen (ASC/DESC). Third one
	 * is a searchMap which is basically a Map of String key and value pairs which
	 * transformed search values for each column in which we are applying
	 * data-tables search.
	 * 
	 * @param dtRequest          {@link SettlementDataTableCrudBean}
	 * @param orderingColumnName {@link String}
	 * @param searchMap          Map with key and value as String
	 */
	@Override
	public DataTablesResponse<SettlementBean> getSettlementList(SettlementDataTableCrudBean dtRequest,String orderingColumnName, Map<String, String> searchMap) {

		String sqlQuery = "{call tsp_web_admin_slave_settlement_getLogs(?,?,?,?,?,?,?,?,?,?,?)}";
		DataTablesResponse<SettlementBean> dtResponse = new DataTablesResponse<>();
		List<SettlementBean> list = new ArrayList<>();

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
            
			callableStatement.setString(1, dtRequest.getSettlementType());
			callableStatement.setInt(2, dtRequest.getDtRequest().getStart());
			callableStatement.setInt(3, dtRequest.getDtRequest().getLength());
			callableStatement.setString(4, orderingColumnName);
			callableStatement.setString(5, dtRequest.getDtRequest().getOrder().get(0).getDir().toString());
			callableStatement.setString(6, dtRequest.getSettlementTypeSearch().trim());
			callableStatement.setString(7, searchMap.get(ColumnNames.SETTLEMENT_FIRSTNAME.get()));
			callableStatement.setString(8, searchMap.get(ColumnNames.SETTLEMENT_REASON.get()));
			callableStatement.setString(9, searchMap.get(ColumnNames.SETTLEMENT_START_TIME.get()));
			callableStatement.setString(10, searchMap.get(ColumnNames.SETTLEMENT_END_TIME.get()));
			
			callableStatement.registerOutParameter(11, java.sql.Types.INTEGER);
			log.info("{}", callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				while (resultSet.next()) {

					SettlementBean bean = SettlementBean.builder().settlementFor(resultSet.getString(1)).initiatedBy(resultSet.getString(2))
							.type(resultSet.getString(6)).startTime(dateTimeConveter(resultSet.getString(4)))
							.endTime(dateTimeConveter(resultSet.getString(5))).reason(resultSet.getString(3)).build();

					list.add(bean);
				}

				log.info("Size of settlement list is: {}", list.size());

				int totalRecordCount = callableStatement.getInt(11);
				log.info("totalRecordCount is: {}", totalRecordCount);
				dtResponse.setData(list);
				dtResponse.setRecordsFiltered(totalRecordCount);
				dtResponse.setRecordsTotal(totalRecordCount);
			}

		} catch (Exception e) {
			log.error("Exception occurred in getSettlementList {}", e);
			return null;
		}

		return dtResponse;
	}
	
	/**
	 * dateTimeConveter is used to convert date from mysql format to our required format
	 * @param date
	 * @return
	 */
	public String dateTimeConveter(String date) {
		log.info("Date : {}", date);
		String responseDate="";
		if(date != null && !date.isEmpty()) {
			SimpleDateFormat settlementDatetime = new SimpleDateFormat(DateConstants.DD_MMMM_YY_HH_MM_SS.get());
			SimpleDateFormat mySettlementDatetime = new SimpleDateFormat(DateConstants.YYYY_MM_DD_HH_MM_SS.get());
		
			try {
				responseDate = settlementDatetime.format(mySettlementDatetime.parse(date));
			} catch (ParseException e) {
				log.info(e.getMessage());
			}
		}
		return responseDate;
	}
	
	/**
	 * createSettlementLog is used to create settlement logs
	 * @param long merchantId, long mmutId, int time,long userId, String reason, String settelementType
	 * @return long
	 */
	@Override
	public long createSettlementLog(long merchantId, long mmutId, int time,String userId, String reason, String settelementType) {
		
		String sql = "{ call tsp_web_admin_master_settlement_createLog(?,?,?,?,?,?,?) }";
		long id = 0;
		try(Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setLong(1, merchantId);
			callableStatement.setLong(2, mmutId);
			callableStatement.setInt(3, time);
			callableStatement.setString(4, userId);
			callableStatement.setString(5, reason);
			callableStatement.setString(6, settelementType);

			callableStatement.registerOutParameter(7, java.sql.Types.BIGINT);
			callableStatement.execute();

			id = callableStatement.getLong(7);

			log.info("createSettlementLog Callable Statement: " + callableStatement);

		} catch (Exception ex) {
			log.error(ex);
		} 

		return id;
	}
	
	/**
	 * getMMUTIDByTime is used to get MMUTIDByTime
	 * @param int time
	 * @return List<Long> mmutidlList
	 */
	@Override
	public List<Long> getMMUTIDByTime(int time) {

		List<Long> mmutidlList = new ArrayList<>();
		String sql = "{ call tsp_web_admin_slave_getTxnForSettlement(?) }";
		try(Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setLong(1, time);

			try(ResultSet rs = callableStatement.executeQuery()){


				log.info("getMMUTIDByTime Callable Statement: " + callableStatement);
	
				while (rs.next()) {
					mmutidlList.add(rs.getLong(1));
				}
			
			}

		} catch (Exception ex) {
			log.error(ex);
		}

		return mmutidlList;
	}
	
	/**
	 * updateSettlementLog is used to update settlement logs
	 * @param long id
	 * @return void
	 */
	@Override
	public void updateSettlementLog(long id) {
		
		String sql = "{call tsp_web_admin_master_settlement_updateLog(?)}";

		try(Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setLong(1, id);
			int result = callableStatement.executeUpdate();
			if(result>0) {
			log.info("Callable Statement: " + callableStatement);
			log.info("updateed successfuly");
			}
			else {
				log.info("failed to update the data");
			}
		} catch (Exception ex) {
			log.error(ex);
		} 
	}
}
