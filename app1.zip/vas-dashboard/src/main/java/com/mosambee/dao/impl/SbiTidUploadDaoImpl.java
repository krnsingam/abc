package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.SBITidUploadBean;
import com.mosambee.dao.SbiTidUploadDao;

import lombok.extern.log4j.Log4j2;

/**
 * @author saurabhkant.shukla
 *
 */
@Log4j2
@Repository("sbiTidUploadDao")
public class SbiTidUploadDaoImpl implements SbiTidUploadDao{
	
	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;
	
	/**
	 * uploadSbiTid(...) is responsible to add SBI TID Details in the Database 
	 * 
	 * @param sBITidUploadBean  {@link SBITidUploadBean}
	 * @param userId  			{Long}
	 * @return String
	 */
	@Override
	public String uploadSbiTid(SBITidUploadBean sBITidUploadBean, Long userId) {
		String message=null;
		String sql = " {call tsp_web_admin_master_sbi_addDetailsWithTID(?,?,?,?,?,?,?)}";
		
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setLong(1, userId);
			callableStatement.setString(2, sBITidUploadBean.getMPosMid());
			callableStatement.setString(3, sBITidUploadBean.getMPosTid());
			callableStatement.setString(4, sBITidUploadBean.getSkuName());
			callableStatement.setString(5, sBITidUploadBean.getStoreName());
			callableStatement.setString(6, sBITidUploadBean.getStoreCity());
			
			callableStatement.registerOutParameter(7, java.sql.Types.VARCHAR);
			
			callableStatement.executeQuery();
			
			message = callableStatement.getString(7);
			log.info("message from procedure: {}, callableStatement: {}", message, callableStatement);

		} catch (Exception e) {
			log.error("exeption occured while processing uploadSbiTid(): {}", e);
		}

		return message;
	}

}
