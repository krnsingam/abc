package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.ApiPasswordBean;
import com.mosambee.bean.ApiPasswordDataBean;
import com.mosambee.bean.CreateAPIGroup;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.UpdateAPIPaswordConfigRequestFromList;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.constants.CommonConstants;
import com.mosambee.dao.ApiPasswordDao;

import lombok.extern.log4j.Log4j2;

/**
 * {@link ApiPasswordDaoImpl} is responsible for handling database
 * operations for Api Password. The class is responsible for fetching the active
 * list of Api Password.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 10-January-2020
 */
@Log4j2
@Repository(value = "apiPasswordDao")
public class ApiPasswordDaoImpl implements ApiPasswordDao{

	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;

	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;
	
	private static final String CALLABLE_STATEMENT = "callableStatement : {}";
	
	/**
	 * getActiveApiPassword(...) is responsible for getting the active
	 * Transaction list, corresponding to the coming data-tables request. Here we
	 * have three parameters, first is the actual {@link DataTablesRequest}, second
	 * one is the orderingColumnName in which ordering is going to happen
	 * (ASC/DESC). Third one is a searchMap which is basically a Map of String key
	 * and value pairs which transformed search values for each column in which we
	 * are applying data-tables search.
	 * 
	 * @param dtRequest          {@link DataTablesRequest}
	 * @param orderingColumnName {@link String}
	 * @param searchMap          Map with key and value as String
	 */
	@Override
	public DataTablesResponse<ApiPasswordBean> getActiveApiPassword(ApiPasswordDataBean dtRequest,
			String orderingColumnName, Map<String, String> searchMap) {
		
		String sqlQuery = "{ call tsp_web_admin_slave_getApiPassword(?,?,?,?,?, ?,?,?) }";
		
		DataTablesResponse<ApiPasswordBean> dtResponse = new DataTablesResponse<>();
		List<ApiPasswordBean> list = new ArrayList<>();
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setInt(1, dtRequest.getDataTable().getStart());
			callableStatement.setInt(2, dtRequest.getDataTable().getLength());
			callableStatement.setString(3, orderingColumnName);
			callableStatement.setString(4, dtRequest.getDataTable().getOrder().get(0).getDir().toString());
			callableStatement.setString(5, searchMap.get(ColumnNames.API_PASSWORD_BUSINESS_NAME.get()));
			callableStatement.setString(6, searchMap.get(ColumnNames.API_PASSWORD_MERCHANT_CODE.get()));
			callableStatement.setString(7, searchMap.get(ColumnNames.API_PASSWORD.get()));
			callableStatement.registerOutParameter(8, java.sql.Types.INTEGER);

			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);
				while (resultSet.next()) {

					ApiPasswordBean bean = ApiPasswordBean.builder().id(resultSet.getInt(1))
						.businessName(resultSet.getString(2)).merchantCode(resultSet.getString(3)).apiPassword(resultSet.getString(4))
						.build();

					list.add(bean);
				}

			}

			log.info("Size of active transaction list: {}", list.size());

			int totalRecordCount = callableStatement.getInt(8);

			dtResponse.setData(list);
			dtResponse.setRecordsFiltered(totalRecordCount);
			dtResponse.setRecordsTotal(totalRecordCount);
		} catch (Exception e) {
			log.error("Exception occurred in getActiveTransactionReport {}", e);
			return null;
		}

		dtResponse.setData(list);
		log.info(dtResponse);
		return dtResponse;
	}
	
	/**
	 * This method is used to fetch details of API Password by id. This
	 * method we have used when we want to edit API Password. This
	 * method operates on database : sfn_transaction and table :
	 * merchant.
	 * 
	 * @param updateAPIPaswordConfigRequestFromList : Expect bean of
	 *                                              "{@link UpdateAPIPaswordConfigRequestFromList}"
	 *                                              which is used to get id of API
	 *                                              Password Config.
	 * @param ApiPasswordBean                        : Expect bean of
	 *                                              "{ApiPasswordBean}" in which the
	 *                                              method will store all data of
	 *                                              API Password Config.
	 * @param responseBean                          : Expect bean of
	 *                                              "{@link ResponseBean}" which is
	 *                                              used to set operation status
	 *                                              message. We can use this to to
	 *                                              render data related to status
	 *                                              message to jsp.
	 * @return boolean : Return "True" if record successfully fetched. Return
	 *         "false" if record is not successfully fetched or record not found.
	 * @author karan.singam
	 */
	@Override
	public boolean updateApiPassword(UpdateAPIPaswordConfigRequestFromList updateAPIPaswordConfigRequestFromList,
			ApiPasswordBean createAPIGroup, ResponseBean responseBean) {

		String sqlQuery = "{ call tsp_web_admin_slave_getApiPasswordById(?,?,?) }";

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1, updateAPIPaswordConfigRequestFromList.getId());
			callableStatement.registerOutParameter(2, java.sql.Types.BOOLEAN);
			callableStatement.registerOutParameter(3, java.sql.Types.VARCHAR);

			log.info(CALLABLE_STATEMENT, callableStatement);

			try (ResultSet resultSet = callableStatement.executeQuery();) {
				while (resultSet.next()) {
					createAPIGroup.setId(resultSet.getLong(1));
					createAPIGroup.setBusinessName(resultSet.getString(2));
					createAPIGroup.setMerchantCode(resultSet.getString(3));
					createAPIGroup.setApiPassword(resultSet.getString(4));
					
					String temp = callableStatement.getString(3);
					responseBean.setMsg(temp);
					responseBean.setData(new HashMap<String, Object>());
					responseBean.getData().put("recordId", resultSet.getLong(1));
				}
				if (callableStatement.getBoolean(2)) {
					return true;
				}
			}

		} catch (Exception e) {
			log.error("Error occurred in updateApiPassword() while fetching record : {}", e);
			responseBean.setMsg(CommonConstants.RECORD_INSERTION_FAILED.get());
			return false;
		}
		return false;
	}

	
	/**
	 * This method is used to update record for API Password. This
	 * method operates on database : sfn_transaction and table :
	 * merchant.
	 * 
	 * @param ApiPasswordBean : Expect bean of "{@link CreateAPIGroup}" from which
	 *                       data should be store.
	 * @param updatedBy      : Expect id of user which is responsible for record
	 *                       updating.
	 * @param responseBean   : Expect bean of "{@link ResponseBean}" which is used
	 *                       to set operation status message as well as id of record
	 *                       inserted which we use for update record as well as use
	 *                       this to render data related to status message to jsp.
	 * @return boolean : Return "true" if record updated successfully. Return
	 *         "false" if record update failed due to any reason.
	 * @author karan.singam
	 */
	@Override
	public boolean updateApi(ApiPasswordBean updateApi, ResponseBean responseBean) {
		log.info("APIPasswordConfigDaoImpl  updateAPIGroup() called. ");
		int status;
		String sqlQuery = "{ call tsp_web_admin_master_updateApiPassword(?,?) }";

		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1, updateApi.getId());
			callableStatement.setString(2, updateApi.getApiPassword());

			log.info(CALLABLE_STATEMENT, callableStatement);
			status = callableStatement.executeUpdate();
			if(status>0) {
				return true;
			}
		} catch (Exception e) {
			log.error("Error occurred in updateApi() while updating record : {}", e);
			responseBean.setMsg(CommonConstants.RECORD_INSERTION_FAILED.get());
			return false;
		}
		return false;
	}
}
