package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.AcquirerBulkUploadBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.AcquirerBulkUploadDao;

/**This class used to provide implementation for all methods of {@link AcquirerBulkUploadDao}
 * This class responsible for store and fetch record in database.
 * @version 1.0
 * @author karan.singam
 */
@Repository("acquirerBulkUploadDao")
public class AcquirerBulkUploadDaoImpl implements AcquirerBulkUploadDao{

	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;
	

	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;
	
	private static final String  CALLABLE_STATEMENT = "callableStatement : {}";
	
	private static final String  SQL = "{call tsp_web_admin_slave_acqTg_matCode(?,?,?,?,?, ?,?)}";
	
	private static final Logger log = LogManager.getLogger(AcquirerBulkUploadDaoImpl.class);
	
	/** This method is used to get list of Acquirer Bulk Upload.
	 *  This method operates on database : sfn_transaction and table : mapping_acquirer_tg. 
	 *	@param 	dtRequest          : Expect bean  of "{@link DataTablesRequest}" which is used to get constraints for fetching record from database.
	 *	@param 	orderingColumnName : Expect name of column for ordering list data.
	 *	@param 	searchMap   	   : Expecting "{@link Map}<String, String>" which stores the column value for data filter. 
	 *	@return {@link DataTablesResponse<{@link AcquirerBulkUploadBean }>
	 *  @author karan.singam
	 */		
	@Override
	public DataTablesResponse<AcquirerBulkUploadBean> getListOfAcquirer(DataTablesRequest dtRequest,
			String orderingColumnName, Map<String, String> searchMap) {
		
		DataTablesResponse<AcquirerBulkUploadBean> dtResponse = new DataTablesResponse<>();
		List<AcquirerBulkUploadBean> list = new ArrayList<>();
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(SQL)) {

			callableStatement.setInt(1, dtRequest.getStart());
			callableStatement.setInt(2, dtRequest.getLength());
			callableStatement.setString(3, orderingColumnName);
			callableStatement.setString(4, dtRequest.getOrder().get(0).getDir().toString());
			callableStatement.setString(5, searchMap.get(ColumnNames.ACQIRER.get()));
			callableStatement.setString(6, searchMap.get(ColumnNames.ACQ_MAT_CODE.get()));
			callableStatement.registerOutParameter(7, java.sql.Types.INTEGER);
			log.info(CALLABLE_STATEMENT, callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {
				while (resultSet.next()) {
					
					AcquirerBulkUploadBean bean = AcquirerBulkUploadBean.builder().acqId(resultSet.getLong(1)).acquirer(resultSet.getString(2))
							.matcode(resultSet.getString(3)).build();
				
					list.add(bean);
				}

				log.info("Size of active program list is: {}", list.size());

				int totalRecordCount = callableStatement.getInt(7);

				dtResponse.setData(list);
				dtResponse.setRecordsFiltered(totalRecordCount);
				dtResponse.setRecordsTotal(totalRecordCount);
				log.info("totalRecordCount : {} ",totalRecordCount);
			}

		} catch (Exception e) {
			log.error("Exception occurred in getActiveProgramList {}", e);
			return null;
		}

		return dtResponse;
	}
	
	/**
	 * downloadActiveAcquirerList(...) is responsible for fetching data
	 * required for downloading Acquirer List from Mapping_acquirer_tg and
	 * return list of AcquirerBulkUploadBean.
	 * 
	 * @return List<AcquirerBulkUploadBean>
	 */
	@Override
	public List<AcquirerBulkUploadBean> downloadActiveAcquirerList(AcquirerBulkUploadBean report) {

		List<AcquirerBulkUploadBean> list = new ArrayList<>();

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(SQL)) {

			callableStatement.setInt(1, 0);
			callableStatement.setInt(2, 0);
			callableStatement.setString(3, "");
			callableStatement.setString(4, "");
			callableStatement.setString(5, report.getAcquirer().trim());
			callableStatement.setString(6, report.getMatcode().trim());
			callableStatement.registerOutParameter(7, java.sql.Types.INTEGER);
			log.info(CALLABLE_STATEMENT, callableStatement);

			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);

				while (resultSet.next()) {

					AcquirerBulkUploadBean bean = AcquirerBulkUploadBean.builder().acqId(resultSet.getLong(1)).acquirer(resultSet.getString(2))
							.matcode(resultSet.getString(3)).build();
				
					list.add(bean);
				}

				log.info("Size of active transaction list is: {}", list.size());

			}

		} catch (Exception e) {
			log.error("Exception occurred in downloadActiveTransactionReportList {}", e);
			return new ArrayList<>();
		}

		return list;
	}
	
}
