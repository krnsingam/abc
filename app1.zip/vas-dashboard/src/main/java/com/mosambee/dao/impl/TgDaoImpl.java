package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.TgBean;
import com.mosambee.bean.TgCrudBean;
import com.mosambee.bean.TgDataTableRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.dao.TgDao;

import lombok.extern.log4j.Log4j2;

/**
 * {@link TgDaoImpl} is responsible for handling database operations
 * for tg module. The class is responsible for fetching the tg list, adding new tg in database and
 * updating existing tg in database.
 * @author mariam.siddique
 * @version 1.0
 * @since 08-April-2020
 */

@Log4j2
@Repository("tgDao")
public class TgDaoImpl implements TgDao{
	
	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;
	
	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;
	
	/**
	 * getTgList(...) is responsible for getting the tg list,
	 * corresponding to the coming data-tables request. Here we have two
	 * parameters, first is the actual {@link TgDataTableRequestBean}, second one is the
	 * orderingColumnName in which ordering is going to happen (ASC/DESC).
	 * 
	 * @param dtRequest          {@link TgDataTableRequestBean}
	 * @param orderingColumnName {@link String}
	 */
	@Override
	public DataTablesResponse<TgBean> getTgList(TgDataTableRequestBean dtRequest, String orderingColumnName) {
		
		DataTablesResponse<TgBean> dtResponse = new DataTablesResponse<>();
		List<TgBean> list = new ArrayList<>();
		
		String sqlQuery = "{ call tsp_web_admin_slave_getTgList(?,?,?,?,?) }";
		
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setInt(1, dtRequest.getDtRequest().getStart());
			callableStatement.setInt(2, dtRequest.getDtRequest().getLength());
			callableStatement.setString(3, orderingColumnName);
			callableStatement.setString(4, dtRequest.getDtRequest().getOrder().get(0).getDir().toString());
			callableStatement.registerOutParameter(5, java.sql.Types.INTEGER);

			log.info("{}", callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				while (resultSet.next()) {

					TgBean bean = TgBean.builder().tgName(resultSet.getString(1)).ipAddress(resultSet.getString(2))
							.port(resultSet.getInt(3)).url(resultSet.getString(4)).status(resultSet.getString(5))
							.tgId(resultSet.getLong(6)).build();
					list.add(bean);
				}
			}

			log.info("Size of tg list: {}", list.size());

			int totalRecordCount = callableStatement.getInt(5);
			dtResponse.setData(list);
			dtResponse.setRecordsFiltered(totalRecordCount);
			dtResponse.setRecordsTotal(totalRecordCount);
			
		} catch (Exception e) {
			log.error("Exception occurred in getTgList {}", e);
			return null;
		}
		dtResponse.setData(list);
		return dtResponse;
	}

	/**
	 * addTg is used to add new tg
	 * @param tgCrudBean {@link TgCrudBean}
	 * @return boolean
	 */
	@Override
	public boolean addTg(TgCrudBean tgCrudBean) {
		boolean result = true;
		
		String sqlQuery = "{ call tsp_web_admin_master_addNewTg(?,?,?,?,?,?,?) }";
		
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, tgCrudBean.getTgName());
			callableStatement.setString(2, tgCrudBean.getIpAddress());
			callableStatement.setInt(3, tgCrudBean.getPort());
			callableStatement.setString(4, tgCrudBean.getUrl());
			callableStatement.setString(5, tgCrudBean.getTestIpAddress());
			callableStatement.setInt(6, tgCrudBean.getTestPort());
			callableStatement.setString(7, tgCrudBean.getTestUrl());
   
			callableStatement.execute();       
			log.info("add tg {}",callableStatement);
		} catch (Exception e) {
			result = false;
			log.error("Exception occurred in addTg {}", e);
		}
		return result;
	}

	/**
	 * getTgDetails is used to get tg details for edit
	 * @param tgId {@link Integer}
	 * @return TgCrudBean
	 */
	@Override
	public TgCrudBean getTgDetails(int tgId) {
		
		String sqlQuery = "{ call tsp_web_admin_slave_getTgDetailsOnId(?) }";
		
		TgCrudBean tgCrudBean = new TgCrudBean();
		
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setInt(1, tgId);
   
			try(ResultSet rs = callableStatement.executeQuery()){
	
				while (rs.next()) {
					tgCrudBean.setId(tgId);
					tgCrudBean.setTgName(rs.getString(1));
					tgCrudBean.setIpAddress(rs.getString(2));
					tgCrudBean.setPort(rs.getInt(3));
					tgCrudBean.setUrl(rs.getString(4));
					tgCrudBean.setTestIpAddress(rs.getString(5));
					tgCrudBean.setTestPort(rs.getInt(6));
					tgCrudBean.setTestUrl(rs.getString(7));
				}        
			}
			
			log.info("found tg details {} ",tgCrudBean);
		} catch (Exception e) {

			log.error("Exception occurred in getTgDetails {}", e.getMessage());
		}

		return tgCrudBean;

	}

	/**
	 * updateTg is used to update existing tg
	 * @param tgCrudBean {@link TgCrudBean}
	 * @return boolean
	 */
	@Override
	public boolean updateTg(TgCrudBean tgCrudBean) {
		boolean result = true;
		
		String sqlQuery = "{ call tsp_web_admin_master_updateTgById(?,?,?,?,?,?,?,?) }";
		
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, tgCrudBean.getTgName());
			callableStatement.setString(2, tgCrudBean.getIpAddress());
			callableStatement.setInt(3, tgCrudBean.getPort());
			callableStatement.setString(4, tgCrudBean.getUrl());
			callableStatement.setString(5, tgCrudBean.getTestIpAddress());
			callableStatement.setInt(6, tgCrudBean.getTestPort());
			callableStatement.setString(7, tgCrudBean.getTestUrl());
			callableStatement.setLong(8,  tgCrudBean.getId());
   
			callableStatement.execute();  
			log.info("update tg {}",callableStatement);
			
		} catch (Exception e) {
			result = false;
			log.error(" Exception occurred in updateTg {}", e.getMessage());
		}
		
		return result;

	}

}
