package com.mosambee.dao;

import java.util.List;
import java.util.Map;

import com.mosambee.bean.KeyBulkUploadBean;
import com.mosambee.bean.MappingBulkUpload;
import com.mosambee.bean.MerchantKeyBean;
import com.mosambee.bean.MerchantKeyDataBean;
import com.mosambee.bean.MerchantMappingBean;
import com.mosambee.bean.MerchantMappingDataBean;
import com.mosambee.bean.MerchantNameBean;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.datatables.DataTablesResponse;

/**
 * MerchantSpecificDao is specification for {@link MerchantSpecificDaoImpl}
 * 
 * @author karan.singam
 * @version 1.0
 * @since 27-February-2020
 */
public interface MerchantSpecificDao {

	public ResponseBean createMerchantMapping(MerchantMappingBean merchantMapping);
	
	public boolean updateMerchantMapping(MerchantMappingBean merchantMapping, ResponseBean responseBean);
	
	public List<MerchantNameBean> getMerchantName(MerchantNameBean merchantbean);
	
	public DataTablesResponse<MerchantMappingBean> getMerchantMappingView(MerchantMappingDataBean dtRequest,
			String orderingColumnName, Map<String, String> searchMap);
	
	public List<MerchantMappingBean> downloadMerchantMapping(MerchantMappingBean report);
	
	public DataTablesResponse<MerchantKeyBean> getMerchantKey(MerchantKeyDataBean dtRequest,
			String orderingColumnName, Map<String, String> searchMap);
	
	public List<MerchantKeyBean> downloadMerchantKey(MerchantKeyBean report);
	
	public boolean editMerchantKey(MerchantKeyBean merchantKey, ResponseBean responseBean);
	
	public boolean processMappingById(MerchantMappingBean merchantMappingBean, MerchantMappingBean createMapping, ResponseBean responseBean);
	
	public boolean processKeyById(MerchantKeyBean merchantMappingBean, MerchantKeyBean createKey, ResponseBean responseBean);
	
	public void insertBulkUploadData(MappingBulkUpload midBulkUpload);
	
	public void insertKeyBulkUploadData(KeyBulkUploadBean bulkUpload);
	
}
