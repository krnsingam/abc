package com.mosambee.dao;

import java.util.List;
import java.util.Map;

import com.mosambee.bean.NetworkMessagesDataTablesRequestBean;
import com.mosambee.bean.NetworkMessagesDownloadBean;
import com.mosambee.bean.NetworkMessagesListBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.dao.impl.SearchByBillNumberDaoImpl;

/**
 * SearchByBillNumberDao is specification for {@link SearchByBillNumberDaoImpl}
 * @author mariam.siddique
 * @version 1.0
 * @since 27-March-2020 */

public interface NetworkMessagesDao {

	DataTablesResponse<NetworkMessagesListBean> getNetworkMessagesList(NetworkMessagesDataTablesRequestBean dtRequest , String orderingColumnName, Map<String, String> map);
	
	public List<NetworkMessagesDownloadBean> downloadNetworkMessagesList(NetworkMessagesDownloadBean bean);

}
