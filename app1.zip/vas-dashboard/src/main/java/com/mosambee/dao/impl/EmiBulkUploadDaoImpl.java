package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.mosambee.bean.EmiBulkUploadBean;
import com.mosambee.bean.EmiDownloadBean;
import com.mosambee.bean.EmiMidTidBean;
import com.mosambee.bean.EmiSearchDatatablesRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.EmiBulkUploadDao;

/**
 * This class is using for TERMINAL upload
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Repository("emiBulkUploadDao")
public class EmiBulkUploadDaoImpl implements EmiBulkUploadDao {
	private static final Logger log = LogManager.getLogger(EmiBulkUploadDaoImpl.class);

	@Autowired
	@Qualifier("slaveSfnVasTemplate")
	JdbcTemplate slaveSfnVasTemplate;

	@Autowired
	@Qualifier("masterSfnVasTemplate")
	private JdbcTemplate masterSfnVasTemplate;

	/**
	 * uploadEmiMidTid()is responsible for inserting values of emi bulk upload in to
	 * database and getting response corresponding these values
	 * 
	 * @return String
	 */
	@Override
	public String uploadEmiMidTid(EmiBulkUploadBean emiBulkUploadBean, String createdBy) {
		String sqlQuery = "{ call tsp_web_admin_master_addDCEMIMidTid(?,?,?,?,?,?,?) }";
		String response = null;
		try (Connection connection = this.masterSfnVasTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			callableStatement.setString(1, emiBulkUploadBean.getMid());
			callableStatement.setString(2, emiBulkUploadBean.getTid());
			callableStatement.setString(3, emiBulkUploadBean.getCredit());
			callableStatement.setString(4, emiBulkUploadBean.getDebit());
			callableStatement.setString(5, createdBy);
			callableStatement.setString(6, emiBulkUploadBean.getAcquirer());
			callableStatement.registerOutParameter(7, java.sql.Types.INTEGER);
			callableStatement.execute();
			log.info("{}", callableStatement);
			response = callableStatement.getString(7);
			log.info("Response from Db {}", response);

		} catch (Exception e) {
			log.error("Exception occured in uploadEmiMidTid: {}", e);

		}

		return response;
	}

	/**
	 * getEmiSearchList(...) is responsible for getting the emi search list,
	 * corresponding to the coming data-tables request. Here we have three
	 * parameters, first is the actual {@link EmiSearchDatatablesRequestBean},
	 * second one is the orderingColumnName in which ordering is going to happen
	 * (ASC/DESC). Third one is a searchMap which is basically a Map of String key
	 * and value pairs which transformed search values for each column in which we
	 * are applying data-tables search.
	 * 
	 * @param dtRequest          {@link EmiSearchDatatablesRequestBean}
	 * @param orderingColumnName {@link String}
	 * @param searchMap          Map with key and value as String
	 */
	@Override
	public DataTablesResponse<EmiMidTidBean> getEmiSearchList(EmiSearchDatatablesRequestBean dtRequest,
			String orderingColumnName, Map<String, String> searchMap) {
		String sql = "{call tsp_web_admin_slave_getEmiSearchList(?,?,?,?,?, ?,?,?,?,?, ?,?)}";
		DataTablesResponse<EmiMidTidBean> dtResponse = new DataTablesResponse<>();
		List<EmiMidTidBean> list = new ArrayList<>();

		try (Connection connection = this.slaveSfnVasTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {
			log.info("{}", callableStatement);
			callableStatement.setString(1, dtRequest.getFromDate());
			callableStatement.setString(2, dtRequest.getToDate());
			callableStatement.setString(3, searchMap.get(ColumnNames.ACQUIRER.get()));// acquirer
			callableStatement.setString(4, searchMap.get(ColumnNames.MERCHANT_CODE.get()));// mid
			callableStatement.setString(5, searchMap.get(ColumnNames.TID.get()));// tid
			callableStatement.setString(6, searchMap.get(ColumnNames.CREDIT.get()));// credit
			callableStatement.setString(7, searchMap.get(ColumnNames.DEBIT.get()));// debit
			callableStatement.setInt(8, dtRequest.getDtRequest().getStart());
			callableStatement.setInt(9, dtRequest.getDtRequest().getLength());
			callableStatement.setString(10, orderingColumnName);
			callableStatement.setString(11, dtRequest.getDtRequest().getOrder().get(0).getDir().toString());
			callableStatement.registerOutParameter(12, java.sql.Types.INTEGER);

			log.info("{}", callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {
				log.info("{}", callableStatement);
				while (resultSet.next()) {
					EmiMidTidBean emiMidTidBean = EmiMidTidBean.builder().acquirer(resultSet.getString(1))
							.mid(resultSet.getString(2)).tid(resultSet.getString(3)).credit(resultSet.getString(4))
							.debit(resultSet.getString(5)).createdTime(resultSet.getString(6)).build();
					list.add(emiMidTidBean);

				}
				log.info("Size of emi search List {} ", list.size());
				int totalRecordCount = callableStatement.getInt(12);
				dtResponse.setData(list);
				dtResponse.setRecordsFiltered(totalRecordCount);
				dtResponse.setRecordsTotal(totalRecordCount);

			}

		} catch (Exception e) {
			log.error("Exception occurred in getEmiSearchList: {}", e);
			return null;
		}
		return dtResponse;
	}

	/**
	 * downloadEmiSearchList() is using for download emi search list
	 *
	 */
	@Override
	public List<EmiMidTidBean> downloadEmiSearchList(EmiDownloadBean emiDownloadBean) {
		String sql = "{call tsp_web_admin_slave_getEmiSearchList(?,?,?,?,?, ?,?,?,?,?, ?,?)}";

		List<EmiMidTidBean> list = new ArrayList<>();

		try (Connection connection = this.slaveSfnVasTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setString(1, emiDownloadBean.getFromDate().trim());// fromDate
			callableStatement.setString(2, emiDownloadBean.getToDate().trim());// toDate
			callableStatement.setString(3, emiDownloadBean.getAcquirer().trim());// acquirer
			callableStatement.setString(4, emiDownloadBean.getMid().trim());// cardBin
			callableStatement.setString(5, emiDownloadBean.getTid().trim());// merchantRefNo
			callableStatement.setString(6, emiDownloadBean.getCredit());// bankRefNo
			callableStatement.setString(7, emiDownloadBean.getDebit());// amount
			callableStatement.setInt(8, 0);// start
			callableStatement.setInt(9, 0);// length
			callableStatement.setString(10, "");
			callableStatement.setString(11, "");
			callableStatement.registerOutParameter(12, java.sql.Types.INTEGER);

			try (ResultSet resultSet = callableStatement.executeQuery()) {
				log.info("{}", callableStatement);
				while (resultSet.next()) {
					EmiMidTidBean emiMidTidBean = EmiMidTidBean.builder().acquirer(resultSet.getString(1))
							.mid(resultSet.getString(2)).tid(resultSet.getString(3)).credit(resultSet.getString(4))
							.debit(resultSet.getString(5)).createdTime(resultSet.getString(6)).build();
					list.add(emiMidTidBean);
				}

				log.info("Size of  download emi search    list is: {}", list.size());
			}
		} catch (Exception e) {
			log.error("Exception occurred in downloadEmiSearchList {}", e);
		}
		return list;
	}

}
