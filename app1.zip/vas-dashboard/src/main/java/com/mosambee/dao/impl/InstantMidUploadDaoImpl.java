package com.mosambee.dao.impl;

import com.mosambee.bean.InstantMidUploadBean;
import com.mosambee.dao.InstantMidUploadDao;
import java.sql.CallableStatement;
import java.sql.Connection;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * this class provides specification for {@link InstantMidUploadDao}
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Repository("instantMidUploadDao")
public class InstantMidUploadDaoImpl implements InstantMidUploadDao {

	private static final Logger log = LogManager.getLogger(InstantMidUploadDaoImpl.class);

	@Autowired
	@Qualifier("slaveSfnVasTemplate")
	JdbcTemplate slaveSfnVasTemplate;


	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;

	/**
	 * uploadInstantMid(...) is responsible for adding the posId,tempTid,tempMid,tid
	 * and mid coming from instant mid upload and then the out parameter is response
	 * which is returned from this method.
	 *
	 */
	@Override
	public String uploadInstantMid(InstantMidUploadBean instantMidUploadBean) {
		String sqlQuery = "{ call tsp_web_admin_master_addInstatntMidTid(?,?,?,?,?,?) }";
		String response = null;

		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			callableStatement.setString(1, instantMidUploadBean.getTempMerchantCode());
			callableStatement.setString(2, instantMidUploadBean.getTempTid());
			callableStatement.setString(3, instantMidUploadBean.getMid());
			callableStatement.setString(4, instantMidUploadBean.getTid());
			callableStatement.setString(5, instantMidUploadBean.getPosId());
			callableStatement.registerOutParameter(6, java.sql.Types.INTEGER);
			callableStatement.execute();
			log.info("{}", callableStatement);
			response = callableStatement.getString(6);
			log.info("Response from Db {}", response);

		} catch (Exception e) {
			log.error("Exception occured in uploadInstantMid: {}", e);

		}
		return response;

	}

}
