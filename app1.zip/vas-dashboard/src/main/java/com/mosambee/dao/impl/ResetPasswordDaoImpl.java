package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.ResetPasswordBean;
import com.mosambee.dao.ResetPasswordDao;

import lombok.extern.log4j.Log4j2;

/**
 * ResetPasswordDaoImpl deals with resetting password in the database.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 05-February-2020
 */
@Log4j2
@Repository("resetPasswordDao")
public class ResetPasswordDaoImpl implements ResetPasswordDao {

	@Autowired
	@Qualifier("slaveSecurityAndLicenseTemplate")
	private JdbcTemplate slaveSecurityAndLicenseTemplate;

	@Autowired
	@Qualifier("masterSecurityAndLicenseTemplate")
	private JdbcTemplate masterSecurityAndLicenseTemplate;

	/**
	 * Responsible for updating user password and recordUpdatedDetails in
	 * securityandlicense.users table & securityandlicense.user_change_password
	 * table.<br/>
	 * <br/>
	 * 
	 * We will get String response from stored procedure.
	 * 
	 * @param resetPassword {@link ResetPasswordBean}
	 * @param userId        long
	 */
	@Override
	public String updateNewPassword(String hashedPassword, Long userId) {

		String sqlQuery = "{ call tsp_web_admin_master_updatePassword(?,?,?) }";
		String response = null;

		try (Connection connection = this.masterSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, hashedPassword);
			callableStatement.setLong(2, userId);
			callableStatement.registerOutParameter(3, java.sql.Types.VARCHAR);

			callableStatement.execute();
			response = callableStatement.getString(3);
			log.info("response: {}, callableStatement: {}", response, callableStatement);

		} catch (Exception e) {
			log.error("{}", e);
		}

		return response;

	}

}
