package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.validation.Valid;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.mosambee.bean.EnquiryBean;
import com.mosambee.bean.EnquiryDataTablesRequestBean;
import com.mosambee.bean.EnquiryDateBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.EnquiryReportingDao;
import com.mosambee.transformer.EnquiryReportingTransformer;
import com.mosambee.validator.CommonValidator;

/**
 * this class is responsible for handling database operations for ENQUIRY. The
 * class is responsible for fetching the ENQUIRY list and to view enquiryDetail
 * and to download enquiry detail
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Repository("enquiryReprtingDao")
public class EnquiryReportingDaoImpl implements EnquiryReportingDao {

	private static final Logger log = LogManager.getLogger("EnquiryReportingDaoImpl.class");

	@Autowired
	CommonValidator commonValidator;

	@Autowired
	@Qualifier("slaveSfnVasTemplate")
	private JdbcTemplate slaveSfnVasTemplate;

	@Autowired
	@Qualifier("slaveSecurityAndLicenseTemplate")
	private JdbcTemplate slaveSecurityAndLicenseTemplate;

	@Autowired
	@Qualifier("masterSfnVasTemplate")
	private JdbcTemplate masterSfnVasTemplate;

	@Autowired
	EnquiryReportingTransformer transformer;

	/**
	 * getEnquiryList(...) is responsible for getting the enquiry reporting list,
	 * corresponding to the coming data-tables request. Here we have three
	 * parameters, first is the actual {@link EnquiryDataTablesRequestBean}, second
	 * one is the orderingColumnName in which ordering is going to happen
	 * (ASC/DESC). Third one is a searchMap which is basically a Map of String key
	 * and value pairs which transformed search values for each column in which we
	 * are applying data-tables search.
	 * 
	 * @param dtRequest          {@link EnquiryDataTablesRequestBean}
	 * @param orderingColumnName {@link String}
	 * @param searchMap          Map with key and value as String
	 */
	@Override
	public DataTablesResponse<EnquiryBean> getEnquiryList(@Valid EnquiryDataTablesRequestBean dtRequest,
			String orderingColumnName, Map<String, String> searchMap) {

		String sql = "{call tsp_web_admin_slave_getEnquiryList(?,?,?,?,?, ?,?,?,?,?, ?,?,?,?)}";
		DataTablesResponse<EnquiryBean> dtResponse = new DataTablesResponse<>();
		List<EnquiryBean> list = new ArrayList<>();

		try (Connection connection = this.slaveSfnVasTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {
			log.info("{}", callableStatement);
			callableStatement.setString(1, dtRequest.getFromDate());
			callableStatement.setString(2, dtRequest.getToDate());
			callableStatement.setString(3, searchMap.get(ColumnNames.ENQUIRY_ISSUER.get()));// issuer
			callableStatement.setInt(4, dtRequest.getCardBin());// cardBin
			callableStatement.setString(5, searchMap.get(ColumnNames.ENQUIRY_MERCHANTREFNO.get()));// merchantRefNo
			callableStatement.setString(6, searchMap.get(ColumnNames.ENQUIRY_BANKREFNO.get()));// bankRefNo
			callableStatement.setInt(7, Integer.parseInt(searchMap.get(ColumnNames.ENQUIRY_AMOUNT.get())));// amount
			callableStatement.setInt(8, dtRequest.getDtRequest().getStart());
			callableStatement.setInt(9, dtRequest.getDtRequest().getLength());
			callableStatement.setString(10, searchMap.get(ColumnNames.ENQUIRY_CARDTYPEID.get()));// cardTypeId
			callableStatement.setString(11, orderingColumnName);
			callableStatement.setString(12, dtRequest.getDtRequest().getOrder().get(0).getDir().toString());
			callableStatement.setLong(13, dtRequest.getId());
			callableStatement.registerOutParameter(14, java.sql.Types.INTEGER);

			log.info("{}", callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {
				log.info("{}", callableStatement);
				while (resultSet.next()) {
					EnquiryBean enquiryBean = EnquiryBean.builder().id(resultSet.getLong(1))
							.cardBin(resultSet.getInt(2)).issuer(resultSet.getString(3)).status(resultSet.getString(4))
							.originatorCode(resultSet.getString(5)).bankRefNo(resultSet.getString(6))
							.eligibilityStatus(resultSet.getString(7)).checkEligibilityTime(resultSet.getString(8))
							.orderConfirmationStatus(resultSet.getString(9))
							.orderConfirmationRespondCode(resultSet.getString(10))
							.merchantRefNo(resultSet.getString(11))
							.amount(commonValidator.validationDecimal(resultSet.getString(12)))
							.cardTypeId(resultSet.getString(13)).createdTime(resultSet.getString(14))
							.updatedTime(resultSet.getString(15)).build();
					list.add(enquiryBean);

				}
				log.info("Size of enquiry List {} ", list.size());
				int totalRecordCount = callableStatement.getInt(14);
				dtResponse.setData(list);
				dtResponse.setRecordsFiltered(totalRecordCount);
				dtResponse.setRecordsTotal(totalRecordCount);

			}

		} catch (Exception e) {
			log.error("Exception occurred in getEnquiryList: {}", e);
			return null;
		}
		return dtResponse;
	}

	/**
	 * to download the enquiry-reporting list
	 *
	 */
	@Override
	public List<EnquiryBean> downloadEnquiryReporting(EnquiryDateBean enquiryDateBean) {
		String sqlQuery = "{call tsp_web_admin_slave_getEnquiryList(?,?,?,?,?, ?,?,?,?,?, ?,?,?,?)}";

		List<EnquiryBean> list = new ArrayList<>();
		try (Connection connection = this.slaveSfnVasTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			String cardBin = enquiryDateBean.getCardBin();
			if (cardBin.contentEquals("")) {
				cardBin = "0";
			}
			String id = enquiryDateBean.getId();
			if (id.contentEquals("")) {
				id = "0";
			}
			callableStatement.setString(1, enquiryDateBean.getFromDate());// fromDate
			callableStatement.setString(2, enquiryDateBean.getToDate());// toDate
			callableStatement.setString(3, enquiryDateBean.getIssuer());// issuer
			callableStatement.setInt(4, Integer.parseInt(cardBin));// cardBin
			callableStatement.setString(5, "");// merchantRefNo
			callableStatement.setString(6, "");// bankRefNo
			callableStatement.setInt(7, 0);// amount
			callableStatement.setInt(8, 0);// start
			callableStatement.setInt(9, 0);// length
			callableStatement.setString(10, "");// cardTypeId
			callableStatement.setString(11, "");
			callableStatement.setString(12, "");
			callableStatement.setInt(13, Integer.parseInt(id));// enquiryId
			callableStatement.registerOutParameter(14, java.sql.Types.INTEGER);

			try (ResultSet resultSet = callableStatement.executeQuery()) {
				log.info("{}", callableStatement);
				while (resultSet.next()) {
					EnquiryBean enquiryBean = EnquiryBean.builder().id(resultSet.getLong(1))
							.cardBin(resultSet.getInt(2)).issuer(resultSet.getString(3)).status(resultSet.getString(4))
							.originatorCode(resultSet.getString(5)).bankRefNo(resultSet.getString(6))
							.eligibilityStatus(resultSet.getString(7)).checkEligibilityTime(resultSet.getString(8))
							.orderConfirmationStatus(resultSet.getString(9))
							.orderConfirmationRespondCode(resultSet.getString(10))
							.merchantRefNo(resultSet.getString(11))
							.amount(commonValidator.validationDecimal(resultSet.getString(12)))
							.cardTypeId(resultSet.getString(13)).createdTime(resultSet.getString(14))
							.updatedTime(resultSet.getString(15)).build();

					list.add(enquiryBean);
				}

				log.info("Size of  download enquiry reporting   list is: {}", list.size());
			}
		} catch (Exception e) {
			log.error("Exception occurred in downloadEnquiryReporting {}", e);
		}
		return list;
	}

	/**
	 * API to fetch view the enquiry detail
	 *
	 */
	@Override
	public EnquiryBean viewEnquiryDetail(long id) {

		String sqlQuery = "{call tsp_web_admin_slave_getEnquiryDetail (?)}";

		EnquiryBean bean = null;
		try (Connection connection = this.slaveSfnVasTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1, id);

			try (ResultSet resultSet = callableStatement.executeQuery()) {
				log.info("{}", callableStatement);
				while (resultSet.next()) {
					bean = EnquiryBean.builder().id(resultSet.getInt(1)).cardBin(resultSet.getInt(2))
							.issuer(resultSet.getString(3)).status(resultSet.getString(4))
							.bankRefNo(resultSet.getString(5)).eligibilityStatus(resultSet.getString(6))
							.checkEligibilityTime(resultSet.getString(7))
							.orderConfirmationStatus(resultSet.getString(8))
							.orderConfirmationRespondCode(resultSet.getString(9)).merchantRefNo(resultSet.getString(10))
							.amount(commonValidator.validationDecimal(resultSet.getString(11)))
							.cardTypeId(resultSet.getString(12)).createdTime(resultSet.getString(13))
							.updatedTime(resultSet.getString(14)).build();
				}

			}
		} catch (Exception e) {
			log.error("Exception occurred in viewEnquiryDetail {}", e);
		}
		return bean;
	}

}
