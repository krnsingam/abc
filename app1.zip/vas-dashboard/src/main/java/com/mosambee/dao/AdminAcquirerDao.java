package com.mosambee.dao;

import java.util.Map;

import com.mosambee.bean.AdminAcquirerBean;
import com.mosambee.bean.AdminAcquirerDataTablesRequestBean;
import com.mosambee.bean.AdminAcquirerListBean;
import com.mosambee.bean.AdminAddAcquirerBean;
import com.mosambee.bean.EditAcquirerDetailsBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.dao.impl.AdminAcquirerDaoImpl;

/**
 * AdminAcquirerDao is specification for {@link AdminAcquirerDaoImpl}
 * @author mariam.siddique
 * @author saurabhkant.shukla
 * @version 1.0
 * @since 18-March-2020 */

public interface AdminAcquirerDao {

	DataTablesResponse<AdminAcquirerBean> getAdminAcquirerList(AdminAcquirerDataTablesRequestBean dtRequest , String orderingColumnName, Map<String, String> searchMap);

	Map<Integer, String> getCurrencyList();

	String addNewAcquirer(AdminAddAcquirerBean bean, long userId);

	DataTablesResponse<AdminAcquirerListBean> getSiteAcquirerList(DataTablesRequest dtRequest,
			String orderingColumnName);

	EditAcquirerDetailsBean getSiteAcquirerData(long acqId);

	String updateAcquirer(EditAcquirerDetailsBean updateBeanData, long acqId, long userId);  
 
}
