package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.ForgotPasswordParams;
import com.mosambee.dao.ForgotPasswordDao;

/**
 * Responsible for providing utility methods to check role id and update
 * password corresponding to email address.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 03-February-2020
 */
@Repository("forgotPasswordDao")
public class ForgotPasswordDaoImpl implements ForgotPasswordDao {

	private static final Logger log = LogManager.getLogger(ForgotPasswordDaoImpl.class);

	@Autowired
	@Qualifier("slaveSecurityAndLicenseTemplate")
	private JdbcTemplate slaveSecurityAndLicenseTemplate;

	@Autowired
	@Qualifier("masterSecurityAndLicenseTemplate")
	private JdbcTemplate masterSecurityAndLicenseTemplate;

	/**
	 * Responsible for getting forgot password parameters i.e.
	 * 
	 * @param username String
	 * @return ForgotPasswordParams
	 */
	@Override
	public ForgotPasswordParams getForgotPasswordParams(String username) {

		String sqlQuery = "{ call tsp_web_admin_slave_getForgotPasswordParams(?,?,?,?,?) }";
		ForgotPasswordParams forgotPasswordParams = null;

		try (Connection connection = this.slaveSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, username);
			callableStatement.registerOutParameter(2, java.sql.Types.INTEGER);
			callableStatement.registerOutParameter(3, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(4, java.sql.Types.BIGINT);
			callableStatement.registerOutParameter(5, java.sql.Types.VARCHAR);

			callableStatement.execute();

			log.info("{}", callableStatement);

			forgotPasswordParams = ForgotPasswordParams.builder().username(username).roleId(callableStatement.getInt(2))
					.message(callableStatement.getString(3)).userId(callableStatement.getLong(4))
					.firstName(callableStatement.getString(5)).build();

		} catch (Exception e) {
			log.error("Exception occurred while processing getForgotPasswordParams: {}", e);
		}

		return forgotPasswordParams;
	}

	/**
	 * Responsible for updating password corresponding to the provided database
	 * userId(primary key) and email address.
	 * 
	 * @param userId   long
	 * @param email    String
	 * @param password String
	 * @return boolean
	 */
	@Override
	public boolean updatePasswordCorrespondingToEmailAddress(long userId, String email, String password) {

		String sqlQuery = "{ call tsp_web_admin_master_updatePasswordCorrespondingToEmail(?,?,?) }";
		int updateCount = 0;

		try (Connection connection = this.masterSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1, userId);
			callableStatement.setString(2, email);
			callableStatement.setString(3, password);

			updateCount = callableStatement.executeUpdate();
			log.info("callableStatement: {}, update count: {}", callableStatement, updateCount);

		} catch (Exception e) {
			log.error("Exception occurred while processing updatePasswordCorrespondingToEmailAddress: {}", e);
		}

		return updateCount > 0;
	}

}
