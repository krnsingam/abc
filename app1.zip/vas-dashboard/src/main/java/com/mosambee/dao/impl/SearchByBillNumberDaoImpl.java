package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.BillNumberBean;
import com.mosambee.bean.BillNumberDataTablesRequestBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.dao.SearchByBillNumberDao;

import lombok.extern.log4j.Log4j2;

/**
 * {@link SearchByBillNumberDaoImpl} is responsible for handling database operations
 * for searchbybillnumber module. The class is responsible for fetching the transaction list 
 * based on provided billnumber.
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 23-March-2020
 */

@Log4j2
@Repository("searchByBillNumberDao")
public class SearchByBillNumberDaoImpl implements SearchByBillNumberDao{

	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;

	/**
	 * getBillNumberTransactionList(...) is responsible for getting the transaction list,
	 * corresponding to the coming data-tables request. Here we have three
	 * parameters, first is the actual {@link DataTablesRequest}, second one is the
	 * orderingColumnName in which ordering is going to happen (ASC/DESC). Third one
	 * is a searchMap which is basically a Map of String key and value pairs which
	 * transformed search values for each column in which we are applying
	 * data-tables search.
	 * 
	 * @param dtRequest          {@link DataTablesRequest}
	 * @param orderingColumnName {@link String}
	 * @param searchMap          Map with key and value as String
	 */
	@Override
	public DataTablesResponse<BillNumberBean> getBillNumberTransactionList(BillNumberDataTablesRequestBean dtRequest,
			String orderingColumnName, Map<String, String> searchMap) {
		DataTablesResponse<BillNumberBean> dtResponse = new DataTablesResponse<>();
		
		List<BillNumberBean> list = new ArrayList<>();
		
		String sqlQuery = "{ call tsp_web_admin_slave_getTransactionsByBillNumber(?,?,?,?,?,?) }";
		
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setInt(1, dtRequest.getDtRequest().getStart());
			callableStatement.setInt(2, dtRequest.getDtRequest().getLength());
			callableStatement.setString(3, orderingColumnName);
			callableStatement.setString(4, dtRequest.getDtRequest().getOrder().get(0).getDir().toString());
			callableStatement.setString(5, searchMap.get("billNumber"));
			log.info("{}", callableStatement);
			callableStatement.registerOutParameter(6, java.sql.Types.INTEGER);


			log.info("{}", callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);
				while (resultSet.next()) {

					BillNumberBean bean = BillNumberBean.builder().userName(resultSet.getString(1)).txnType(resultSet.getString(2))
							.terminalId(resultSet.getString(3)).cardNumber(resultSet.getString(4)).rrn(resultSet.getString(5))
							.amount(resultSet.getDouble(6)).txnTime(resultSet.getString(7)).responseCode(resultSet.getString(8))
							.authCode(resultSet.getString(9)).status(resultSet.getString(10)).settlementStatus(resultSet.getString(11))
							.transactionId(resultSet.getLong(12)).build();

					list.add(bean);
				}

			}

			log.info("Size of search by billnumber transaction list: {}", list.size());

			int totalRecordCount = callableStatement.getInt(6);

			dtResponse.setData(list);
			dtResponse.setRecordsFiltered(totalRecordCount);
			dtResponse.setRecordsTotal(totalRecordCount);
		} catch (Exception e) {
			log.error("Exception occurred in getBillNumberTransactionList {}", e);
			return null;
		}

		dtResponse.setData(list);
		log.info(dtResponse);
		return dtResponse;
	}

}
