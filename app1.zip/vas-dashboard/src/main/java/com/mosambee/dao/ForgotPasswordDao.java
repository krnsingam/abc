package com.mosambee.dao;

import com.mosambee.bean.ForgotPasswordParams;

public interface ForgotPasswordDao {

	ForgotPasswordParams getForgotPasswordParams(String email);

	boolean updatePasswordCorrespondingToEmailAddress(long userId, String email, String password);

}
