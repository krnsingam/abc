package com.mosambee.dao;

import com.mosambee.bean.InstantMidUploadBean;

/**
 * This class provides specification for {@link InstantMidUploadDaoImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 */
public interface InstantMidUploadDao {
	String uploadInstantMid(InstantMidUploadBean instantMidUploadBean);

}
