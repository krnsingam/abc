package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.EmiUploadBean;
import com.mosambee.dao.EmiUploadDao;

/**
 * This class is responsible for db operation for emi upload
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
@Repository("emiUploadDao")
public class EmiUploadDaoImpl implements EmiUploadDao {
	private static final Logger log = LogManager.getLogger(EmiUploadDaoImpl.class);

	@Autowired
	@Qualifier("masterSfnVasTemplate")
	private JdbcTemplate masterSfnVasTemplate;

	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;

	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;

	/**
	 * updateEmi() is responsible for validate matcode of acquirer coming in emi
	 * upload field and give response according matcode.
	 * 
	 * @return EmiUploadBean
	 */
	@Override
	public EmiUploadBean updateEmi(EmiUploadBean emiUploadBean) {
		String sqlQuery = "{ call tsp_web_admin_slave_getMatcodeDetails(?,?,?,?,?,?) }";
		EmiUploadBean error = new EmiUploadBean();
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			callableStatement.setString(1, emiUploadBean.getEmiMatCode());
			callableStatement.setString(2, emiUploadBean.getEmiType());
			callableStatement.registerOutParameter(3, java.sql.Types.INTEGER);// acquirer
			callableStatement.registerOutParameter(4, java.sql.Types.INTEGER);// tgName
			callableStatement.registerOutParameter(5, java.sql.Types.INTEGER);// acquirerTgId
			callableStatement.registerOutParameter(6, java.sql.Types.INTEGER);// errorCode
			callableStatement.execute();
			log.info("{}", callableStatement);
			error.setEmiMatCode(emiUploadBean.getEmiMatCode());
			error.setAcquirer(callableStatement.getString(3));
			error.setTgName(callableStatement.getString(4));
			error.setAcquirerTgId(callableStatement.getString(5));
			error.setErrorCode(callableStatement.getInt(6));
			error.setBaseTid(emiUploadBean.getBaseTid());
			error.setBaseMid(emiUploadBean.getBaseMid());
			error.setBrandEmiFlag(emiUploadBean.getBrandEmiFlag());
			error.setEmiSettlement(emiUploadBean.getEmiSettlement());
			error.setCcEmiFlag(emiUploadBean.getCcEmiFlag());
			error.setDcEmiFlag(emiUploadBean.getDcEmiFlag());
			error.setEmi(emiUploadBean.getDcEmiFlag());
			error.setEmiEnquiry(emiUploadBean.getEmiEnquiry());
			error.setEmiProgramEnquiry(emiUploadBean.getEmiProgramEnquiry());
			error.setEmiAllow(emiUploadBean.getEmiAllow());
			error.setEmiVoid(emiUploadBean.getEmiVoid());
			error.setEmiTid(emiUploadBean.getEmiTid());
			error.setEmiMid(emiUploadBean.getEmiMid());
			error.setMosambeeEmi(emiUploadBean.getMosambeeEmi());
			error.setEmiType(emiUploadBean.getEmiType());
			error.setMerchantType(emiUploadBean.getMerchantType());
			error.setUserId(emiUploadBean.getUserId());
			log.info("Response from Db for matcode {}", callableStatement.getInt(6));

		} catch (Exception e) {
			log.error("Exception occured in updateEmi: {}", e);
		}
		return error;
	}

	/**
	 * insertEmiUploadData() is responsible for insert data when acquirer is Atos
	 * 
	 * @return String
	 */
	@Override
	public String insertEmiUploadDataForAtos(EmiUploadBean emiUploadBean) {
		String sql = "{call tsp_web_admin_master_addEMIMidTidAtos(?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?, ?)}";
		String response = null;
		String mosambeeEmi = emiUploadBean.getMosambeeEmi();
		if (mosambeeEmi != null) {
			if (mosambeeEmi.equalsIgnoreCase("TERMINAL")) {
				emiUploadBean.setMosambeeEmi("2");
			} else if (mosambeeEmi.equalsIgnoreCase("MERCHANT")) {
				emiUploadBean.setMosambeeEmi("1");
			} else if (mosambeeEmi.equalsIgnoreCase("NO")) {
				emiUploadBean.setMosambeeEmi("0");
			}
		}				
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {
			callableStatement.setString(1, emiUploadBean.getBaseMid());
			callableStatement.setString(2, emiUploadBean.getBaseTid());
			callableStatement.setString(3, emiUploadBean.getEmiMid());
			callableStatement.setString(4, emiUploadBean.getEmiTid());
			callableStatement.setString(5, emiUploadBean.getAcquirerTgId());
			callableStatement.setString(6, emiUploadBean.getMosambeeEmi());
			callableStatement.setString(7, emiUploadBean.getEmiType());
			callableStatement.setString(8, emiUploadBean.getEmi());
			callableStatement.setString(9, emiUploadBean.getEmiEnquiry());
			callableStatement.setString(10, emiUploadBean.getEmiProgramEnquiry());
			callableStatement.setString(11, emiUploadBean.getEmiVoid());
			callableStatement.setString(12, emiUploadBean.getEmiSettlement());
			callableStatement.setString(13, emiUploadBean.getCcEmiFlag());
			callableStatement.setString(14, emiUploadBean.getDcEmiFlag());
			callableStatement.setString(15, emiUploadBean.getBrandEmiFlag());
			callableStatement.registerOutParameter(16, java.sql.Types.INTEGER);// errorCode
			callableStatement.execute();
			log.info("{}", callableStatement);
			response = callableStatement.getString(16);
			log.info("Response from db for Atos {}", response);
		} catch (Exception e) {
			log.error("Exception occured in insertEmiUploadData: {}", e);
		}
		return response;

	}

	/**
	 * insertEmiUploadDataHDFC() is responsible for insert data when acquirer is
	 * HDFC return String
	 */
	@Override
	public String insertEmiUploadDataForHDFC(EmiUploadBean emiUploadBean) {
		String sql = "{call tsp_web_admin_master_addEMIMidTid(?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?, ?,?,?)}";
		String response = null;
		String mosambeeEmi = emiUploadBean.getMosambeeEmi();
		if (mosambeeEmi != null) {
			if (mosambeeEmi.equalsIgnoreCase("TERMINAL")) {
				emiUploadBean.setMosambeeEmi("2");
			} else if (mosambeeEmi.equalsIgnoreCase("MERCHANT")) {
				emiUploadBean.setMosambeeEmi("1");
			} else if (mosambeeEmi.equalsIgnoreCase("NO")) {
				emiUploadBean.setMosambeeEmi("0");
			}
		}
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {
			callableStatement.setString(1, emiUploadBean.getBaseMid());
			callableStatement.setString(2, emiUploadBean.getBaseTid());
			callableStatement.setString(3, emiUploadBean.getEmiMid());
			callableStatement.setString(4, emiUploadBean.getEmiTid());
			callableStatement.setString(5, emiUploadBean.getAcquirerTgId());
			callableStatement.setString(6, emiUploadBean.getMosambeeEmi());
			callableStatement.setLong(7, emiUploadBean.getMerchantType());
			callableStatement.setString(8, emiUploadBean.getEmiType());
			callableStatement.setString(9, emiUploadBean.getEmi());
			callableStatement.setString(10, emiUploadBean.getEmiEnquiry());
			callableStatement.setString(11, emiUploadBean.getEmiProgramEnquiry());
			callableStatement.setString(12, emiUploadBean.getEmiVoid());
			callableStatement.setString(13, emiUploadBean.getEmiSettlement());
			callableStatement.setString(14, emiUploadBean.getCcEmiFlag());
			callableStatement.setString(15, emiUploadBean.getDcEmiFlag());
			callableStatement.setString(16, emiUploadBean.getBrandEmiFlag());
			callableStatement.setLong(17, emiUploadBean.getUserId());
			callableStatement.registerOutParameter(18, java.sql.Types.INTEGER);// errorCode
			callableStatement.execute();
			log.info("{}", callableStatement);
			response = callableStatement.getString(18);
			log.info("Response from db for hdfc {}", response);
		} catch (Exception e) {
			log.error("Exception occured in insertEmiUploadDataHDFC: {}", e);
		}
		return response;

	}

}
