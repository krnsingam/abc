package com.mosambee.dao;

import com.mosambee.bean.EmiUploadBean;

/**
 * This class provides specification for {@link EmiUploadDaoImpl}}
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
public interface EmiUploadDao {
	EmiUploadBean updateEmi(EmiUploadBean emiUploadBean);

	String insertEmiUploadDataForAtos(EmiUploadBean emiUploadBean);

	String insertEmiUploadDataForHDFC(EmiUploadBean emiUploadBean);

}
