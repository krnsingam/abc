package com.mosambee.dao;

import java.util.List;
import java.util.Map;

import com.mosambee.bean.SettlementBean;
import com.mosambee.bean.SettlementDataTableCrudBean;
import com.mosambee.bean.datatables.DataTablesResponse;

public interface SettlementDao {
	DataTablesResponse<SettlementBean> getSettlementList(SettlementDataTableCrudBean dtRequest,String orderingColumnName, Map<String, String> searchMap);
	public long createSettlementLog(long merchantId, long mmutId, int time,String userId, String reason, String settelementType);
	public List<Long> getMMUTIDByTime(int time);
	public void updateSettlementLog(long id);
}
