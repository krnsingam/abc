package com.mosambee.dao;

import java.util.Map;

import com.mosambee.bean.ActiveProgramBean;
import com.mosambee.bean.ProgramBulkUploadBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.dao.impl.LaunchProgramDaoImpl;

/**
 * LaunchProgramDao is specification for {@link LaunchProgramDaoImpl}
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 20-December-2019
 */
public interface LaunchProgramDao {

	DataTablesResponse<ActiveProgramBean> getActiveProgramList(DataTablesRequest dtRequest, String orderingColumnName,
			Map<String, String> searchMap);

	String addProgramAndGetProgramCode(ProgramBulkUploadBean programBulkUploadBean, String prefixName);

}
