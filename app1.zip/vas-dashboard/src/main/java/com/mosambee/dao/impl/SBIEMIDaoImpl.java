package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.AddSbiDetailsMidBean;
import com.mosambee.bean.EditSbiDetailsBean;
import com.mosambee.bean.AddSbiDetailsTidBean;
import com.mosambee.bean.SBIEMIListBean;
import com.mosambee.bean.SBIEMISearchDataTableBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.SBIEMIDao;

import lombok.extern.log4j.Log4j2;
/**
 * SBIEMIDaoImpl deals with Adding Sbi Details in the database and Fetching the added records from the database.
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 * @since 18-March-2020
 */
@Log4j2
@Repository("sBIEMIDao")
public class SBIEMIDaoImpl implements SBIEMIDao{

	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;
	
	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;
	
	/**
	 * addSBITransaction(...) is responsible to add SBI MID Details in the Database 
	 * 
	 * @param sbiFormBean  		{@link AddSbiDetailsMidBean}
	 * @param userId  			{Long}
	 * @return String
	 */
	@Override
	public String addSBITransaction(AddSbiDetailsMidBean sbiFormBean, long userId) {

		String message="";
		String sql = " {call tsp_web_admin_master_sbi_addDetailsWithMId(?,?,?,?,?)}";
		
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setLong(1, userId);
			callableStatement.setString(2, sbiFormBean.getMPosMerchantId());
			callableStatement.setString(3, sbiFormBean.getMerchantName());
			callableStatement.setString(4, sbiFormBean.getMerchantCity());
			
			callableStatement.registerOutParameter(5, java.sql.Types.VARCHAR);
			
			callableStatement.executeQuery();
			
			message = callableStatement.getString(5);
			log.info("message from procedure: {}, callableStatement: {}", message, callableStatement);

		} catch (Exception e) {
			log.error("exeption occured while processing addSBITransaction(): {}", e);
		}

		return message;
	}

	/**
	 * addSBITransactionWithTid(...) is responsible to add SBI TID Details in the Database 
	 * 
	 * @param bean  		{@link AddSbiDetailsTidBean}
	 * @param userId  		{Long}
	 * @return String
	 */
	@Override
	public String addSBITransactionWithTid(AddSbiDetailsTidBean bean, Long userId) {
		String message="";
		String sql = " {call tsp_web_admin_master_sbi_addDetailsWithTID(?,?,?,?,?,?,?)}";
		
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setLong(1, userId);
			callableStatement.setString(2, bean.getMPosMerchantId());
			callableStatement.setString(3, bean.getMPosTerminalId());
			callableStatement.setString(4, bean.getSkuName());
			callableStatement.setString(5, bean.getStoreName());
			callableStatement.setString(6, bean.getStoreCity());
			
			callableStatement.registerOutParameter(7, java.sql.Types.VARCHAR);
			
			callableStatement.executeQuery();
			
			message = callableStatement.getString(7);
			log.info("message from procedure: {}, callableStatement: {}", message, callableStatement);

		} catch (Exception e) {
			log.error("exeption occured while processing addSBITransactionWithTid(): {}", e);
		}

		return message;
	}

	/**
	 * getSBITransactionList(...) is responsible to add SBI TID Details in the Database 
	 * 
	 * @param dtRequest  				{@link SBIEMISearchDataTableBean}
	 * @param orderingColumnName  		{String}
	 * @param searchMap  				{Map<String, String>}
	 * @return DataTablesResponse<SBIEMIListBean>
	 */
	@Override
	public DataTablesResponse<SBIEMIListBean> getSBITransactionList(SBIEMISearchDataTableBean dtRequest,
			String orderingColumnName, Map<String, String> searchMap) {
		
		DataTablesResponse<SBIEMIListBean> dtResponse = new DataTablesResponse<>();
		List<SBIEMIListBean> list = new ArrayList<>();
		
		String sql = "{call tsp_web_admin_slave_sbi_getTrxnList(?,?,?,?, ?,?,?,?)}";
		int type = Integer.parseInt(searchMap.get(ColumnNames.TYPE.get()));
		
		
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {
			
			log.info("Type: {}",type);
			callableStatement.setInt(1, dtRequest.getDataTableParameters().getStart());
			callableStatement.setInt(2, dtRequest.getDataTableParameters().getLength());
			callableStatement.setString(3, orderingColumnName);
			callableStatement.setString(4, dtRequest.getDataTableParameters().getOrder().get(0).getDir().toString());
			callableStatement.setInt(5, type);
			callableStatement.setString(6, searchMap.get(ColumnNames.MPOS_MID.get()));
			callableStatement.setString(7, searchMap.get(ColumnNames.MPOS_TID.get()));
			callableStatement.registerOutParameter(8, java.sql.Types.INTEGER);
			log.info("callableStatement : {}", callableStatement);
			
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);

				while (resultSet.next()) {

					SBIEMIListBean bean = new SBIEMIListBean();
					
					if (type==1) {
						bean.setSbiId(resultSet.getLong(1));
						bean.setMposMerchantCode(resultSet.getString(2));
						bean.setSbiMerchantCode(resultSet.getString(3));
						bean.setMerchantName(resultSet.getString(4));
						bean.setMerchantCity(resultSet.getString(5));
						int status = resultSet.getInt(6);
						if (status == 1) {
							bean.setStatus("Yes");
						} else {
							bean.setStatus("No");
						}
						log.info("Status: {}", bean.getStatus());
						int setUpFilestatus = resultSet.getInt(7);
						if (setUpFilestatus == 1) {
							bean.setSetupFileStatus("Yes");
						} else {
							bean.setSetupFileStatus("No");
						} 
					}
					else {
						bean.setSbiId(resultSet.getLong(1));
						bean.setMposTerminalId(resultSet.getString(2));
						bean.setSkuName(resultSet.getString(3));
						bean.setStoreName(resultSet.getString(4));
						bean.setStoreCity(resultSet.getString(5));
						
						int tidStatus = resultSet.getInt(6);
						if(tidStatus == 1){
							bean.setTidStatus("Yes");
						}else{
							bean.setTidStatus("No");
						}
						
						int tidSetUpFilestatus = resultSet.getInt(7);
						if(tidSetUpFilestatus == 1){
							bean.setTidSetupFileStatus("Yes");
						}else{
							bean.setTidSetupFileStatus("No");
						}
						
						int skuStatus = resultSet.getInt(8);
						if(skuStatus == 1){
							bean.setSkuStatus("Yes");
						}else{
							bean.setSkuStatus("No");
						}
						
						int skuSetUpFilestatus = resultSet.getInt(9);
						if(skuSetUpFilestatus == 1){
							bean.setSkuSetupFileStatus("Yes");
						}else{
							bean.setSkuSetupFileStatus("No");
						}
					}
					
					list.add(bean);
				}

				log.info("Size of active transaction list is: {}", list.size());
				
				int totalRecordCount = callableStatement.getInt(8);

				dtResponse.setData(list);
				dtResponse.setRecordsFiltered(totalRecordCount);
				dtResponse.setRecordsTotal(totalRecordCount);
				log.info("totalRecordCount : {} ",totalRecordCount);
			}

		}
		catch (Exception e) {
			log.error("Exception occurred in getSBITransactionList {}", e);
			return null;
		}
		
		return dtResponse;
	}

	/**
	 * getSBIDetailsToEdit(...) is responsible to get Details to Edit SBI MID and TID Details
	 * 
	 * @param type  				{long}
	 * @param sbiId  				{long}
	 * @return EditSbiDetailsBean
	 */
	@Override
	public EditSbiDetailsBean getSBIDetailsToEdit(long type, long sbiId) {

		String sql = "{call tsp_web_admin_slave_getSBIDetailsToEdit(?,?)}";
		
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {
			
			callableStatement.setLong(1, type);
			callableStatement.setLong(2, sbiId);

			try (ResultSet resultSet = callableStatement.executeQuery()) {
				log.info("CallableStatement: {}", callableStatement);
				
				while (resultSet.next()) {
					
					if(type==1){
						
						EditSbiDetailsBean midBean = new EditSbiDetailsBean();
						
						midBean.setMerchantName(resultSet.getString(1));
						midBean.setMerchantCity(resultSet.getString(2));
						midBean.setStatus(resultSet.getInt(3));
						log.info("Status: {}",resultSet.getInt(3));
						midBean.setSetupFileStatus(resultSet.getInt(4));
						log.info("SetupFileStatus: {}",resultSet.getInt(4));
						
						return midBean;
						
					}else{
						EditSbiDetailsBean tidBean = new EditSbiDetailsBean();
						
						tidBean.setSkuName(resultSet.getString(1));
						tidBean.setStoreName(resultSet.getString(2));
						tidBean.setStoreCity(resultSet.getString(3));
						tidBean.setTidStatus(resultSet.getInt(4));
						tidBean.setTidSetupFileStatus(resultSet.getInt(5));
						tidBean.setSkuStatus(resultSet.getInt(6));
						tidBean.setSkuSetupFileStatus(resultSet.getInt(7));
						
						return tidBean;
					}
				}
			}

		}
		catch (Exception e) {
			log.error("Exception occurred in getSBIDetailsToEdit {}", e);
			return null;
		}
		
		return null;
	}

	/**
	 * updateSBITransactionList(...) is responsible to Update the Details of SBI MID and TID
	 * 
	 * @param type  				{long}
	 * @param sbiId  				{long}
	 * @param addBeanData  			{@link EditSbiDetailsBean}
	 * @return String
	 */
	@Override
	public String updateSBITransactionList(long type, long sbiId, EditSbiDetailsBean addBeanData) {
		String message="";
		String sql = " {call tsp_web_admin_master_sbi_updateDetails(?,?,?,?,?, ?,?,?,?,?, ?,?,?)}";
		
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setLong(1, type);
			callableStatement.setLong(2, sbiId);
			//MID
			callableStatement.setString(3, addBeanData.getMerchantName());
			callableStatement.setString(4, addBeanData.getMerchantCity());
			callableStatement.setInt(5, addBeanData.getStatus());
			callableStatement.setInt(6, addBeanData.getSetupFileStatus());
			// TID
			callableStatement.setString(7, addBeanData.getSkuName());
			callableStatement.setString(8, addBeanData.getStoreName());
			callableStatement.setString(9, addBeanData.getStoreCity());
			callableStatement.setInt(10, addBeanData.getTidStatus());
			callableStatement.setInt(11, addBeanData.getTidSetupFileStatus());
			callableStatement.setInt(12, addBeanData.getSkuStatus());
			callableStatement.setInt(13, addBeanData.getSkuSetupFileStatus());
			
			callableStatement.executeQuery();
			
			message = "success";
			log.info("message from procedure: {}, callableStatement: {}", message, callableStatement);

		} catch (Exception e) {
			log.error("exeption occured while processing updateSBITransactionList(): {}", e);
		}

		return message;
	}

}
