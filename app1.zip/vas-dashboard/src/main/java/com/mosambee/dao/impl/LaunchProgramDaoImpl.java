package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.ActiveProgramBean;
import com.mosambee.bean.ProgramBulkUploadBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.CommonDao;
import com.mosambee.dao.LaunchProgramDao;

/**
 * {@link LaunchProgramDaoImpl} is responsible for handling database operations
 * for programs. The class is responsible for fetching the active list of
 * programs and batch insert programs.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 20-December-2019
 */
@Repository("launchProgramDao")
public class LaunchProgramDaoImpl implements LaunchProgramDao {

	private static final Logger log = LogManager.getLogger(LaunchProgramDaoImpl.class);

	@Autowired
	@Qualifier("slaveSfnVasTemplate")
	private JdbcTemplate slaveSfnVasTemplate;

	@Autowired
	@Qualifier("slaveSecurityAndLicenseTemplate")
	private JdbcTemplate slaveSecurityAndLicenseTemplate;

	@Autowired
	@Qualifier("masterSfnVasTemplate")
	private JdbcTemplate masterSfnVasTemplate;

	/**
	 * getActiveProgramList(...) is responsible for getting the active program list,
	 * corresponding to the coming data-tables request. Here we have three
	 * parameters, first is the actual {@link DataTablesRequest}, second one is the
	 * orderingColumnName in which ordering is going to happen (ASC/DESC). Third one
	 * is a searchMap which is basically a Map of String key and value pairs which
	 * transformed search values for each column in which we are applying
	 * data-tables search.
	 * 
	 * @param dtRequest          {@link DataTablesRequest}
	 * @param orderingColumnName {@link String}
	 * @param searchMap          Map with key and value as String
	 */
	@Override
	public DataTablesResponse<ActiveProgramBean> getActiveProgramList(DataTablesRequest dtRequest,
			String orderingColumnName, Map<String, String> searchMap) {

		String sqlQuery = "{call tsp_web_admin_slave_getActiveProgramList(?,?,?,?,?,?,?,?,?,?,?)}";
		DataTablesResponse<ActiveProgramBean> dtResponse = new DataTablesResponse<>();
		List<ActiveProgramBean> list = new ArrayList<>();

		try (Connection connection = this.slaveSfnVasTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setInt(1, dtRequest.getStart());
			callableStatement.setInt(2, dtRequest.getLength());
			callableStatement.setString(3, orderingColumnName);
			callableStatement.setString(4, dtRequest.getOrder().get(0).getDir().toString());
			callableStatement.setString(5, searchMap.get(ColumnNames.PROGRAM_NAME.get()));
			callableStatement.setString(6, searchMap.get(ColumnNames.PROGRAM_CODE.get()));
			callableStatement.setString(7, searchMap.get(ColumnNames.PROGRAM_PRIORITY.get()));
			callableStatement.setString(8, searchMap.get(ColumnNames.PROGRAM_START_TIME.get()));
			callableStatement.setString(9, searchMap.get(ColumnNames.PROGRAM_END_TIME.get()));
			callableStatement.setString(10, searchMap.get(ColumnNames.PROGRAM_DESCRIPTION.get()));

			callableStatement.registerOutParameter(11, java.sql.Types.INTEGER);

			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);

				while (resultSet.next()) {

					ActiveProgramBean bean = ActiveProgramBean.builder().programName(resultSet.getString(1))
							.programCode(resultSet.getString(2)).programPriority(resultSet.getString(3))
							.programStartTime(resultSet.getString(4)).programEndTime(resultSet.getString(5))
							.programDescription(resultSet.getString(6)).build();

					list.add(bean);
				}

				log.info("Size of active program list is: {}", list.size());

				int totalRecordCount = callableStatement.getInt(11);
				log.info("totalRecordCount is: {}", totalRecordCount);
				dtResponse.setData(list);
				dtResponse.setRecordsFiltered(totalRecordCount);
				dtResponse.setRecordsTotal(totalRecordCount);
			}

		} catch (Exception e) {
			log.error("Exception occurred in getActiveProgramList {}", e);
			return null;
		}

		return dtResponse;
	}

	/**
	 * addProgramAndGetProgramCode(...) is responsible for adding the program coming
	 * from program bulk upload & prefixName(coming from
	 * {@link CommonDao#getPrefixName(String)}) into the database and then the out
	 * parameter is programCode which is returned from this method.
	 * 
	 * @param programBulkUploadBean {@link ProgramBulkUploadBean}
	 * @param prefixName            String
	 * @return String programCode
	 */
	@Override
	public String addProgramAndGetProgramCode(ProgramBulkUploadBean programBulkUploadBean, String prefixName) {
		String sqlQuery = "{ call tsp_web_admin_master_addProgramAndGetProgramCode(?,?,?,?,?,?,?,?,?) }";

		String programCode = null;

		try (Connection connection = this.masterSfnVasTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, programBulkUploadBean.getProgramName());
			callableStatement.setString(2, programBulkUploadBean.getProgramDescription());
			callableStatement.setString(3, programBulkUploadBean.getProgramPriority());
			callableStatement.setString(4, programBulkUploadBean.getProgramStartDateTime());
			callableStatement.setString(5, programBulkUploadBean.getProgramEndDateTime());
			callableStatement.setString(6, programBulkUploadBean.getProgramCumulativeCount());
			callableStatement.setString(7, programBulkUploadBean.getProgramCumulativeCountMode());
			callableStatement.setString(8, prefixName);

			callableStatement.registerOutParameter(9, java.sql.Types.VARCHAR);

			callableStatement.execute();

			programCode = callableStatement.getString(9);
			log.info("Program code is: {}", programCode);

		} catch (Exception e) {
			log.error("Exception occurred while addProgramAndGetProgramCo̥de(): {}", e);
		}

		return programCode;
	}

}
