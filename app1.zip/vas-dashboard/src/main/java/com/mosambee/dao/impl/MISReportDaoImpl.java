package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.AcquirerBean;
import com.mosambee.bean.BusinessMISCrudBean;
import com.mosambee.bean.BusinessMISDownloadCrudBean;
import com.mosambee.bean.BusinessMISDownloadResponseBean;
import com.mosambee.dao.MISReportDao;

import lombok.extern.log4j.Log4j2;

/**
 * {@link MISReportDaoImpl} is responsible for handling database operations
 * for Business-MIS module. The class is responsible for updating existing MIS in database and for fetching data to download
 * MIS for acquirers.
 * @author mariam.siddique
 * @version 1.0
 * @since 15-April-2020
 */
@Log4j2
@Repository("misReportDao")
public class MISReportDaoImpl implements MISReportDao{

	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;
	
	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;
	
	
	/**
	 * updateBusinessMIS is used to update existing MIS
	 * @param businessMISCrudBean {@link BusinessMISCrudBean}
	 * @return boolean
	 */
	@Override
	public boolean updateBusinessMIS(BusinessMISCrudBean businessMISCrudBean) {
		boolean result = true;
		
		String sqlQuery = "{ call tsp_web_admin_master_updateBusinessMIS(?,?,?) }";
		
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, businessMISCrudBean.getUserNumber());
			callableStatement.setString(2, businessMISCrudBean.getActivationRequestDate());
			callableStatement.setString(3, businessMISCrudBean.getActivationConfirmationDate());
			
			callableStatement.execute();  
			log.info("updateBusinessMIS {}",callableStatement);
			
		} catch (Exception e) {
			result = false;
			log.error(" Exception occurred in updateBusinessMIS {}", e.getMessage());
		}
		return result;
	}

	/**
	 * checkUserNameExist is used to check for existing User Number
	 * @param userNumber {@link String}
	 * @return exist
	 */
	@Override
	public int checkUserNameExist(String userNumber) {
		int exist = 0;
		
		String sqlQuery = "{ call tsp_web_admin_slave_checkUserNameExist(?,?) }";
		
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, userNumber);
			callableStatement.registerOutParameter(2, java.sql.Types.INTEGER);
			callableStatement.execute();  
			exist = callableStatement.getInt(2);
			log.info("checkUserNameExist {}",callableStatement);
		} catch (Exception e) {
			exist = -1;
			log.error("Exception occurred in checkUserNameExist {}", e);
		}
		return exist;
	}

	@Override
	public List<AcquirerBean> getListOfAcquirer() {
		
		List<AcquirerBean> acquirerBeanList = new ArrayList<>();
        
		String sql = "{ call tsp_web_admin_getAcquiererList() }";
		
		try(Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {
            
			log.info("getListOfAcquirer {}",callableStatement);
			try(ResultSet resultSet = callableStatement.executeQuery()){

				while (resultSet.next()) {
					AcquirerBean acquirerBean = new AcquirerBean();
					acquirerBean.setId(resultSet.getInt(1));
					acquirerBean.setName(resultSet.getString(2));
					acquirerBeanList.add(acquirerBean);
				}
				
				log.info("acquirerBeanList {}",acquirerBeanList);
			}
		} catch (Exception e) {
			log.error("error occured on getListOfAcquirer {} ",e);
		} 

		return acquirerBeanList;

	}

	/**
	 * getDataToDownloadBusinessMIS is used to get data to download MIS for acquirer.
	 * @param businessMISDownloadCrudBean {@link BusinessMISDownloadCrudBean}
	 * @return List<BusinessMISDownloadResponseBean>
	 */
	@Override
	public List<BusinessMISDownloadResponseBean> getDataToDownloadBusinessMIS(BusinessMISDownloadCrudBean businessMISDownloadCrudBean) {
		
		List<BusinessMISDownloadResponseBean> list = new ArrayList<>();
		
		String sqlQuery = "{ call tsp_web_admin_slave_getBusinessMISDownloadList(?,?,?) }";
		
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, businessMISDownloadCrudBean.getAcquirer());
			callableStatement.setString(2, businessMISDownloadCrudBean.getFromDate());
			callableStatement.setString(3, businessMISDownloadCrudBean.getToDate());
			
			log.info("{}", callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				while (resultSet.next()) {

					BusinessMISDownloadResponseBean result = BusinessMISDownloadResponseBean.builder().mId(resultSet.getString(1)).merchantName(resultSet.getString(4))
							.merchantPhone(resultSet.getString(2)).merchantContactPerson(resultSet.getString(5)).merchantEmail(resultSet.getString(3))
							.merchantAddress(resultSet.getString(6)).merchantState(resultSet.getString(7)).merchantCity(resultSet.getString(8)).merchantPin(resultSet.getString(9))
							.merchantUser(resultSet.getString(10)).merchantUserName(resultSet.getString(11)).merchantUserStatus(resultSet.getString(21)).merchantDebitTid(resultSet.getString(12))
							.merchantCreditTid(resultSet.getString(13)).merchantAcq(resultSet.getString(14)).month(resultSet.getString(15)).reqDateAcq(resultSet.getString(16))
							.confirmDateAcq(resultSet.getString(17)).installReqDate(resultSet.getString(18)).installDate(resultSet.getString(19)).withingTAT(resultSet.getString(21))
							.serialNo(resultSet.getString(20)).deactivationDate(resultSet.getString(22)).deactivationComment(resultSet.getString(23)).build();

					list.add(result);
				}

			}

			log.info("Size of download businessMIS list: {}", list.size());
		} catch (Exception e) {
			log.error("Exception occurred in downloadBusinessMIS {}", e);
			return null;
		}

		return list;

	}

}
