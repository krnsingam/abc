package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.KeyBulkUploadBean;
import com.mosambee.bean.MappingBulkUpload;
import com.mosambee.bean.MerchantKeyBean;
import com.mosambee.bean.MerchantKeyDataBean;
import com.mosambee.bean.MerchantMappingBean;
import com.mosambee.bean.MerchantMappingDataBean;
import com.mosambee.bean.MerchantNameBean;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.constants.CommonConstants;
import com.mosambee.dao.MerchantSpecificDao;

/**
 * {@link MerchantSpecificDaoImpl} is responsible for handling database
 * operations for Merchant specific details. The class is responsible for fetching the active
 * merchants data and update and add the merchant data.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 27-February-2020
 */
@Repository(value = "merchantSpecificDao")
public class MerchantSpecificDaoImpl implements MerchantSpecificDao{

	private static final Logger log = LogManager.getLogger(MerchantSpecificDaoImpl.class);

	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;
	

	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;
	
	private static final String  CALLABLE_STATEMENT = "callableStatement : {}";
	
	private static final String  SUCCESS_MSG = "Success";
	
	private static final String  FAIL_MSG = "Data not updated properly";
	
	private static final String  RECORD_ID = "recordId";

	//common sql for Map listing queries
	private static final String SQLMAP = "{ call tsp_web_admin_slave_merchantSpecificGetList(?,?,?,?,?,?,?,?) }";
	
	//common sql for Key listing queries
	private static final String SQLKEY = "{ call tsp_web_admin_slave_merchantSpecificGetKeyList(?,?,?,?,?, ?,?,?) }";
	
	/** This method is used to create/insert record for MerchantMappingBean.
	 *  This method operates on database : sfn_transaction and table : merchant_specific_service. 
	 *	@param  MerchantMappingBean : Expect bean  of "{@link MerchantMappingBean}" from which data should be store.
	 *	@return	ResponseBean		    
	 *  @author karan.singam
	 */		
	@Override
	public ResponseBean createMerchantMapping(MerchantMappingBean merchantMapping) {
			
		String sqlQuery = "{ call tsp_web_admin_master_merchantSpecific_addService(?,?,?,?) }";
		ResponseBean responseBean = new ResponseBean();
		
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			callableStatement.setLong(1,merchantMapping.getMerchantId());
			callableStatement.setString(2,merchantMapping.getClassPath());
			callableStatement.setString(3,merchantMapping.getUrl());
			callableStatement.registerOutParameter(4,java.sql.Types.BIGINT);
			
			log.info(CALLABLE_STATEMENT,callableStatement);			
			callableStatement.execute();
			responseBean.setMsg(SUCCESS_MSG);
			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put(RECORD_ID,callableStatement.getLong(4));
			responseBean.setUpdateRequest(true);
			return responseBean;
		} catch (Exception e) {
			log.error("Error occurred in createMerchantMapping() while inserting record : {}", e.getMessage());
			responseBean.setMsg(CommonConstants.RECORD_INSERTION_FAILED.get());
			responseBean.setUpdateRequest(false);
			return responseBean;
		}
			
	}

	/** This method is used to update record for MerchantMappingBean.
	 *  This method operates on database : sfn_transaction and table : merchant_specific_service. 
	 *	@param 	MerchantMappingBean : Expect bean  of "{@link MerchantMappingBean}" from which data should be store.
	 *	@param 	responseBean   : Expect bean of "{@link ResponseBean}" which is used to set operation status message as well as id of record inserted
	 *							 which we use for update record as well as use this to render data related to status message to jsp.
	 *	@return boolean 	   : Return "true" if record updated successfully.
	 *							 Return "false" if record update failed due to any reason.
	 *  @author karan.singam
	 */		
	@Override
	public boolean updateMerchantMapping(MerchantMappingBean merchantMapping, ResponseBean responseBean) {
		log.info("APIPasswordConfigDaoImpl  updateAPIGroup() called. ");
		
		String sqlQuery = "{ call tsp_web_admin_master__merchantSpecific_updateService(?,?,?,?) }";

		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1,merchantMapping.getMerchMapId());//id
			callableStatement.setLong(2,merchantMapping.getMerchantId());//mid
			callableStatement.setString(3,merchantMapping.getClassPath());
			callableStatement.setString(4,merchantMapping.getUrl());
			
			log.info(CALLABLE_STATEMENT,callableStatement);			
			int result = callableStatement.executeUpdate();
			if(result>0) {
			responseBean.setMsg(SUCCESS_MSG);
			return true;
			}else {
				responseBean.setMsg(FAIL_MSG);
				return false;
			}
		} catch (Exception e) {
			log.error("Error occurred in updateAPIGroup() while updating record : {}", e.getMessage());
			responseBean.setMsg(CommonConstants.RECORD_INSERTION_FAILED.get());
			return false;
		}
		
	}
	
	/** This method is used to update record for MerchantKeyBean.
	 *  This method operates on database : sfn_transaction and table : merchant. 
	 *	@param 	MerchantKeyBean : Expect bean  of "{@link MerchantKeyBean}" from which data should be store.
	 *	@param 	responseBean   : Expect bean of "{@link ResponseBean}" which is used to set operation status message as well as id of record inserted
	 *							 which we use for update record as well as use this to render data related to status message to jsp.
	 *	@return boolean 	   : Return "true" if record updated successfully.
	 *							 Return "false" if record update failed due to any reason.
	 *  @author karan.singam
	 */			
	@Override
	public boolean editMerchantKey(MerchantKeyBean merchantKey, ResponseBean responseBean) {
		log.info("APIPasswordConfigDaoImpl  updateAPIGroup() called. ");
		
		String sqlQuery = "{ call tsp_web_admin_master_editMerchantKey(?,?,?) }";

		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1,merchantKey.getMerchKeyId());
			callableStatement.setString(2,merchantKey.getMerchantKey());
			callableStatement.setString(3,merchantKey.getMerchantCode());
			
			log.info(CALLABLE_STATEMENT,callableStatement);			
			int result = callableStatement.executeUpdate();
			if(result>0) {
			responseBean.setMsg(SUCCESS_MSG);
			return true;
			}
			else {
				responseBean.setMsg(FAIL_MSG);
				return false;
			}
		} catch (Exception e) {
			log.error("Error occurred in updateAPIGroup() while updating record : {}", e.getMessage());
			responseBean.setMsg(CommonConstants.RECORD_INSERTION_FAILED.get());
			return false;
		}
	}

	
	/** This method is used to fetch details of MerchantMappingBean by id.
	 *  This method we have used when we want to edit MerchantMappingBean from list.
	 *  This method operates on database : sfn_transaction and table : merchant_specific_service. 
	 *	@param 	MerchantMappingBean : Expect bean  of "{@link MerchantMappingBean}" which is used to get id of MerchantMappingBean.
	 *	@param 	MerchantMappingBean 						  : Expect bean of "{MerchantMappingBean}" in which the method will store all data of MerchantMappingBean.
	 *	@param 	responseBean   						  : Expect bean of "{@link ResponseBean}" which is used to set operation status message. We can use this to
	 *				 									to render data related to status message to jsp.
	 *	@return boolean								  : Return "True" if record successfully fetched.
	 *													Return "false" if record is not successfully fetched or record not found.
	 *  @author karan.singam
	 */		
	@Override
	public boolean processMappingById(MerchantMappingBean merchantMappingBean, MerchantMappingBean createMapping, ResponseBean responseBean) {
				
		String sqlQuery = "{ call tsp_web_admin_slave_merchantSpecificGetService(?,?,?) }";

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1,merchantMappingBean.getMerchMapId());
			callableStatement.setLong(2,merchantMappingBean.getMerchantId());
			callableStatement.registerOutParameter(3,java.sql.Types.VARCHAR);
			
			log.info(CALLABLE_STATEMENT,callableStatement);			
			
			try(ResultSet resultSet = callableStatement.executeQuery();)
			{
				while(resultSet.next())
				{
					createMapping.setMerchMapId(resultSet.getLong(1));
					createMapping.setMerchantId(resultSet.getLong(2));
					createMapping.setClassPath(resultSet.getString(3));
					createMapping.setUrl(resultSet.getString(4));
					createMapping.setMerchantName(callableStatement.getString(3));

					responseBean.setMsg(SUCCESS_MSG);
					responseBean.setData(new HashMap<String, Object>());
					responseBean.getData().put(RECORD_ID,resultSet.getLong(1));
				}
				
			}
			return true;
		} catch (Exception e) {
			log.error("Error occurred in getAPIGroupDataById() while fetching record : {}", e.getMessage());
			responseBean.setMsg(CommonConstants.RECORD_INSERTION_FAILED.get());
			return false;
		}
	}
	
	/** This method is used to fetch details of MerchantKeyBean by id.
	 *  This method we have used when we want to edit MerchantKeyBean from list.
	 *  This method operates on database : sfn_transaction and table : merchant. 
	 *	@param 	MerchantKeyBean : Expect bean  of "{@link MerchantKeyBean}" which is used to get id of MerchantKeyBean.
	 *	@param 	MerchantKeyBean 						  : Expect bean of "{MerchantKeyBean}" in which the method will store all data of MerchantKeyBean.
	 *	@param 	responseBean   						  : Expect bean of "{@link ResponseBean}" which is used to set operation status message. We can use this to
	 *				 									to render data related to status message to jsp.
	 *	@return boolean								  : Return "True" if record successfully fetched.
	 *													Return "false" if record is not successfully fetched or record not found.
	 *  @author karan.singam
	 */		
	@Override
	public boolean processKeyById(MerchantKeyBean merchantMappingBean, MerchantKeyBean createKey, ResponseBean responseBean) {
				
		String sqlQuery = "{ call tsp_web_admin_slave_merchantSpecificKey(?,?,?,?) }";

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1,merchantMappingBean.getMerchKeyId());
			callableStatement.registerOutParameter(2,java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(3,java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(4,java.sql.Types.VARCHAR);
			
			log.info(CALLABLE_STATEMENT,callableStatement);			
			
			try(ResultSet resultSet = callableStatement.executeQuery();)
			{
				while(resultSet.next())
				{
					createKey.setMerchKeyId(resultSet.getLong(1));
					createKey.setMerchant(callableStatement.getString(2));
					createKey.setMerchantKey(callableStatement.getString(3));
					createKey.setMerchantCode(callableStatement.getString(4));
	
					responseBean.setMsg(SUCCESS_MSG);
					responseBean.setData(new HashMap<String, Object>());
					responseBean.getData().put(RECORD_ID,resultSet.getLong(1));
				}
				
			}
		return true;
		} catch (Exception e) {
			log.error("Error occurred in getAPIGroupDataById() while fetching record : {}", e.getMessage());
			responseBean.setMsg(CommonConstants.RECORD_INSERTION_FAILED.get());
			return false;
		}
	}
	
	
	/** 
	 *  This method operates on database : sfn_transaction and table : merchant. 
	 *	@param  MerchantNameBean : Expect bean  of "{@link MerchantNameBean}" from which data should be store.
	 *	@return	List<MerchantNameBean>	 
	 *  @author karan.singam
	 */		
	@Override
	public List<MerchantNameBean> getMerchantName(MerchantNameBean merchantbean) {
			
		String sqlQuery = "{ call tsp_web_admin_slave_getMerchantNameIdList(?) }";
		List<MerchantNameBean> list = new ArrayList<>();
		MerchantNameBean bean = null;
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			callableStatement.setString(1,merchantbean.getMerchantNameCode().trim());
			
			log.info(CALLABLE_STATEMENT,callableStatement);			
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);

				while (resultSet.next()) {

					bean = MerchantNameBean.builder().merchId(resultSet.getLong(1)).merchantNameCode(resultSet.getString(2)).build();
					list.add(bean);
				}

				log.info("Size of Merchant list is: {}", list.size());

			}
		} catch (Exception e) {
			log.error("Error occurred in createAPIGroup() while inserting record : {}", e.getMessage());
		}

		return list;
	}

		/**
		 * getMerchantMappingView(...) is responsible for getting the active
		 * Merchant mapping list, corresponding to the coming data-tables request. Here we
		 * have three parameters, first is the actual {@link DataTablesRequest}, second
		 * one is the orderingColumnName in which ordering is going to happen
		 * (ASC/DESC). Third one is a searchMap which is basically a Map of String key
		 * and value pairs which transformed search values for each column in which we
		 * are applying data-tables search.
		 * 
		 * @param dtRequest          {@link DataTablesRequest}
		 * @param orderingColumnName {@link String}
		 * @param searchMap          Map with key and value as String
		 */
		@Override
		public DataTablesResponse<MerchantMappingBean> getMerchantMappingView(MerchantMappingDataBean dtRequest,
				String orderingColumnName, Map<String, String> searchMap) {
			DataTablesResponse<MerchantMappingBean> dtResponse = new DataTablesResponse<>();
			List<MerchantMappingBean> list = new ArrayList<>();
			try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
					CallableStatement callableStatement = connection.prepareCall(SQLMAP)) {
				log.info("{}", connection);
				callableStatement.setInt(1, dtRequest.getDataTable().getStart());
				callableStatement.setInt(2, dtRequest.getDataTable().getLength());
				callableStatement.setString(3, orderingColumnName);
				callableStatement.setString(4, dtRequest.getDataTable().getOrder().get(0).getDir().toString());
				callableStatement.setString(5, searchMap.get(ColumnNames.MERCHANT_NAME.get()));
				callableStatement.setString(6, searchMap.get(ColumnNames.MERCHANT_CLASSPATH.get()));
				callableStatement.setString(7, searchMap.get(ColumnNames.MERCHANT_URL.get()));
				callableStatement.registerOutParameter(8, java.sql.Types.INTEGER);
				log.info("{} ", callableStatement);
				try (ResultSet resultSet = callableStatement.executeQuery()) {

					log.info("{}", callableStatement);
					while (resultSet.next()) {

						MerchantMappingBean bean = MerchantMappingBean.builder().merchMapId(resultSet.getLong(1)).merchantId(resultSet.getLong(2))
								.merchantName(resultSet.getString(3)).classPath(resultSet.getString(4)).url(resultSet.getString(5))
								.build();
						
						list.add(bean);
					}

				}

				log.info("Size of active transaction list: {}", list.size());

				int totalRecordCount = callableStatement.getInt(8);

				dtResponse.setData(list);
				dtResponse.setRecordsFiltered(totalRecordCount);
				dtResponse.setRecordsTotal(totalRecordCount);
			} catch (Exception e) {
				log.error("Exception occurred in getMerchantMappingView {}", e.getMessage());
				return null;
			}

			dtResponse.setData(list);
			log.info(dtResponse);
			return dtResponse;
		}

		/**
		 * downloadMerchantMapping(...) is responsible for fetching data
		 * required for downloading Merchant mapping list from merchant and merchant_specific and
		 * return list of MerchantMappingBean.
		 * 
		 * @return List<TransactionReportBean>
		 */
		@Override
		public List<MerchantMappingBean> downloadMerchantMapping(MerchantMappingBean report) {

			MerchantMappingBean bean = null;
			List<MerchantMappingBean> list = new ArrayList<>();

			try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
					CallableStatement callableStatement = connection.prepareCall(SQLMAP)) {

				callableStatement.setInt(1, 0);
				callableStatement.setInt(2, 0);
				callableStatement.setString(3, "");
				callableStatement.setString(4, "");
				callableStatement.setString(5, report.getMerchantName().trim());
				callableStatement.setString(6, report.getClassPath().trim());
				callableStatement.setString(7, report.getUrl().trim());
				callableStatement.registerOutParameter(8, java.sql.Types.INTEGER);

				try (ResultSet resultSet = callableStatement.executeQuery()) {

					log.info("{}", callableStatement);

					while (resultSet.next()) {

						bean = MerchantMappingBean.builder().merchMapId(resultSet.getLong(1)).merchantId(resultSet.getLong(2))
								.merchantName(resultSet.getString(3)).classPath(resultSet.getString(4)).url(resultSet.getString(5))
								.build();
						list.add(bean);
					}

					log.info("Size of active transaction list is: {}", list.size());

				}

			} catch (Exception e) {
				log.error("Exception occurred in downloadActiveTransactionReportList {}", e.getMessage());
				return new ArrayList<>();
			}

			return list;
		}
		
		/**
		 * getMerchantKey(...) is responsible for getting the active
		 * Merchant mapping list, corresponding to the coming data-tables request. Here we
		 * have three parameters, first is the actual {@link DataTablesRequest}, second
		 * one is the orderingColumnName in which ordering is going to happen
		 * (ASC/DESC). Third one is a searchMap which is basically a Map of String key
		 * and value pairs which transformed search values for each column in which we
		 * are applying data-tables search.
		 * 
		 * @param dtRequest          {@link DataTablesRequest}
		 * @param orderingColumnName {@link String}
		 * @param searchMap          Map with key and value as String
		 */
		@Override
		public DataTablesResponse<MerchantKeyBean> getMerchantKey(MerchantKeyDataBean dtRequest,
				String orderingColumnName, Map<String, String> searchMap) {
			DataTablesResponse<MerchantKeyBean> dtResponse = new DataTablesResponse<>();
			List<MerchantKeyBean> list = new ArrayList<>();
			try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
					CallableStatement callableStatement = connection.prepareCall(SQLKEY)) {

				callableStatement.setInt(1, dtRequest.getDataTable().getStart());
				callableStatement.setInt(2, dtRequest.getDataTable().getLength());
				callableStatement.setString(3, orderingColumnName);
				callableStatement.setString(4, dtRequest.getDataTable().getOrder().get(0).getDir().toString());
				callableStatement.setString(5, searchMap.get(ColumnNames.MERCHANT.get()));
				callableStatement.setString(6, searchMap.get(ColumnNames.MERCHANT_CODE.get()));
				callableStatement.setString(7, searchMap.get(ColumnNames.MERCHANT_KEY.get()));
				callableStatement.registerOutParameter(8, java.sql.Types.INTEGER);

				try (ResultSet resultSet = callableStatement.executeQuery()) {

					log.info("{}", callableStatement);
					while (resultSet.next()) {

						MerchantKeyBean bean = MerchantKeyBean.builder().merchKeyId(resultSet.getInt(1))
								.merchant(resultSet.getString(2)).merchantCode(resultSet.getString(3)).merchantKey(resultSet.getString(4))
								.build();

						list.add(bean);
					}

				}

				log.info("Size of active transaction list: {}", list.size());

				int totalRecordCount = callableStatement.getInt(8);

				dtResponse.setData(list);
				dtResponse.setRecordsFiltered(totalRecordCount);
				dtResponse.setRecordsTotal(totalRecordCount);
			} catch (Exception e) {
				log.error("Exception occurred in getActiveTransactionReport {}", e.getMessage());
				return null;
			}

			dtResponse.setData(list);
			log.info(dtResponse);
			return dtResponse;
		}

		/**
		 * downloadMerchantKey(...) is responsible for fetching data
		 * required for downloading Merchant key list from merchant and merchant_specific and
		 * return list of MerchantMappingBean.
		 * 
		 * @return List<TransactionReportBean>
		 */
		@Override
		public List<MerchantKeyBean> downloadMerchantKey(MerchantKeyBean report) {

			MerchantKeyBean bean = null;
			List<MerchantKeyBean> list = new ArrayList<>();

			try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
					CallableStatement callableStatement = connection.prepareCall(SQLKEY)) {

				callableStatement.setInt(1, 0);
				callableStatement.setInt(2, 0);
				callableStatement.setString(3, "");
				callableStatement.setString(4, "");
				callableStatement.setString(5, report.getMerchant().trim());
				callableStatement.setString(6, report.getMerchantCode().trim());
				callableStatement.setString(7, report.getMerchantKey().trim());
				callableStatement.registerOutParameter(8, java.sql.Types.INTEGER);

				try (ResultSet resultSet = callableStatement.executeQuery()) {

					log.info("{}", callableStatement);

					while (resultSet.next()) {

						bean = MerchantKeyBean.builder().merchKeyId(resultSet.getInt(1))
								.merchant(resultSet.getString(2)).merchantCode(resultSet.getString(3)).merchantKey(resultSet.getString(4))
								.build();
						list.add(bean);
					}

					log.info("Size of active transaction list is: {}", list.size());

				}

			} catch (Exception e) {
				log.error("Exception occurred in downloadActiveTransactionReportList {}", e.getMessage());
				return new ArrayList<>();
			}

			return list;
		}
		
		/** This method is used to insert record of {@link MappingBulkUpload} bean
		 *  This method operates on database : sfn_transaction and table : merchant_specific.
		 *	@param 	MappingBulkUpload : Expect bean  of "{@link MappingBulkUpload}" of which data we want to store.
		 *  @author karan.singam
		 */		
		@Override
		public void insertBulkUploadData(MappingBulkUpload midBulkUpload)
		{
			String sqlQuery = "{ call tsp_web_admin_master_getMIDUsingMerchantCode(?,?,?,?,?) }";
			
			try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
					CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			
				callableStatement.setString(1,midBulkUpload.getMerchantCode());
				callableStatement.setString(2,midBulkUpload.getTerminalId());
				callableStatement.setString(3,midBulkUpload.getUrl());
				callableStatement.setString(4,midBulkUpload.getClassPath());
				callableStatement.registerOutParameter(5,java.sql.Types.VARCHAR);
					
				log.info(CALLABLE_STATEMENT,callableStatement);			
				
				callableStatement.execute();
				midBulkUpload.setStatus(callableStatement.getString(5));
				midBulkUpload.setErrCode(0);
				log.info("Status : {}",midBulkUpload.getStatus());
			}
			catch(Exception e)
			{
				log.error("Error occurred in insertBulkUploadData() while inserting MIDBulkUpload for MerchantCode : {}, TerminalId : {}, ClassPath : {} e : {}", midBulkUpload.getMerchantCode() , midBulkUpload.getTerminalId() ,midBulkUpload.getClassPath(),e.getMessage());
			}
		}
		
		/** This method is used to insert record of {@link KeyBulkUploadBean} bean
		 *  This method operates on database : sfn_transaction and table : merchant.
		 *	@param 	KeyBulkUploadBean : Expect bean  of "{@link KeyBulkUploadBean}" of which data we want to store.
		 *  @author karan.singam
		 */		
		@Override
		public void insertKeyBulkUploadData(KeyBulkUploadBean bulkUpload)
		{
			String code = "";
			if(bulkUpload.getCodeNeed().equals("Y") && bulkUpload.getMerchantCode().isEmpty()) {
				code = RandomStringUtils.randomAlphanumeric(19).toUpperCase();
				while(!checkKey(code)){
					int i=1;
					code = RandomStringUtils.randomAlphanumeric(19).toUpperCase();
					log.info("Random String 19 digit's {}:, i:{}",code,i);
					i++;
				}
				log.info("final code {}:",code);
			}
			bulkUpload.setMerchantCode(code);
			String sqlQuery = "{ call tsp_web_admin_master_updateMerchantKey(?,?,?,?,?) }";
			
			try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
					CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			
				callableStatement.setString(1,bulkUpload.getMerchantCode());
				callableStatement.setString(2,bulkUpload.getMid());
				callableStatement.setString(3,bulkUpload.getMerchantKey());
				callableStatement.setString(4,bulkUpload.getCodeNeed());
				callableStatement.registerOutParameter(5,java.sql.Types.VARCHAR);
					
				log.info(CALLABLE_STATEMENT,callableStatement);			
				
				callableStatement.execute();
				bulkUpload.setStatus(callableStatement.getString(5));
				bulkUpload.setErrCode(0);
				log.info("Status : {}",bulkUpload.getStatus());
			}
			catch(Exception e)
			{
				log.error("Error occurred in insertBulkUploadData() while inserting MIDBulkUpload for MerchantCode : {}, Mid : {}, CodeNeed : {} e : {}", bulkUpload.getMerchantCode() , bulkUpload.getMid() ,bulkUpload.getCodeNeed(),e.getMessage());
			}
		}

		/** This method is used to check record Merchant Code
		 *  This method operates on database : sfn_transaction and table : merchant.
		 *	@param 	String.
		 *	@return boolean.
		 *  @author karan.singam
		 */	
		public boolean checkKey(String key) {
			boolean result;
			String sqlQuery = "{ call tsp_web_admin_slave_checkMerchantKey(?,?) }";
			
			try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
					CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			
				callableStatement.setString(1,key);
				callableStatement.registerOutParameter(2,java.sql.Types.BOOLEAN);
					
				log.info(CALLABLE_STATEMENT,callableStatement);			
				
				callableStatement.execute();
				result = callableStatement.getBoolean(2);
				log.info("Key Status : {}",result);
			}
			catch(Exception e)
			{
				log.error("Error occurred in checkKey() while checking for code : {}, e : {}", key,e.getMessage());
				result = true;
			}
			
			return result;
		}
}
