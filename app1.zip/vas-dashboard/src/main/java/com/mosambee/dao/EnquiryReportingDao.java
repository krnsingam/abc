package com.mosambee.dao;

import java.util.List;
import java.util.Map;
import com.mosambee.bean.EnquiryBean;
import com.mosambee.bean.EnquiryDataTablesRequestBean;
import com.mosambee.bean.EnquiryDateBean;
import com.mosambee.bean.datatables.DataTablesResponse;

/**
 * This class provides specification for {@linkEnquiryReportingDaoImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 */
public interface EnquiryReportingDao {
	DataTablesResponse<EnquiryBean> getEnquiryList(EnquiryDataTablesRequestBean dtRequest, String orderingColumnName,
			Map<String, String> searchMap);

	List<EnquiryBean> downloadEnquiryReporting(EnquiryDateBean enquiryDateBean);

	EnquiryBean viewEnquiryDetail(long id);

}
