package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.mosambee.bean.AddBqrMerchantsBean;
import com.mosambee.bean.BqrListDatatablesRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.AddBqrMerchantsDao;
import lombok.extern.log4j.Log4j2;

/**
 * This class is responsible for db operation for add bqr merchants,edit bqr
 * merchants,update bqr merchants and display bqr merchants list
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
@Log4j2
@Repository("addBqrMerchantsDao")
public class AddBqrMerchantsDaoImpl implements AddBqrMerchantsDao {

	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;

	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;

	/**
	 * This method is responsible for inserting values to add bwr merchant i db and
	 * provide response according values of bqr merchants
	 *
	 */
	@Override
	public String addBqrMerchants(AddBqrMerchantsBean addBqrMerchantsBean, String userId) {

		String sqlQuery = "{ call tsp_web_admin_master_addBqrMerchants(?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?,  ?,?,?,?,?, ?,?,?,?,?) }";
		String response = null;
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			callableStatement.setString(1, userId);
			callableStatement.setString(2, addBqrMerchantsBean.getMerchantId());
			callableStatement.setString(3, addBqrMerchantsBean.getTerminalId());
			callableStatement.setString(4, addBqrMerchantsBean.getVisaNetworkId1());
			callableStatement.setString(5, addBqrMerchantsBean.getVisaNetworkId2());
			callableStatement.setString(6, addBqrMerchantsBean.getMasterCardNetworkId1());
			callableStatement.setString(7, addBqrMerchantsBean.getMasterCardNetworkId2());
			callableStatement.setString(8, addBqrMerchantsBean.getNpciNetworkId1());
			callableStatement.setString(9, addBqrMerchantsBean.getNpciNetworkId2());
			callableStatement.setString(10, addBqrMerchantsBean.getReferenceTag09());
			callableStatement.setString(11, addBqrMerchantsBean.getReferenceTag10());
			callableStatement.setString(12, addBqrMerchantsBean.getIfscAccountNo());
			callableStatement.setString(13, addBqrMerchantsBean.getAmexNetworkId1());
			callableStatement.setString(14, addBqrMerchantsBean.getAmexNetworkId2());
			callableStatement.setString(15, addBqrMerchantsBean.getMerchantCategoriesCode());
			callableStatement.setString(16, addBqrMerchantsBean.getCurrencyCode());
			callableStatement.setString(17, addBqrMerchantsBean.getCountryCode());
			callableStatement.setString(18, addBqrMerchantsBean.getQrMerchantName());
			callableStatement.setString(19, addBqrMerchantsBean.getMerchantCity());
			callableStatement.setString(20, addBqrMerchantsBean.getPostalCode());
			callableStatement.setString(21, addBqrMerchantsBean.getTipIndicator());
			callableStatement.setString(22, addBqrMerchantsBean.getSmsFlag());
			callableStatement.setString(23, addBqrMerchantsBean.getAcquirer());
			callableStatement.setString(24, addBqrMerchantsBean.getStatus());
			callableStatement.registerOutParameter(25, java.sql.Types.VARCHAR);
			callableStatement.execute();
			log.info("Callable Statement {} :", callableStatement);
			response = callableStatement.getString(25);
			log.info(response);

			addBqrMerchantsBean.setMessage(response);

		} catch (Exception e) {
			log.error("Exception occured in addBqrMerchants: {}", e);

		}

		return response;

	}

	/**
	 * This method is responsible to fetch list of bqr merchants
	 *
	 */
	@Override
	public DataTablesResponse<AddBqrMerchantsBean> getBqrMerchantsList(BqrListDatatablesRequestBean dtRequest,
			String orderingColumnName, Map<String, String> searchMap) {

		String sql = "{call tsp_web_admin_slave_getBQRList(?,?,?,?,?, ?,?,?,?,?,?)}";
		DataTablesResponse<AddBqrMerchantsBean> dtResponse = new DataTablesResponse<>();
		List<AddBqrMerchantsBean> list = new ArrayList<>();

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {
			log.info("{}", callableStatement);
			callableStatement.setInt(1, dtRequest.getDtRequest().getStart());
			callableStatement.setInt(2, dtRequest.getDtRequest().getLength());
			callableStatement.setString(3, searchMap.get(ColumnNames.ACQUIRER_NAME.get()));// acquirer
			callableStatement.setString(4, searchMap.get(ColumnNames.MDAT_MERCHANTCODE.get()));// merchantCode
			callableStatement.setString(5, searchMap.get(ColumnNames.MMUT_TERMINALID.get()));// terminalId
			callableStatement.setString(6, searchMap.get(ColumnNames.QR_MERCHANTMAPPING.get()));// Status
			callableStatement.setString(7, searchMap.get(ColumnNames.QRM_IFSCACCOUNTNO.get()));// ifscAccountNo
			callableStatement.setString(8, searchMap.get(ColumnNames.QRM_MERCHANTNAME.get()));// qrMerchantName
			callableStatement.setString(9, orderingColumnName);
			callableStatement.setString(10, dtRequest.getDtRequest().getOrder().get(0).getDir().toString());
			callableStatement.registerOutParameter(11, java.sql.Types.INTEGER);
			try (ResultSet resultSet = callableStatement.executeQuery()) {
				log.info("{}", callableStatement);
				while (resultSet.next()) {
					String status1 = resultSet.getString(8);
					if (status1.equalsIgnoreCase("1")) {
						status1 = "Yes";
					} else if (status1.equalsIgnoreCase("0")) {
						status1 = "No";
					}
					AddBqrMerchantsBean addBqrMerchantsBean = AddBqrMerchantsBean.builder().id(resultSet.getLong(1))
							.visaNetworkId1(resultSet.getString(2)).masterCardNetworkId1(resultSet.getString(3))
							.npciNetworkId1(resultSet.getString(4)).ifscAccountNo(resultSet.getString(5))
							.merchantCategoriesCode(resultSet.getString(6)).qrMerchantName(resultSet.getString(7))
							.status(status1).acquirer(resultSet.getString(9)).terminalId(resultSet.getString(10))
							.merchantId(resultSet.getString(11)).build();
					list.add(addBqrMerchantsBean);

				}
				log.info("Size of bqrMerchantsList List {} ", list.size());
				int totalRecordCount = callableStatement.getInt(11);
				dtResponse.setData(list);
				dtResponse.setRecordsFiltered(totalRecordCount);
				dtResponse.setRecordsTotal(totalRecordCount);

			}

		} catch (Exception e) {
			log.error("Exception occurred in getBqrMerchantsList: {}", e);
			return null;
		}
		return dtResponse;
	}

	/**
	 * This method is responsible to fetch details of bqr merchants by id to edit
	 *
	 */
	@Override
	public AddBqrMerchantsBean editBqrMerchants(long id) {

		String sqlQuery = "{ call tsp_web_admin_slave_editBqrMerchant(?) }";

		AddBqrMerchantsBean addBqrMerchantsBean = new AddBqrMerchantsBean();

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			callableStatement.setLong(1, id);

			try (ResultSet resultSet = callableStatement.executeQuery()) {
				log.info("{}", callableStatement);
				while (resultSet.next()) {

					addBqrMerchantsBean.setId(resultSet.getLong(1));
					addBqrMerchantsBean.setMerchantId(resultSet.getString(2));
					addBqrMerchantsBean.setTerminalId(resultSet.getString(3));
					addBqrMerchantsBean.setVisaNetworkId1(resultSet.getString(4));
					addBqrMerchantsBean.setVisaNetworkId2(resultSet.getString(5));
					addBqrMerchantsBean.setMasterCardNetworkId1(resultSet.getString(6));
					addBqrMerchantsBean.setMasterCardNetworkId2(resultSet.getString(7));
					addBqrMerchantsBean.setNpciNetworkId1(resultSet.getString(8));
					addBqrMerchantsBean.setNpciNetworkId2(resultSet.getString(9));
					addBqrMerchantsBean.setReferenceTag09(resultSet.getString(10));
					addBqrMerchantsBean.setReferenceTag10(resultSet.getString(11));
					addBqrMerchantsBean.setIfscAccountNo(resultSet.getString(12));
					addBqrMerchantsBean.setAmexNetworkId1(resultSet.getString(13));
					addBqrMerchantsBean.setAmexNetworkId2(resultSet.getString(14));
					addBqrMerchantsBean.setMerchantCategoriesCode(resultSet.getString(15));
					addBqrMerchantsBean.setCurrencyCode(resultSet.getString(16));
					addBqrMerchantsBean.setTipIndicator(resultSet.getString(17));
					addBqrMerchantsBean.setCountryCode(resultSet.getString(18));
					addBqrMerchantsBean.setQrMerchantName(resultSet.getString(19));
					addBqrMerchantsBean.setMerchantCity(resultSet.getString(20));
					addBqrMerchantsBean.setPostalCode(resultSet.getString(21));
					addBqrMerchantsBean.setSmsFlag(resultSet.getString(22));
					addBqrMerchantsBean.setStatus(resultSet.getString(23));
					addBqrMerchantsBean.setAcquirer(resultSet.getString(24));
				}
			}
		} catch (Exception e) {
			log.error("Exception occurred in edit BqrMerchants", e);
		}

		return addBqrMerchantsBean;

	}

	/**
	 * This method is responsible for updating information of bqr merchants by
	 * id.And provide response according values.
	 *
	 */
	@Override
	public String updateBqrMerchants(AddBqrMerchantsBean addBqrMerchantsBean, String userId) {

		String sqlQuery = "{ call tsp_web_admin_master_updateBqrMerchants(?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?,  ?,?,?,?,?, ?,?,?,?,?) }";
		String response = null;
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			callableStatement.setLong(1, addBqrMerchantsBean.getId());
			callableStatement.setString(2, addBqrMerchantsBean.getMerchantId());
			callableStatement.setString(3, addBqrMerchantsBean.getTerminalId());
			callableStatement.setString(4, addBqrMerchantsBean.getVisaNetworkId1());
			callableStatement.setString(5, addBqrMerchantsBean.getVisaNetworkId2());
			callableStatement.setString(6, addBqrMerchantsBean.getMasterCardNetworkId1());
			callableStatement.setString(7, addBqrMerchantsBean.getMasterCardNetworkId2());
			callableStatement.setString(8, addBqrMerchantsBean.getNpciNetworkId1());
			callableStatement.setString(9, addBqrMerchantsBean.getNpciNetworkId2());
			callableStatement.setString(10, addBqrMerchantsBean.getReferenceTag09());
			callableStatement.setString(11, addBqrMerchantsBean.getReferenceTag10());
			callableStatement.setString(12, addBqrMerchantsBean.getIfscAccountNo());
			callableStatement.setString(13, addBqrMerchantsBean.getAmexNetworkId1());
			callableStatement.setString(14, addBqrMerchantsBean.getAmexNetworkId2());
			callableStatement.setString(15, addBqrMerchantsBean.getMerchantCategoriesCode());
			callableStatement.setString(16, addBqrMerchantsBean.getCurrencyCode());
			callableStatement.setString(17, addBqrMerchantsBean.getTipIndicator());
			callableStatement.setString(18, addBqrMerchantsBean.getCountryCode());
			callableStatement.setString(19, addBqrMerchantsBean.getQrMerchantName());
			callableStatement.setString(20, addBqrMerchantsBean.getMerchantCity());
			callableStatement.setString(21, addBqrMerchantsBean.getPostalCode());
			callableStatement.setString(22, addBqrMerchantsBean.getSmsFlag());
			callableStatement.setString(23, addBqrMerchantsBean.getStatus());
			callableStatement.setString(24, userId);
			callableStatement.registerOutParameter(25, java.sql.Types.VARCHAR);
			callableStatement.execute();
			log.info("Callable Statement {} :", callableStatement);
			response = callableStatement.getString(25);
			addBqrMerchantsBean.setMessage(response);

		} catch (Exception e) {
			log.error("Exception occured in updateBqrMerchants: {}", e);

		}

		return response;
	}

}
