package com.mosambee.dao;

import java.util.List;
import java.util.Map;

import com.mosambee.bean.EmiBulkUploadBean;
import com.mosambee.bean.EmiDownloadBean;
import com.mosambee.bean.EmiMidTidBean;
import com.mosambee.bean.EmiSearchDatatablesRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;

/**
 * This class provides specification for {@link EmiBulkUploadDaoImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 */
public interface EmiBulkUploadDao {
	String uploadEmiMidTid(EmiBulkUploadBean emiBulkUploadBean, String createdBy);

	DataTablesResponse<EmiMidTidBean> getEmiSearchList(EmiSearchDatatablesRequestBean dtRequest,
			String orderingColumnName, Map<String, String> searchMap);

	List<EmiMidTidBean> downloadEmiSearchList(EmiDownloadBean emiDownloadBean);

}
