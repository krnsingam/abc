package com.mosambee.dao.impl;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.BlockedUserBean;
import com.mosambee.bean.BlockedUserDataTableBean;
import com.mosambee.bean.CustomUser;
import com.mosambee.bean.Role;
import com.mosambee.bean.UserBean;
import com.mosambee.bean.UserCrudBean;
import com.mosambee.bean.UserCrudDataTableBean;
import com.mosambee.bean.UserExistAndNotBlockedBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.constants.LoginResultIdConstant;
import com.mosambee.dao.UserDao;

import lombok.extern.log4j.Log4j2;

/**
 * UserDaoImpl is used to load the user details by providing user name.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 02-December-2019
 */
@Log4j2
@Repository("userDao")
public class UserDaoImpl implements UserDao {
	
	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;
	
	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;

	@Autowired
	@Qualifier("slaveSecurityAndLicenseTemplate")
	private JdbcTemplate slaveSecurityAndLicenseTemplate;

	@Autowired
	@Qualifier("masterSecurityAndLicenseTemplate")
	private JdbcTemplate masterSecurityAndLicenseTemplate;

	/**
	 * Responsible for loading the user details via the provided user-name.
	 * 
	 * @param username String
	 * @return {@link UserBean}
	 */
	@Override
	public UserBean loadUserByUsername(String username) {
		String sqlQuery = "{ call tsp_web_admin_slave_loadUserByUsername(?) }";
		UserBean userBean = null;
		Role role = null;

		try (Connection connection = this.slaveSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, username);

			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);

				if (resultSet.next()) {

					role = Role.builder().id(resultSet.getInt(4)).name(resultSet.getString(5)).build();

					userBean = UserBean.builder().id(resultSet.getLong(1)).username(resultSet.getString(2))
							.password(resultSet.getString(3)).firstName(resultSet.getString(6)).role(role).build();
				}
			}
		} catch (Exception e) {
			log.error("Exception occurred in loadUserByUsername {}", e);
		}

		return userBean;
	}

	/**
	 * Responsible for checking the CP status i.e. change password status from the
	 * database.
	 * 
	 * @param username String
	 * @return boolean cpStatus
	 */
	@Override
	public boolean checkCpStatus(String username) {

		String sqlQuery = "{call tsp_web_admin_slave_checkCpStatus(?,?) }";
		boolean cpStatus = false;

		try (Connection connection = this.slaveSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, username);
			callableStatement.registerOutParameter(2, java.sql.Types.BOOLEAN);

			callableStatement.execute();
			cpStatus = callableStatement.getBoolean(2);

			log.info("cpStatus: {}, {}", callableStatement, cpStatus);

		} catch (Exception e) {
			log.error("{}", e);
		}

		return cpStatus;
	}

	/**
	 * checkIfUserIsBlocked(...) is responsible for checking if the user is blocked
	 * or not.
	 * 
	 * @param userId
	 * @return boolean
	 * 
	 */
	@Override
	public boolean checkIfUserIsBlocked(long userId) {

		String sqlQuery = "{ call tsp_web_admin_slave_checkIfUserIsBlocked(?, ?, ?) }";
		boolean isUserBlocked = false;
		int duration = getBlockedExpirationDuration();

		try (Connection connection = this.slaveSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1, userId);
			callableStatement.setInt(2, duration);
			callableStatement.registerOutParameter(3, java.sql.Types.BOOLEAN);
			callableStatement.execute();

			isUserBlocked = callableStatement.getBoolean(3);

			log.info("isUserBlocked: {}, callableStatement: {}", isUserBlocked, callableStatement);

		} catch (Exception e) {
			log.error("Exception occurred while processing checkIfUserIsBlocked: {}", e);
		}

		return isUserBlocked;
	}

	/**
	 * Responsible for adding login logs for a user.
	 * 
	 * @param code       String coming from {@link LoginResultIdConstant}
	 * @param remoteAddr String IP address of the client
	 * @param userId     id column of users table
	 * @return void
	 */
	@Override
	public void addLoginLogs(String code, String remoteAddr, Long userId) {

		String sqlQuery = "{ call tsp_web_admin_master_addLoginLogs(?,?,?) }";

		try (Connection connection = this.masterSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, code);
			callableStatement.setString(2, remoteAddr);
			callableStatement.setLong(3, userId);

			int updateCount = callableStatement.executeUpdate();

			log.info("update count: {}, callableStatement: {}", updateCount, callableStatement);

		} catch (Exception e) {
			log.error("Exception occurred while processing addLoginLogs(...) {}", e);
		}

	}

	/**
	 * Responsible for checking if user exists and is not blocked.
	 * 
	 * @param username String
	 * @return {@link UserExistAndNotBlockedBean}
	 */
	@Override
	public UserExistAndNotBlockedBean checkIfUserExistsAndNotBlocked(String username) {

		String userExistSqlQuery = "{ call tsp_web_admin_slave_checkIfUserExistsCorrespondingToUsername(?, ?) }";
		UserExistAndNotBlockedBean userExistAndNotBlockedBean = UserExistAndNotBlockedBean.builder().userExists(false)
				.notBlocked(false).userId(0).build();

		try (Connection connection = this.slaveSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(userExistSqlQuery)) {

			callableStatement.setString(1, username);
			callableStatement.registerOutParameter(2, java.sql.Types.BIGINT);

			callableStatement.execute();

			long userId = callableStatement.getLong(2);

			log.info("userId: {}, callableStatement: {}", userId, callableStatement);

			if (userId > 0) {
				userExistAndNotBlockedBean.setUserExists(true);
				userExistAndNotBlockedBean.setUserId(userId);

				if (!checkIfUserIsBlocked(userId)) {
					userExistAndNotBlockedBean.setNotBlocked(true);
				}
				int blockDuration = getBlockedExpirationDuration();
				boolean updateCount = updateBlockDuration(blockDuration, userId);

				log.info("Able to update block duration: {}", updateCount);
			}

		} catch (Exception e) {
			log.error("Exception occurred while processing checkIfUserExitsAndNotBlocked(...) {}", e);
		}

		log.info("userExistAndNotBlockedBean: {}", userExistAndNotBlockedBean);
		return userExistAndNotBlockedBean;
	}

	/**
	 * Responsible for checking wrong credentials count corresponding to userId.
	 * 
	 * @param userId
	 * @return boolean
	 */
	@Override
	public boolean checkWrongCredentialCount(long userId) {

		String sqlQuery = "{ call tsp_web_admin_slave_checkWrongCredentialsCount(?, ?, ?) }";
		boolean isUserGettingBlocked = true;

		try (Connection connection = this.slaveSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1, userId);
			callableStatement.registerOutParameter(2, java.sql.Types.BOOLEAN);
			callableStatement.registerOutParameter(3, java.sql.Types.INTEGER);

			callableStatement.execute();

			isUserGettingBlocked = callableStatement.getBoolean(2);
			int blockedDuration = callableStatement.getInt(3);

			log.info("isUserGettingBlocked: {}, callableStatement {}", isUserGettingBlocked, callableStatement);

			if (isUserGettingBlocked) {
				log.info("blockedDuration: {}", blockedDuration);
				// insert entry into the user_block table
				boolean blockStatus = blockUser(blockedDuration, userId);
				log.info("user with userId: {}, with block status as: {}", userId, blockStatus);

			}

		} catch (Exception e) {
			log.error("Exception occurred while processing checkWrongCredentialsCount(...) {}", e);
		}

		return isUserGettingBlocked;
	}

	/**
	 * Responsible for blocking the provided user with userId and for incoming
	 * duration. Basically insertion of userId is going to happen in user_block
	 * table
	 * 
	 * @param blockDuration integer
	 * @param userId        long
	 * @return boolean
	 */
	@Override
	public boolean blockUser(int blockDuration, long userId) {

		String sqlQuery = "{ call tsp_web_admin_master_blockUser(?, ?) }";

		try (Connection connection = this.masterSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setInt(1, blockDuration);
			callableStatement.setLong(2, userId);

			int updateCount = callableStatement.executeUpdate();

			log.info("updateCount: {}, callableStatement: {}", updateCount, callableStatement);

			return updateCount > 0;
		} catch (Exception e) {
			log.error("Exception occurred while processing blockUser(...) {}", e);
		}

		return false;
	}

	/**
	 * Responsible for updating the blockedExpirationDuration corresponding to a
	 * userId
	 * 
	 * @param blockDuration int
	 * @param userId        long
	 * @return boolean
	 */
	@Override
	public boolean updateBlockDuration(int blockDuration, long userId) {

		String sqlQuery = "{ call tsp_web_admin_master_updateBlockExpirationDuration(?, ?) }";

		try (Connection connection = this.masterSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setInt(1, blockDuration);
			callableStatement.setLong(2, userId);

			int updateCount = callableStatement.executeUpdate();

			log.info("updateCount: {}, callableStatement: {}", updateCount, callableStatement);

			return updateCount > 0;

		} catch (Exception e) {
			log.error("Exception occurred while processing updateBlockDuration(..) {}", e);
		}

		return false;
	}

	/**
	 * getBlockedExpirationDuration() is responsible for getting the blocked
	 * expiration duration.
	 * 
	 * @return int blockedExpirationDuration
	 */
	@Override
	public int getBlockedExpirationDuration() {

		String sqlQuery = "{ call tsp_web_admin_slave_getBlockedDuration(?) }";
		int blockedDuration = 0;

		try (Connection connection = this.slaveSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.registerOutParameter(1, java.sql.Types.INTEGER);
			callableStatement.execute();

			blockedDuration = callableStatement.getInt(1);

			log.info("blockedDuration: {}, callableStatement: {}", blockedDuration, callableStatement);

		} catch (Exception e) {
			log.error("Exception occurred while processing getBlockedExpirationDuration(...) {}", e);
		}

		return blockedDuration;
	}
	
	/**
	 * getUserList(...) is responsible for getting the user list,
	 * corresponding to the coming data-tables request. Here we have three
	 * parameters, first is the actual {@link UserCrudDataTableBean}, second one is the
	 * orderingColumnName in which ordering is going to happen (ASC/DESC). Third one
	 * is a searchMap which is basically a Map of String key and value pairs which
	 * transformed search values for each column in which we are applying
	 * data-tables search.
	 * 
	 * @param dtRequest          {@link UserCrudDataTableBean}
	 * @param orderingColumnName {@link String}
	 * @param searchMap          Map with key and value as String
	 */
	@Override
	public DataTablesResponse<UserBean> getUserList(UserCrudDataTableBean dtRequest,String orderingColumnName, Map<String, String> searchMap) {
        log.info("getting user info list");
		String sqlQuery = "{call tsp_web_admin_slave_getAllExistingUsers(?,?,?,?,?,?,?,?,?)}";
		DataTablesResponse<UserBean> dtResponse = new DataTablesResponse<>();
		List<UserBean> list = new ArrayList<>();
		
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String createdBy = user.getMyMap().get("id");

		try (Connection connection = this.slaveSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setInt(1, dtRequest.getDtRequest().getStart());
			callableStatement.setInt(2, dtRequest.getDtRequest().getLength());
			callableStatement.setString(3, orderingColumnName);
			callableStatement.setString(4, dtRequest.getDtRequest().getOrder().get(0).getDir().toString());
			callableStatement.setString(5, searchMap.get(ColumnNames.USERNAME.get()));
			callableStatement.setString(6, searchMap.get(ColumnNames.USR_ROLE.get()));
			callableStatement.setBigDecimal(7, new BigDecimal(createdBy));
			callableStatement.setString(8, searchMap.get(ColumnNames.USR_STATUS.get()));
			
			callableStatement.registerOutParameter(9, java.sql.Types.INTEGER);
			log.info("{}", callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				while (resultSet.next()) {

					UserBean bean = UserBean.builder().username(resultSet.getString(1))
							.status(resultSet.getString(2)).id(resultSet.getInt(3))
							.roleName(resultSet.getString(4)).build();

					list.add(bean);
				}

				log.info("Size of user list is: {}", list.size());

				int totalRecordCount = callableStatement.getInt(9);
				log.info("totalRecordCount is: {}", totalRecordCount);
				dtResponse.setData(list);
				dtResponse.setRecordsFiltered(totalRecordCount);
				dtResponse.setRecordsTotal(totalRecordCount);
			}

		} catch (Exception e) {
			log.error("Exception occurred in getUserList {}", e);
			return null;
		}

		return dtResponse;
	}
	
	
	/**
	 * updateUserStatus(...) is responsible for updating status of user
	 * 
	 * @param groupId int,status int
	 * @retrun boolean
	 */
	@Override
	public boolean updateUserStatus(int status,int userId) {
		boolean response = true;
		String sqlQuery = "{ call tsp_web_admin_slave_getAdminStatus(?,?) }";
		int st;

		try (Connection connection = this.slaveSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setInt(1, userId);
			callableStatement.registerOutParameter(2, java.sql.Types.INTEGER);
   
			callableStatement.executeQuery();  
			st = callableStatement.getInt(2);
			log.info("status from db {}",st);
			response = updateUserStatusById(status,userId);
			log.info("updateUserStatus {} {} ", callableStatement , response);
		} catch (Exception e) {
			response = false;
			log.error("Exception occurred in updateUserStatus {}", e);
		}
		
		return response;
	}
	
	
	/**
	 * updateUserStatusById(...) is responsible for updating status of user
	 * 
	 * @param groupId int,status int
	 * @retrun boolean
	 */
	public boolean updateUserStatusById(int status,int userId) {
		log.info("status {} userId {}",status,userId);
		boolean response = true;
		String sqlQuery2 = "{ call tsp_web_admin_master_updateAdminStatus(?,?) }";

		try (Connection connection = this.masterSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery2)) {

			callableStatement.setInt(1, userId);
			callableStatement.setInt(2, status);
   
			callableStatement.execute();  
			log.info("updateUserStatusById {}", callableStatement);
		} catch (Exception e) {
			response = false;
			log.info("Exception occurred in updateUserStatusById {}", e);
		}
		
		return response;
	}
	
	/**
	 * getRoles is used to get roles details from database
	 * @return Map<Integer, String>
	 */
	@Override
	public Map<Integer, String> getRoles(){
		Map<Integer, String> map = new LinkedHashMap<>();
		
		String sqlQuery = "{ call tsp_web_admin_slave_getRoles(?) }";
		
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String userId = user.getMyMap().get("id");
		
		try (Connection connection = this.slaveSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setBigDecimal(1, new BigDecimal(userId));
   
			try(ResultSet rs = callableStatement.executeQuery()){
	
				while (rs.next()) {
					map.put(rs.getInt(1), rs.getString(2));
				}        
			
			}
			
			log.info("found roles {} ",map);
		} catch (Exception e) {

			log.error("Exception occurred in getRoles {}", e.getMessage());
		}

		return map;
	}
	
	/**
	 * createUser is used to create new user
	 * @param int userId
	 * @return boolean
	 */
	@Override
	public boolean createUser(UserCrudBean userCrudBean) {
		boolean result = true;
		
		String sqlQuery = "{ call tsp_web_admin_master_addAdminUser(?,?,?,?,?,?,?,?) }";
		
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String userId = user.getMyMap().get("id");

		try (Connection connection = this.masterSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, userCrudBean.getFirstName());
			callableStatement.setString(2, userCrudBean.getLastName());
			callableStatement.setString(3, userCrudBean.getEmail());
			callableStatement.setBigDecimal(4, new BigDecimal(userId));
			callableStatement.setString(5, userCrudBean.getEmail());
			callableStatement.setString(6, null);
			callableStatement.setString(7, userCrudBean.getRoleName());
			callableStatement.setString(8, userCrudBean.getPassword());
   
			callableStatement.execute();       
			log.info("create user {}",callableStatement);
		} catch (Exception e) {
			result = false;
			log.error("Exception occurred in createUser {}", e);
		}
		
		return result;
	}
	
	/**
	 * getUserDetails is used to get user information from database
	 * @param int userId
	 * @return UserCrudBean
	 */
	public UserCrudBean getUserDetails(int userId) {
		
		String sqlQuery = "{ call tsp_web_admin_slave_getUserInfoOnId(?) }";
		
		UserCrudBean userCrudBean = new UserCrudBean();
		
		try (Connection connection = this.slaveSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setBigDecimal(1, new BigDecimal(userId));
   
			try(ResultSet rs = callableStatement.executeQuery()){
	
				while (rs.next()) {
					userCrudBean.setId(userId);
					userCrudBean.setUsername(rs.getString(1));
					userCrudBean.setEmail(rs.getString(2));
					userCrudBean.setFirstName(rs.getString(3));
					userCrudBean.setLastName(rs.getString(4));
					userCrudBean.setRoleName(rs.getString(5));
				}        
			
			}
			
			log.info("found user details {} ",userCrudBean);
		} catch (Exception e) {

			log.error("Exception occurred in getRoles {}", e.getMessage());
		}

		return userCrudBean;

	}
	
	
	/**
	 * updateUser is used to create new user
	 * @param int userId
	 * @return boolean
	 */
	@Override
	public int updateUser(UserCrudBean userCrudBean) {
		int result = 0;
		
		String sqlQuery = "{ call tsp_web_admin_slave_checkMerchantUser(?,?,?) }";
		
		try (Connection connection = this.masterSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, userCrudBean.getEmail());
			callableStatement.setBigDecimal(2, new BigDecimal(userCrudBean.getId()));
			callableStatement.registerOutParameter(3, java.sql.Types.INTEGER);
   
			callableStatement.execute();  
			result = callableStatement.getInt(3);
			log.info("update user {}",callableStatement);
			
			if(result == 0 && !updateUserById(userCrudBean)) {
					result = 100;
			}
			
		} catch (Exception e) {
			result = 100;
			log.error(" Exception occurred in updateUser {}", e.getMessage());
		}
		
		return result;
	}
	
	@Override
	public boolean updateUserById(UserCrudBean userCrudBean) {
		boolean result = true;
		
		String sqlQuery = "{ call tsp_web_admin_master_updateMerchantUserById(?,?,?,?,?) }";
		
		try (Connection connection = this.masterSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, userCrudBean.getFirstName());
			callableStatement.setString(2, userCrudBean.getLastName());
			callableStatement.setString(3, userCrudBean.getEmail());
			callableStatement.setBigDecimal(4, new BigDecimal(userCrudBean.getId()));
			callableStatement.setString(5, userCrudBean.getRoleName());
   
			callableStatement.execute();  
			log.info("update user {}",callableStatement);
			
		} catch (Exception e) {
			result = false;
			log.error(" Exception occurred in updateUserById {}", e.getMessage());
		}
		
		return result;
	}

	
	/**
	 * getWebBlockedUsers is used to get list of blocked users from database
	 * @param BlockedUserDataTableBeandtRequest
	 * @return DataTablesResponse<BlockedUserBean> dtResponse 
	 */
	public DataTablesResponse<BlockedUserBean> getWebBlockedUsers(BlockedUserDataTableBean dtRequest, String orderingColumnName,
			Map<String, String> searchMap){
		
        String sqlQuery = "{ call tsp_web_admin_slave_getBlockedWebUsers(?,?,?,?,?,?,?,?,?,?) }";
        
		DataTablesResponse<BlockedUserBean> dtResponse = new DataTablesResponse<>();
		List<BlockedUserBean> list = new ArrayList<>();
		
		try (Connection connection = this.slaveSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setInt(1, dtRequest.getDtRequest().getStart());
			callableStatement.setInt(2, dtRequest.getDtRequest().getLength());
			callableStatement.setString(3, orderingColumnName);
			callableStatement.setString(4, dtRequest.getDtRequest().getOrder().get(0).getDir().toString());
			callableStatement.setString(5, searchMap.get(ColumnNames.WEB_BLOCKED_USERNAME.get()));
			callableStatement.setString(6, searchMap.get(ColumnNames.WEB_BLOCKED_FIRSTNAME.get()));
			callableStatement.setString(7, searchMap.get(ColumnNames.WEB_BLOCKED_EMAIL.get()));
			callableStatement.setString(8, searchMap.get(ColumnNames.WEB_BLOCKED_BLOCKED_DATE.get()));
			callableStatement.setString(9, searchMap.get(ColumnNames.WEB_BLOCKED_EXPIRY_DATE.get()));
			
			callableStatement.registerOutParameter(10, java.sql.Types.INTEGER);
            log.info("blocked user callable statement {}",callableStatement);
			try(ResultSet rs = callableStatement.executeQuery()){
	
				while (rs.next()) {
					BlockedUserBean blockedUserBean = new BlockedUserBean();
					blockedUserBean.setId(rs.getLong(1));
					blockedUserBean.setUserName(rs.getString(2));
					blockedUserBean.setFirstName(rs.getString(3));
					blockedUserBean.setEmail(rs.getString(4));
					blockedUserBean = parseDatesFromDatabase(rs,blockedUserBean);
					
					list.add(blockedUserBean);
				}        
			    
				int totalRecordCount = callableStatement.getInt(10);
				
				dtResponse.setData(list);
				dtResponse.setRecordsFiltered(totalRecordCount);
				dtResponse.setRecordsTotal(totalRecordCount);
			}
			
			log.info("found web blocked user details {} ",list);
		} catch (Exception e) {

			log.error("Exception occurred in getWebBlockedUsers {}", e.getMessage());
		}

		return dtResponse;
	}
	
	public BlockedUserBean parseDatesFromDatabase(ResultSet rs,BlockedUserBean blockedUserBean) {
		
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		DateFormat timeFormat = new SimpleDateFormat("hh:mm:ss a");
		
		try {
			java.util.Date d = rs.getTimestamp(5);
			blockedUserBean.setBlockDate(dateFormat.format(d)+"  "+timeFormat.format(d));
			java.util.Date d1 = rs.getTimestamp(6);
			blockedUserBean.setExpireDate(dateFormat.format(d1)+"  "+timeFormat.format(d1));
		} catch (Exception e) {
			blockedUserBean.setBlockDate(" ");
			blockedUserBean.setExpireDate(" ");
		}
		
		return blockedUserBean;
	}
	
	/**
	 * unblockBlockedUsers is used to unblock users
	 * @param int mUserId,String comment 
	 * @return boolean
	 */
	@Override
	public boolean unblockBlockedUsers(long mUserId,String comment) {
        boolean result = true;
		log.info("unlock user dao data {} {}",mUserId,comment);
		String sqlQuery = "{ call tsp_web_admin_master_unblockUser(?,?,?) }";
		
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String userId = user.getMyMap().get("id");
		
		try (Connection connection = this.masterSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1, mUserId);
			callableStatement.setString(2, comment);
			callableStatement.setString(3, userId);

   
			callableStatement.execute();    
			log.info("update blocked user {}",callableStatement);
		} catch (Exception e) {
			result = false;
			log.error("Exception occurred in updateUser {}", e.getMessage());
		}
		
		return result;
	}
	
	/**
	 * getMobileBlockedUsers is used to get list of blocked users from database
	 * @param BlockedUserDataTableBeandtRequest
	 * @return DataTablesResponse<BlockedUserBean> dtResponse 
	 */
	public DataTablesResponse<BlockedUserBean> getMobileBlockedUsers(BlockedUserDataTableBean dtRequest, String orderingColumnName,
			Map<String, String> searchMap){
		
        String sqlQuery = "{ call tsp_web_admin_slave_getBlockedMobileUsers(?,?,?,?,?,?,?,?,?,?) }";
        
		DataTablesResponse<BlockedUserBean> dtResponse = new DataTablesResponse<>();
		List<BlockedUserBean> list = new ArrayList<>();
		
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setInt(1, dtRequest.getDtRequest().getStart());
			callableStatement.setInt(2, dtRequest.getDtRequest().getLength());
			callableStatement.setString(3, orderingColumnName);
			callableStatement.setString(4, dtRequest.getDtRequest().getOrder().get(0).getDir().toString());
			callableStatement.setString(5, searchMap.get(ColumnNames.WEB_BLOCKED_USERNAME.get()));
			callableStatement.setString(6, searchMap.get(ColumnNames.WEB_BLOCKED_FIRSTNAME.get()));
			callableStatement.setString(7, searchMap.get(ColumnNames.WEB_BLOCKED_EMAIL.get()));
			callableStatement.setString(8, searchMap.get(ColumnNames.WEB_BLOCKED_BLOCKED_DATE.get()));
			callableStatement.setString(9, searchMap.get(ColumnNames.WEB_BLOCKED_EXPIRY_DATE.get()));
			log.info("mobile blocked user callable statement {}",callableStatement);
			callableStatement.registerOutParameter(10, java.sql.Types.INTEGER);
          
			try(ResultSet rs = callableStatement.executeQuery()){
	
				while (rs.next()) {
					BlockedUserBean blockedUserBean = new BlockedUserBean();
					blockedUserBean.setId(rs.getLong(1));
					blockedUserBean.setUserName(rs.getString(2));
					blockedUserBean.setFirstName(rs.getString(3));
					blockedUserBean.setEmail(rs.getString(4));
					blockedUserBean = parseDatesFromDatabase(rs,blockedUserBean);
					
					list.add(blockedUserBean);
				}        
			    
				int totalRecordCount = callableStatement.getInt(10);
				
				dtResponse.setData(list);
				dtResponse.setRecordsFiltered(totalRecordCount);
				dtResponse.setRecordsTotal(totalRecordCount);
			}
			
			log.info("found web blocked user details {} ",list);
		} catch (Exception e) {

			log.error("Exception occurred in getMobileBlockedUsers {}", e);
		}

		return dtResponse;
	}
	
	/**
	 * unblockMobileBlockedUsers is used to unblock users
	 * @param int mUserId,String comment 
	 * @return boolean
	 */
	@Override
	public boolean unblockMobileBlockedUsers(long mUserId,String comment) {
        boolean result = true;
		log.info("unlock user dao data {} {}",mUserId,comment);
		String sqlQuery = "{ call tsp_web_admin_master_unblockUser(?,?,?) }";
		
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String userId = user.getMyMap().get("id");
		
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1, mUserId);
			callableStatement.setString(2, comment);
			callableStatement.setString(3, userId);

   
			callableStatement.execute();    
			log.info("update blocked user {}",callableStatement);
		} catch (Exception e) {
			result = false;
			log.error("Exception occurred in updateUser {}", e.getMessage());
		}
		
		return result;
	}

}
