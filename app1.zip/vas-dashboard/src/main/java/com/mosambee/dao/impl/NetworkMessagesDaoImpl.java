package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.NetworkMessagesDataTablesRequestBean;
import com.mosambee.bean.NetworkMessagesDownloadBean;
import com.mosambee.bean.NetworkMessagesListBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.dao.NetworkMessagesDao;

import lombok.extern.log4j.Log4j2;

/**
 * {@link NetworkMessagesDaoImpl} is responsible for handling database operations
 * for networkmessages module. The class is responsible for fetching the list 
 * based on provided userId and dates.
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 27-March-2020
 */

@Log4j2
@Repository("networkMessagesDao")
public class NetworkMessagesDaoImpl implements NetworkMessagesDao{
	
	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;

	
	/**
	 * getNetworkMessagesList(...) is responsible for getting the list,
	 * corresponding to the coming data-tables request. Here we have three
	 * parameters, first is the actual {@link DataTablesRequest}, second one is the
	 * orderingColumnName in which ordering is going to happen (ASC/DESC). Third one
	 * is a map which is basically a Map of String key and value pairs which
	 * transformed request parameters.
	 * 
	 * @param dtRequest          {@link DataTablesRequest}
	 * @param orderingColumnName {@link String}
	 * @param map                Map with key and value as String
	 */
	@Override
	public DataTablesResponse<NetworkMessagesListBean> getNetworkMessagesList(NetworkMessagesDataTablesRequestBean dtRequest, String orderingColumnName, Map<String, String> map) {
		
		DataTablesResponse<NetworkMessagesListBean> dtResponse = new DataTablesResponse<>();
		
		List<NetworkMessagesListBean> list = new ArrayList<>();
		
		String sqlQuery = "{ call tsp_web_admin_slave_getNetworkMessagesList(?,?,?,?,?,?,?,?) }";
		
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, map.get("networkMessagesUserId"));
			callableStatement.setString(2, dtRequest.getFromDate());
			callableStatement.setString(3, dtRequest.getToDate());
			callableStatement.setInt(4, dtRequest.getDtRequest().getStart());
			callableStatement.setInt(5, dtRequest.getDtRequest().getLength());
			callableStatement.setString(6, orderingColumnName);
			callableStatement.setString(7, dtRequest.getDtRequest().getOrder().get(0).getDir().toString());
			callableStatement.registerOutParameter(8, java.sql.Types.INTEGER);

			log.info("{}", callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				while (resultSet.next()) {

					NetworkMessagesListBean bean = NetworkMessagesListBean.builder().userName(resultSet.getString(1)).terminalId(resultSet.getString(2))
							.processingCode(resultSet.getString(3)).messageType(resultSet.getInt(4)).responseCode(resultSet.getString(5))
							.hsmResponseCode(resultSet.getString(6)).date(resultSet.getString(7)).build();

					list.add(bean);
				}

			}

			log.info("Size of search by networkmessages list: {}", list.size());

			int totalRecordCount = callableStatement.getInt(8);

			dtResponse.setData(list);
			dtResponse.setRecordsFiltered(totalRecordCount);
			dtResponse.setRecordsTotal(totalRecordCount);
			
		} catch (Exception e) {
			log.error("Exception occurred in getNetworkMessagesList {}", e);
			return null;
		}

		dtResponse.setData(list);
		log.info(dtResponse);
		return dtResponse;
	}

	/**
	 * downloadNetworkMessagesList(...) is responsible for fetching data
	 * required for downloading NetworkmessagesList.
	 * 
	 * @return List<NetworkMessagesDownloadBean>
	 */
	@Override
	public List<NetworkMessagesDownloadBean> downloadNetworkMessagesList(NetworkMessagesDownloadBean bean) {
		List<NetworkMessagesDownloadBean> list = new ArrayList<>();
		
		String sqlQuery = "{ call tsp_web_admin_slave_getNetworkMessagesDownloadList(?,?,?) }";
		
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, bean.getUserId().trim());
			callableStatement.setString(2, bean.getFromDate());
			callableStatement.setString(3, bean.getToDate());
			
			log.info("{}", callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				while (resultSet.next()) {

					NetworkMessagesDownloadBean result = NetworkMessagesDownloadBean.builder().userName(resultSet.getString(1)).terminalId(resultSet.getString(2))
							.processingCode(resultSet.getString(3)).messageType(resultSet.getInt(4)).responseCode(resultSet.getString(5))
							.hsmResponseCode(resultSet.getString(6)).date(resultSet.getString(7)).build();

					list.add(result);
				}

			}

			log.info("Size of download networkmessages list: {}", list.size());
		} catch (Exception e) {
			log.error("Exception occurred in downloadNetworkMessagesList {}", e);
			return null;
		}

		return list;

	}


}
