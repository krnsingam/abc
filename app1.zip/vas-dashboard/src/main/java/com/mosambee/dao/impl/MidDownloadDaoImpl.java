package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.mosambee.bean.MidDateBean;
import com.mosambee.bean.MidDownloadBean;
import com.mosambee.dao.MidDownloadDao;

/**
 * This class provides specification for {@link MidDownloadDao}
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Repository("midDownloadDao")
public class MidDownloadDaoImpl implements MidDownloadDao {

	private static final Logger log = LogManager.getLogger("MidDownloadDaoImpl.class");

	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;

	/**
	 * downloadMid() is responsible for downloading mid
	 *
	 */
	@Override
	public List<MidDownloadBean> downloadMid(MidDateBean midDateBean) {
		String sqlQuery = "{call  tsp_web_admin_slave_getInstantMerchantList(?,?,?,?,?,?,?)}";

		List<MidDownloadBean> list = new ArrayList<>();

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, midDateBean.getFromDate());// fromDate
			callableStatement.setString(2, midDateBean.getToDate());// toDate
			callableStatement.setString(3, midDateBean.getAcquirer());
			callableStatement.setString(4, midDateBean.getMid());
			callableStatement.setString(5, midDateBean.getTempMerchantCode());
			callableStatement.setString(6, midDateBean.getTempTid());
			callableStatement.setString(7, midDateBean.getTypeId());
			
			try (ResultSet resultSet = callableStatement.executeQuery()) {
				log.info("{}", callableStatement);
				while (resultSet.next()) {
					MidDownloadBean midDownloadBean = MidDownloadBean.builder().posId(resultSet.getString(1))
							.mid(resultSet.getString(2)).tempMerchantCode(resultSet.getString(3))
							.tempTid(resultSet.getString(4)).typeId(resultSet.getString(5))
							.acquirer(resultSet.getString(6)).createdTime(resultSet.getString(7)).build();
					list.add(midDownloadBean);
				}
				log.info("Size of  download Mid list is: {}", list.size());
			}
		} catch (Exception e) {
			log.error("Exception occurred in downloadMid {}", e);
		}
		return list;
	}

}
