package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.mosambee.bean.CreateAPIGroup;
import com.mosambee.bean.ListOfAPIGroup;
import com.mosambee.bean.MIDBulkUpload;
import com.mosambee.bean.MidApiGroupDaetailBean;
import com.mosambee.bean.MidTidBean;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.UpdateAPIPaswordConfigRequestFromList;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.constants.CommonConstants;
import com.mosambee.dao.APIPasswordConfigDao;
import com.mosambee.util.SHA1;

/**
 * This class used to provide implementation for all methods of
 * {@link APIPasswordConfigDao} This class responsible for store and fetch
 * record in database.
 * 
 * @version 1.0
 * @author mandar.chaudhari
 */
@Repository("apiPasswordConfigDaoImpl")
public class APIPasswordConfigDaoImpl implements APIPasswordConfigDao {

	private static final Logger log = LogManager.getLogger(APIPasswordConfigDaoImpl.class);

	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;

	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;

	@Autowired
	SHA1 sha1;

	private static final String CALLABLE_STATEMENT = "callableStatement : {}";

	/**
	 * This method is used to create/insert record for API Password Config Group.
	 * This method operates on database : sfn_transaction and table :
	 * merchant_api_division.
	 * 
	 * @param createAPIGroup : Expect bean of "{@link CreateAPIGroup}" from which
	 *                       data should be store.
	 * @param createdBy      : Expect id of user which is responsible for record
	 *                       creating.
	 * @param responseBean   : Expect bean of "{@link ResponseBean}" which is used
	 *                       to set operation status message as well as id of record
	 *                       inserted which we use for update record.
	 * @return boolean : Return "true" if record inserted successfully. Return
	 *         "false" if record insertion failed due to any reason.
	 * @author mandar.chaudhari
	 */
	@Override
	public ResponseBean createAPIGroup(CreateAPIGroup createAPIGroup, long createdBy) {

		String sqlQuery = "{ call tsp_web_admin_master_createAPIGroup(?,?,?,?,?,?,?,?,?,?,?,?,?,?) }";
		ResponseBean responseBean = new ResponseBean();

		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			callableStatement.setString(1, createAPIGroup.getApiDivisionName());
			callableStatement.setString(2, createAPIGroup.getApiDivisionCode());
			callableStatement.setString(3, createAPIGroup.getApiPassword());
			callableStatement.setString(4, createAPIGroup.getApiURL1());
			callableStatement.setString(5, createAPIGroup.getApiURL2());
			callableStatement.setString(6, createAPIGroup.getDivisionRef1());
			callableStatement.setString(7, createAPIGroup.getDivisionRef2());
			callableStatement.setString(8, createAPIGroup.getDivisionRef3());
			callableStatement.setString(9, createAPIGroup.getDivisionRef4());
			callableStatement.setLong(10, createdBy);
			callableStatement.setInt(11, createAPIGroup.getFlag());
			callableStatement.registerOutParameter(12, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(13, java.sql.Types.BIGINT);
			callableStatement.registerOutParameter(14, java.sql.Types.BOOLEAN);

			createAPIGroup.setDivisionStatus((byte) 1);
			log.info(CALLABLE_STATEMENT, callableStatement);
			callableStatement.execute();
			String temp = callableStatement.getString(12);
			responseBean.setMsg(temp);
			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put("recordId", callableStatement.getLong(13));

			if (callableStatement.getBoolean(14)) {
				responseBean.setUpdateRequest(true);
				return responseBean;
			}

		} catch (Exception e) {
			log.error("Error occurred in createAPIGroup() while inserting record : {}", e);
			responseBean.setMsg(CommonConstants.RECORD_INSERTION_FAILED.get());
			responseBean.setUpdateRequest(false);
			return responseBean;
		}
		responseBean.setUpdateRequest(false);
		return responseBean;
	}

	/**
	 * This method is used to update record for API Password Config Group. This
	 * method operates on database : sfn_transaction and table :
	 * merchant_api_division.
	 * 
	 * @param createAPIGroup : Expect bean of "{@link CreateAPIGroup}" from which
	 *                       data should be store.
	 * @param updatedBy      : Expect id of user which is responsible for record
	 *                       updating.
	 * @param responseBean   : Expect bean of "{@link ResponseBean}" which is used
	 *                       to set operation status message as well as id of record
	 *                       inserted which we use for update record as well as use
	 *                       this to render data related to status message to jsp.
	 * @return boolean : Return "true" if record updated successfully. Return
	 *         "false" if record update failed due to any reason.
	 * @author mandar.chaudhari
	 */
	@Override
	public boolean updateAPIGroup(CreateAPIGroup createAPIGroup, ResponseBean responseBean, long updatedBy) {
		log.info("APIPasswordConfigDaoImpl  updateAPIGroup() called. ");

		String sqlQuery = "{ call tsp_web_admin_master_updateAPIGroup(?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?) }";

		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, createAPIGroup.getApiDivisionName());
			callableStatement.setString(2, createAPIGroup.getApiPassword());
			callableStatement.setString(3, createAPIGroup.getApiURL1());
			callableStatement.setString(4, createAPIGroup.getApiURL2());
			callableStatement.setString(5, createAPIGroup.getDivisionRef1());
			callableStatement.setString(6, createAPIGroup.getDivisionRef2());
			callableStatement.setString(7, createAPIGroup.getDivisionRef3());
			callableStatement.setString(8, createAPIGroup.getDivisionRef4());
			callableStatement.setLong(9, createAPIGroup.getDivisionStatus());
			callableStatement.setLong(10, updatedBy);
			callableStatement.setLong(11, createAPIGroup.getId());
			if (createAPIGroup.getApiPassword() != null && !createAPIGroup.getApiPassword().isEmpty()) {
				callableStatement.setLong(12, 1);
			} else {
				callableStatement.setLong(12, 0);
			}
			callableStatement.setLong(13, createAPIGroup.getFlag());
			callableStatement.registerOutParameter(14, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(15, java.sql.Types.BOOLEAN);

			log.info(CALLABLE_STATEMENT, callableStatement);
			callableStatement.execute();
			String temp = callableStatement.getString(14);
			responseBean.setMsg(temp);
			if (callableStatement.getBoolean(15)) {
				return true;
			}

		} catch (Exception e) {
			log.error("Error occurred in updateAPIGroup() while updating record : {}", e);
			responseBean.setMsg(CommonConstants.RECORD_INSERTION_FAILED.get());
			return false;
		}
		return false;
	}

	/**
	 * This method is used to get list of API Password Config Group. This method
	 * operates on database : sfn_transaction and table : merchant_api_division.
	 * 
	 * @param dtRequest          : Expect bean of "{@link DataTablesRequest}" which
	 *                           is used to get constraints for fetching record from
	 *                           database.
	 * @param orderingColumnName : Expect name of column for ordering list data.
	 * @param searchMap          : Expecting "{@link Map}<String, String>" which
	 *                           stores the column value for data filter.
	 * @return {@link DataTablesResponse<{@link ListOfAPIGroup }>
	 * @author mandar.chaudhari
	 */
	@Override
	public DataTablesResponse<ListOfAPIGroup> getListOfAPIGroup(DataTablesRequest dtRequest, String orderingColumnName,
			Map<String, String> searchMap) {

		String sqlQuery = "{call tsp_web_admin_slave_getListOfAPIGroup(?,?,?,?,?,?,?,?,?,?,?)}";
		DataTablesResponse<ListOfAPIGroup> dtResponse = new DataTablesResponse<>();
		List<ListOfAPIGroup> list = new ArrayList<>();
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setInt(1, dtRequest.getStart());
			callableStatement.setInt(2, dtRequest.getLength());
			callableStatement.setString(3, orderingColumnName);
			callableStatement.setString(4, dtRequest.getOrder().get(0).getDir().toString());
			callableStatement.setLong(5, Long.parseLong(searchMap.get(ColumnNames.ID.get())));
			callableStatement.setString(6, searchMap.get(ColumnNames.API_DIVISION_NAME.get()));
			callableStatement.setString(7, searchMap.get(ColumnNames.API_DIVISION_CODE.get()));
			callableStatement.setString(8, searchMap.get(ColumnNames.MPOS_API_PASSWORD.get()));
			callableStatement.setInt(9, Integer.parseInt(searchMap.get(ColumnNames.DIVISION_STATUS.get())));
			callableStatement.setString(10, searchMap.get(ColumnNames.API_URL_1.get()));
			callableStatement.registerOutParameter(11, java.sql.Types.INTEGER);
			log.info(CALLABLE_STATEMENT, callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {
				while (resultSet.next()) {
					String stat;
					if (resultSet.getString(6) != null && resultSet.getString(6).equals("1")) {
						stat = "Yes";
					} else {
						stat = "No";
					}
					ListOfAPIGroup bean = ListOfAPIGroup.builder().id(resultSet.getLong(1))
							.apiDivisionName(resultSet.getString(2)).apiDivisionCode(resultSet.getString(3))
							.apiPassword(resultSet.getString(4))
							.apiURL1((resultSet.getString(5).equals("") ? "NA" : resultSet.getString(5)))
							.divisionStatus(stat).midCount(resultSet.getLong(7)).build();
					log.info(resultSet.getLong(7));

					list.add(bean);
				}

				log.info("Size of getListOfAPIGroup  is: {}", list.size());

				int totalRecordCount = callableStatement.getInt(11);

				dtResponse.setData(list);
				dtResponse.setRecordsFiltered(totalRecordCount);
				dtResponse.setRecordsTotal(totalRecordCount);
				log.info("totalRecordCount : {} ", totalRecordCount);
			}

		} catch (Exception e) {
			log.error("Exception occurred in getListOfAPIGroup {}", e);
			return null;
		}

		return dtResponse;
	}

	/**
	 * This method is used to get Mid Tid. This method operates on database :
	 * sfn_transaction and table : merchant_api_division.
	 * 
	 * @param dtRequest          : Expect bean of "{@link DataTablesRequest}" which
	 *                           is used to get constraints for fetching record from
	 *                           database.
	 * @param orderingColumnName : Expect name of column for ordering list data.
	 * @param searchMap          : Expecting "{@link Map}<String, String>" which
	 *                           stores the column value for data filter.
	 * @return {@link DataTablesResponse<{@link ListOfAPIGroup }>
	 * @author mandar.chaudhari
	 */
	@Override
	public DataTablesResponse<MidTidBean> listMidTid(DataTablesRequest dtRequest, String orderingColumnName,
			Map<String, String> searchMap, int id) {

		String sqlQuery = "{call tsp_web_admin_slave_getMidTidDetails(?,?,?,?,?, ?,?,?,?)}";
		DataTablesResponse<MidTidBean> dtResponse = new DataTablesResponse<>();
		List<MidTidBean> list = new ArrayList<>();
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setInt(1, dtRequest.getStart());
			callableStatement.setInt(2, dtRequest.getLength());
			callableStatement.setString(3, orderingColumnName);
			callableStatement.setString(4, dtRequest.getOrder().get(0).getDir().toString());
			callableStatement.setLong(5, id);
			callableStatement.setString(6, searchMap.get(ColumnNames.MID_DETAIL.get()));
			callableStatement.setString(7, searchMap.get(ColumnNames.TID_DETAIL.get()));
			callableStatement.setString(8, searchMap.get(ColumnNames.DIVISION_CODE_DETAIL.get()));
			callableStatement.registerOutParameter(9, java.sql.Types.INTEGER);
			log.info(CALLABLE_STATEMENT, callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {
				while (resultSet.next()) {

					MidTidBean bean = MidTidBean.builder().mid(resultSet.getString(2)).tid(resultSet.getString(3))
							.divCode(resultSet.getString(4)).build();

					list.add(bean);
				}

				log.info("Size of listMidTid  is: {}", list.size());

				int totalRecordCount = callableStatement.getInt(9);

				dtResponse.setData(list);
				dtResponse.setRecordsFiltered(totalRecordCount);
				dtResponse.setRecordsTotal(totalRecordCount);
				log.info("totalRecordCount : {} ", totalRecordCount);
			}

		} catch (Exception e) {
			log.info("Exception occurred in listMidTid {}", e);
			return null;
		}

		return dtResponse;
	}

	/**
	 * This method is used to fetch details of API Password Config Group by id. This
	 * method we have used when we want to edit API Password Config from list. This
	 * method operates on database : sfn_transaction and table :
	 * merchant_api_division.
	 * 
	 * @param updateAPIPaswordConfigRequestFromList : Expect bean of
	 *                                              "{@link UpdateAPIPaswordConfigRequestFromList}"
	 *                                              which is used to get id of API
	 *                                              Password Config.
	 * @param createAPIGroup                        : Expect bean of
	 *                                              "{@CreateAPIGroup}" in which the
	 *                                              method will store all data of
	 *                                              API Password Config.
	 * @param responseBean                          : Expect bean of
	 *                                              "{@link ResponseBean}" which is
	 *                                              used to set operation status
	 *                                              message. We can use this to to
	 *                                              render data related to status
	 *                                              message to jsp.
	 * @return boolean : Return "True" if record successfully fetched. Return
	 *         "false" if record is not successfully fetched or record not found.
	 * @author mandar.chaudhari
	 */
	@Override
	public boolean getAPIGroupDataById(UpdateAPIPaswordConfigRequestFromList updateAPIPaswordConfigRequestFromList,
			CreateAPIGroup createAPIGroup, ResponseBean responseBean) {

		String sqlQuery = "{ call tsp_web_admin_slave_getPasswordConfigById(?,?,?) }";

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1, updateAPIPaswordConfigRequestFromList.getId());
			callableStatement.registerOutParameter(2, java.sql.Types.BOOLEAN);
			callableStatement.registerOutParameter(3, java.sql.Types.VARCHAR);

			log.info(CALLABLE_STATEMENT, callableStatement);

			try (ResultSet resultSet = callableStatement.executeQuery();) {
				while (resultSet.next()) {
					createAPIGroup.setApiDivisionName(resultSet.getString(2));
					createAPIGroup.setApiDivisionCode(resultSet.getString(3));
					createAPIGroup.setApiPassword(resultSet.getString(4));
					createAPIGroup.setApiURL1(resultSet.getString(5));
					createAPIGroup.setApiURL2(resultSet.getString(6));
					createAPIGroup.setDivisionRef1(resultSet.getString(7));
					createAPIGroup.setDivisionRef2(resultSet.getString(8));
					createAPIGroup.setDivisionRef3(resultSet.getString(9));
					createAPIGroup.setDivisionRef4(resultSet.getString(10));
					createAPIGroup.setDivisionStatus(resultSet.getByte(11));
					createAPIGroup.setFlag(resultSet.getByte(12));

					String temp = callableStatement.getString(3);
					responseBean.setMsg(temp);
					responseBean.setData(new HashMap<String, Object>());
					responseBean.getData().put("recordId", resultSet.getLong(1));
				}
				if (callableStatement.getBoolean(2)) {
					return true;
				}
			}

		} catch (Exception e) {
			log.error("Error occurred in getAPIGroupDataById() while fetching record : {}", e);
			responseBean.setMsg(CommonConstants.RECORD_INSERTION_FAILED.get());
			return false;
		}
		return false;
	}

	/**
	 * This method is used to validating record of {@link MIDBulkUpload} bean This
	 * method operates on database : sfn_transaction and table :
	 * merchant_api_division.
	 * 
	 * @param midBulkUpload : Expect bean of "{@link MIDBulkUpload}" of which data
	 *                      we want to store.
	 * @author karan.singam
	 */
	@Override
	public MIDBulkUpload validateMIDBulkUploadData(MIDBulkUpload midBulkUpload) {

		MIDBulkUpload bulkup = new MIDBulkUpload();
		String sqlQuery = "{ call tsp_web_admin_slave_getCheckGroupAPIDetail(?,?,?,?,?, ?,?) }";

		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, midBulkUpload.getDivisionCode());
			callableStatement.setString(2, midBulkUpload.getMid());
			callableStatement.setString(3, midBulkUpload.getTid());
			callableStatement.registerOutParameter(4, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(5, java.sql.Types.BIGINT);
			callableStatement.registerOutParameter(6, java.sql.Types.BIGINT);
			callableStatement.registerOutParameter(7, java.sql.Types.INTEGER);

			log.info(CALLABLE_STATEMENT, callableStatement);

			callableStatement.execute();
			bulkup.setDivisionCode(midBulkUpload.getDivisionCode());
			bulkup.setMid(midBulkUpload.getMid());
			bulkup.setTid(midBulkUpload.getTid());
			bulkup.setMposPassword(callableStatement.getString(4));
			bulkup.setPosId(callableStatement.getLong(5));
			bulkup.setDivId(callableStatement.getLong(6));
			bulkup.setErrCode(callableStatement.getInt(7));
			log.info("Status : {}", midBulkUpload.getStatus());
		} catch (Exception e) {
			log.error(
					"Error occurred in validateMIDBulkUploadData() while validating MIDBulkUpload for MID : {}, TID : {}, divisionCode : {} e : {}",
					midBulkUpload.getMid(), midBulkUpload.getTid(), midBulkUpload.getDivisionCode(), e);
		}
		return bulkup;
	}

	/**
	 * This method is used to insert record of {@link MIDBulkUpload} bean This
	 * method operates on database : sfn_transaction and table :
	 * merchant_api_division_merchant_code.
	 * 
	 * @param midBulkUpload : Expect bean of "{@link MIDBulkUpload}" of which data
	 *                      we want to store.
	 * @author mandar.chaudhari
	 */
	public void insertMIDBulkUploadData(MIDBulkUpload midBulkUpload, long createdBy) {
		String sqlQuery = "{ call tsp_web_admin_master_AddGroupMIDTID(?,?,?,?,?, ?,?,?) }";

		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, midBulkUpload.getMposPassword());
			callableStatement.setLong(2, midBulkUpload.getDivId());
			callableStatement.setString(3, midBulkUpload.getMid());
			callableStatement.setString(4, midBulkUpload.getTid());
			callableStatement.setLong(5, midBulkUpload.getPosId());
			callableStatement.setLong(6, createdBy);
			callableStatement.setInt(7, midBulkUpload.getErrCode());
			callableStatement.registerOutParameter(8, java.sql.Types.INTEGER);

			log.info(CALLABLE_STATEMENT, callableStatement);

			callableStatement.execute();
			midBulkUpload.setErrCode(callableStatement.getInt(8));
			log.info("Status : {}", midBulkUpload.getStatus());
		} catch (Exception e) {
			log.error(
					"Error occurred in insertMIDBulkUploadData() while inserting MIDBulkUpload for MID : {}, TID : {}, divisionCode : {} e : {}",
					midBulkUpload.getMid(), midBulkUpload.getTid(), midBulkUpload.getDivisionCode(), e);
		}
	}

	/**
	 * This method is used to check whether "password" is present for this "id".
	 * This method operates on database : sfn_transaction and table :
	 * merchant_api_division_merchant_code.
	 * 
	 * @param password : Expect String which should be checked.
	 * @param id       : Expect id as long which should be checked with password.
	 * @return boolean : Return "True" is password present. Return "False" is
	 *         password not present.
	 * @author mandar.chaudhari
	 */
	@Override
	public boolean isAPIPasswordConfigPasswordPresent(String password, long id) {
		String sqlQuery = "{ call tsp_web_admin_master_checkConfigPassword(?,?,?) }";

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1, id);
			callableStatement.setString(2, password);
			callableStatement.registerOutParameter(3, java.sql.Types.BOOLEAN);

			log.info(CALLABLE_STATEMENT, callableStatement);

			callableStatement.execute();
			return callableStatement.getBoolean(3);

		} catch (Exception e) {
			log.error(
					"Error occurred in isAPIPasswordConfigPasswordPresent() while checking APIPasswordConfig password is present or not : {}",
					e);
			return false;
		}
	}

	/**
	 * This method operates on database : sfn_transaction and table :
	 * merchant_api_division. It is used for updating email or API sent status.
	 * 
	 * @param CreateAPIGroup
	 * @param long
	 * @return boolean
	 */
	@Override
	public boolean updateApiEmailCall(CreateAPIGroup createAPIGroup, long id) {
		String sqlQuery = "{ call tsp_web_admin_master_UpdateGroupNotification(?,?) }";

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1, id);
			if (createAPIGroup.isApiUpdateStat()) {
				callableStatement.setInt(2, 1);
			} else {
				callableStatement.setInt(2, 0);
			}

			log.info(CALLABLE_STATEMENT, callableStatement);

			callableStatement.execute();
			return true;

		} catch (Exception e) {
			log.info(e.getMessage());
			return false;
		}
	}

	/**
	 * isAPIDetailsPresent() is used to get details of API-URL and references to be
	 * used after midBulk upload.
	 *
	 * @param id : Expect id as long.
	 * @return MidApiGroupDaetailBean
	 */
	@Override
	public MidApiGroupDaetailBean isAPIDetailsPresent(long id) {
		MidApiGroupDaetailBean bean = new MidApiGroupDaetailBean();
		String sqlQuery = "{ call tsp_web_admin_slave_getAPIGroupDetail(?) }";

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1, id);

			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);
				while (resultSet.next()) {

					bean = MidApiGroupDaetailBean.builder().apiUrl1(resultSet.getString(1))
							.apiUrl2(resultSet.getString(2)).divRefNo1(resultSet.getString(3))
							.divRefNo2(resultSet.getString(4)).divRefNo3(resultSet.getString(5))
							.mPosApiPassword(resultSet.getString(6)).build();
				}

			}

			return bean;
		} catch (Exception e) {
			log.error(
					"Error occurred in isAPIPasswordConfigPasswordPresent() while checking APIPasswordConfig password is present or not : {}",
					e);
			return bean;
		}
	}
}
