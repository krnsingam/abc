package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.AcquirerBean;
import com.mosambee.bean.TransactionDateReportBean;
import com.mosambee.bean.TransactionReportBean;
import com.mosambee.bean.TransactionSearchFormBean;
import com.mosambee.bean.TransactionSearchFormDataTableBean;
import com.mosambee.bean.TransactionSearchReportBean;
import com.mosambee.bean.TransactionTypeBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.TransactionReportDao;
import com.mosambee.validator.CommonValidator;

/**
 * {@link TransactionReportDaoImpl} is responsible for handling database
 * operations for Transaction. The class is responsible for fetching the active
 * list of Transaction.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 10-January-2020
 */
@Repository(value = "transactionReportDao")
public class TransactionReportDaoImpl implements TransactionReportDao {

	private static final Logger log = LogManager.getLogger(TransactionReportDaoImpl.class);

	@Autowired
	@Qualifier("slaveSfnVasTemplate")
	JdbcTemplate slaveSfnVasTemplate;

	@Autowired
	@Qualifier("slaveSecurityAndLicenseTemplate")
	JdbcTemplate slaveSecurityAndLicenseTemplate;

	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;
	
	@Autowired
	CommonValidator commonValidator;

	// common sql for all query and Strings for use
	private static final String TXN_REPORT_DETAILS_QUERY = "{call tsp_web_admin_slave_getTransactionReportDetails(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
	
	private static final String TIMEFORMAT = "hh:mm:ss a";

	/**
	 * getActiveTransactionReport(...) is responsible for getting the active
	 * Transaction list, corresponding to the coming data-tables request. Here we
	 * have three parameters, first is the actual {@link DataTablesRequest}, second
	 * one is the orderingColumnName in which ordering is going to happen
	 * (ASC/DESC). Third one is a searchMap which is basically a Map of String key
	 * and value pairs which transformed search values for each column in which we
	 * are applying data-tables search.
	 * 
	 * @param dtRequest          {@link DataTablesRequest}
	 * @param orderingColumnName {@link String}
	 * @param searchMap          Map with key and value as String
	 */
	@Override
	public DataTablesResponse<TransactionReportBean> getActiveTransactionReport(TransactionDateReportBean dtRequest,
			String orderingColumnName, Map<String, String> searchMap) {
		DataTablesResponse<TransactionReportBean> dtResponse = new DataTablesResponse<>();
		List<TransactionReportBean> list = new ArrayList<>();

		try (Connection connection = this.slaveSfnVasTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(TXN_REPORT_DETAILS_QUERY)) {

			callableStatement.setInt(1, dtRequest.getDataTable().getStart());
			callableStatement.setInt(2, dtRequest.getDataTable().getLength());
			callableStatement.setString(3, orderingColumnName);
			callableStatement.setString(4, dtRequest.getDataTable().getOrder().get(0).getDir().toString());
			callableStatement.setString(5, dtRequest.getFromDate());
			callableStatement.setString(6, dtRequest.getToDate());
			callableStatement.setString(7, searchMap.get(ColumnNames.TRANSACTION_AUTH_CODE.get()));
			callableStatement.setString(8, searchMap.get(ColumnNames.TRANSACTION_BIN_VALUE.get()));
			callableStatement.setString(9, searchMap.get(ColumnNames.TRANSACTION_TXN_AMOUNT.get()));
			callableStatement.setString(10, searchMap.get(ColumnNames.TRANSACTION_ISSUER.get()));
			callableStatement.setString(11, searchMap.get(ColumnNames.TRANSACTION_STATUS.get()));
			callableStatement.setString(12, "");
			callableStatement.setString(13, searchMap.get(ColumnNames.TRANSACTION_REFERENCE_NO.get()));
			callableStatement.setInt(14, 0);
			callableStatement.registerOutParameter(15, java.sql.Types.INTEGER);

			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);
				while (resultSet.next()) {
					String settlement = resultSet.getString(9);
					if (!settlement.equals("SETTLED")) {
						settlement = "UNSETTLED";
					}
					TransactionReportBean bean = TransactionReportBean.builder().id(resultSet.getInt(1))
							.txnRefNo(resultSet.getString(2)).enquiryId(resultSet.getInt(3)).rrn(resultSet.getString(4))
							.authCode(resultSet.getString(5))
							.txnAmount(commonValidator.validationDecimal(resultSet.getString(6)))
							.binValue(resultSet.getString(7)).issuer(resultSet.getString(8))
							.status(resultSet.getString(9)).conversionStatus(resultSet.getString(10))
							.txnTime(resultSet.getString(11)).cardType(resultSet.getString(15))
							.emiConverted(resultSet.getString(16)).settlementStatus(settlement).build();

					list.add(bean);
				}

			}

			log.info("Size of active transaction list: {}", list.size());

			int totalRecordCount = callableStatement.getInt(15);

			dtResponse.setData(list);
			dtResponse.setRecordsFiltered(totalRecordCount);
			dtResponse.setRecordsTotal(totalRecordCount);
		} catch (Exception e) {
			log.error("Exception occurred in getActiveTransactionReport {}", e);
			return null;
		}

		dtResponse.setData(list);
		log.info(dtResponse);
		return dtResponse;
	}

	/**
	 * downloadActiveTransactionReportList(...) is responsible for fetching data
	 * required for downloading TransactionList from transactions and enquiry and
	 * return list of TransactionReportBean.
	 * 
	 * @return List<TransactionReportBean>
	 */
	@Override
	public List<TransactionReportBean> downloadActiveTransactionReportList(TransactionReportBean report) {

		TransactionReportBean bean = null;
		List<TransactionReportBean> list = new ArrayList<>();

		try (Connection connection = this.slaveSfnVasTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(TXN_REPORT_DETAILS_QUERY)) {

			callableStatement.setInt(1, 0);
			callableStatement.setInt(2, 0);
			callableStatement.setString(3, "");
			callableStatement.setString(4, "");
			callableStatement.setString(5, report.getFromDate().trim());
			callableStatement.setString(6, report.getToDate().trim());
			callableStatement.setString(7, report.getAuthCode().trim());
			callableStatement.setString(8, report.getBinValue().trim());
			callableStatement.setString(9, report.getTxnAmount().trim());
			callableStatement.setString(10, report.getIssuer().trim());
			callableStatement.setString(11, report.getStatus().trim());
			callableStatement.setString(12, "");
			callableStatement.setString(13, report.getTxnRefNo().trim());
			callableStatement.setInt(14, 0);
			callableStatement.registerOutParameter(15, java.sql.Types.INTEGER);

			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);

				while (resultSet.next()) {
					StringBuilder intRate = new StringBuilder(
							commonValidator.validationDecimal(resultSet.getString(14))).append("%");
					bean = TransactionReportBean.builder().id(resultSet.getInt(1)).txnRefNo(resultSet.getString(2))
							.enquiryId(resultSet.getInt(3)).rrn(resultSet.getString(4)).authCode(resultSet.getString(5))
							.txnAmount(commonValidator.validationDecimal(resultSet.getString(6)))
							.binValue(resultSet.getString(7)).issuer(resultSet.getString(8))
							.status(resultSet.getString(9)).conversionStatus(resultSet.getString(10))
							.txnTime(resultSet.getString(11))
							.emiAmount(commonValidator.validationDecimal(resultSet.getString(12)))
							.tenure(resultSet.getString(13)).interestRate(intRate.toString())
							.cardType(resultSet.getString(15)).emiConverted(resultSet.getString(16))
							.comment(resultSet.getString(17)).build();
					list.add(bean);
				}

				log.info("Size of active transaction list is: {}", list.size());

			}

		} catch (Exception e) {
			log.error("Exception occurred in downloadActiveTransactionReportList {}", e);
			return new ArrayList<>();
		}

		return list;
	}

	/**
	 * getActiveTransaction(...) is responsible for fetching data required for
	 * Single transaction from transactions and enquiry and return
	 * TransactionReportBean.
	 * 
	 * @return List<TransactionReportBean>
	 */
	@Override
	public TransactionReportBean getActiveTransaction(int id) {

		TransactionReportBean bean = null;

		try (Connection connection = this.slaveSfnVasTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(TXN_REPORT_DETAILS_QUERY)) {

			callableStatement.setInt(1, 0);
			callableStatement.setInt(2, 0);
			callableStatement.setString(3, "");
			callableStatement.setString(4, "");
			callableStatement.setString(5, "");
			callableStatement.setString(6, "");
			callableStatement.setString(7, "");
			callableStatement.setString(8, "");
			callableStatement.setString(9, "");
			callableStatement.setString(10, "");
			callableStatement.setString(11, "");
			callableStatement.setString(12, "");
			callableStatement.setString(13, "");
			callableStatement.setInt(14, id);
			callableStatement.registerOutParameter(15, java.sql.Types.INTEGER);

			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);

				while (resultSet.next()) {
					StringBuilder intRate = new StringBuilder(
							commonValidator.validationDecimal(resultSet.getString(14))).append("%");
					bean = TransactionReportBean.builder().id(resultSet.getInt(1)).txnRefNo(resultSet.getString(2))
							.enquiryId(resultSet.getInt(3)).rrn(resultSet.getString(4)).authCode(resultSet.getString(5))
							.txnAmount(commonValidator.validationDecimal(resultSet.getString(6)))
							.binValue(resultSet.getString(7)).issuer(resultSet.getString(8))
							.status(resultSet.getString(9)).conversionStatus(resultSet.getString(10))
							.txnTime(resultSet.getString(11))
							.emiAmount(commonValidator.validationDecimal(resultSet.getString(12)))
							.tenure(resultSet.getString(13)).interestRate(intRate.toString())
							.cardType(resultSet.getString(15)).emiConverted(resultSet.getString(16))
							.comment(resultSet.getString(17)).build();

				}
			}

		} catch (Exception e) {
			log.error("Exception occurred in downloadActiveTransactionReportList {}", e);
			return bean;
		}

		return bean;
	}
	
	/**
	 * getListOfTrxnType is used to get list of all txn type from database
	 * @return List<TransactionTypeBean>
	 */
	@Override
	public List<TransactionTypeBean> getListOfTrxnType(){

		List<TransactionTypeBean> transactionTypeBeanList = new ArrayList<>();
        
		String sql = "{ call tsp_web_admin_slave_getListOfTransactionType() }";
		
		try(Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {
            
			log.info("getListOfTrxnType {}",callableStatement);
			try(ResultSet resultSet = callableStatement.executeQuery()){

				while (resultSet.next()) {
					TransactionTypeBean transactionTypeBean = new TransactionTypeBean();
					transactionTypeBean.setId(resultSet.getInt(1));
					transactionTypeBean.setTxtnType(resultSet.getString(2));
					transactionTypeBeanList.add(transactionTypeBean);
				}
				
				log.info("transactionTypeBeanList  {}",transactionTypeBeanList);
			}
		} catch (Exception e) {
			log.error("error occured on getListOfTrxnType  {} ",e);
		} 

		return transactionTypeBeanList;

	}
	
	/**
	 * getListOfAcquirer is used to get list of all acquirer from database
	 * @return List<TransactionTypeBean>
	 */
	@Override
	public List<AcquirerBean> getListOfAcquirer(){

		List<AcquirerBean> acquirerBeanList = new ArrayList<>();
        
		String sql = "{ call tsp_web_admin_getAcquiererList() }";
		
		try(Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {
            
			log.info("getListOfAcquirer {}",callableStatement);
			try(ResultSet resultSet = callableStatement.executeQuery()){

				while (resultSet.next()) {
					AcquirerBean acquirerBean = new AcquirerBean();
					acquirerBean.setId(resultSet.getInt(1));
					acquirerBean.setName(resultSet.getString(2));
					acquirerBeanList.add(acquirerBean);
				}
				
				log.info("transactionTypeBeanList {}",acquirerBeanList);
			}
		} catch (Exception e) {
			log.error("error occured on getListOfTrxnType {} ",e);
		} 

		return acquirerBeanList;

	}
	
	
	/**
	 * getListOfMerchantName is used to get list of all acquirer from database
	 * @return List<TransactionTypeBean>
	 */
	@Override
	public List<String> getListOfMerchantName(String name){

		List<String> merchantNameList = new ArrayList<>();
        
		String sql = "{ call tsp_web_admin_getMerchantNameList(?) }";
		
		try(Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {
			    callableStatement.setString(1,name);
			
			log.info("getListOfMerchantName {}",callableStatement);
			try(ResultSet resultSet = callableStatement.executeQuery()){

				while (resultSet.next()) {
					merchantNameList.add(resultSet.getString(1));
				}
				
				log.info("transactionTypeBeanList {}",merchantNameList);
			}
		} catch (Exception e) {
			log.error("error occured on getListOfTrxnType {} ",e);
		} 

		return merchantNameList;

	}
	
	/**
	 * getCountOfTransactions function get all the selected transactions types data from database
	 * @param transactionSearchFormBean
	 * @return List<TransactionSearchReportBean>
	 */
	@Override
	public List<TransactionSearchReportBean> getCountOfTransactions(TransactionSearchFormBean transactionSearchFormBean){
		
		log.info("in txn type {}",transactionSearchFormBean.getTxnType());
		
		List<TransactionSearchReportBean> transactionSearchReportBeanList = getTransactionSearch(transactionSearchFormBean);
		
		
		log.info("in getCountOfTransactions");
		
		if(transactionSearchFormBean.getTxnType().contains("101")) {
			TransactionSearchReportBean transactionSearchReportSettlementBean = getSettlementTransactions(transactionSearchFormBean);
			transactionSearchReportBeanList.add(transactionSearchReportSettlementBean);
		}
		
		if(transactionSearchFormBean.getTxnType().contains("102")) {
			TransactionSearchReportBean transactionSearchReportDeclinedSettlementBean = getDeclinedSettlementTransactions(transactionSearchFormBean);
			transactionSearchReportBeanList.add(transactionSearchReportDeclinedSettlementBean);
		}
		
		if(transactionSearchFormBean.getTxnType().contains("103")) {
			TransactionSearchReportBean transactionSearchReportDeclinedBean = getDeclinedTransactions(transactionSearchFormBean);
			transactionSearchReportBeanList.add(transactionSearchReportDeclinedBean);
		}
		
		if(transactionSearchFormBean.getTxnType().contains("104")) {
			TransactionSearchReportBean transactionSearchReportAllBean = getAllTransactions(transactionSearchFormBean);
			transactionSearchReportBeanList.add(transactionSearchReportAllBean);
		}
		
		log.info("getCountOfTransactions {}",transactionSearchReportBeanList);

		return transactionSearchReportBeanList;
		
	}
	
    /**
     * getSettlementTransactions is used to get settlement transaction data
     * @param TransactionSearchFormBean
     * @return TransactionSearchReportBean
     */
	public TransactionSearchReportBean getSettlementTransactions(TransactionSearchFormBean searchFormBean) {

		String sql = "{ call tsp_web_admin_slave_getSettlementTransactions(?,?,?,?,?,?,?,?,?,?,?,?,?) }";
		
		TransactionSearchReportBean transactionSearchReportBean = new TransactionSearchReportBean();
		
		try(Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setString(1, searchFormBean.getMerchantName());
			callableStatement.setString(2, searchFormBean.getUserId());
			callableStatement.setString(3, null);
			callableStatement.setString(4, searchFormBean.getRrn());
			callableStatement.setString(5, searchFormBean.getAuthCode());
			callableStatement.setString(6, searchFormBean.getCardHolderName());
			callableStatement.setString(7, "");
			callableStatement.setString(8, searchFormBean.getMaskedCardNumber());
			callableStatement.setString(9, dateTimeConveter(searchFormBean.getTransactionDateFrom()));
			callableStatement.setString(10, dateTimeConveter(searchFormBean.getTransactionDateTo()));
			callableStatement.setString(11, searchFormBean.getMid());
			callableStatement.setString(12, searchFormBean.getTid());
			callableStatement.setString(13, searchFormBean.getAcquirer());

			try(ResultSet rs = callableStatement.executeQuery()){

				log.info("getSettlementTransactions callableStatement {}",callableStatement);
				
				while(rs.next()) {
	
					transactionSearchReportBean.setTotalTransactionValue(formatNumber(rs.getString(3)));
					transactionSearchReportBean.setTotalTransation(rs.getString(2));
					transactionSearchReportBean.setTransactionType("Settlement Transactions");
					transactionSearchReportBean.setTransactionTypeId("101");
	
				}
				
				log.info("getSettlementTransactions {}",transactionSearchReportBean);
			
			}

		} catch (Exception e) {
			log.error("error occured in getSettlementTransactions {}", e);
		} 

		return transactionSearchReportBean;
	}
	
	/**
	 * getDeclinedSettlementTransactions is used to get all declined settlement transaction data
	 * @param TransactionSearchFormBean
	 * @return TransactionSearchReportBean
	 */
	public TransactionSearchReportBean getDeclinedSettlementTransactions(TransactionSearchFormBean searchFormBean) {

		String sql = "{ call tsp_web_admin_slave_getDeclinedSettlementTransactions(?,?,?,?,?,?,?,?,?,?,?,?,?) }";
		
		TransactionSearchReportBean transactionSearchReportBean = new TransactionSearchReportBean();
		
		try(Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setString(1, searchFormBean.getMerchantName());
			callableStatement.setString(2, searchFormBean.getUserId());
			callableStatement.setString(3, null);
			callableStatement.setString(4, searchFormBean.getRrn());
			callableStatement.setString(5, searchFormBean.getAuthCode());
			callableStatement.setString(6, searchFormBean.getCardHolderName());
			callableStatement.setString(7, null);
			callableStatement.setString(8, searchFormBean.getMaskedCardNumber());
			callableStatement.setString(9, dateTimeConveter(searchFormBean.getTransactionDateFrom()));
			callableStatement.setString(10, dateTimeConveter(searchFormBean.getTransactionDateTo()));
			callableStatement.setString(11, searchFormBean.getMid());
			callableStatement.setString(12, searchFormBean.getTid());
			callableStatement.setString(13, searchFormBean.getAcquirer());

			try(ResultSet rs = callableStatement.executeQuery()){

				log.info("getDeclinedSettlementTransactions callableStatement {}",callableStatement);
				
				while(rs.next()) {
	
					transactionSearchReportBean.setTotalTransactionValue(formatNumber(rs.getString(3)));
					transactionSearchReportBean.setTotalTransation(rs.getString(2));
					transactionSearchReportBean.setTransactionType("Declined Settlement Transactions");
					transactionSearchReportBean.setTransactionTypeId("102");
	
				}
				
				log.info("getDeclinedSettlementTransactions {}",transactionSearchReportBean);
			
			}

		} catch (Exception e) {
			log.error("error occured in getDeclinedSettlementTransactions {}", e);
		} 

		return transactionSearchReportBean;
	}
	
	/**
	 * getDeclinedTransactions is used to get declined transaction data
	 * @param TransactionSearchFormBean
	 * @return TransactionSearchReportBean
	 */
	public TransactionSearchReportBean getDeclinedTransactions(TransactionSearchFormBean searchFormBean) {

		String sql = "{ call tsp_web_admin_slave_getDeclinedTransaction(?,?,?,?,?,?,?,?,?,?,?,?,?) }";
		
		TransactionSearchReportBean transactionSearchReportBean = new TransactionSearchReportBean();
		
		try(Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setString(1, searchFormBean.getMerchantName());
			callableStatement.setString(2, searchFormBean.getUserId());
			callableStatement.setString(3, null);
			callableStatement.setString(4, searchFormBean.getRrn());
			callableStatement.setString(5, searchFormBean.getAuthCode());
			callableStatement.setString(6, searchFormBean.getCardHolderName());
			callableStatement.setString(7, null);
			callableStatement.setString(8, searchFormBean.getMaskedCardNumber());
			callableStatement.setString(9, dateTimeConveter(searchFormBean.getTransactionDateFrom()));
			callableStatement.setString(10, dateTimeConveter(searchFormBean.getTransactionDateTo()));
			callableStatement.setString(11, searchFormBean.getMid());
			callableStatement.setString(12, searchFormBean.getTid());
			callableStatement.setString(13, searchFormBean.getAcquirer());
			
			log.info("getDeclinedTransactions callableStatement {}",callableStatement);

			try(ResultSet rs = callableStatement.executeQuery()){
				
				while(rs.next()) {
	
					transactionSearchReportBean.setTotalTransactionValue(formatNumber(rs.getString(3)));
					transactionSearchReportBean.setTotalTransation(rs.getString(2));
					transactionSearchReportBean.setTransactionType("Declined Transactions");
					transactionSearchReportBean.setTransactionTypeId("103");
	
				}
				
				log.info("getDeclinedTransactions {}",transactionSearchReportBean);
			
			}

		} catch (Exception e) {
			log.error("error occured in getDeclinedTransactions {}", e);
		} 

		return transactionSearchReportBean;
	}
	
	/**
	 * getAllTransactions is used to get all transaction data
	 * @param TransactionSearchFormBean
	 * @return TransactionSearchReportBean
	 */
	public TransactionSearchReportBean getAllTransactions(TransactionSearchFormBean searchFormBean) {

		String sql = "{ call tsp_web_admin_slave_getAllTransaction(?,?,?,?,?,?,?,?,?,?,?,?,?) }";
		
		TransactionSearchReportBean transactionSearchReportBean = new TransactionSearchReportBean();
		
		try(Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setString(1, searchFormBean.getMerchantName());
			callableStatement.setString(2, searchFormBean.getUserId());
			callableStatement.setString(3, null);
			callableStatement.setString(4, searchFormBean.getRrn());
			callableStatement.setString(5, searchFormBean.getAuthCode());
			callableStatement.setString(6, searchFormBean.getCardHolderName());
			callableStatement.setString(7, null);
			callableStatement.setString(8, searchFormBean.getMaskedCardNumber());
			callableStatement.setString(9, dateTimeConveter(searchFormBean.getTransactionDateFrom()));
			callableStatement.setString(10, dateTimeConveter(searchFormBean.getTransactionDateTo()));
			callableStatement.setString(11, searchFormBean.getMid());
			callableStatement.setString(12, searchFormBean.getTid());
			callableStatement.setString(13, searchFormBean.getAcquirer());

			try(ResultSet rs = callableStatement.executeQuery()){

				log.info("getAllTransactions callableStatement {}",callableStatement);
				
				while(rs.next()) {
	
					transactionSearchReportBean.setTotalTransactionValue(formatNumber(rs.getString(3)));
					transactionSearchReportBean.setTotalTransation(rs.getString(2));
					transactionSearchReportBean.setTransactionType("All Transactions");
					transactionSearchReportBean.setTransactionTypeId("104");
	
				}
				
				log.info("getAllTransactions {}",transactionSearchReportBean);
			
			}

		} catch (Exception e) {
			log.error("error occured in getAllTransactions {}", e);
		} 

		return transactionSearchReportBean;
	}
	
	/**
	 * getTransactionSearch is used to get all transaction data based on search
	 * @param TransactionSearchFormBean
	 * @return TransactionSearchReportBean
	 */
	public List<TransactionSearchReportBean> getTransactionSearch(TransactionSearchFormBean searchFormBean) {

		String sql = "{ call tsp_web_admin_slave_getTransaction(?,?,?,?,?,?,?,?,?,?,?,?,?,?) }";
		
		List<TransactionSearchReportBean> transactionSearchReportBeanList = new ArrayList<>();
		
		for(String txnType : searchFormBean.getTxnType()) {
			
			try(Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
					CallableStatement callableStatement = connection.prepareCall(sql)) {
	
				callableStatement.setString(1, searchFormBean.getMerchantName());
				callableStatement.setString(2, searchFormBean.getUserId());
				callableStatement.setString(3, searchFormBean.getTransactionId());
				callableStatement.setString(4, searchFormBean.getRrn());
				callableStatement.setString(5, searchFormBean.getAuthCode());
				callableStatement.setString(6, searchFormBean.getCardHolderName());
				callableStatement.setString(7, null);
				callableStatement.setString(8, searchFormBean.getMaskedCardNumber());
				callableStatement.setString(9, dateTimeConveter(searchFormBean.getTransactionDateFrom()));
				callableStatement.setString(10, dateTimeConveter(searchFormBean.getTransactionDateTo()));
				callableStatement.setString(11, searchFormBean.getMid());
				callableStatement.setString(12, searchFormBean.getTid());
				callableStatement.setString(13, searchFormBean.getAcquirer());
				callableStatement.setString(14 ,txnType);
				
				log.info("getTransactionSearch callableStatement {}",callableStatement);
	
				try(ResultSet rs = callableStatement.executeQuery()){
					
					while(rs.next()) {
						log.info("txn result {} {} {} {}",rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
						TransactionSearchReportBean transactionSearchReportBean = new TransactionSearchReportBean();
						transactionSearchReportBean.setTotalTransactionValue(formatNumber(rs.getString(3)));
						transactionSearchReportBean.setTotalTransation(rs.getString(2));
						transactionSearchReportBean.setTransactionType(rs.getString(1));
						transactionSearchReportBean.setTransactionTypeId(rs.getString(4));

						transactionSearchReportBeanList.add(transactionSearchReportBean);
					}
										
				}
	
			} catch (Exception e) {
				log.error("error occured in getTransactionSearch {}", e);
			} 
		}
		log.info("getTransactionSearch {}",transactionSearchReportBeanList);
		return transactionSearchReportBeanList;
	}
	
	/**
	 * getTransactionListData(...) is responsible for getting the active
	 * Transaction list, corresponding to the coming data-tables request. Here we
	 * have three parameters, first is the actual {@link TransactionSearchFormDataTableBean}, second
	 * one is the orderingColumnName in which ordering is going to happen
	 * (ASC/DESC). Third one is a searchMap which is basically a Map of String key
	 * and value pairs which transformed search values for each column in which we
	 * are applying data-tables search.
	 * 
	 * @param dtRequest          {@link DataTablesRequest}
	 * @param orderingColumnName {@link String}
	 * @param searchMap          Map with key and value as String
	 */
	@Override
	public DataTablesResponse<TransactionSearchReportBean> getTransactionListData(TransactionSearchFormDataTableBean dtRequest, String orderingColumnName, Map<String, String> searchMap){
		
		String sql ="{ call tsp_web_admin_slave_getTransactionSearchList(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }";
		
		DataTablesResponse<TransactionSearchReportBean> dtResponse = new DataTablesResponse<>();
		List<TransactionSearchReportBean> list = new ArrayList<>();
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setInt(1, dtRequest.getDtRequest().getStart());
			callableStatement.setInt(2, dtRequest.getDtRequest().getLength());
			callableStatement.setString(3, orderingColumnName);
			callableStatement.setString(4, dtRequest.getDtRequest().getOrder().get(0).getDir().toString());
			callableStatement.setString(5, searchMap.get(ColumnNames.TXN_LIST_MERCHANT_NAME.get()));
			callableStatement.setString(6, searchMap.get(ColumnNames.TXN_LIST_USER_ID.get()));
			callableStatement.setString(7, searchMap.get(ColumnNames.TXN_LIST_AUTOCODE.get()));
			callableStatement.setString(8, searchMap.get(ColumnNames.TXN_LIST_CARD_HOLDER_NAME.get()));
			callableStatement.setString(9, null);
			callableStatement.setString(10, searchMap.get(ColumnNames.TXN_LIST_CARD_NUMBER.get()));
			callableStatement.setString(11, dateTimeConveter(searchMap.get(ColumnNames.TXN_LIST_DATE_FROM.get())));
			callableStatement.setString(12, dateTimeConveter(searchMap.get(ColumnNames.TXN_LIST_DATE_TO.get())));
			callableStatement.setString(13, searchMap.get(ColumnNames.TXN_LIST_TXN_TYPE.get()));
			callableStatement.setString(14, searchMap.get(ColumnNames.TXN_LIST_MID.get()));
			callableStatement.setString(15, searchMap.get(ColumnNames.TXN_LIST_TID.get()));
			callableStatement.setString(16, searchMap.get(ColumnNames.TXN_LIST_ACQUIRER.get()));
			callableStatement.setString(17, searchMap.get(ColumnNames.TXN_LIST_TXN_ID.get()));
			callableStatement.setString(18, searchMap.get(ColumnNames.TXN_LIST_RRN.get()));
      
			callableStatement.registerOutParameter(19, java.sql.Types.INTEGER);
			
			log.info("tsp_web_admin_slave_getTransactionSearchList callable statement {}", callableStatement);

			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);
				while (resultSet.next()) {
                    log.info("terminal ID {}",resultSet.getString(14));
					TransactionSearchReportBean bean = TransactionSearchReportBean.builder().transactionId(resultSet.getLong(1))
							.userName(resultSet.getString(2)).cardNumber(resultSet.getString(3)).rrn(resultSet.getString(4))
							.authCode(resultSet.getString(13))
							.amt(resultSet.getString(5))
							.txnDate(resultSet.getString(6)).txnDate(resultSet.getString(6))
							.responseCode(resultSet.getString(12)).authCode(resultSet.getString(13)).terminalId(resultSet.getString(14))
							.status(resultSet.getString(9)).type(resultSet.getString(10)).settleStatus(resultSet.getInt(16))
						    .build();

					list.add(bean);
				}

			}

			log.info("Size of active transaction list: {}", list.size());

			int totalRecordCount = callableStatement.getInt(19);

			dtResponse.setData(list);
			dtResponse.setRecordsFiltered(totalRecordCount);
			dtResponse.setRecordsTotal(totalRecordCount);
		} catch (Exception e) {
			log.error("Exception occurred in getTransactionListData {}", e);
			return null;
		}

		dtResponse.setData(list);
		dtResponse.setDraw(dtRequest.getDtRequest().getDraw());
		log.info(dtResponse);
		return dtResponse;
		
	}
	
	/**
	 * processBillNumber is used to process bill number here we split bill number 
	 * @param String
	 * @return Map<String, String>
	 */
	public Map<String, String> processBillNumber(String billNumber) {

		Map<String, String> vals = new LinkedHashMap<>();

		if (billNumber != null) {

			String[] arr = billNumber.split("\\:");

			for (String val : arr) {

				String[] keyValue = val.split("=");

				if (keyValue.length == 2) {
					vals.put(keyValue[0], keyValue[1]);
				}
			}
		}

		return vals;
	}
	
	/**
	 * getTransById is used to get data of transaction by using its id
	 * @param long tranId
	 * @return TransactionSearchReportBean
	 */
	@Override
	public TransactionSearchReportBean getTransById(long tranId) {

		String appLabel = "";
		String appLabelString = "";
		
		String sql = "{call tsp_web_admin_slave_GetReceiptDetails(?,?,?,?)}";

		TransactionSearchReportBean transactionReport = new TransactionSearchReportBean();

		try(Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)){

			callableStatement.setLong(1, tranId);
			callableStatement.registerOutParameter(2, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(3, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(4, java.sql.Types.VARCHAR);

			log.info("Callable Statement: {}" , callableStatement);
            
			try(ResultSet rs = callableStatement.executeQuery()) {
			    while (rs.next()) {
			    	transactionReport.setMerchantCode(rs.getString(2));
					transactionReport.setBusinessName(rs.getString(3));
					transactionReport.setLine1(rs.getString(4));
					transactionReport.setLine2(rs.getString(5));
					transactionReport.setTxnDate(rs.getString(6));
					transactionReport.setTime(rs.getString(7));
					transactionReport.setLatitude(rs.getString(8));
					transactionReport.setLongitude(rs.getString(9));
					transactionReport.setStan(rs.getString(10));
					transactionReport.setRrn(rs.getString(11));
					transactionReport.setAmount(rs.getDouble(12));
					transactionReport.setAuthCode(rs.getString(13));
					transactionReport.setBatchNo(rs.getInt(14));
					transactionReport.setCardNumber(rs.getString(15));
					transactionReport.setTerminalId(rs.getString(16));
					transactionReport.setInvoiceNo(rs.getString(17));
					transactionReport.setStatus(rs.getString(18));
					transactionReport.setTransactionId(rs.getLong(21));
					transactionReport.setBillNumber(rs.getString(23));
					transactionReport.setCardType(rs.getString(24));
					transactionReport.setCardHolderName(rs.getString(28));
					transactionReport.setType(rs.getString(29));
					transactionReport.setUserName(rs.getString(30));
					transactionReport.setImageId(rs.getInt(31));
					transactionReport.setAid(rs.getString(33));
					appLabel = rs.getString(36);
					if (appLabel != null && !appLabel.equals("")) {
						appLabelString = hexToAscii(appLabel);
					}
					transactionReport.setAppLabel(appLabelString);
					transactionReport.setTvr(rs.getString(37));
					transactionReport.setTsi(rs.getString(38));
					transactionReport.setIsTipPresent(rs.getInt(42));
					transactionReport.setModeId(rs.getString(43));
					transactionReport.setAppVersion(rs.getString(44));
					transactionReport.setCityName(rs.getString(47));
					transactionReport.setCountryName(rs.getString(48));
					transactionReport.setPinVerified(rs.getInt(50));
					transactionReport.setRefTransaction(rs.getString(52));
					transactionReport.setTgTransactionId(rs.getString(53));
					transactionReport.setTgName(rs.getString(54));
					// EMI Changes
					transactionReport.setTenure(rs.getInt(55));
					transactionReport.setEmiDesclaimer(rs.getString(57));
					transactionReport.setEmiAmt(rs.getDouble(58));
					transactionReport.setRateOfInterest(rs.getDouble(59));
					transactionReport.setEmiAmtWithInterest(rs.getDouble(60));
					transactionReport.setCashbackPercent(rs.getDouble(61));
					transactionReport.setCashBackAmount(rs.getDouble(62));
					transactionReport.setProcessingFee(rs.getDouble(63));
					transactionReport.setCostToCust(rs.getDouble(64));
					transactionReport.setSecurityToken(rs.getString(65));
					transactionReport.setClientId(rs.getString(66));
					transactionReport.setProdCode(rs.getString(67));
					transactionReport.setCustMobile(rs.getString(68));
					transactionReport.setProdCodeDesclaimer(rs.getString(69));
					transactionReport.setMfgName(rs.getString(70));
					transactionReport.setProdCodeDescription(rs.getString(71));
					transactionReport.setCurrencyCode(rs.getString(74));

				}
			    
			    Map<String, String> descList = processBillNumber(transactionReport.getBillNumber());
			    
			    transactionReport.setDescList(descList);
				String timAmt = callableStatement.getString(2);
				transactionReport.setTipAmt(timAmt);
				transactionReport.setCashBackAmount(callableStatement.getDouble(3));
				transactionReport.setAcuirerName(callableStatement.getString(4));
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		log.info("transactionReport {}",transactionReport);
		return transactionReport;
	}
    
	/**
	 * hexToAscii is used to convert hex value into its ascii value
	 * @param hex
	 * @return
	 */
	public String hexToAscii(String hex) {
		StringBuilder output = new StringBuilder();
		for (int i = 0; i < hex.length(); i += 2) {
			String str = hex.substring(i, i + 2);
			output.append((char) Integer.parseInt(str, 16));
		}
		return output.toString();
	}
	
	/**
	 * getTransactionType returns the txn type for specific txn types like 101,102,103,104
	 * @param String
	 * @return String
	 */
	public String getTransactionType(String s) {
		if(s.equals("101")) {
			s = "3";
		}else if(s.equals("102")){
			s = "-2";
		}else if(s.equals("103")){
			s = "0";
		}else if(s.equals("104")){
			s = "20";
		}
		return s;
	}
	
	/**
	 * getTransactionSearchListExcel is used to get transaction data for excel based on search filters
	 * @param TransactionSearchFormBean
	 * @return List<Map<Integer, String>>
	 */
	@Override
	public List<Map<Integer, String>> getTransactionSearchListExcel(TransactionSearchFormBean searchFormBean) {

		List<Map<Integer, String>> list=new ArrayList<>();
		
		String sql = "{ call tsp_web_admin_slave_getTransactionSearchListExcel(?,?,?,?,?,?,?,?,?,?,?,?,?,?) }";
				
		String txnType = getTransactionType(searchFormBean.getTxnType().get(0));
		
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		DateFormat timeFormat = new SimpleDateFormat(TIMEFORMAT);
		DateFormat allFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a");
		
		
		
		try(Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
		CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setString(1, searchFormBean.getMerchantName());
			callableStatement.setString(2, searchFormBean.getUserId());
			callableStatement.setString(3, searchFormBean.getAuthCode());
			callableStatement.setString(4, searchFormBean.getCardHolderName());
			callableStatement.setString(5, null);
			callableStatement.setString(6, searchFormBean.getMaskedCardNumber());
			callableStatement.setString(7, dateTimeConveter(searchFormBean.getTransactionDateFrom()));
			callableStatement.setString(8, dateTimeConveter(searchFormBean.getTransactionDateTo()));
			callableStatement.setString(9, txnType);
			callableStatement.setString(10, searchFormBean.getMid());
			callableStatement.setString(11, searchFormBean.getTid());
			callableStatement.setString(12, searchFormBean.getAcquirer());
			callableStatement.setString(13, searchFormBean.getTransactionId());
			callableStatement.setString(14, searchFormBean.getRrn());

			log.info("getTransactionSearchListExcel callableStatement {}",callableStatement);

			try(ResultSet rs = callableStatement.executeQuery()){
	
				while(rs.next())
				{
					Map<Integer, String> map= new HashMap<>();
					map.put(1, rs.getString(1));
					java.util.Date d =rs.getTimestamp(2);
					map.put(2, dateFormat.format(d));
					map.put(3, timeFormat.format(d));
					map.put(4, rs.getString(4));
					map.put(5, "");
					map.put(6, rs.getString(6));
					map.put(7, rs.getString(7));
					map.put(8, rs.getString(8));
					map.put(9, rs.getString(9));
					map.put(10, rs.getString(10));
					map.put(11, rs.getString(11));
					map.put(12, rs.getString(12));
					map.put(13, rs.getString(13));
					map.put(14, rs.getString(14));
	
					if(rs.getInt(15)== 1) {
						map.put(15, "EMV");
					} else if (rs.getInt(15) == 5) {
						map.put(15, "LIVE");
					} else {
						map.put(15, "SWIPE");
					}
	
					map.put(16, rs.getString(16));
					map.put(17, rs.getString(17));
					map.put(18, rs.getString(18));
	
					if(rs.getInt(19)== 1){
						map.put(19, "UNSETTLED");
					} else {
						map.put(19, "SETTLED");
					}
	
					java.util.Date d1 =rs.getTimestamp(20);
					if( d1 != null)
						map.put(20, allFormat.format(d1));
					else
						map.put(20,"");
	
					map.put(21, rs.getString(21));
					map.put(22, rs.getString(22));
					map.put(23, rs.getString(23));
					map.put(24, rs.getString(24));
					map.put(25, rs.getString(25));
					map.put(26, rs.getString(26));
					map.put(27, rs.getString(27));
					map.put(28, rs.getString(28));
					map.put(29, rs.getString(29));
					map.put(30, rs.getString(30));
					map.put(31, rs.getString(31));
					
					// Card Type
					String cardType = rs.getString(32);		
					map = setCardType(map,cardType);
					
					// If transaction type is (ALL/EMI) then only check for EMI fields
					if(searchFormBean.getTxnType().get(0).equals("15") || searchFormBean.getTxnType().get(0).equals("20")) {
						map.put(33, rs.getString(33));
						map.put(34, rs.getString(34));
						map.put(35, rs.getString(35));
						map.put(36, rs.getString(36));
						map.put(37, rs.getString(37));
						map.put(38, rs.getString(38));
						map.put(39, rs.getString(39));
						map.put(40, rs.getString(40));
						map.put(41, rs.getString(41));
						map.put(42, rs.getString(42));
					}
	
					list.add(map);
				}
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		
		return list;
	}
	
	/**
	 * setCardType is used to set card type data based on condition
	 * @param map
	 * @param cardType
	 * @return
	 */
	public Map<Integer, String> setCardType(Map<Integer, String> map,String cardType) {
		if("DD".equalsIgnoreCase(cardType) || "DC".equalsIgnoreCase(cardType)){
			map.put(32, cardType);					
		}else {
			map.put(32, "NA");
		}
		
		return map;
	}
	
    
	/**
	 * this function is used to format number in 2 digits
	 */
	
	public String formatNumber(String s) {
		
		log.info("number to format {}",s);
		
		if(s == null || s.isEmpty()) {
			return null;
		}
		
		return String.format("%.2f",Float.parseFloat(s));
	}
	
	/**
	 * dateTimeConveter convert time from dd-mm-yyyy to yyyy-mm-dd format
	 * @param inDate
	 * @return String
	 */

    public String  dateTimeConveter(String inDate) {
    	SimpleDateFormat inSDF = new SimpleDateFormat("dd-mm-yyyy");
    	SimpleDateFormat outSDF = new SimpleDateFormat("yyyy-mm-dd");

    	String outDate = "";
        if (inDate != null) {
            try {
                Date date = inSDF.parse(inDate);
                outDate = outSDF.format(date);
            } catch (Exception ex){ 
            	
            	log.info("error paresultSeting date {}",inDate);
            	Date dateobj = new Date();
            	outDate = outSDF.format(dateobj);
            }
        }
        log.info("responseDate {}",outDate);
        return outDate;
	}
	
}
