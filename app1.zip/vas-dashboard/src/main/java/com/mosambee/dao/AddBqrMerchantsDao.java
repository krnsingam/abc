package com.mosambee.dao;

import java.util.Map;

import com.mosambee.bean.AddBqrMerchantsBean;
import com.mosambee.bean.BqrListDatatablesRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;

/**
 * This class provides specification for {@link AddBqrMerchantsDao}
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
public interface AddBqrMerchantsDao {
	String addBqrMerchants(AddBqrMerchantsBean addBqrMerchantsBean, String userId);

	String updateBqrMerchants(AddBqrMerchantsBean addBqrMerchantsBean, String userId);

	AddBqrMerchantsBean editBqrMerchants(long id);

	DataTablesResponse<AddBqrMerchantsBean> getBqrMerchantsList(BqrListDatatablesRequestBean dtRequest,
			String orderingColumnName, Map<String, String> searchMap);

}
