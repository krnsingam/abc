package com.mosambee.dao;

import java.util.Map;

import com.mosambee.bean.BillNumberBean;
import com.mosambee.bean.BillNumberDataTablesRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.dao.impl.SearchByBillNumberDaoImpl;

/**
 * SearchByBillNumberDao is specification for {@link SearchByBillNumberDaoImpl}
 * @author mariam.siddique
 * @version 1.0
 * @since 23-March-2020 */

public interface SearchByBillNumberDao {

	DataTablesResponse<BillNumberBean> getBillNumberTransactionList(BillNumberDataTablesRequestBean dtRequest , String orderingColumnName, Map<String, String> searchMap);

}
