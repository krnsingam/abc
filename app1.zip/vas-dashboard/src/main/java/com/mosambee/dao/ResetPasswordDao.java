package com.mosambee.dao;

public interface ResetPasswordDao {

	String updateNewPassword(String hashedPassword, Long userId);

}
