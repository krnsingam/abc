package com.mosambee.dao;

import java.util.List;
import java.util.Map;

import com.mosambee.bean.CityBean;
import com.mosambee.bean.CountryBean;
import com.mosambee.bean.EnterpriseBatchList;
import com.mosambee.bean.EnterpriseBean;
import com.mosambee.bean.EnterpriseDataBean;
import com.mosambee.bean.EnterpriseListBean;
import com.mosambee.bean.EnterpriseNoOfTerminalBean;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.StateBean;
import com.mosambee.bean.TransactionSearchReportBean;
import com.mosambee.bean.UpdateAPIPaswordConfigRequestFromList;
import com.mosambee.bean.datatables.DataTablesResponse;

public interface EnterpriseDao {

	public ResponseBean createEnterprise(EnterpriseBean createAPIGroup);

	public  List<CountryBean> getCountry();
	
	public List<StateBean> getState(CountryBean country);
	
	public List<CityBean> getCity(StateBean state);
	
	public DataTablesResponse<EnterpriseListBean> enterpriseList(EnterpriseDataBean dtRequest,
			String orderingColumnName, Map<String, String> searchMap);
	
	public List<EnterpriseListBean> getEnterpriseName(EnterpriseListBean bean);
	
	public boolean updateEnterpriseList(UpdateAPIPaswordConfigRequestFromList updateAPIPaswordConfigRequestFromList,
			EnterpriseBean enterprise, ResponseBean responseBean);
	
	public boolean updateEnterprise(EnterpriseBean enterprise, ResponseBean responseBean);
	
	public List<EnterpriseBatchList> getBatchList(EnterpriseDataBean entList);
	
	public List<TransactionSearchReportBean> getTotalTransaction(EnterpriseDataBean entList);
	
	public List<EnterpriseNoOfTerminalBean> getNoOfEnterpriseTerminal(EnterpriseDataBean entList);
	
}
