package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.OfflineKeyBean;
import com.mosambee.bean.OfflineMerchantTerminalSearchBean;
import com.mosambee.bean.OfflineMerchantsListBean;
import com.mosambee.bean.OfflineMerchantsSearchBean;
import com.mosambee.bean.OfflineTerminalListBean;
import com.mosambee.bean.OfflineTerminalSearchBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.dao.OfflineMerchantsDao;

import lombok.extern.log4j.Log4j2;

/**
 * {@link OfflineMerchantsDaoImpl} is responsible for handling database operations
 * for offlineMerchants module. The class is responsible for fetching the offlineMerchants list .
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 01-April-2020
 */

@Log4j2
@Repository("offlineMerchantsDao")
public class OfflineMerchantsDaoImpl implements OfflineMerchantsDao{
	
	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;
	
	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;
	
	/**
	 * getOfflineMerchantsList(...) is responsible for getting the offlineMerchants list,
	 * corresponding to the coming data-tables request. Here we have three
	 * parameters, first is the actual {@link DataTablesRequest}, second one is the
	 * orderingColumnName in which ordering is going to happen (ASC/DESC). 
	 * 
	 * @param dtRequest          {@link DataTablesRequest}
	 * @param orderingColumnName {@link String}
	 */
	@Override
	public DataTablesResponse<OfflineMerchantsListBean> getOfflineMerchantsList(OfflineMerchantsSearchBean dtRequest,
			String orderingColumnName) {
		
		DataTablesResponse<OfflineMerchantsListBean> dtResponse = new DataTablesResponse<>();
		
		List<OfflineMerchantsListBean> list = new ArrayList<>();
		
		String sqlQuery = "{ call tsp_web_admin_slave_getOfflineMerchantsList(?,?,?,?,?,?,?) }";
		
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			
			callableStatement.setString(1, dtRequest.getMerchantName());
			callableStatement.setString(2, dtRequest.getMerchantCode());
			callableStatement.setInt(3, dtRequest.getDtRequest().getStart());
			callableStatement.setInt(4, dtRequest.getDtRequest().getLength());
			callableStatement.setString(5, orderingColumnName);
			callableStatement.setString(6, dtRequest.getDtRequest().getOrder().get(0).getDir().toString());
			callableStatement.registerOutParameter(7, java.sql.Types.INTEGER);

			log.info("{}", callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				while (resultSet.next()) {

					OfflineMerchantsListBean bean = OfflineMerchantsListBean.builder().merchantId(resultSet.getLong(1)).merchantName(resultSet.getString(2))
							.noOfTerminals(resultSet.getLong(3)).build();

					list.add(bean);
				}

			}

			log.info("Size of getOfflineMerchantsList: {}", list.size());

			int totalRecordCount = callableStatement.getInt(7);

			dtResponse.setData(list);
			dtResponse.setRecordsFiltered(totalRecordCount);
			dtResponse.setRecordsTotal(totalRecordCount);
		} catch (Exception e) {
			log.error("Exception occurred in getOfflineMerchantsList {}", e);
			return null;
		}

		dtResponse.setData(list);
		log.info(dtResponse);
		return dtResponse;

	}

	/**
	 * getOfflineTerminalList(...) is responsible for getting the offline terminal list,
	 * corresponding to the coming data-tables request. Here we have three
	 * parameters, first is the actual {@link OfflineTerminalSearchBean}, second one is the
	 * orderingColumnName in which ordering is going to happen (ASC/DESC). 
	 * 
	 * @param dtRequest          {@link OfflineTerminalSearchBean}
	 * @param orderingColumnName {@link String}
	 */
	@Override
	public DataTablesResponse<OfflineTerminalListBean> getOfflineTerminalList(OfflineTerminalSearchBean searchBean , String orderingColumnName) {
		
		DataTablesResponse<OfflineTerminalListBean> dtResponse = new DataTablesResponse<>();
		List<OfflineTerminalListBean> list = new ArrayList<>();
		
		String sqlQuery = "{ call tsp_web_admin_slave_getOfflineTerminalList(?,?,?,?,?,?,?) }";
		
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			
			callableStatement.setString(1, searchBean.getUserId());
			callableStatement.setString(2, searchBean.getTerminalId());
			callableStatement.setInt(3, searchBean.getDtRequest().getStart());
			callableStatement.setInt(4, searchBean.getDtRequest().getLength());
			callableStatement.setString(5, orderingColumnName);
			callableStatement.setString(6, searchBean.getDtRequest().getOrder().get(0).getDir().toString());
			callableStatement.registerOutParameter(7, java.sql.Types.INTEGER);
			
			log.info("{}", callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				while (resultSet.next()) {

					OfflineTerminalListBean bean = OfflineTerminalListBean.builder().terminalId(resultSet.getString(2)).userId(resultSet.getString(1))
							.offlineKey(resultSet.getString(3)).build();
					
					list.add(bean);
				}
				
			}
			int totalRecordCount = callableStatement.getInt(7);
			
			dtResponse.setData(list);
			dtResponse.setRecordsFiltered(totalRecordCount);
			dtResponse.setRecordsTotal(totalRecordCount);
			
		} catch (Exception e) {
			log.error("Exception occurred in getOfflineTerminalList {}", e);
			return null;
		}
		dtResponse.setData(list);
		return dtResponse;

	}

	/**
	 * getOfflineMerchantTerminalList(...) is responsible for getting the offline merchant's terminals list,
	 * corresponding to the coming data-tables request. Here we have three
	 * parameters, first is the actual {@link OfflineMerchantTerminalSearchBean}, second one is the
	 * orderingColumnName in which ordering is going to happen (ASC/DESC). 
	 * 
	 * @param dtRequest          {@link OfflineMerchantTerminalSearchBean}
	 * @param orderingColumnName {@link String}
	 */
	@Override
	public DataTablesResponse<OfflineTerminalListBean> getOfflineMerchantTerminalList(OfflineMerchantTerminalSearchBean searchBean, String orderingColumnName) {
		
		DataTablesResponse<OfflineTerminalListBean> dtResponse = new DataTablesResponse<>();
		List<OfflineTerminalListBean> list = new ArrayList<>();
		
		String sqlQuery = "{ call tsp_web_admin_slave_getOfflineTerminalListByMerchantId(?,?,?,?,?,?) }";
		
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			
			callableStatement.setLong(1, searchBean.getMerchantId());
			callableStatement.setInt(2, searchBean.getDtRequest().getStart());
			callableStatement.setInt(3, searchBean.getDtRequest().getLength());
			callableStatement.setString(4, orderingColumnName);
			callableStatement.setString(5, searchBean.getDtRequest().getOrder().get(0).getDir().toString());
			callableStatement.registerOutParameter(6, java.sql.Types.INTEGER);
			
			log.info("{}", callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				while (resultSet.next()) {

					OfflineTerminalListBean bean = OfflineTerminalListBean.builder().terminalId(resultSet.getString(2)).userId(resultSet.getString(1))
							.offlineKey(resultSet.getString(3)).build();
					
					list.add(bean);
				}
				
			}
			int totalRecordCount = callableStatement.getInt(6);
			
			dtResponse.setData(list);
			dtResponse.setRecordsFiltered(totalRecordCount);
			dtResponse.setRecordsTotal(totalRecordCount);
			
		} catch (Exception e) {
			log.error("Exception occurred ingetOfflineMerchantTerminalList {}", e);
			return null;
		}
		dtResponse.setData(list);
		return dtResponse;
		
	}

	/**
	 * getMerchantsTerminalForOfflineKeySet(...) is responsible for getting the offline merchant's terminals for offline key set,
	 * corresponding to the coming request. Here we have one parameter {long merchantId}. 
	 * 
	 * @param merchantId         {@link Long}
	 */
	@Override
	public List<OfflineKeyBean> getMerchantsTerminalForOfflineKeySet(long merchantId) {
		
		List<OfflineKeyBean> list = new ArrayList<>();
		
		String sqlQuery = "{ call tsp_web_admin_slave_getMerchantsTerminalForOfflineKeySet(?) }";
		
		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			
			callableStatement.setLong(1, merchantId);
			
			log.info("{}", callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				while (resultSet.next()) {

					OfflineKeyBean bean = OfflineKeyBean.builder().tableTerminalId(resultSet.getLong(1)).merchantId(resultSet.getLong(2)).build();
					list.add(bean);
				}
			}
			
		} catch (Exception e) {
			log.error("Exception occurred in getMerchantsTerminalForOfflineKeySet {}", e);
			return null;
		}
		return list;
	}

	/**
	 * bulkUpdateOfflineKey(...) is responsible for setting the offline key in bulk for terminals
	 * corresponding to the coming request. Here we have four parameters,one is merchantId {@link long}. 
	 * second is tableTerminalId ,third is generated offline key to be set in database and fourth is login userId.
	 * @param merchantId         {@link Long}
	 * @param tableTerminalId    {@link Long}
	 * @param offlineKey      	 {@link String}
	 * @param createdUserId      {@link Long}
	 */
	@Override
	public void bulkUpdateOfflineKey(long merchantId, long tableTerminalId, String offlineKey, long createdUserId) {
		
		String sqlQuery = "{ call tsp_web_admin_master_setBulkOfflineKey(?,?,?,?) }";
		
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			
			callableStatement.setLong(1, merchantId);
			callableStatement.setLong(2, tableTerminalId);
			callableStatement.setString(3, offlineKey);
			callableStatement.setLong(4, createdUserId);
			callableStatement.executeUpdate();
			
			log.info("{}", callableStatement);
		
		} catch (Exception e) {
			log.error("Exception occurred in bulkUpdateOfflineKey {}", e);
		
		}
		
	}

	/**
	 * updateOfflineKey(...) is responsible for setting the offline key for single terminal
	 * corresponding to the coming request. Here we have threee parameters,one is terminalId {@link String}. 
	 * second is generated offline key to be set in database and third is login userId.
	 * @param terminalId         {@link String}
	 * @param offlineKey      	 {@link String}
	 * @param createdUserId      {@link Long}
	 */
	@Override
	public int updateOfflineKey(String terminalId, String offlineKey, long createdUserId) {
		
		String sqlQuery = "{ call tsp_web_admin_master_setOfflineKey(?,?,?) }";
		int count = 0;
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			
			callableStatement.setString(1, terminalId);
			callableStatement.setString(2, offlineKey);
			callableStatement.setLong(3, createdUserId);
			count = callableStatement.executeUpdate();
			
			log.info("{}", callableStatement);
		
		} catch (Exception e) {
			log.error("Exception occurred in updateOfflineKey {}", e);
		
		}
		return count;
	}

}
