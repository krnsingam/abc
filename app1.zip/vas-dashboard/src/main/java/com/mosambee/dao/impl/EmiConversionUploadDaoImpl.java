package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.EmiConversionUploadBean;
import com.mosambee.dao.EmiConversionUploadDao;

/**
 * This class is responsible for database operations for emi conversion upload
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Repository("emiConversionUploadDao")
public class EmiConversionUploadDaoImpl implements EmiConversionUploadDao {
	private static final Logger log = LogManager.getLogger(EmiConversionUploadDaoImpl.class);

	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;
	
	@Autowired
	@Qualifier("masterSfnVasTemplate")
	private JdbcTemplate masterSfnVasTemplate;

	/**
	 * uploadEmiConversion() is using to insert values of emi conversion upload
	 * fields in database and getting response corresponding values
	 *
	 */
	@Override
	public String uploadEmiConversion(EmiConversionUploadBean emiConversionUploadBean) {
		String sqlQuery = "{ call tsp_web_admin_master_addComment(?,?,?,?,?) }";
		String response = null;

		try (Connection connection = this.masterSfnVasTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			callableStatement.setString(1, emiConversionUploadBean.getIssuer());
			callableStatement.setString(2, emiConversionUploadBean.getTxnRefId());
			callableStatement.setString(3, emiConversionUploadBean.getMessage());
			callableStatement.setString(4, emiConversionUploadBean.getComment());
			callableStatement.registerOutParameter(5, java.sql.Types.INTEGER);
			callableStatement.execute();
			log.info("{}", callableStatement);
			response = callableStatement.getString(5);
			log.info("Response from Db {}", response);

		} catch (Exception e) {
			log.error("Exception occured in uploadEmiConversion: {}", e);

		}
		return response;
	}

}
