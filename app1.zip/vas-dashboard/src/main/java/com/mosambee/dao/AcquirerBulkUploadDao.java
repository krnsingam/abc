package com.mosambee.dao;

import java.util.List;
import java.util.Map;

import com.mosambee.bean.AcquirerBulkUploadBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;

/**
 * AcquirerBulkUploadDao is specification for {@link AcquirerBulkUploadDaoImpl}
 * 
 * @author karan.singam
 * @version 1.0
 * @since 20-February-2020
 */
public interface AcquirerBulkUploadDao {

	public  DataTablesResponse<AcquirerBulkUploadBean> getListOfAcquirer(DataTablesRequest dtRequest,String orderingColumnName, Map<String, String> searchMap);
	
	public List<AcquirerBulkUploadBean> downloadActiveAcquirerList(AcquirerBulkUploadBean report);
	
}
