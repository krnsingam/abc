package com.mosambee.dao;

import com.mosambee.bean.SBITidUploadBean;

/**
 * @author saurabhkant.shukla
 *
 */
public interface SbiTidUploadDao {

	String uploadSbiTid(SBITidUploadBean sBITidUploadBean, Long userId);
 
}
