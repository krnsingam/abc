package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.AdminAcquirerBean;
import com.mosambee.bean.AdminAcquirerDataTablesRequestBean;
import com.mosambee.bean.AdminAcquirerListBean;
import com.mosambee.bean.AdminAddAcquirerBean;
import com.mosambee.bean.EditAcquirerDetailsBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.dao.AdminAcquirerDao;

import lombok.extern.log4j.Log4j2;

/**
 * {@link AdminAcquirerDaoImpl} is responsible for handling database operations
 * for admin-acquirer module. The class is responsible for fetching the acquirer
 * list based on provided dates.
 * 
 * @author mariam.siddique
 * @author saurabhkant.shukla
 * @version 1.0
 * @since 18-March-2020
 */
@Log4j2
@Repository("adminAcquirerDao")
public class AdminAcquirerDaoImpl implements AdminAcquirerDao {

	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;

	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;

	/**
	 * getAdminAcquirerList(...) is responsible for getting the acquirers list,
	 * corresponding to the coming data-tables request. Here we have three
	 * parameters, first is the actual {@link AdminAcquirerDataTablesRequestBean},
	 * second one is the orderingColumnName in which ordering is going to happen
	 * (ASC/DESC). Third one is a searchMap which is basically a Map of String key
	 * and value pairs which transformed search values for each column in which we
	 * are applying data-tables search.
	 * 
	 * @param dtRequest          {@link AdminAcquirerDataTablesRequestBean}
	 * @param orderingColumnName {@link String}
	 * @param searchMap          Map with key and value as String
	 */
	@Override
	public DataTablesResponse<AdminAcquirerBean> getAdminAcquirerList(AdminAcquirerDataTablesRequestBean dtRequest,
			String orderingColumnName, Map<String, String> searchMap) {

		DataTablesResponse<AdminAcquirerBean> dtResponse = new DataTablesResponse<>();

		List<AdminAcquirerBean> list = new ArrayList<>();

		String sqlQuery = "{ call tsp_web_admin_slave_getMosambeeAcquirersList(?,?,?,?,?,?,?) }";

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setInt(1, dtRequest.getDtRequest().getStart());
			callableStatement.setInt(2, dtRequest.getDtRequest().getLength());
			callableStatement.setString(3, orderingColumnName);
			callableStatement.setString(4, dtRequest.getDtRequest().getOrder().get(0).getDir().toString());
			callableStatement.setString(5, dtRequest.getFromDate());
			callableStatement.setString(6, dtRequest.getToDate());
			callableStatement.registerOutParameter(7, java.sql.Types.INTEGER);

			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);
				while (resultSet.next()) {

					AdminAcquirerBean bean = AdminAcquirerBean.builder().acqId(resultSet.getLong(1))
							.acqName(resultSet.getString(2)).noOfMid(resultSet.getInt(3)).noOfUsers(resultSet.getInt(4))
							.saleTxn(resultSet.getInt(5)).saleTxnValue(resultSet.getString(6))
							.lastTxnDate(resultSet.getString(7)).declinedTxn(resultSet.getInt(8)).build();

					list.add(bean);
				}

			}

			log.info("Size of admin acquirer list: {}", list.size());

			int totalRecordCount = callableStatement.getInt(7);

			dtResponse.setData(list);
			dtResponse.setRecordsFiltered(totalRecordCount);
			dtResponse.setRecordsTotal(totalRecordCount);
		} catch (Exception e) {
			log.error("Exception occurred in getAdminAcquirerList {}", e);
			return null;
		}

		dtResponse.setData(list);
		log.info(dtResponse);
		return dtResponse;
	}

	/**
	 * getCurrencyList(...) is responsible for getting the List of Currencies from
	 * the Database.
	 * 
	 * @return Map<Integer, String>
	 */
	@Override
	public Map<Integer, String> getCurrencyList() {

		Map<Integer, String> map = new HashMap<>();

		String sqlQuery = "{ call tsp_web_admin_slave_getCurrencyList() }";

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			try (ResultSet resultSet = callableStatement.executeQuery()) {
				log.info("{}", callableStatement);

				map.put(0, "Select Currency");

				while (resultSet.next()) {
					map.put(resultSet.getInt(1), resultSet.getString(2));
				}

			}

		} catch (Exception e) {
			log.error("Exception occurred in getCurrencyList {}", e);
			return null;
		}

		return map;
	}

	/**
	 * addNewAcquirer(...) is responsible for adding a new acquirer in the database.
	 * Here we have two parameters, first is the bean containing field values,
	 * second one is the userId of currently logged in user.
	 * 
	 * @param bean   {@link AdminAddAcquirerBean}
	 * @param userId {@link long}
	 * @return String
	 */
	@Override
	public String addNewAcquirer(AdminAddAcquirerBean bean, long userId) {
		String message = "";
		String sql = " {call tsp_web_admin_master_addNewAcquirer(?,?,?,?,?,?,?,?,?,?,?)}";

		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setString(1, bean.getName());
			callableStatement.setString(2, bean.getZmk());
			callableStatement.setString(3, bean.getZpk());
			callableStatement.setString(4, bean.getZek());
			callableStatement.setDouble(5, bean.getTipPercent());
			callableStatement.setLong(6, userId);
			callableStatement.setString(7, bean.getApkName());
			callableStatement.setLong(8, bean.getCurrencyId());
			callableStatement.setInt(9, bean.getDecimalAmountLength());
			callableStatement.setInt(10, bean.getServerTimeInMin());
			callableStatement.setInt(11, bean.getMobileNoLength());

			boolean flag = callableStatement.execute();

			if (!flag) {
				message = "Acquirer Added Successfully";
			} else {
				message = "Unable to Add Acquirer";
			}
			log.info("Message: {}", message);
			log.info("CallableStatement: {}", callableStatement);

		} catch (Exception e) {
			log.error("exeption occured while processing addNewAcquirer(): {}", e);
		}

		return message;
	}

	/**
	 * getSiteAcquirerList(...) is responsible for getting the site-acquirers list,
	 * corresponding to the coming data-tables request. Here we have two
	 * parameters, first is the actual dtRequest {@link DataTablesRequest},
	 * second one is the orderingColumnName in which ordering is going to happen
	 * (ASC/DESC).
	 * 
	 * @param dtRequest          {@link DataTablesRequest}
	 * @param orderingColumnName {@link String}
	 * @return DataTablesResponse<AdminAcquirerListBean>
	 */
	@Override
	public DataTablesResponse<AdminAcquirerListBean> getSiteAcquirerList(DataTablesRequest dtRequest,
			String orderingColumnName) {

		DataTablesResponse<AdminAcquirerListBean> dtResponse = new DataTablesResponse<>();

		List<AdminAcquirerListBean> list = new ArrayList<>();

		String sqlQuery = "{ call tsp_web_admin_slave_getSiteAcquirerList(?,?,?,?,?) }";

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setInt(1, dtRequest.getStart());
			callableStatement.setInt(2, dtRequest.getLength());
			callableStatement.setString(3, orderingColumnName);
			callableStatement.setString(4, dtRequest.getOrder().get(0).getDir().toString());
			
			callableStatement.registerOutParameter(5, java.sql.Types.INTEGER);
			
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);
				while (resultSet.next()) {

					AdminAcquirerListBean bean = new AdminAcquirerListBean();

					bean.setAcqId(resultSet.getInt(1));
					bean.setName(resultSet.getString(2));
					bean.setZmk(resultSet.getString(3));
					bean.setZpk(resultSet.getString(4));
					bean.setZek(resultSet.getString(5));

					if (null == resultSet.getString(6) || resultSet.getString(6).equals("")) {
						bean.setTipPercent("0.00%");
					} else if (null != resultSet.getString(6) || !resultSet.getString(6).equals("")) {
						bean.setTipPercent(resultSet.getString(6) + "%");
					}

					bean.setApkName(resultSet.getString(7));
					bean.setCurrencyCode(resultSet.getString(8));
					bean.setDecimalAmountLength(resultSet.getInt(9));
					bean.setServerTimeInMin(resultSet.getInt(10));
					bean.setMobileNoLength(resultSet.getInt(11));

					list.add(bean);
				}

			}

			log.info("Size of admin site acquirer list: {}", list.size());

			int totalRecordCount = callableStatement.getInt(5);

			dtResponse.setData(list);
			dtResponse.setRecordsFiltered(totalRecordCount);
			dtResponse.setRecordsTotal(totalRecordCount);
		} catch (Exception e) {
			log.error("Exception occurred in getSiteAcquirerList {}", e);
			return null;
		}

		dtResponse.setData(list);
		log.info(dtResponse);
		return dtResponse;

	}

	/**
	 * getSiteAcquirerData(...) is responsible to get Details to Edit Acquirer Details
	 * 
	 * @param acqId  				{long}
	 * @return AdminAcquirerListBean
	 */
	@Override
	public EditAcquirerDetailsBean getSiteAcquirerData(long acqId) {

		String sql = "{call tsp_web_admin_slave_getSiteAcquirerData(?)}";

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setLong(1, acqId);

			try (ResultSet resultSet = callableStatement.executeQuery()) {
				log.info("CallableStatement: {}", callableStatement);

				while (resultSet.next()) {

					EditAcquirerDetailsBean bean = new EditAcquirerDetailsBean();

					bean.setName(resultSet.getString(1));
					bean.setZmk(resultSet.getString(2));
					bean.setZpk(resultSet.getString(3));
					bean.setZek(resultSet.getString(4));
					bean.setTipPercent(resultSet.getDouble(5));
					bean.setApkName(resultSet.getString(6));
					bean.setCurrencyId(resultSet.getInt(7));
					bean.setDecimalAmountLength(resultSet.getInt(8));
					bean.setServerTimeInMin(resultSet.getInt(9));
					bean.setMobileNoLength(resultSet.getInt(10));
					bean.setAcqId(acqId);	

					return bean;

				}
			}

		} catch (Exception e) {
			log.error("Exception occurred in getSiteAcquirerData {}", e);
			return null;
		}

		return null;
	}

	@Override
	public String updateAcquirer(EditAcquirerDetailsBean updateBeanData, long acqId, long userId) {
		String message="";
		String sql = " {call tsp_web_admin_master_updateAcquirer(?,?,?,?,?,?,?,?,?,?,?,?)}";
		
		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sql)) {

			callableStatement.setString(1, updateBeanData.getName());
			callableStatement.setString(2, updateBeanData.getZmk());
			callableStatement.setString(3, updateBeanData.getZpk());
			callableStatement.setString(4, updateBeanData.getZek());
			callableStatement.setDouble(5, updateBeanData.getTipPercent());
			callableStatement.setInt(6, (int)acqId);
			callableStatement.setLong(7,userId);
			callableStatement.setString(8, updateBeanData.getApkName());
			callableStatement.setLong(9, updateBeanData.getCurrencyId());
			callableStatement.setInt(10, updateBeanData.getDecimalAmountLength());
			callableStatement.setInt(11, updateBeanData.getServerTimeInMin());
			callableStatement.setInt(12, updateBeanData.getMobileNoLength());
			
			boolean flag = callableStatement.execute();
			
			if (!flag) {
				message = "success";
			} else {
				message = "Unable to Update Acquirer";
			}
			log.info("message from procedure: {}, callableStatement: {}", message, callableStatement);

		} catch (Exception e) {
			log.error("exeption occured while processing updateAcquirer(): {}", e);
		}

		return message;
	}

}
