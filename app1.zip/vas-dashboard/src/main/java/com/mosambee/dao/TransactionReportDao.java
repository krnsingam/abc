package com.mosambee.dao;

import java.util.List;
import java.util.Map;

import com.mosambee.bean.AcquirerBean;
import com.mosambee.bean.TransactionDateReportBean;
import com.mosambee.bean.TransactionReportBean;
import com.mosambee.bean.TransactionSearchFormBean;
import com.mosambee.bean.TransactionSearchFormDataTableBean;
import com.mosambee.bean.TransactionSearchReportBean;
import com.mosambee.bean.TransactionTypeBean;
import com.mosambee.bean.datatables.DataTablesResponse;

/**
 * TransactionReportDao is specification for {@link TransactionReportDaoImpl}
 * 
 * @author karan.singam
 * @version 1.0
 * @since 10-January-2020
 */
public interface TransactionReportDao {

	public DataTablesResponse<TransactionReportBean> getActiveTransactionReport(TransactionDateReportBean dtRequest, String orderingColumnName, Map<String, String> searchMap);

	public List<TransactionReportBean> downloadActiveTransactionReportList(TransactionReportBean report);
	
	public TransactionReportBean getActiveTransaction(int id);
	
	public List<TransactionTypeBean> getListOfTrxnType(); 
	
	List<TransactionSearchReportBean> getCountOfTransactions(TransactionSearchFormBean transactionSearchFormBean);
	
	public DataTablesResponse<TransactionSearchReportBean> getTransactionListData(TransactionSearchFormDataTableBean dtRequest, String orderingColumnName, Map<String, String> searchMap);
	
	public TransactionSearchReportBean getTransById(long tranId);
	
	public List<Map<Integer, String>> getTransactionSearchListExcel(TransactionSearchFormBean searchFormBean);
	
	public List<AcquirerBean> getListOfAcquirer();
	
	public List<String> getListOfMerchantName(String name);
	
}
