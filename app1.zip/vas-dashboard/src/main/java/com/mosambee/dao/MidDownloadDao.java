package com.mosambee.dao;

import java.util.List;
import com.mosambee.bean.MidDateBean;
import com.mosambee.bean.MidDownloadBean;

/**
 * This class provides specification for {@link MidDownloadDaoImpl}
 * 
 * @author pooja.singh
 * @version
 */
public interface MidDownloadDao {
	List<MidDownloadBean> downloadMid(MidDateBean midDateBean);

}
