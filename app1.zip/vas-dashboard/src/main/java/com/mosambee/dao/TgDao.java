package com.mosambee.dao;

import com.mosambee.bean.TgBean;
import com.mosambee.bean.TgCrudBean;
import com.mosambee.bean.TgDataTableRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.dao.impl.TgDaoImpl;

/**
 * TgDao is specification for {@link TgDaoImpl}
 * @author mariam.siddique
 * @version 1.0
 * @since 08-April-2020 
 * */

public interface TgDao {
	
	DataTablesResponse<TgBean> getTgList(TgDataTableRequestBean dtRequest , String orderingColumnName);
	
	boolean addTg(TgCrudBean tgCrudBean);
	
	TgCrudBean getTgDetails(int tgId);
	
	boolean updateTg(TgCrudBean tgCrudBean);


}
