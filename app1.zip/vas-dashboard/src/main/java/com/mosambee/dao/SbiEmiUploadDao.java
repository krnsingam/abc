package com.mosambee.dao;

import com.mosambee.bean.SBIMidUploadBean;

/**
 * @author saurabhkant.shukla
 *
 */
public interface SbiEmiUploadDao {

	String uploadSbiMid(SBIMidUploadBean sBIMidUploadBean, Long userId);

}
