package com.mosambee.dao;

import com.mosambee.bean.EmiConversionUploadBean;

public interface EmiConversionUploadDao {
	String uploadEmiConversion(EmiConversionUploadBean emiConversionUploadBean);
}
