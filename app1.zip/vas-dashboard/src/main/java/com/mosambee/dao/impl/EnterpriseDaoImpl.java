package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.CityBean;
import com.mosambee.bean.CountryBean;
import com.mosambee.bean.EnterpriseBatchList;
import com.mosambee.bean.EnterpriseBean;
import com.mosambee.bean.EnterpriseDataBean;
import com.mosambee.bean.EnterpriseListBean;
import com.mosambee.bean.EnterpriseNoOfTerminalBean;
import com.mosambee.bean.MerchantNameBean;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.StateBean;
import com.mosambee.bean.TransactionSearchReportBean;
import com.mosambee.bean.UpdateAPIPaswordConfigRequestFromList;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.CommonConstants;
import com.mosambee.dao.EnterpriseDao;

import lombok.extern.log4j.Log4j2;

/**
 * This class used to provide implementation for all methods of
 * {@link EnterpriseDao} This class responsible for store and fetch
 * record in database.
 * 
 * @version 1.0
 * @author karan.singam
 */
@Log4j2
@Repository("enterpriseDao")
public class EnterpriseDaoImpl implements EnterpriseDao{

	@Autowired
	@Qualifier("masterSFNTransactionTemplate")
	private JdbcTemplate masterSFNTransactionTemplate;

	@Autowired
	@Qualifier("slaveSFNTransactionTemplate")
	private JdbcTemplate slaveSFNTransactionTemplate;
	
	@Autowired
	@Qualifier("masterSecurityAndLicenseTemplate")
	private JdbcTemplate masterSecurityAndLicenseTemplate;
	
	private static final String CALLABLE_STATEMENT = "callableStatement : {}";
	
	private static final String  SUCCESS_MSG = "Success";
	
	private static final String  RECORD_ID = "recordId";
	
	/**
	 * This method is used to create/insert record for Enterprise
	 * This method operates on database : sfn_transaction and table : address.
	 * 
	 * @param EnterpriseBean : Expect bean of "{@link EnterpriseBean}" from which
	 *                       data should be store.
	 * @param responseBean   : Expect bean of "{@link ResponseBean}" which is used
	 *                       to set operation status message as well as id of record
	 *                       inserted which we use for update record.
	 * @return boolean : Return "true" if record inserted successfully. Return
	 *         "false" if record insertion failed due to any reason.
	 * @author karan.singam
	 */
	@Override
	public ResponseBean createEnterprise(EnterpriseBean enterprise) {

		String sqlQuery = "{ call tsp_web_admin_master_addEnterpriseStructure(?,?,?,?,?,?,?,?,?,?,?,?,?,?) }";
		ResponseBean responseBean = new ResponseBean();

		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			callableStatement.registerOutParameter(1, java.sql.Types.BIGINT);
			callableStatement.setLong(2,enterprise.getPentId());
			callableStatement.setInt(3, 1);
			callableStatement.setString(4, enterprise.getName());
			callableStatement.setString(5, enterprise.getTz());
			callableStatement.setInt(6, 1);
			callableStatement.setString(7, enterprise.getAddress1());
			callableStatement.setString(8, enterprise.getAddress2());
			callableStatement.setString(9, enterprise.getLandmark());
			callableStatement.setLong(10, enterprise.getCity());
			callableStatement.setLong(11, enterprise.getState());
			callableStatement.setLong(12, enterprise.getCountry());
			callableStatement.setString(13, enterprise.getPin());
			callableStatement.setString(14, enterprise.getPhone());
			callableStatement.setInt(15, 1);
			callableStatement.setLong(16, enterprise.getAddressId());
			callableStatement.setLong(17, enterprise.getEId());
			callableStatement.registerOutParameter(16, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(17, java.sql.Types.BIGINT);
			log.info(CALLABLE_STATEMENT, callableStatement);
			callableStatement.execute();
			String temp = "added";
			responseBean.setMsg(temp);
			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put("recordId", callableStatement.getLong(17));		

		} catch (Exception e) {
			log.error("Error occurred in createAPIGroup() while inserting record : {}", e);
			responseBean.setMsg(CommonConstants.RECORD_INSERTION_FAILED.get());
			responseBean.setUpdateRequest(false);
			return responseBean;
		}
		responseBean.setUpdateRequest(false);
		return responseBean;
	}
	
	/**
	 * This method is used to get country detail record for Enterprise
	 * This method operates on database : sfn_transaction and table : Country.
	 * 
	 * @return List<CountryBean>
	 * @author karan.singam
	 */
	@Override
	public List<CountryBean> getCountry() {
		
		CountryBean bean = null;
		List<CountryBean> country = new ArrayList<>();
		String sqlQuery = "{ call tsp_Countries() }";

		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			
			log.info(CALLABLE_STATEMENT, callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);

				while (resultSet.next()) {
					bean = CountryBean.builder().id(resultSet.getInt(1)).name(resultSet.getString(2)).build();
					country.add(bean);
				}
			}
		} catch (Exception e) {
			log.info("Error occurred in getCountry() : {}", e);
		}
		return country;
	}
	
	
	/**
	 * This method is used to get State detail record for Enterprise
	 * This method operates on database : sfn_transaction and table : State.
	 * 
	 * @return List<StateBean>
	 * @author karan.singam
	 */
	@Override
	public List<StateBean> getState(CountryBean country) {
		
		StateBean bean = null;
		List<StateBean> state = new ArrayList<>();
		String sqlQuery = "{ call tsp_state(?) }";

		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			
			callableStatement.setLong(1, country.getId());
			
			log.info(CALLABLE_STATEMENT, callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);

				while (resultSet.next()) {
					bean = StateBean.builder().id(resultSet.getInt(1)).name(resultSet.getString(2)).build();
					state.add(bean);
				}
			}
		} catch (Exception e) {
			log.info("Error occurred in getState() : {}", e);
		}
		return state;
	}
	
	/**
	 * This method is used to get City detail record for Enterprise
	 * This method operates on database : sfn_transaction and table : City.
	 * 
	 * @return List<CityBean>
	 * @author karan.singam
	 */
	@Override
	public List<CityBean> getCity(StateBean state) {
		
		CityBean bean = null;
		List<CityBean> city = new ArrayList<>();
		String sqlQuery = "{ call tsp_city(?) }";

		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			
			callableStatement.setLong(1, state.getId());
			
			log.info(CALLABLE_STATEMENT, callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);

				while (resultSet.next()) {
					bean = CityBean.builder().id(resultSet.getInt(1)).name(resultSet.getString(2)).build();
					city.add(bean);
				}
			}
		} catch (Exception e) {
			log.info("Error occurred in getCity() : {}", e);
		}
		return city;
	}
	
	/**
	 * enterpriseList(...) is responsible for getting the active
	 * enterprise list, corresponding to the coming data-tables request. Here we
	 * have three parameters, first is the actual {@link DataTablesRequest}, second
	 * one is the orderingColumnName in which ordering is going to happen
	 * (ASC/DESC). Third one is a searchMap which is basically a Map of String key
	 * and value pairs which transformed search values for each column in which we
	 * are applying data-tables search.
	 * 
	 * @param dtRequest          {@link DataTablesRequest}
	 * @param orderingColumnName {@link String}
	 * @param searchMap          Map with key and value as String
	 */
	@Override
	public DataTablesResponse<EnterpriseListBean> enterpriseList(EnterpriseDataBean dtRequest,
			String orderingColumnName, Map<String, String> searchMap) {
		DataTablesResponse<EnterpriseListBean> dtResponse = new DataTablesResponse<>();
		List<EnterpriseListBean> list = new ArrayList<>();
		String sqlQuery = "{ call tsp_web_admin_slave_getEntSummary(?,?,?,?,?,?,?,?) }";
		log.info("dtRequest {} orderingColumn {}",dtRequest,orderingColumnName);
		try (Connection connection = this.masterSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setInt(1, dtRequest.getDataTable().getStart());
			callableStatement.setInt(2, dtRequest.getDataTable().getLength());
			callableStatement.setString(3, orderingColumnName);
			callableStatement.setString(4, dtRequest.getDataTable().getOrder().get(0).getDir().toString());
			callableStatement.setString(5, dtRequest.getFromDate());
			callableStatement.setString(6, dtRequest.getToDate());
			callableStatement.setLong(7, dtRequest.getEid());
		
			callableStatement.registerOutParameter(8, java.sql.Types.INTEGER);
            log.info("callableSatement {}",callableStatement);
			try (ResultSet resultSet = callableStatement.executeQuery()) {
				log.info("{}", callableStatement);
				while (resultSet.next()) {
					EnterpriseListBean bean = EnterpriseListBean.builder().enterpriseName(resultSet.getString(1)).eId(resultSet.getLong(2))
							.numberOfTerminals(resultSet.getLong(3)).totalSales(resultSet.getLong(5))
							.totalTransaction(resultSet.getLong(4)).declinedTransaction(resultSet.getLong(8))
							.viewEnterprise("Structure").build();
					list.add(bean);
				}
			}
			log.info("Size of enterprise list: {}", list.size());

			int totalRecordCount = callableStatement.getInt(8);

			dtResponse.setData(list);
			dtResponse.setRecordsFiltered(totalRecordCount);
			dtResponse.setRecordsTotal(totalRecordCount);
		} catch (Exception e) {
			log.info("Exception occurred in enterpriseList : {}", e.getMessage());
			return dtResponse;
		}

		dtResponse.setData(list);
		log.info(dtResponse);
		return dtResponse;
	}
	
	/** 
	 *  This method operates on database : sfn_transaction and table : merchant. 
	 *	@param  MerchantNameBean : Expect bean  of "{@link MerchantNameBean}" from which data should be store.
	 *	@return	List<MerchantNameBean>	 
	 *  @author karan.singam
	 */		
	@Override
	public List<EnterpriseListBean> getEnterpriseName(EnterpriseListBean entList) {			
		String sqlQuery = "{ call tsp_web_admin_slave_getEnterpriseName(?) }";
		List<EnterpriseListBean> list = new ArrayList<>();
		EnterpriseListBean bean = null;
		try (Connection connection = this.masterSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			callableStatement.setString(1, entList.getEnterpriseName());
			
			log.info(CALLABLE_STATEMENT,callableStatement);			
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);

				while (resultSet.next()) {

					bean = EnterpriseListBean.builder().eId(resultSet.getLong(1)).enterpriseName(resultSet.getString(2)).build();
					list.add(bean);
				}

				log.info("Size of Merchant list is: {}", list.size());

			}
		} catch (Exception e) {
			log.error("Error occurred in createAPIGroup() while inserting record : {}", e.getMessage());
		}

		return list;
	}

	/**
	 * This method is used to fetch details of API Password Config Group by id. This
	 * method we have used when we want to edit API Password Config from list. This
	 * method operates on database : sfn_transaction and table :
	 * merchant_api_division.
	 * 
	 * @param updateAPIPaswordConfigRequestFromList : Expect bean of
	 *                                              "{@link UpdateAPIPaswordConfigRequestFromList}"
	 *                                              which is used to get id of API
	 *                                              Password Config.
	 * @param createAPIGroup                        : Expect bean of
	 *                                              "{@CreateAPIGroup}" in which the
	 *                                              method will store all data of
	 *                                              API Password Config.
	 * @param responseBean                          : Expect bean of
	 *                                              "{@link ResponseBean}" which is
	 *                                              used to set operation status
	 *                                              message. We can use this to to
	 *                                              render data related to status
	 *                                              message to jsp.
	 * @return boolean : Return "True" if record successfully fetched. Return
	 *         "false" if record is not successfully fetched or record not found.
	 * @author mandar.chaudhari
	 */
	@Override
	public boolean updateEnterpriseList(UpdateAPIPaswordConfigRequestFromList updateAPIPaswordConfigRequestFromList,
			EnterpriseBean enterprise, ResponseBean responseBean) {
		String sqlQuery = "{ call tsp_web_admin_slave_editStructure(?) }";

		try (Connection connection = this.slaveSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setLong(1, updateAPIPaswordConfigRequestFromList.getId());
			callableStatement.registerOutParameter(2, java.sql.Types.BOOLEAN);
			callableStatement.registerOutParameter(3, java.sql.Types.VARCHAR);

			log.info(CALLABLE_STATEMENT, callableStatement);

			try (ResultSet resultSet = callableStatement.executeQuery();) {
				while (resultSet.next()) {
					
					enterprise.setEId(resultSet.getInt(1));
					enterprise.setClientId(resultSet.getInt(2));
					enterprise.setPentId(resultSet.getInt(3));
					enterprise.setLevel(resultSet.getInt(4));
					enterprise.setName(resultSet.getString(5));
					enterprise.setTz(resultSet.getString(6));
					enterprise.setRecStatus(resultSet.getInt(7));

					enterprise.setAddress1(resultSet.getString(8));
					enterprise.setAddress2(resultSet.getString(9));
					enterprise.setLandmark(resultSet.getString(10));

					enterprise.setCity(resultSet.getLong(11));
					enterprise.setState(resultSet.getLong(12));
					enterprise.setCountry(resultSet.getLong(13));
					enterprise.setPin(resultSet.getString(14));
					enterprise.setPhone(resultSet.getString(15));

					responseBean.setMsg(SUCCESS_MSG);
					responseBean.setData(new HashMap<String, Object>());
					responseBean.getData().put(RECORD_ID,resultSet.getLong(1));
				}
					return true;	
			}
		} catch (Exception e) {
			log.error("Error occurred in getAPIGroupDataById() while fetching record : {}", e);
			responseBean.setMsg(CommonConstants.RECORD_INSERTION_FAILED.get());
			return false;
		}
	}
	
	/**
	 * This method is used to update record for API Password Config Group. This
	 * method operates on database : sfn_transaction and table :
	 * merchant_api_division.
	 * 
	 * @param EnterpriseBean : Expect bean of "{@link EnterpriseBean}" from which
	 *                       data should be store.
	 * @param responseBean   : Expect bean of "{@link ResponseBean}" which is used
	 *                       to set operation status message as well as id of record
	 *                       inserted which we use for update record as well as use
	 *                       this to render data related to status message to jsp.
	 * @return boolean : Return "true" if record updated successfully. Return
	 *         "false" if record update failed due to any reason.
	 * @author mandar.chaudhari
	 */
	@Override
	public boolean updateEnterprise(EnterpriseBean enterprise, ResponseBean responseBean) {
		log.info("APIPasswordConfigDaoImpl  updateAPIGroup() called. ");
		String sqlQuery = "{ call tsp_updateStructure(?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?) }";

		try (Connection connection = this.masterSFNTransactionTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, enterprise.getName());
			/*callableStatement.setString(2, enterprise.getApiPassword());
			callableStatement.setString(3, enterprise.getApiURL1());
			callableStatement.setString(4, enterprise.getApiURL2());
			callableStatement.setString(5, enterprise.getDivisionRef1());
			callableStatement.setString(6, enterprise.getDivisionRef2());
			callableStatement.setString(7, enterprise.getDivisionRef3());
			callableStatement.setString(8, enterprise.getDivisionRef4());*/
			callableStatement.setLong(11, enterprise.getEId());
			
			callableStatement.registerOutParameter(14, java.sql.Types.VARCHAR);
			callableStatement.registerOutParameter(15, java.sql.Types.BOOLEAN);

			log.info(CALLABLE_STATEMENT, callableStatement);
			callableStatement.execute();
			String temp = callableStatement.getString(14);
			responseBean.setMsg(temp);
			if (callableStatement.getBoolean(15)) {
				return true;
			}

		} catch (Exception e) {
			log.error("Error occurred in updateAPIGroup() while updating record : {}", e);
			responseBean.setMsg(CommonConstants.RECORD_INSERTION_FAILED.get());
			return false;
		}
		return false;
	}

	
	/** 
	 *  This method operates on database : securityandlicense. 
	 *	@param  EnterpriseDataBean : Expect bean  of "{@link EnterpriseDataBean}" from which data should be store.
	 *	@return	List<EnterpriseNoOfTerminalBean>	 
	 *  @author karan.singam
	 */		
	@Override
	public List<EnterpriseNoOfTerminalBean> getNoOfEnterpriseTerminal(EnterpriseDataBean entList) {		
		String sqlQuery = "{ call tsp_getUserDetailsByEntId_T(?) }";
		List<EnterpriseNoOfTerminalBean> list = new ArrayList<>();
		EnterpriseNoOfTerminalBean bean = null;
		try (Connection connection = this.masterSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			callableStatement.setLong(1, entList.getEid());
			
			log.info(CALLABLE_STATEMENT,callableStatement);			
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);

				while (resultSet.next()) {

					bean = EnterpriseNoOfTerminalBean.builder().mobileNo(resultSet.getString(1)).userId(resultSet.getLong(2))
							.noOfTransaction(resultSet.getLong(4)).batches(resultSet.getLong(5)).noOfCnpTransaction(resultSet.getLong(6))
							.noOfFailedTransaction(resultSet.getLong(7))
							.build();
					list.add(bean);
				}

				log.info("Size of Merchant list is: {}", list.size());

			}
		} catch (Exception e) {
			log.error("Error occurred in createAPIGroup() while inserting record : {}", e.getMessage());
		}

		return list;
	}
	
	/** 
	 *  This method operates on database : securityandlicense. 
	 *	@param  EnterpriseDataBean : Expect bean  of "{@link EnterpriseDataBean}" from which data should be store.
	 *	@return	List<TransactionSearchReportBean>	 
	 *  @author karan.singam
	 */		
	@Override
	public List<TransactionSearchReportBean> getTotalTransaction(EnterpriseDataBean entList) {
			
		String sqlQuery = "{ call tsp_web_admin_slave_getEnterpriseTransactionSearchListTest(?) }";
		List<TransactionSearchReportBean> list = new ArrayList<>();
		TransactionSearchReportBean bean = null;
		try (Connection connection = this.masterSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			callableStatement.setLong(1, entList.getEid());
			
			log.info(CALLABLE_STATEMENT,callableStatement);			
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);

				while (resultSet.next()) {

					bean = TransactionSearchReportBean.builder().transactionId(resultSet.getLong(1)).userName(resultSet.getString(6))
							.cardNumber(resultSet.getString(7)).rrn(resultSet.getString(8)).amount(resultSet.getLong(9))
							.time(resultSet.getString(10)).txnDate(resultSet.getString(10)).stan(resultSet.getString(11))
							.netAmount(resultSet.getLong(8)).status(resultSet.getString(12)).type(resultSet.getString(13))
							.tgId(resultSet.getInt(14)).responseCode(resultSet.getString(15)).authCode(resultSet.getString(16))
							.build();
					list.add(bean);
				}

				log.info("Size of Merchant list is: {}", list.size());

			}
		} catch (Exception e) {
			log.error("Error occurred in createAPIGroup() while inserting record : {}", e.getMessage());
		}

		return list;
	}
	
	/** 
	 *  This method operates on database : securityandlicense. 
	 *	@param  EnterpriseDataBean : Expect bean  of "{@link EnterpriseDataBean}" from which data should be store.
	 *	@return	List<EnterpriseBatchList>	 
	 *  @author karan.singam
	 */		
	@Override
	public List<EnterpriseBatchList> getBatchList(EnterpriseDataBean entList) {
		String sqlQuery = "{ call tsp_getBtachDetailsByUser(?) }";
		List<EnterpriseBatchList> list = new ArrayList<>();
		EnterpriseBatchList bean = null;
		try (Connection connection = this.masterSecurityAndLicenseTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {
			callableStatement.setLong(1, entList.getEid());
			
			log.info(CALLABLE_STATEMENT,callableStatement);			
			try (ResultSet resultSet = callableStatement.executeQuery()) {

				log.info("{}", callableStatement);

				while (resultSet.next()) {

					bean = EnterpriseBatchList.builder().batchNumber(resultSet.getLong(1)).sales(resultSet.getLong(2))
							.voidCount(resultSet.getLong(3)).refund(resultSet.getLong(4)).salesAmount(resultSet.getDouble(5))
							.voidAmount(resultSet.getDouble(6)).refundAmount(resultSet.getDouble(7)).tid(resultSet.getString(8))
							.build();
					list.add(bean);
				}

				log.info("Size of Merchant list is: {}", list.size());

			}
		} catch (Exception e) {
			log.error("Error occurred in createAPIGroup() while inserting record : {}", e.getMessage());
		}

		return list;
	}
	
}
