package com.mosambee.dao;

import java.util.Map;

import com.mosambee.bean.BlockedUserBean;
import com.mosambee.bean.BlockedUserDataTableBean;
import com.mosambee.bean.UserBean;
import com.mosambee.bean.UserCrudBean;
import com.mosambee.bean.UserCrudDataTableBean;
import com.mosambee.bean.UserExistAndNotBlockedBean;
import com.mosambee.bean.datatables.DataTablesResponse;

public interface UserDao {

	UserBean loadUserByUsername(String username);

	boolean checkCpStatus(String username);

	boolean checkIfUserIsBlocked(long userId);

	void addLoginLogs(String code, String remoteAddr, Long userId);

	UserExistAndNotBlockedBean checkIfUserExistsAndNotBlocked(String username);

	boolean checkWrongCredentialCount(long userId);

	boolean blockUser(int blockDuration, long userId);

	boolean updateBlockDuration(int blockDuration, long userId);

	int getBlockedExpirationDuration();
    
	DataTablesResponse<UserBean> getUserList(UserCrudDataTableBean dtRequest, String orderingColumnName,
			Map<String, String> searchMap);
	
	boolean  updateUserStatus(int status,int userId);
	
	public Map<Integer, String> getRoles();
	
	public boolean createUser(UserCrudBean userCrudBean);
	
	public int updateUser(UserCrudBean userCrudBean);
	
	public boolean updateUserById(UserCrudBean userCrudBean);
	
	UserCrudBean getUserDetails(int userId);
	
	DataTablesResponse<BlockedUserBean> getWebBlockedUsers(BlockedUserDataTableBean dtRequest, String orderingColumnName,
			Map<String, String> searchMap);
	
	boolean unblockBlockedUsers(long mUserId,String comment);
	
	boolean unblockMobileBlockedUsers(long mUserId,String comment);
	
	DataTablesResponse<BlockedUserBean> getMobileBlockedUsers(BlockedUserDataTableBean dtRequest, String orderingColumnName,
			Map<String, String> searchMap);
}
