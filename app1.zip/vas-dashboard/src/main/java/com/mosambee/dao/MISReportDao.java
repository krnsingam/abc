package com.mosambee.dao;

import java.util.List;

import com.mosambee.bean.AcquirerBean;
import com.mosambee.bean.BusinessMISCrudBean;
import com.mosambee.bean.BusinessMISDownloadCrudBean;
import com.mosambee.bean.BusinessMISDownloadResponseBean;

/**
 * MISReportDao is specification for {@link MISReportDao}
 * @author mariam.siddique
 * @version 1.0
 * @since 15-April-2020 
 * */
public interface MISReportDao {
	
	boolean updateBusinessMIS(BusinessMISCrudBean businessMISCrudBean);
	
	int checkUserNameExist(String userNumber);
	
	public List<AcquirerBean> getListOfAcquirer();

	public List<BusinessMISDownloadResponseBean> getDataToDownloadBusinessMIS(BusinessMISDownloadCrudBean businessMISDownloadCrudBean);
}
