package com.mosambee.dao;

/**
 * CommonDao is specification for CommonDaoImpl.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 03-January-2020
 */
public interface CommonDao {
	
	String getPrefixName(String moduleName);

}
