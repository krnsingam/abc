package com.mosambee.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.dao.CommonDao;

/**
 * CommonDaoImpl is basically collections of common database related operations
 * that will be used throughout this application.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 03-January-2020
 */
@Repository("commonDao")
public class CommonDaoImpl implements CommonDao {

	private static final Logger log = LogManager.getLogger(CommonDaoImpl.class);

	@Autowired
	@Qualifier("slaveSfnVasTemplate")
	private JdbcTemplate slaveSfnVasTemplate;

	/**
	 * getPrefixName(...) is responsible for getting the prefixName corresponding to
	 * a moduleName in database table sfn_vas.group_prefix
	 * 
	 * @param moduleName String
	 * @return String prefixName
	 */
	@Override
	public String getPrefixName(String moduleName) {
		String sqlQuery = "{ call tsp_web_admin_slave_getGroupPrefix(?,?) }";

		String prefixName = null;

		try (Connection connection = this.slaveSfnVasTemplate.getDataSource().getConnection();
				CallableStatement callableStatement = connection.prepareCall(sqlQuery)) {

			callableStatement.setString(1, moduleName);
			callableStatement.registerOutParameter(2, java.sql.Types.VARCHAR);

			callableStatement.execute();

			prefixName = callableStatement.getString(2);
			log.info("prefixName is: {}, corresponding to the moduleName: {}", prefixName, moduleName);
		} catch (Exception e) {
			log.error("Error occurred while getPrefixName(): {}", e);
		}

		return prefixName;
	}

}
