package com.mosambee.dao;

import java.util.Map;
import com.mosambee.bean.CreateAPIGroup;
import com.mosambee.bean.ListOfAPIGroup;
import com.mosambee.bean.MIDBulkUpload;
import com.mosambee.bean.MidApiGroupDaetailBean;
import com.mosambee.bean.MidTidBean;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.UpdateAPIPaswordConfigRequestFromList;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;

/**
 * This interface use to declare methods which we want to deal with database in
 * {@link APIPasswordConfigDaoImpl}.
 * 
 * @author mandar.chaudhari
 * @version 1.0
 */
public interface APIPasswordConfigDao {
	public ResponseBean createAPIGroup(CreateAPIGroup createAPIGroup, long createdBy);

	public boolean updateAPIGroup(CreateAPIGroup createAPIGroup, ResponseBean responseBean, long createdBy);

	public DataTablesResponse<ListOfAPIGroup> getListOfAPIGroup(DataTablesRequest dtRequest, String orderingColumnName,
			Map<String, String> searchMap);

	public boolean getAPIGroupDataById(UpdateAPIPaswordConfigRequestFromList updateAPIPaswordConfigRequestFromList,
			CreateAPIGroup createAPIGroup, ResponseBean responseBean);

	public void insertMIDBulkUploadData(MIDBulkUpload midBulkUpload, long createdBy);

	public boolean isAPIPasswordConfigPasswordPresent(String password, long id);

	public MidApiGroupDaetailBean isAPIDetailsPresent(long id);

	public MIDBulkUpload validateMIDBulkUploadData(MIDBulkUpload midBulkUpload);

	public boolean updateApiEmailCall(CreateAPIGroup createAPIGroup, long id);
	
	public DataTablesResponse<MidTidBean> listMidTid(DataTablesRequest dtRequest,
			String orderingColumnName, Map<String, String> searchMap, int id);
}
