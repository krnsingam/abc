package com.mosambee.service;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.core.io.Resource;


import com.mosambee.bean.AcquirerBean;
import com.mosambee.bean.TransactionDateReportBean;
import com.mosambee.bean.TransactionReportBean;
import com.mosambee.bean.TransactionSearchFormBean;
import com.mosambee.bean.TransactionSearchFormDataTableBean;
import com.mosambee.bean.TransactionSearchReportBean;
import com.mosambee.bean.TransactionTypeBean;
import com.mosambee.bean.datatables.DataTablesResponse;


/**
 * TransactionReportService.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 10-January-2020
 */
public interface TransactionReportService {

	public DataTablesResponse<TransactionReportBean> getActiveTransactionList(TransactionDateReportBean dtRequest);
	
	public Resource downloadActiveTransactionReportList(TransactionReportBean report);
	
	public TransactionReportBean getActiveTransaction(int id);
	
	
	List<TransactionSearchReportBean> getCountOfTransactions(TransactionSearchFormBean transactionSearchFormBean);
	
	DataTablesResponse<TransactionSearchReportBean> getTransactionListData(TransactionSearchFormDataTableBean dtRequest);
	
	public TransactionSearchReportBean getTransById(long tranId) ;
	
	public List<Map<Integer, String>> getTransactionSearchListExcelData(TransactionSearchFormBean transactionSearchFormBean);
	
	HSSFWorkbook getTransactionSearchListExcel(List<Map<Integer, String>> list,TransactionSearchFormBean transactionSearchFormBean);
	
	public Resource getResourceFromWorkbook(HSSFWorkbook responseWorkbook);	
	
	public boolean sendTransactionSMS(long tranId,String sms);
	
	public List<AcquirerBean> getListOfAcquirer();
	
	public List<String> getListOfMerchantName(String name);
	
	public Resource getTransactionCSV(List<Map<Integer, String>> list);
	
	public Resource getResourceFromCSV(File file);
	
	public boolean sendTransactionEmail(long transactionId,String emailId);
	
	public List<TransactionTypeBean> getListOfTrxnType();
	
}
