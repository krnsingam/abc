package com.mosambee.service;

import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import com.mosambee.bean.EmiDownloadBean;
import com.mosambee.bean.EmiMidTidBean;
import com.mosambee.bean.EmiSearchDatatablesRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;

/**
 * This class provides specification for {@link EmiBulkUploadServiceImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
public interface EmiBulkUploadService {
	Resource processEmiBulkUploadExcel(MultipartFile file,String createdBy);

	Resource getEmiBulkUploadFormat();

	DataTablesResponse<EmiMidTidBean> getEmiSearchList(EmiSearchDatatablesRequestBean dtRequest);
	
	List<EmiMidTidBean> downloadEmiSearchList(EmiDownloadBean emiDownloadBean);

	Resource processEmiSearchList(List<EmiMidTidBean> responseBean);

}
