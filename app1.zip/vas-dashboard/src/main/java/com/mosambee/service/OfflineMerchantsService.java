package com.mosambee.service;

import com.mosambee.bean.OfflineMerchantTerminalSearchBean;
import com.mosambee.bean.OfflineMerchantsListBean;
import com.mosambee.bean.OfflineMerchantsSearchBean;
import com.mosambee.bean.OfflineTerminalListBean;
import com.mosambee.bean.OfflineTerminalSearchBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.service.impl.OfflineMerchantsServiceImpl;

/**
 * OfflineMerchantsService specification for {@link OfflineMerchantsServiceImpl} class
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 01-April-2020
 */
public interface OfflineMerchantsService {
	
	DataTablesResponse<OfflineMerchantsListBean> getOfflineMerchantsList(OfflineMerchantsSearchBean dtRequest);

	DataTablesResponse<OfflineTerminalListBean> getOfflineTerminalList(OfflineTerminalSearchBean searchBean);
	
	DataTablesResponse<OfflineTerminalListBean> getOfflineMerchantTerminalList(OfflineMerchantTerminalSearchBean searchBean);
	
	boolean getMerchantsTerminalForOfflineKeySet(long merchantId);
		
	int updateOfflineKey(String terminalId,String offlineKey, long createdUserId);
	

}
