package com.mosambee.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mosambee.bean.KeyBulkUploadBean;
import com.mosambee.bean.MappingBulkUpload;
import com.mosambee.bean.MerchantKeyBean;
import com.mosambee.bean.MerchantKeyDataBean;
import com.mosambee.bean.MerchantMappingBean;
import com.mosambee.bean.MerchantMappingDataBean;
import com.mosambee.bean.MerchantNameBean;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.BulkUploadCategory;
import com.mosambee.constants.BulkUploadFileLocation;
import com.mosambee.constants.ColumnNames;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ModuleName;
import com.mosambee.constants.ViewLayer;
import com.mosambee.dao.MerchantSpecificDao;
import com.mosambee.properties.ExcelHeaderProperties;
import com.mosambee.service.ExcelService;
import com.mosambee.service.MerchantSpecificService;
import com.mosambee.transformer.MerchantSpecificTransformer;
import com.mosambee.validator.MerchantSpecificValidator;

/**
 * MerchantSpecificServiceImpl class implementing {@link MerchantSpecific}
 * specification.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 10-February-2020
 */
@Service(value = "merchantSpecificService")
public class MerchantSpecificServiceImpl implements MerchantSpecificService{
	
	@Autowired
	ExcelService excelService;
	
	@Autowired
	private ExcelHeaderProperties excelHeaderProperties;
	
	@Autowired
	MerchantSpecificDao dao;
	
	@Autowired
	MerchantSpecificValidator merchantSpecificValidator;
	
	@Autowired
	MerchantSpecificTransformer merchantTransformer;
	
	
	private static final Logger log = LogManager.getLogger(MerchantSpecificServiceImpl.class);
	
	private static final  String RECORD_ID = "recordId";
	
	private static final  String SORRY_MSG = "Sorry, Data is not valid.";
	
	private static final  String BREADCRUMB = "breadCrumb";
	
	private static final DataFormatter dataFormatter = new DataFormatter();
	
	/**
	 * This method is used to call validation methods on {@link MerchantMappingBean}.
	 * Also this method checks that bean is validated or not if bean is validated it allows to insert record in database by calling
	 * {@link #createMerchantMapping(MerchantMappingBean)} of {@link MerchantSpecificDao}. If bean failed in validation then it set {@link ResponseBean} class field "operationStatus" to 400,
	 * If data is successfully inserted then set "updateRequest" to "True" and "operationStatus" to 200 otherwise set "operationStatus" to 400
	 * and "updateRequest" to "False".
	 * 
	 * @param responseBean   : Expect bean of "{@link ResponseBean}" which is used to set operation status message. We can use this to
	 *				 		   to render data related to status message to jsp.
	 * @param MerchantMappingBean : Expect bean of "{@link MerchantMappingBean}" from which data should be store.
	 * @return ResponseBean
	 */
	@Override
	public ResponseBean createMerchantMapping(MerchantMappingBean merchantMapping) {
		
		ResponseBean responseBean = new ResponseBean();
		merchantSpecificValidator.validateMerchantMapping(merchantMapping); // This call is sued to validate "createAPIGroup" bean.  
		boolean status;
		if(merchantMapping.isValidate()) // If validation succeed then insert record.
		{
			responseBean = dao.createMerchantMapping(merchantMapping);
			status = responseBean.isUpdateRequest();
			
			if(status)  // Checks that insert record operation successful or not.
			{
				responseBean.setUpdateRequest(true);
				responseBean.setOperationStatus(200);
				responseBean.getData().put(BREADCRUMB, true);
				responseBean.setAction(ViewLayer.MERCHANT_MAPPING_UPDATE.get()); // Set form action to update record.
				
			}
			else
			{
				
				responseBean.setUpdateRequest(false);
				responseBean.setOperationStatus(400);
				responseBean.getData().put(BREADCRUMB, true);
				responseBean.setAction(ViewLayer.MERCHANT_MAPPING_ACTION.get()); // Set form action to create record.
			}
			log.info("createMerchantMapping validation status : {} ",merchantMapping.isValidate());
			return responseBean;
		}
		else
		{
			responseBean.setMsg(SORRY_MSG);
			responseBean.setOperationStatus(400);
			responseBean.getData().put(BREADCRUMB, true);
			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put(RECORD_ID,0);
		    responseBean.setAction(ViewLayer.MERCHANT_MAPPING_ACTION.get());
		    log.info("createMerchantMapping validation status : {} ",merchantMapping.isValidate());
		    return responseBean;
		}
		
	}

	/**
	 * This method is used to call validation methods on {@link MerchantMappingBean}.
	 * Also this method checks that bean is validated or not if bean is validated it allows to update record in database by calling
	 * {@link #updateMerchantMapping(MerchantMappingBean)} of {@link MerchantSpecificDao}. If bean failed in validation then it set {@link ResponseBean} class field "operationStatus" to 400,
	 * If data is successfully inserted then set "updateRequest" to "True" and "operationStatus" to 200 otherwise set "operationStatus" to 400
	 * and "updateRequest" to "False".
	 * 
	 * @param responseBean   : Expect bean of "{@link ResponseBean}" which is used to set operation status message. We can use this to
	 *				 		   to render data related to status message to jsp.
	 * @param MerchantMappingBean : Expect bean of "{@link MerchantMappingBean}" from which data should be store.
	 * @return ResponseBean
	 */
	@Override
	public ResponseBean updateMerchantMapping(MerchantMappingBean merchantMapping) {
		ResponseBean responseBean = new ResponseBean();
		responseBean.setAction(ViewLayer.MERCHANT_MAPPING_UPDATE.get()); // Set form action to update record.
		merchantSpecificValidator.validateMerchantMapping(merchantMapping); // This call is used to validate "createAPIGroup" bean.
		if(merchantMapping.isValidate()) // Check that bean validation successful or not.
		{
			responseBean.setUpdateRequest(true);
			boolean status = dao.updateMerchantMapping(merchantMapping, responseBean);
			
			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put(RECORD_ID, merchantMapping.getMerchMapId());
			if(status)   // Checks that Update record operation successful or not.
			{
				responseBean.setUpdateRequest(true);
				responseBean.setOperationStatus(200);
				responseBean.getData().put(BREADCRUMB, true);
			}
			else
			{
				responseBean.setUpdateRequest(true);
				responseBean.setOperationStatus(400);
				responseBean.getData().put(BREADCRUMB, true);
			}
		}
		else
		{
			responseBean.setMsg(SORRY_MSG);
			responseBean.setOperationStatus(400);
			responseBean.getData().put(BREADCRUMB, true);
		}
		
		log.info("returning from updateMerchantMapping {} ",merchantMapping.isValidate());
		return responseBean;
	}
	
	
	/**
	 * This method is used to call validation methods on {@link MerchantKeyBean}.
	 * Also this method checks that bean is validated or not if bean is validated it allows to update record in database by calling
	 * {@link #editMerchantKey(MerchantKeyBean)} of {@link MerchantSpecificDao}. If bean failed in validation then it set {@link ResponseBean} class field "operationStatus" to 400,
	 * If data is successfully inserted then set "updateRequest" to "True" and "operationStatus" to 200 otherwise set "operationStatus" to 400
	 * and "updateRequest" to "False".
	 * 
	 * @param responseBean   : Expect bean of "{@link ResponseBean}" which is used to set operation status message. We can use this to
	 *				 		   to render data related to status message to jsp.
	 * @param MerchantKeyBean : Expect bean of "{@link MerchantKeyBean}" from which data should be store.
	 * @return ResponseBean
	 */
	@Override
	public ResponseBean editMerchantKey(MerchantKeyBean merchantkey) {
		ResponseBean responseBean = new ResponseBean();
		responseBean.setAction(ViewLayer.MERCHANT_KEY_UPDATE.get()); // Set form action to update record.
		merchantSpecificValidator.validateMerchantKey(merchantkey); // This call is used to validate "createAPIGroup" bean.
		if(merchantkey.isValidate()) // Check that bean validation successful or not.
		{
			responseBean.setUpdateRequest(true);
			boolean status = dao.editMerchantKey(merchantkey, responseBean);
			
			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put(RECORD_ID, merchantkey.getMerchKeyId());
			if(status)   // Checks that Update record operation successful or not.
			{
				responseBean.setUpdateRequest(true);
				responseBean.setOperationStatus(200);
				responseBean.getData().put(BREADCRUMB, true);
			}
			else
			{
				responseBean.setUpdateRequest(true);
				responseBean.setOperationStatus(400);
				responseBean.getData().put(BREADCRUMB, true);
			}
		}
		else
		{
			responseBean.setMsg(SORRY_MSG);
			responseBean.setUpdateRequest(true);
			responseBean.setOperationStatus(400);
			responseBean.getData().put(BREADCRUMB, true);
		}
		
		log.info("returning from updateMerchantKey {} ",merchantkey.isValidate());
		return responseBean;
	}
	
	/**
	 * This method is basically calling {@link #processMappingById()} of {@link dao} if it return "True" then set {@link ResponseBean} "operationStatus" to  200
	 * and "action" to "update action" otherwise set "operationStatus" to 400.
	 */
	@Override
	public void processMappingById(MerchantMappingBean merchantMappingBean, MerchantMappingBean createMapping, ResponseBean responseBean) {
		responseBean.setData(new HashMap<String, Object>());
		responseBean.getData().put(RECORD_ID, createMapping.getMerchMapId()); // This id will render on jsp page which will be used for update APIPasswordConfig request.
		boolean status = dao.processMappingById(merchantMappingBean, createMapping, responseBean); // Fetch APIPasswordConfig details by passing updateAPIPaswordConfigRequestFromList.
		if(status)
		{
			responseBean.setOperationStatus(200);
			responseBean.setAction(ViewLayer.MERCHANT_MAPPING_UPDATE.get());
			responseBean.getData().put(BREADCRUMB, true);
			responseBean.setUpdateRequest(true);
		}
		else
		{
			responseBean.setOperationStatus(400);
		}
		
	}
	
	/**
	 * This method is basically calling {@link #processKeyById()} of {@link dao} if it return "True" then set {@link ResponseBean} "operationStatus" to  200
	 * and "action" to "update action" otherwise set "operationStatus" to 400.
	 */
	@Override
	public void processKeyById(MerchantKeyBean merchantKeyBean, MerchantKeyBean createKey, ResponseBean responseBean) {
		responseBean.setData(new HashMap<String, Object>());
		responseBean.getData().put(RECORD_ID, createKey.getMerchKeyId()); // This id will render on jsp page which will be used for update APIPasswordConfig request.
		boolean status = dao.processKeyById(merchantKeyBean, createKey, responseBean); // Fetch APIPasswordConfig details by passing updateAPIPaswordConfigRequestFromList.
		if(status)
		{
			responseBean.setOperationStatus(200);
			responseBean.setAction(ViewLayer.MERCHANT_KEY_UPDATE.get());
			responseBean.getData().put(BREADCRUMB, true);
			responseBean.setUpdateRequest(true);
		}
		else
		{
			responseBean.setOperationStatus(400);
		}
		
	}
	
	
	/**
	 * getMerchantName(...) is responsible for 
	 * calling the DAO to get Id and Name as values.
	 * 
	 * @param MerchantNameBean {@link MerchantNameBean}
	 * @return List<MerchantNameBean>
	 */
	@Override
	public List<MerchantNameBean> getMerchantName(MerchantNameBean merchantbean) {
	
		return dao.getMerchantName(merchantbean);
	}
	
	/**
	 * getMerchantMappingView(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request & then
	 * calling the DAO to get those values.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return DataTablesResponse of MerchantMappingBean
	 */
	@Override
	public DataTablesResponse<MerchantMappingBean> getMerchantMappingView(MerchantMappingDataBean dtRequest) {

		// GET THE COLUMN NAME FROM COLUMN INDEX
		int orderingColumnIndex = dtRequest.getDataTable().getOrder().get(0).getColumn();
		String orderingColumnName = getOrderingColumnName(orderingColumnIndex);
		log.info("orderingColumnIndex: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);

		
		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ACTIVE TRANSACTION
		Map<String, String> searchMap = merchantTransformer.transformMerchantMappingView(dtRequest);
		log.info("size of searchMap: {}", searchMap.size());

		return dao.getMerchantMappingView(dtRequest, orderingColumnName, searchMap);
	}

	/**
	 * getOrderingColumnName(...) method is responsible for returning
	 * orderingColumnName when it is provided with orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnName(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.MERCHANT_MAPPING_ID.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.MERCHANT_NAME.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.MERCHANT_CLASSPATH.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.MERCHANT_URL.get();
			break;

		default:
			orderingColumnName = ColumnNames.MERCHANT_MAPPING_ID.get();
			break;
		}

		return orderingColumnName;
	}

	/**
	 * downloadMerchantMapping(...) method is responsible for returning
	 * Resource in byte stream for download. Used for downloading all the
	 * Merchant mapping for Report.
	 * 
	 * @param DataTablesRequest
	 * @return Resource
	 */
	@Override
	public Resource downloadMerchantMapping(MerchantMappingBean report) {

		Resource res = null;
		
		// GET DOWNLOAD LIST FROM DAO LAYER
		List<MerchantMappingBean> response = dao.downloadMerchantMapping(report);
		if(!response.isEmpty()) {
		res = process(response);
		}
		return res;

	}

	/**
	 * process(...) method is responsible for returning Resource as workbook.
	 * 
	 * @param List<TransactionReportBean>
	 * @return Resource
	 */
	public Resource process(List<MerchantMappingBean> responseBean) {

		// GET THE EXCEL WITH RESPONSE
		Workbook responseWorkbook = writeListToExcel(responseBean);

		return excelService.getResourceFromWorkbook(responseWorkbook);
	}

	/**
	 * writeListToExcel(...) method is responsible for returning Workbook as after
	 * parsing data for excel and seting it.
	 * 
	 * @param List<MerchantMappingBean>
	 * @return Workbook
	 */
	private Workbook writeListToExcel(List<MerchantMappingBean> responseBean) {
		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.MERCHANT_MAPPING);
		Sheet sheet = workbook.getSheetAt(0);

		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		int i = 1;
		for (MerchantMappingBean bean : responseBean) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(i++);
			row.createCell(1).setCellValue(bean.getMerchantName());
			row.createCell(2).setCellValue(bean.getClassPath());
			row.createCell(3).setCellValue(bean.getUrl());
		}
		excelService.autoSizeExcel(workbook);
		return workbook;
	}

	
	/**
	 * getMerchantKey(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request & then
	 * calling the DAO to get those values.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return DataTablesResponse of MerchantKeyBean
	 */
	@Override
	public DataTablesResponse<MerchantKeyBean> getMerchantKey(MerchantKeyDataBean dtRequest) {

		// GET THE COLUMN NAME FROM COLUMN INDEX
		int orderingColumnIndex = dtRequest.getDataTable().getOrder().get(0).getColumn();
		String orderingColumnName = getOrderingColumnNameKey(orderingColumnIndex);
		log.info("orderingColumnIndex: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);

		
		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ACTIVE TRANSACTION
		Map<String, String> searchMap = merchantTransformer.transformMerchantKey(dtRequest);
		log.info("size of searchMap: {}", searchMap.size());

		return dao.getMerchantKey(dtRequest, orderingColumnName, searchMap);
	}

	/**
	 * getOrderingColumnNameKey(...) method is responsible for returning
	 * orderingColumnName when it is provided with orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnNameKey(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.MERCHANT_KEY_ID.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.MERCHANT.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.MERCHANT_CODE.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.MERCHANT_KEY.get();
			break;

		default:
			orderingColumnName = ColumnNames.MERCHANT_KEY_ID.get();
			break;
		}

		return orderingColumnName;
	}

	/**
	 * downloadMerchantKey(...) method is responsible for returning
	 * Resource in byte stream for download. Used for downloading all the
	 * Merchant mapping for Report.
	 * 
	 * @param DataTablesRequest
	 * @return Resource
	 */
	@Override
	public Resource downloadMerchantKey(MerchantKeyBean report) {

		Resource res = null;
		
		// GET DOWNLOAD LIST FROM DAO LAYER
		List<MerchantKeyBean> response = dao.downloadMerchantKey(report);
		if(!response.isEmpty()) {
		res = processKey(response);
		}
		return res;

	}

	/**
	 * processKey(...) method is responsible for returning Resource as workbook.
	 * 
	 * @param List<MerchantKeyBean>
	 * @return Resource
	 */
	public Resource processKey(List<MerchantKeyBean> responseBean) {

		// GET THE EXCEL WITH RESPONSE
		Workbook responseWorkbook = writeListToExcelKey(responseBean);

		return excelService.getResourceFromWorkbook(responseWorkbook);
	}

	/**
	 * writeListToExcelKey(...) method is responsible for returning Workbook as after
	 * parsing data for excel and seting it.
	 * 
	 * @param List<TransactionReportBean>
	 * @return Workbook
	 */
	private Workbook writeListToExcelKey(List<MerchantKeyBean> responseBean) {
		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.MERCHANT_KEY);
		Sheet sheet = workbook.getSheetAt(0);

		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		int i = 1;
		for (MerchantKeyBean bean : responseBean) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(i++);
			row.createCell(1).setCellValue(bean.getMerchant());
			row.createCell(2).setCellValue(bean.getMerchantCode());
			row.createCell(3).setCellValue(bean.getMerchantKey());
		}
		excelService.autoSizeExcel(workbook);
		return workbook;
	}
	
	/**
	 * Performs validation for security issues in excel file. Mainly we are check
	 * for embedded object, macros and VB Scripts.
	 *
	 * @param file     MultipartFile
	 * @param workbook Workbook
	 * @return boolean
	 */
	private boolean validateSecurityIssues(MultipartFile file, Workbook workbook) {
		return excelService.checkForEmbeddedObjects(workbook) && excelService.checkForMacrosAndVbScript(file);
	}
	
	/**
	 * Responsible for processing {@link MultipartFile} ... Here we are validating
	 * the header, security issues, parsing the data from the {@link Workbook} &
	 * then again parsing the validated data from the {@link Workbook}
	 *
	 * @param file {@link MultipartFile}
	 * @return 	   {@link Resource}
	 */
	@Override 
	public Resource processBulkUploadExcel(MultipartFile file) 
	{
	  Workbook workbook = excelService.getWorkbookFromMultipartFile(file);
	  List<MappingBulkUpload> bulkUploadBeanList;
	  List<MappingBulkUpload> successRecordList = new ArrayList<>();
	  List<MappingBulkUpload> failedRecordList = new ArrayList<>();
	  
	  // VALIDATE THE HEADER & VALIDATE SECURITY ISSUES
	  if (validateExcelFile(file,workbook) && validateSecurityIssues(file, workbook)) {
	 
	  // PARSE DATA FROM WORKBOOK List<MappingBulkUpload>	  
		  bulkUploadBeanList = parseBulkUploadFields(workbook);
	  
	  // VALIDATE THE PARSED DATA FROM WORKBOOK INTO SUCCESS & FAILED RECORD LIST
	  validateMIDBulkUpload(bulkUploadBeanList, successRecordList, failedRecordList);
	
	  // PERSIST THE PROGRAMS IN DATABASE 
	  persistMIDBulkUpload(successRecordList);
	  
	  // Cleared previous midBulkUploadBeanList to add new data otherwise data will be duplicate
	  bulkUploadBeanList.clear();
	  
	  // ADD ALL SUCCESS AND FAILED RECORDS IN A COMMON LIST
	  bulkUploadBeanList.addAll(failedRecordList);
	  bulkUploadBeanList.addAll(successRecordList);
	 
	  // GET THE EXCEL WITH RESPONSE Workbook responseWorkbook =
	  Workbook responseWorkbook =  writeBulkUploadBeanListToExcel(bulkUploadBeanList);
	  
	  return excelService.getResourceFromWorkbook(responseWorkbook);
	 }
	 else 
	 {
		log.error("Excel file is not valid"); 
	 }
	 return null;
	}
	 
	/**
	 * Performs validation for excel extension and validates the excel header.
	 * 
	 * @param  file     MultipartFile
	 * @param  workbook Workbook
	 * @return boolean
	 */
	private boolean validateExcelFile(MultipartFile file, Workbook workbook) {
		log.info("BulkUploadCategory.MID_BULK_UPLOAD {}",BulkUploadCategory.MAPPING_BULK_UPLOAD);
		return excelService.validateExtension(file)
				&& excelService.validateHeader(workbook, BulkUploadCategory.MAPPING_BULK_UPLOAD);
	}

	

	/**
	 * parseBulkUploadFields(...) is responsible to parsing the workbook.
	 * Here we are parsing the sheet present at 0th index and then iterating the
	 * rows and cells inside them to extract the values.
	 * 
	 * @param  workbook {@link Workbook}
	 * @return {@link List} of {@link MappingBulkUpload}
	 */
	private List<MappingBulkUpload> parseBulkUploadFields(Workbook workbook) {
		Iterator<Row> rowIterator = workbook.getSheetAt(0).iterator();
		List<MappingBulkUpload> bulkUploadList = new ArrayList<>();

		// SKIPING THE HEADER ROW
		rowIterator.next();

		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			MappingBulkUpload bulkUpload = parseRow(row);
			bulkUploadList.add(bulkUpload);
		}

		return bulkUploadList;
	}

	/**
	 * {@link #parseRow(Row)} method is responsible for parsing the row and storing
	 * the parsed value in the object of {@link MappingBulkUpload}
	 * 
	 * @param row
	 * @return {@link MappingBulkUpload}
	 */
	private MappingBulkUpload parseRow(Row row) {
		MappingBulkUpload midBulkUpload = new MappingBulkUpload();

		// SUBTRACT 1 FROM THE SIZE AS IT HAS STATUS HEADER.
		int sizeOfExcelHeader = excelHeaderProperties.getMappingBulkUploadHeaders().size() - 1;

		for (int i = 0; i < sizeOfExcelHeader; ++i) {
			
			Cell cell = row.getCell(i);

			switch (i) {
			case 0:
				midBulkUpload.setMerchantCode(dataFormatter.formatCellValue(cell));
				break;

			case 1:
				midBulkUpload.setTerminalId(dataFormatter.formatCellValue(cell));
				break;
				
			case 2:
				midBulkUpload.setClassPath(dataFormatter.formatCellValue(cell));
				break;
				
			case 3:
				midBulkUpload.setUrl(dataFormatter.formatCellValue(cell));
				break;
				
			default:
				log.info("MIDBulkUpload default case for cell no : {} ", i);
			}
		}

		return midBulkUpload;

	}

	/**
	 * <strong>validateMIDBulkUpload(...)</strong> is responsible for
	 * iterating over the list of mid and then putting them into two separate
	 * list, on the basis of their success and failed validation status. <br>
	 * <br>
	 * 
	 * Here we are using two lists, i.e. successRecordList & failedRecordList for
	 * success and failed records. <br>
	 * 
	 * @param midBulkUploadList     {@link List} of all the MappingBulkUpload.
	 * @param successRecordList 	{@link List} of all the success records.
	 * @param failedRecordList  	{@link List} of all the failed records.
	 * @return void
	 */
	private void validateMIDBulkUpload(List<MappingBulkUpload> midBulkUploadList, List<MappingBulkUpload> successRecordList,
			List<MappingBulkUpload> failedRecordList) {

		// LOOP OVER THE LIST OF MIDs
		for (MappingBulkUpload midBulkUpload : midBulkUploadList) {

			// VALIDATE THE BEAN
			merchantSpecificValidator.validateBulkUpload(midBulkUpload);
			log.info("merchnatCode : {}, tid : {},  classpath : {}, url : {}, status : {}, isValidate : {}", midBulkUpload.getMerchantCode(), midBulkUpload.getTerminalId(), midBulkUpload.getClassPath(),midBulkUpload.getUrl(), midBulkUpload.getStatus(), midBulkUpload.isValidate());
			// PUT THEM IN RESPECTIVE LIST.
			if (midBulkUpload.isValidate()) {
				successRecordList.add(midBulkUpload);
			} else {
				failedRecordList.add(midBulkUpload);
			}
		}
	}

	/**
	 * persistMIDBulkUpload(...) is responsible for getting the prefixName from
	 * {@link ModuleName} and then persist the program details into the database. We
	 * will get programCode after persisting a particular bean which is then set to
	 * the same record.
	 * 
	 * @param successRecordList
	 * @return void
	 */
	private void persistMIDBulkUpload(List<MappingBulkUpload> successRecordList) {

		for (MappingBulkUpload midBulkUpload : successRecordList) {
			
			dao.insertBulkUploadData(midBulkUpload);
		}

	}
	
	/**
	 * {@link #writeBulkUploadBeanListToExcel(List)} is responsible for for creating
	 * the excel with the response after processing the bulk upload excel
	 * file.
	 * 
	 * @param bulkUploadBeanList
	 * @return {@link Workbook}
	 */
	private Workbook writeBulkUploadBeanListToExcel(List<MappingBulkUpload> bulkUploadBeanList) {

		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.MAPPING_BULK_UPLOAD);
		Sheet sheet = workbook.getSheetAt(0);

		log.info("midBulkUploadBeanList.size() : {} ",bulkUploadBeanList.size());
		
		if(bulkUploadBeanList.isEmpty())
		{
			MappingBulkUpload midBulkUploadTemp = new MappingBulkUpload();
			midBulkUploadTemp.setStatus(CommonConstants.NO_RECORD_IN_EXCEL.get());
			bulkUploadBeanList.add(midBulkUploadTemp);
		}
		
		
		
		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		for (MappingBulkUpload midBulkUpload : bulkUploadBeanList) {
			Row row = sheet.createRow(rowNum++);
			
			row.createCell(0).setCellValue(midBulkUpload.getMerchantCode());
			row.createCell(1).setCellValue(midBulkUpload.getTerminalId());
			row.createCell(2).setCellValue(midBulkUpload.getClassPath());
			row.createCell(3).setCellValue(midBulkUpload.getUrl());
			row.createCell(4).setCellValue(midBulkUpload.getStatus());
		}
		excelService.autoSizeExcel(workbook);
		return workbook;

	}
	
	/**
	 * getBulkUploadFormat() is responsible for converting the bulk upload
	 * files present in {@link BulkUploadFileLocation} to {@link Resource}
	 */
	@Override
	public Resource getBulkUploadFormat() {
		ClassPathResource resource = null;
		resource = new ClassPathResource(BulkUploadFileLocation.MAPPING_BULK_UPLOAD_FILE.get());
		return resource.exists() ? resource : null;
	}
	
	/**
	 * getKeyBulkUploadFormat() is responsible for converting the bulk upload
	 * files present in {@link BulkUploadFileLocation} to {@link Resource}
	 */
	@Override
	public Resource getKeyBulkUploadFormat() {
		ClassPathResource resource = null;
		resource = new ClassPathResource(BulkUploadFileLocation.KEY_BULK_UPLOAD_FILE.get());
		return resource.exists() ? resource : null;
	}
	
	/**
	 * Responsible for processing {@link MultipartFile} ... Here we are validating
	 * the header, security issues, parsing the data from the {@link Workbook} &
	 * then again parsing the validated data from the {@link Workbook}
	 *
	 * @param file {@link MultipartFile}
	 * @return 	   {@link Resource}
	 */
	@Override 
	public Resource processKeyBulkUploadExcel(MultipartFile file) 
	{
	  Workbook workbook = excelService.getWorkbookFromMultipartFile(file);
	  List<KeyBulkUploadBean> bulkUploadBeanList;
	  List<KeyBulkUploadBean> successRecordList = new ArrayList<>();
	  List<KeyBulkUploadBean> failedRecordList = new ArrayList<>();
	  
	  // VALIDATE THE HEADER & VALIDATE SECURITY ISSUES
	  if (validateKeyExcelFile(file,workbook) && validateSecurityIssues(file, workbook)) {
	 
	  // PARSE DATA FROM WORKBOOK List<MappingBulkUpload>	  
		  bulkUploadBeanList = parseKeyBulkUploadFields(workbook);
	  
	  // VALIDATE THE PARSED DATA FROM WORKBOOK INTO SUCCESS & FAILED RECORD LIST
		  validateKeyBulkUpload(bulkUploadBeanList, successRecordList, failedRecordList);
	
	  // PERSIST THE PROGRAMS IN DATABASE 
		  persistKeyBulkUpload(successRecordList);
	  
	  // Cleared previous midBulkUploadBeanList to add new data otherwise data will be duplicate
		  bulkUploadBeanList.clear();
	  
	  // ADD ALL SUCCESS AND FAILED RECORDS IN A COMMON LIST
		  bulkUploadBeanList.addAll(failedRecordList);
		  bulkUploadBeanList.addAll(successRecordList);
	 
	  // GET THE EXCEL WITH RESPONSE Workbook responseWorkbook =
		  Workbook responseWorkbook =  writeKeyBulkUploadBeanListToExcel(bulkUploadBeanList);
	  
	  return excelService.getResourceFromWorkbook(responseWorkbook);
	 }
	 else 
	 {
		log.error("Excel file is not valid"); 
	 }
	 return null;
	}
	 
	/**
	 * Performs validation for excel extension and validates the excel header.
	 * 
	 * @param  file     MultipartFile
	 * @param  workbook Workbook
	 * @return boolean
	 */
	private boolean validateKeyExcelFile(MultipartFile file, Workbook workbook) {
		log.info("BulkUploadCategory.MID_BULK_UPLOAD {}",BulkUploadCategory.KEY_BULK_UPLOAD);
		return excelService.validateExtension(file)
				&& excelService.validateHeader(workbook, BulkUploadCategory.KEY_BULK_UPLOAD);
	}

	

	/**
	 * parseKeyBulkUploadFields(...) is responsible to parsing the workbook.
	 * Here we are parsing the sheet present at 0th index and then iterating the
	 * rows and cells inside them to extract the values.
	 * 
	 * @param  workbook {@link Workbook}
	 * @return {@link List} of {@link KeyBulkUploadBean}
	 */
	private List<KeyBulkUploadBean> parseKeyBulkUploadFields(Workbook workbook) {
		Iterator<Row> rowIterator = workbook.getSheetAt(0).iterator();
		List<KeyBulkUploadBean> bulkUploadList = new ArrayList<>();

		// SKIPING THE HEADER ROW
		rowIterator.next();

		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			KeyBulkUploadBean bulkUpload = parseRowKey(row);
			bulkUploadList.add(bulkUpload);
		}

		return bulkUploadList;
	}

	/**
	 * {@link #parseRow(Row)} method is responsible for parsing the row and storing
	 * the parsed value in the object of {@link KeyBulkUploadBean}
	 * 
	 * @param row
	 * @return {@link KeyBulkUploadBean}
	 */
	private KeyBulkUploadBean parseRowKey(Row row) {
		KeyBulkUploadBean midBulkUpload = new KeyBulkUploadBean();

		// SUBTRACT 1 FROM THE SIZE AS IT HAS STATUS HEADER.
		int sizeOfExcelHeader = excelHeaderProperties.getMappingBulkUploadHeaders().size() - 1;

		for (int i = 0; i < sizeOfExcelHeader; ++i) {
			
			Cell cell = row.getCell(i);

			switch (i) {
			case 0:
				midBulkUpload.setMid(dataFormatter.formatCellValue(cell));
				break;

			case 1:
				midBulkUpload.setMerchantKey(dataFormatter.formatCellValue(cell));
				break;
				
			case 2:
				midBulkUpload.setMerchantCode(dataFormatter.formatCellValue(cell));
				break;
				
			case 3:
				midBulkUpload.setCodeNeed(dataFormatter.formatCellValue(cell));
				break;
				
			default:
				log.info("KeyBulkUploadBean default case for cell no : {} ", i);
			}
		}

		return midBulkUpload;

	}

	/**
	 * <strong>validateKeyBulkUpload(...)</strong> is responsible for
	 * iterating over the list of mid and then putting them into two separate
	 * list, on the basis of their success and failed validation status. <br>
	 * <br>
	 * 
	 * Here we are using two lists, i.e. successRecordList & failedRecordList for
	 * success and failed records. <br>
	 * 
	 * @param KeyBulkUploadBean     {@link List} of all the KeyBulkUploadBean.
	 * @param successRecordList 	{@link List} of all the success records.
	 * @param failedRecordList  	{@link List} of all the failed records.
	 * @return void
	 */
	private void validateKeyBulkUpload(List<KeyBulkUploadBean> midBulkUploadList, List<KeyBulkUploadBean> successRecordList,
			List<KeyBulkUploadBean> failedRecordList) {

		// LOOP OVER THE LIST OF MIDs
		for (KeyBulkUploadBean midBulkUpload : midBulkUploadList) {

			// VALIDATE THE BEAN
			merchantSpecificValidator.validateKeyBulkUpload(midBulkUpload);
			log.info("merchnatCode : {}, mid : {},  merchantKey : {}, codeNeeded : {}, status : {}, isValidate : {}", midBulkUpload.getMerchantCode(), midBulkUpload.getMid(), midBulkUpload.getMerchantKey(),midBulkUpload.getCodeNeed(), midBulkUpload.getStatus(), midBulkUpload.isValidate());
			// PUT THEM IN RESPECTIVE LIST.
			if (midBulkUpload.isValidate()) {
				successRecordList.add(midBulkUpload);
			} else {
				failedRecordList.add(midBulkUpload);
			}
		}
	}

	/**
	 * persistKeyBulkUpload(...) is responsible for getting the prefixName from
	 * {@link ModuleName} and then persist the program details into the database. We
	 * will get programCode after persisting a particular bean which is then set to
	 * the same record.
	 * 
	 * @param successRecordList
	 * @return void
	 */
	private void persistKeyBulkUpload(List<KeyBulkUploadBean> successRecordList) {

		for (KeyBulkUploadBean midBulkUpload : successRecordList) {
			
			dao.insertKeyBulkUploadData(midBulkUpload);
		}

	}
	
	/**
	 * {@link #writeKeyBulkUploadBeanListToExcel(List)} is responsible for for creating
	 * the excel with the response after processing the bulk upload excel
	 * file.
	 * 
	 * @param bulkUploadBeanList
	 * @return {@link Workbook}
	 */
	private Workbook writeKeyBulkUploadBeanListToExcel(List<KeyBulkUploadBean> bulkUploadBeanList) {

		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.KEY_BULK_UPLOAD);
		Sheet sheet = workbook.getSheetAt(0);

		log.info("midBulkUploadBeanList.size() : {} ",bulkUploadBeanList.size());
		
		if(bulkUploadBeanList.isEmpty())
		{
			KeyBulkUploadBean midBulkUploadTemp = new KeyBulkUploadBean();
			midBulkUploadTemp.setStatus(CommonConstants.NO_RECORD_IN_EXCEL.get());
			bulkUploadBeanList.add(midBulkUploadTemp);
		}
		
		
		
		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		for (KeyBulkUploadBean midBulkUpload : bulkUploadBeanList) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(midBulkUpload.getMid());
			row.createCell(1).setCellValue(midBulkUpload.getMerchantKey());
			row.createCell(2).setCellValue(midBulkUpload.getMerchantCode());
			row.createCell(3).setCellValue(midBulkUpload.getCodeNeed());
			row.createCell(4).setCellValue(midBulkUpload.getStatus());
		}
		excelService.autoSizeExcel(workbook);
		return workbook;

	}
	
}
