package com.mosambee.service;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

/**
 * This class provides specification for {@link EmiConversionUploadServiceImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 */
public interface EmiConversionUploadService {

	Resource processEmiConversionUploadExcel(MultipartFile file);
	Resource getEmiConversionUploadFormat();

}
