package com.mosambee.service.impl;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.mosambee.bean.SettlementBean;
import com.mosambee.bean.SettlementDataTableCrudBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.SettlementDao;
import com.mosambee.service.SettlementService;
import com.mosambee.transformer.SettlementTransformer;

/**
 * SettlementServiceImpl implements SettlementService. Basically used to load settlement data and 
 * process settlement initiation
 * 
 * @author rahul.mishra
 * @version 1.0
 * @since 28-February-2019
 */
@Service("settlementService")
public class SettlementServiceImpl implements SettlementService {
	
	@Autowired
	SettlementTransformer settlementTransformer;
	
	@Autowired
	SettlementDao settlementDao;
	
	@Value("${spring.application.settlementurl}")
	private String settlementUrl;
 
	private static final Logger log = LogManager.getLogger(SettlementServiceImpl.class);
	
	
	/**
	 * getSettlementList is used to get list of settlements from settlementDao and send to controller
	 * @param SettlementDataTableCrudBean 
	 * @return DataTablesResponse<UserBean>
	 */
	@Override
	public DataTablesResponse<SettlementBean> getSettlementList(SettlementDataTableCrudBean dtRequest){
		int orderingColumnIndex = dtRequest.getDtRequest().getOrder().get(0).getColumn();
		String orderingColumnName = getOrderingColumnName(orderingColumnIndex,dtRequest.getSettlementType());
		log.info("orderingColumnIndex: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);

		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ACTIVE PROGRAMS
		Map<String, String> searchMap = settlementTransformer.transformSettlementDataTableRequest(dtRequest);
		log.info("size of searchMap : {}", searchMap.size());
		return settlementDao.getSettlementList(dtRequest, orderingColumnName, searchMap);
	}
	
	/**
	 * getOrderingColumnName(...) method is responsible for returning
	 * orderingColumnName when it is provided with orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnName(int orderingColumnIndex,String settlementType) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = getColumn(settlementType);
			break;
		case 1:
			orderingColumnName = ColumnNames.SETTLEMENT_FIRSTNAME.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.SETTLEMENT_TYPE.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.SETTLEMENT_START_TIME.get();
			break;
		case 4:
			orderingColumnName = ColumnNames.SETTLEMENT_END_TIME.get();
			break;
		case 5:
			orderingColumnName = ColumnNames.SETTLEMENT_REASON.get();
			break;
		default:
			orderingColumnName = ColumnNames.SETTLEMENT_FIRSTNAME.get();
			break;
		}

		return orderingColumnName;
	}
	
	/**
	 * getColumn is used to get the column name of first column on search by using its settlement type
	 * @param settlementType
	 * @return
	 */
	public String getColumn(String settlementType) {
		String column;
		switch(settlementType) {
	     	case "merchant":
		    	column = "m.businessName";
			break;
	     	case "user":
		    	column = "mmut.userName";
			break;
	     	case "time":
		    	column = "msl.settleByTime";
			break;
	     	case "AutoSettle":
		    	column = "msl.settleByTime";
			break;
			default:
				column = "m.businessName";
			break;
			
		}
		
		return column;
	}
	
	/**
	 * settleTransactionByTime is async method to perform settlement of transactions
	 * @param final int time, final String reason
	 * 
	 */
	@Async
	public void settleTransactionByTime(final int time, final String reason,String createdBy) {
        log.info("settleTransactionByTime started time {} reason {}",time,reason);
		
		log.info("current user {} ",createdBy);
		log.info("calling createSettlement log ");
		
		long id = createSettlementLog(0, 0, time, createdBy, reason, "time");
		
		log.info("response from createSettlementLog id {}",id);
		log.info("calling getMMUTIDByTime Dao function");
		
		List<Long> mmutlist=  settlementDao.getMMUTIDByTime(time);
		
		log.info("getMMUTIDByTimeDao function  response {} ",mmutlist);
		
		for(long mmutID: mmutlist) {
			settleTransaction(mmutID);					
		}				
		updateSettlementLog(id);
	}
	
	/**
	 * createSettlementLog is used to create logs by calling settlementDao s createsettlementLog function 
	 * @param merchantId
	 * @param mmutId
	 * @param time
	 * @param userId
	 * @param reason
	 * @param settelementType
	 * @return
	 */
	public long createSettlementLog(long merchantId, long mmutId, int time, String userId, String reason, String settelementType) {
		return  settlementDao.createSettlementLog(merchantId, mmutId, time, userId,  reason,settelementType);		
	}
	
	/**
	 * updateSettlementLog is used to update the settlement by calling settlement dao function updateSettlementLog
	 * @param id
	 */
	public void updateSettlementLog(long id) {
		settlementDao.updateSettlementLog(id);
	}
    
	/**
	 * settleTransaction is used to call the settlement web service and post mmtuid 
	 * and give response back 
	 * @param long mutId
	 * @return String
	 */
	@Override
	public String settleTransaction(long mmutId) {
        
		RestTemplate restTemplate = new RestTemplate();
		
		String status = "SUCCESS";
		
		log.info("Settlement process initiated for mmutid {} ",mmutId);
		// create headers
	    HttpHeaders headers = new HttpHeaders();
	    // set `content-type` header
	    headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
	    // set `accept` header
	    
	    MultiValueMap<String, String> requestBody = new LinkedMultiValueMap<>();
	    requestBody.add("mmutId", "5843");

	    HttpEntity formEntity = new HttpEntity<MultiValueMap<String, String>>(requestBody, headers);
  
	    try {
		    // send POST request
	    	ResponseEntity<String> response = restTemplate.postForEntity(this.settlementUrl, formEntity, String.class);
	    
		    log.info("Settlement process response for mmutid {} response {}",mmutId,response.getBody());
		    
		    // check response status code
		    if (response.getStatusCode() == HttpStatus.OK) {
		        return status;
		    } else {
		        return response.getBody();
		    }
	    
        }catch(Exception e) {
	    	log.info("settleTransaction error occured {} ",e);
	    	return e.getMessage();
	    }
	    
	}
}
