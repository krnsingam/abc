package com.mosambee.service;

import java.util.Map;

import com.mosambee.bean.AdminAcquirerBean;
import com.mosambee.bean.AdminAcquirerDataTablesRequestBean;
import com.mosambee.bean.AdminAcquirerListBean;
import com.mosambee.bean.AdminAddAcquirerBean;
import com.mosambee.bean.EditAcquirerDetailsBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.service.impl.AdminAcquirerServiceImpl;

/**
 * AdminAcquirerService specification for {@link AdminAcquirerServiceImpl} class
 * 
 * @author mariam.siddique
 * @author saurabhkant.shukla
 * @version 1.0
 * @since 18-March-2020
 */
public interface AdminAcquirerService {
	
	DataTablesResponse<AdminAcquirerBean> getAdminAcquirerList(AdminAcquirerDataTablesRequestBean dtRequest);

	Map<Integer, String> getCurrencyList();

	String addNewAcquirer(AdminAddAcquirerBean bean, long userId);

	DataTablesResponse<AdminAcquirerListBean> getSiteAcquirerList(DataTablesRequest dtRequest);

	EditAcquirerDetailsBean getSiteAcquirerData(long acqId);

	String updateAcquirer(EditAcquirerDetailsBean updateBeanData, long acqId, long userId);   
	 
}
