package com.mosambee.service.impl;

import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.mosambee.bean.NetworkMessagesDataTablesRequestBean;
import com.mosambee.bean.NetworkMessagesDownloadBean;
import com.mosambee.bean.NetworkMessagesListBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.BulkUploadCategory;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.NetworkMessagesDao;
import com.mosambee.service.ExcelService;
import com.mosambee.service.NetworkMessagesService;
import com.mosambee.transformer.NetworkMessagesTransformer;
import com.mosambee.validator.CommonValidator;

import lombok.extern.log4j.Log4j2;

/**
 * NetworkMessagesServiceImpl class implementing {@link NetworkMessagesService}
 * specification.
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 27-March-2020
 */

@Log4j2
@Service("networkMessagesService")
public class NetworkMessagesServiceImpl implements NetworkMessagesService{

	@Autowired
	private NetworkMessagesDao dao;
	
	@Autowired
	private CommonValidator commonValidator;

	@Autowired
	private NetworkMessagesTransformer transformer;
	
	@Autowired
	private ExcelService excelService;
	
	/**
	 * getNetworkMessagesList(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request & then
	 * calling the DAO to get those values.
	 * 
	 * @param dtRequest {@link NetworkMessagesDataTablesRequestBean}
	 * @return DataTablesResponse of NetworkMessagesListBean
	 */
	@Override
	public DataTablesResponse<NetworkMessagesListBean> getNetworkMessagesList(NetworkMessagesDataTablesRequestBean dtRequest) {
		
		// getting column index
		int orderingColumnIndex = dtRequest.getDtRequest().getOrder().get(0).getColumn();
				
		//getting columnName based on column index
		String orderingColumnName = getOrderingColumnNameOfNetworkMessagesList(orderingColumnIndex);
		log.info("orderingColumnIndexs: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);
	
		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF NETWORK MESSAGES
		Map<String, String> map = transformer.transformNetworkMessagesRequest(dtRequest);
				
		// Setting up date format
		dtRequest.setFromDate(commonValidator.dateTimeValidator(map.get("networkMessagesFromDate")));
		dtRequest.setToDate(commonValidator.timeValidator(map.get("networkMessagesToDate")));
				
		return dao.getNetworkMessagesList(dtRequest, orderingColumnName, map);
				
	}
	
	/**
	 * getOrderingColumnNameOfNetworkMessagesList (...) method is responsible for returning
	 * orderingColumnName of NetworkMessagesListBean when it is provided with
	 * orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnNameOfNetworkMessagesList(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.NETWORK_MESSAGES_USERNAME.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.NETWORK_MESSAGES_TERMINALID.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.NETWORK_MESSAGES_PROCESSINGCODE.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.NETWORK_MESSAGES_MESSAGETYPE.get();
			break;
		case 4:
			orderingColumnName = ColumnNames.NETWORK_MESSAGES_RESPONSECODE.get();
			break;
		case 5:
			orderingColumnName = ColumnNames.NETWORK_MESSAGES_HSMRESPONSECODE.get();
			break;
		case 6:
			orderingColumnName = ColumnNames.NETWORK_MESSAGES_DATE.get();
			break;
		default:
			orderingColumnName = ColumnNames.NETWORK_MESSAGES_USERNAME.get();
			break;
		}

		return orderingColumnName;
	}

	@Override
	public Resource downloadNetworkMessagesList(NetworkMessagesDownloadBean bean) {
		
		Resource res = null;
		
		// Date-time check
		bean.setFromDate(commonValidator.dateTimeValidator(bean.getFromDate()));
		bean.setToDate(commonValidator.timeValidator(bean.getToDate()));

		// GET DOWNLOAD LIST FROM DAO LAYER
				List<NetworkMessagesDownloadBean> response = dao.downloadNetworkMessagesList(bean);
				if(response.isEmpty()) {
					return null;
				}
				res = process(response);

				return res;
	}
	
	/**
	 * process(...) method is responsible for returning Resource as workbook.
	 * 
	 * @param List<NetworkMessagesDownloadBean>
	 * @return Resource
	 */
	public Resource process(List<NetworkMessagesDownloadBean> responseBean) {

		// GET THE EXCEL WITH RESPONSE
		Workbook responseWorkbook = writeListToExcel(responseBean);

		return excelService.getResourceFromWorkbook(responseWorkbook);
	}

	/**
	 * writeListToExcel(...) method is responsible for returning Workbook as after
	 * parsing data for excel and seting it.
	 * 
	 * @param List<TransactionReportBean>
	 * @return Workbook
	 */
	private Workbook writeListToExcel(List<NetworkMessagesDownloadBean> responseBean) {
		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.NETWORK_MESSAGES);
		Sheet sheet = workbook.getSheetAt(0);

		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		int i = 1;
		String message = "";
		
		for (NetworkMessagesDownloadBean bean : responseBean) {
			
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(i++);
			row.createCell(1).setCellValue(bean.getUserName());
			row.createCell(2).setCellValue(bean.getTerminalId());
			row.createCell(3).setCellValue(bean.getProcessingCode());
			if(bean.getMessageType() == 1) {
				message = "TMK1 Download";
			}else if(bean.getMessageType() == 2) {
				message = "TMK2 Download";
			}else if(bean.getMessageType() == 3) {
				message = "Logon";
			}else if(bean.getMessageType() == 4) {
				message = "Initialization";
			}else {
				message = "";
			}			
			row.createCell(4).setCellValue(message);
			row.createCell(5).setCellValue(bean.getResponseCode());
			row.createCell(6).setCellValue(bean.getHsmResponseCode());
			row.createCell(7).setCellValue(bean.getDate());
			}
		excelService.autoSizeExcel(workbook);
		return workbook;
	}

}