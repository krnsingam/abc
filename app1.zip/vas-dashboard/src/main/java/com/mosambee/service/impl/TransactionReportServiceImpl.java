package com.mosambee.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.mosambee.bean.AcquirerBean;
import com.mosambee.bean.EmailBean;
import com.mosambee.bean.TransactionDateReportBean;
import com.mosambee.bean.TransactionReportBean;
import com.mosambee.bean.TransactionSearchFormBean;
import com.mosambee.bean.TransactionSearchFormDataTableBean;
import com.mosambee.bean.TransactionSearchReportBean;
import com.mosambee.bean.TransactionTypeBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.BulkUploadCategory;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.TransactionReportDao;
import com.mosambee.service.EmailService;
import com.mosambee.service.ExcelService;
import com.mosambee.service.TransactionReportService;
import com.mosambee.transformer.TransactionReportTransformer;
import com.mosambee.util.SendSMSUtil;
import com.mosambee.validator.CommonValidator;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

/**
 * TransactionReportServiceImpl class implementing {@link ProductService}
 * specification.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 10-January-2020
 */
@Service(value = "transactionReportService")
public class TransactionReportServiceImpl implements TransactionReportService {

	@Autowired
	TransactionReportDao dao;

	@Autowired
	ExcelService excelService;

	@Autowired
	TransactionReportTransformer transformer;

	@Autowired
	CommonValidator commonValidator;

	@Autowired
	private EmailService emailService;

	@Autowired
	private TemplateEngine templateEngine;
	
	@Autowired
	private SendSMSUtil sendSMSUtil;

	private static final Logger log = LogManager.getLogger(TransactionReportServiceImpl.class);

	private static final String PAYBYLINK = "paybylink";
	private static final String WALLET = "wallet";
	private static final String CHEQUE = "cheque";
	private static final String CASH = "cash";
	private static final String UPI = "upi";
	private static final String DECLINED = "Declined";
	private static final String CASHABCK = "CashBack";
	private static final String TXN_TYPE = "Txn Type";
	private static final String AUTH_CODE = "Auth Code";
	private static final String CARD_TYPE = "Card Type";
	private static final String CARD_TXN_TYPE = "Card Txn Type";
	private static final String RRN = "RRN    ";
	private static final String INVOICE = "Invoice#";
	private static final String DEVICE_SERIAL = "Device Serial";
	private static final String STATUS = "Status";
	private static final String SETTLED_ON = "Settled On";
	private static final String LABEL = "Label";
	private static final String BATCH = "Batch#";
	private static final String REFERENCE = "Reference#";
	private static final String REF_2 = "Ref# 2#";
	private static final String REF_3 = "Ref# 3#";
	private static final String REF_4 = "Ref# 4#";
	private static final String REF_5 = "Ref# 5#";
	private static final String CHEQUE_NO = "Cheque No";
	private static final String BANK_CODE = "Bank Code";
	private static final String RECEIPT_NO = "Receipt No";
	private static final String ADDITIONAL_INFO = "Additional Information";
	private static final String TID_LOCATION = "TID Location";
	private static final String DX_MODE = "DX Mode";
	private static final String CHEQUE_DATE = "Cheque Date";
	private static final String TXN_STATUS = "Transaction Status";
	private static final String ME_NAME = "ME Name";
	private static final String ACQUIRER = "Acquirer";
	private static final String REFUND = "Refund";
	private static final String PAY_BY_LINK = "PayByLink";
	private static final String CHQUE = "Cheque";
	private static final String PATH_DELIMETER = "/";

	/**
	 * getActiveTransactionList(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request & then
	 * calling the DAO to get those values.
	 * 
	 * @param dtRequest
	 *            {@link DataTablesRequest}
	 * @return DataTablesResponse of TransactionReportBean
	 */
	public DataTablesResponse<TransactionReportBean> getActiveTransactionList(TransactionDateReportBean dtRequest) {

		// GET THE COLUMN NAME FROM COLUMN INDEX
		int orderingColumnIndex = dtRequest.getDataTable().getOrder().get(0).getColumn();
		String orderingColumnName = getOrderingColumnName(orderingColumnIndex);
		log.info("orderingColumnIndex: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);

		// Setting up date format
		dtRequest.setFromDate(commonValidator.dateTimeValidator(dtRequest.getFromDate()));
		dtRequest.setToDate(commonValidator.timeValidator(dtRequest.getToDate()));

		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ACTIVE TRANSACTION
		Map<String, String> searchMap = transformer.transformTransactionReportDataTableRequest(dtRequest);
		log.info("size of searchMap: {}", searchMap.size());

		return dao.getActiveTransactionReport(dtRequest, orderingColumnName, searchMap);
	}

	/**
	 * getOrderingColumnName(...) method is responsible for returning
	 * orderingColumnName when it is provided with orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnName(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.TRANSACTION_ENQUIRYID.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.TRANSACTION_REFERENCE_NO.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.TRANSACTION_AUTH_CODE.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.TRANSACTION_RRN.get();
			break;
		case 4:
			orderingColumnName = ColumnNames.TRANSACTION_TXN_AMOUNT.get();
			break;
		case 5:
			orderingColumnName = ColumnNames.TRANSACTION_BIN_VALUE.get();
			break;
		case 6:
			orderingColumnName = ColumnNames.TRANSACTION_CARD_TYPE.get();
			break;
		case 7:
			orderingColumnName = ColumnNames.TRANSACTION_ISSUER.get();
			break;
		case 8:
			orderingColumnName = ColumnNames.TRANSACTION_STATUS.get();
			break;
		case 9:
			orderingColumnName = ColumnNames.TRANSACTION_TIME.get();
			break;
		case 10:
			orderingColumnName = ColumnNames.TRANSACTION_EMICONVERTED.get();
			break;

		default:
			orderingColumnName = ColumnNames.TRANSACTION_ID.get();
			break;
		}

		return orderingColumnName;
	}

	/**
	 * downloadActiveTransactionReportList(...) method is responsible for returning
	 * Resource in byte stream for download. Used for downloading all the
	 * transaction for Report.
	 * 
	 * @param DataTablesRequest
	 * @return Resource
	 */
	@Override
	public Resource downloadActiveTransactionReportList(TransactionReportBean report) {

		Resource res = null;

		// Date-time check
		report.setFromDate(commonValidator.dateTimeValidator(report.getFromDate()));
		report.setToDate(commonValidator.timeValidator(report.getToDate()));
		// GET DOWNLOAD LIST FROM DAO LAYER
		List<TransactionReportBean> response = dao.downloadActiveTransactionReportList(report);
		if(response.isEmpty()) {
			return null;
		}
		res = process(response);

		return res;

	}

	/**
	 * process(...) method is responsible for returning Resource as workbook.
	 * 
	 * @param List<TransactionReportBean>
	 * @return Resource
	 */
	public Resource process(List<TransactionReportBean> responseBean) {

		// GET THE EXCEL WITH RESPONSE
		Workbook responseWorkbook = writeListToExcel(responseBean);

		return excelService.getResourceFromWorkbook(responseWorkbook);
	}

	/**
	 * writeListToExcel(...) method is responsible for returning Workbook as after
	 * parsing data for excel and seting it.
	 * 
	 * @param List<TransactionReportBean>
	 * @return Workbook
	 */
	private Workbook writeListToExcel(List<TransactionReportBean> responseBean) {
		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.TRANSACTION_REPORT);
		Sheet sheet = workbook.getSheetAt(0);

		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		int i = 1;
		for (TransactionReportBean bean : responseBean) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(i++);
			row.createCell(1).setCellValue(bean.getEnquiryId());
			row.createCell(2).setCellValue(bean.getTxnRefNo());
			row.createCell(3).setCellValue(bean.getAuthCode());
			row.createCell(4).setCellValue(bean.getRrn());
			row.createCell(5).setCellValue(bean.getTxnAmount());
			row.createCell(6).setCellValue(bean.getEmiAmount());
			row.createCell(7).setCellValue(bean.getInterestRate());
			row.createCell(8).setCellValue(bean.getTenure());
			row.createCell(9).setCellValue(bean.getBinValue());
			row.createCell(10).setCellValue(bean.getCardType());
			row.createCell(11).setCellValue(bean.getIssuer());
			row.createCell(12).setCellValue(bean.getTxnTime());
			row.createCell(13).setCellValue(bean.getStatus());
			row.createCell(14).setCellValue(bean.getEmiConverted());
			row.createCell(15).setCellValue(bean.getComment());
		}
		excelService.autoSizeExcel(workbook);
		return workbook;
	}

	public TransactionReportBean getActiveTransaction(int id) {
		return dao.getActiveTransaction(id);
	}

	/**
	 * getListOfTrxnType function returns list of all txn types
	 * 
	 * @return List<TransactionTypeBean>
	 */
	@Override
	public List<TransactionTypeBean> getListOfTrxnType() {
		return dao.getListOfTrxnType();
	}

	/**
	 * getListOfAcquirer function returns list of all acquirers
	 * 
	 * @return List<TransactionTypeBean>
	 */
	@Override
	public List<AcquirerBean> getListOfAcquirer() {
		return dao.getListOfAcquirer();
	}

	/**
	 * getCountOfTransactions calls all counts of transaction data from
	 * transactionReport Dao
	 * 
	 * @param transactionSearchFormBean
	 * @return List<TransactionSearchReportBean>
	 */
	@Override
	public List<TransactionSearchReportBean> getCountOfTransactions(
			TransactionSearchFormBean transactionSearchFormBean) {
		return dao.getCountOfTransactions(transactionSearchFormBean);
	}

	/**
	 * getTransactionListData is used to get TransactionListData from dao layer
	 * 
	 * @param TransactionSearchFormDataTableBean
	 * @return DataTablesResponse<TransactionSearchReportBean>
	 */
	@Override
	public DataTablesResponse<TransactionSearchReportBean> getTransactionListData(
			TransactionSearchFormDataTableBean dtRequest) {
		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF TRANSACTIONS

		int orderingColumnIndex = dtRequest.getDtRequest().getOrder().get(0).getColumn();
		String orderingColumnName = getOrderingColumnNameForTransaxtionList(orderingColumnIndex);
		log.info("dtRequest : {}", dtRequest);
		Map<String, String> searchMap = transformer.transformTransactionListDataTableRequest(dtRequest);

		log.info("size of searchMap : {} {}", searchMap.size(),searchMap);
		return dao.getTransactionListData(dtRequest, orderingColumnName, searchMap);
	}

	/**
	 * getTransById is used to get transaction data by id
	 * 
	 * @param long
	 *            tranId
	 * @return TransactionSearchReportBean
	 */
	@Override
	public TransactionSearchReportBean getTransById(long tranId) {
		return dao.getTransById(tranId);
	}

	/**
	 * getListOfMerchantName is used to get list pf merchant name from dao layer
	 * 
	 * @param String
	 *            name
	 * @return List<String>
	 */
	@Override
	public List<String> getListOfMerchantName(String name) {
		return dao.getListOfMerchantName(name);
	}

	/**
	 * getOrderingColumnNameForTransaxtionList(...) method is responsible for
	 * returning orderingColumnName when it is provided with orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnNameForTransaxtionList(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.TXN_LIST_TXN_ID.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.TXN_LIST_TXN_TYPE.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.TXN_LIST_TID.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.TXN_LIST_USER_ID.get();
			break;
		case 4:
			orderingColumnName = ColumnNames.TXN_LIST_CARD_NUMBER.get();
			break;
		case 5:
			orderingColumnName = ColumnNames.TXN_LIST_RRN.get();
			break;
		case 6:
			orderingColumnName = ColumnNames.TXN_LIST_AMT.get();
			break;
		case 7:
			orderingColumnName = ColumnNames.TXN_LIST_DATE_FROM.get();
			break;
		case 8:
			orderingColumnName = ColumnNames.TXN_LIST_DATE_FROM.get();
			break;
		case 9:
			orderingColumnName = ColumnNames.TXN_LIST_REASON.get();
			break;
		case 10:
			orderingColumnName = ColumnNames.TXN_LIST_AUTOCODE.get();
			break;
		case 11:
			orderingColumnName = ColumnNames.TXN_LIST_REASON.get();
			break;
		case 12:
			orderingColumnName = ColumnNames.TXN_SETTLEMENT_STATUS.get();
			break;
		default:
			orderingColumnName = ColumnNames.TXN_LIST_USER_ID.get();
			break;
		}

		return orderingColumnName;
	}

	/**
	 * getTransactionSearchListExcelData is used to get excel list data from dao
	 * layer
	 * 
	 * @param TransactionSearchFormBean
	 * @return List<Map<Integer, String>>
	 */
	@Override
	public List<Map<Integer, String>> getTransactionSearchListExcelData(
			TransactionSearchFormBean transactionSearchFormBean) {
		
		return dao.getTransactionSearchListExcel(transactionSearchFormBean);
	}

	/**
	 * getTransactionSearchListExcel is used to convert transactionSearchFormBean
	 * data into excel
	 * 
	 * @param List<Map<Integer,String>>
	 *            list,TransactionSearchFormBean transactionSearchFormBean
	 * @return HSSFWorkbook
	 */
	@Override
	public HSSFWorkbook getTransactionSearchListExcel(List<Map<Integer, String>> list,
			TransactionSearchFormBean transactionSearchFormBean) {

		HSSFWorkbook hwb = new HSSFWorkbook();
		int index = 0;

		if (!list.isEmpty()) {
			if (!transactionSearchFormBean.getTxnType().get(0).equals("15")) {
				HSSFSheet sheet1 = hwb.createSheet("sheet1");
				HSSFRow rowhead = sheet1.createRow(0);

				rowhead.createCell(0).setCellValue("ID               ");
				rowhead.createCell(1).setCellValue("Date    ");
				rowhead.createCell(2).setCellValue("Mobile    ");
				rowhead.createCell(3).setCellValue("Email                   ");
				rowhead.createCell(4).setCellValue("User        ");
				rowhead.createCell(5).setCellValue("Username   ");
				rowhead.createCell(6).setCellValue("Type  ");
				rowhead.createCell(7).setCellValue("Mode  ");
				rowhead.createCell(8).setCellValue("Amount   ");
				rowhead.createCell(9).setCellValue("Tip ");
				rowhead.createCell(10).setCellValue(CASHABCK);
				rowhead.createCell(11).setCellValue(TXN_TYPE);
				rowhead.createCell(12).setCellValue(AUTH_CODE);
				rowhead.createCell(13).setCellValue("Card               ");
				rowhead.createCell(14).setCellValue(CARD_TYPE);
				rowhead.createCell(15).setCellValue("Brand Type  ");
				rowhead.createCell(16).setCellValue(CARD_TXN_TYPE);
				rowhead.createCell(17).setCellValue(RRN);
				rowhead.createCell(18).setCellValue(INVOICE);
				rowhead.createCell(19).setCellValue(DEVICE_SERIAL);
				rowhead.createCell(20).setCellValue(STATUS);
				rowhead.createCell(21).setCellValue(SETTLED_ON);
				rowhead.createCell(22).setCellValue(LABEL);
				rowhead.createCell(23).setCellValue("MID             ");
				rowhead.createCell(24).setCellValue("TID       ");
				rowhead.createCell(25).setCellValue(BATCH);
				rowhead.createCell(26).setCellValue(REFERENCE);
				rowhead.createCell(27).setCellValue(REF_2);
				rowhead.createCell(28).setCellValue(REF_3);
				rowhead.createCell(29).setCellValue(REF_4);
				rowhead.createCell(30).setCellValue(REF_5);
				rowhead.createCell(31).setCellValue(CHEQUE_NO);
				rowhead.createCell(32).setCellValue(BANK_CODE);
				rowhead.createCell(33).setCellValue(RECEIPT_NO);
				rowhead.createCell(34).setCellValue(ADDITIONAL_INFO);
				rowhead.createCell(35).setCellValue("Latitude       ");
				rowhead.createCell(36).setCellValue("Longitude      ");
				rowhead.createCell(37).setCellValue("Payer       ");
				rowhead.createCell(38).setCellValue(TID_LOCATION);
				rowhead.createCell(39).setCellValue(DX_MODE);
				rowhead.createCell(40).setCellValue(CHEQUE_DATE);
				rowhead.createCell(41).setCellValue("Time    ");
				rowhead.createCell(42).setCellValue(TXN_STATUS);
				rowhead.createCell(43).setCellValue(ME_NAME);
				rowhead.createCell(44).setCellValue(ACQUIRER);

				for (int i = 0; i < list.size(); i++) {
					Map<Integer, String> map = list.get(i);

					if (!"EMI".equalsIgnoreCase(map.get(8))) {
						HSSFRow row = sheet1.createRow(index + 1);
						double amount = getConditionalAmount(map);

						row.createCell(0).setCellValue(map.get(1));
						row.createCell(1).setCellValue(map.get(2));
						row.createCell(2).setCellValue(map.get(4));
						row.createCell(3).setCellValue(map.get(5));
						row.createCell(4).setCellValue(map.get(6));
						row.createCell(5).setCellValue(map.get(7));
						row.createCell(6).setCellValue(map.get(8));

						String txnType = (map.get(8));
						row = getConditionalDataForTypeFifteen(row, txnType, transactionSearchFormBean, map, amount);

						row.createCell(10).setCellValue("0");
						row.createCell(11).setCellValue(map.get(8));
						row.createCell(12).setCellValue(map.get(12));
						row.createCell(13).setCellValue(map.get(13));
						row.createCell(14).setCellValue(map.get(32));
						row.createCell(15).setCellValue(map.get(14));
						row.createCell(16).setCellValue(map.get(15));
						row.createCell(17).setCellValue(map.get(16));
						row.createCell(18).setCellValue(map.get(17));
						row.createCell(19).setCellValue(map.get(18));
						row.createCell(20).setCellValue(map.get(19));
						row.createCell(21).setCellValue(map.get(20));
						row.createCell(22).setCellValue(map.get(29));
						row.createCell(23).setCellValue(map.get(21));
						row.createCell(24).setCellValue(map.get(22));
						row.createCell(25).setCellValue(map.get(23));
						row.createCell(26).setCellValue(map.get(28));
						row.createCell(27).setCellValue("N/A");
						row.createCell(28).setCellValue("N/A");
						row.createCell(29).setCellValue("N/A");
						row.createCell(30).setCellValue("N/A");
						row.createCell(31).setCellValue("N/A");
						row.createCell(32).setCellValue("N/A");
						row.createCell(33).setCellValue("N/A");
						row.createCell(34).setCellValue(map.get(24));
						row.createCell(35).setCellValue(map.get(25));
						row.createCell(36).setCellValue(map.get(26));
						row.createCell(37).setCellValue(map.get(27));
						row.createCell(38).setCellValue(map.get(29));
						row.createCell(39).setCellValue("N/A");
						row.createCell(40).setCellValue("N/A");
						row.createCell(41).setCellValue(map.get(3));
						row.createCell(42).setCellValue(map.get(11));
						row.createCell(43).setCellValue(map.get(30));
						row.createCell(44).setCellValue(map.get(31));

						index++;
					}
				}
			}

			if (transactionSearchFormBean.getTxnType().get(0).equals("All")
					|| transactionSearchFormBean.getTxnType().get(0).equals("20")
					|| transactionSearchFormBean.getTxnType().get(0).equals("15")
					|| transactionSearchFormBean.getTxnType().get(0).equals("0")
					|| DECLINED.equalsIgnoreCase(transactionSearchFormBean.getTxnType().get(0))
					|| "3".equalsIgnoreCase(transactionSearchFormBean.getTxnType().get(0))) {
				index = 0;
				HSSFSheet sheet2 = hwb.createSheet("sheet2");
				HSSFRow rowhead = sheet2.createRow(0);

				rowhead.createCell(0).setCellValue("ID               ");
				rowhead.createCell(1).setCellValue("Date    ");
				rowhead.createCell(2).setCellValue("Mobile    ");
				rowhead.createCell(3).setCellValue("Email                   ");
				rowhead.createCell(4).setCellValue("User        ");
				rowhead.createCell(5).setCellValue("Username   ");
				rowhead.createCell(6).setCellValue("Type  ");
				rowhead.createCell(7).setCellValue("Mode  ");
				rowhead.createCell(8).setCellValue("Amount   ");
				rowhead.createCell(9).setCellValue("Tip ");
				rowhead.createCell(10).setCellValue(CASHABCK);
				rowhead.createCell(11).setCellValue(TXN_TYPE);
				rowhead.createCell(12).setCellValue(AUTH_CODE);
				rowhead.createCell(13).setCellValue("Card               ");
				rowhead.createCell(14).setCellValue(CARD_TYPE);
				rowhead.createCell(15).setCellValue("Brand Type  ");
				rowhead.createCell(16).setCellValue(CARD_TXN_TYPE);
				rowhead.createCell(17).setCellValue(RRN);
				rowhead.createCell(18).setCellValue(INVOICE);
				rowhead.createCell(19).setCellValue(DEVICE_SERIAL);
				rowhead.createCell(20).setCellValue(STATUS);
				rowhead.createCell(21).setCellValue(SETTLED_ON);
				rowhead.createCell(22).setCellValue(LABEL);
				rowhead.createCell(23).setCellValue("MID             ");
				rowhead.createCell(24).setCellValue("TID       ");
				rowhead.createCell(25).setCellValue(BATCH);
				rowhead.createCell(26).setCellValue(REFERENCE);
				rowhead.createCell(27).setCellValue(REF_2);
				rowhead.createCell(28).setCellValue(REF_3);
				rowhead.createCell(29).setCellValue(REF_4);
				rowhead.createCell(30).setCellValue(REF_5);
				rowhead.createCell(31).setCellValue(CHEQUE_NO);
				rowhead.createCell(32).setCellValue(BANK_CODE);
				rowhead.createCell(33).setCellValue(RECEIPT_NO);
				rowhead.createCell(34).setCellValue(ADDITIONAL_INFO);
				rowhead.createCell(35).setCellValue("Latitude       ");
				rowhead.createCell(36).setCellValue("Longitude      ");
				rowhead.createCell(37).setCellValue("Payer       ");
				rowhead.createCell(38).setCellValue(TID_LOCATION);
				rowhead.createCell(39).setCellValue(DX_MODE);
				rowhead.createCell(40).setCellValue(CHEQUE_DATE);
				rowhead.createCell(41).setCellValue("Time    ");
				rowhead.createCell(42).setCellValue(TXN_STATUS);
				rowhead.createCell(43).setCellValue(ME_NAME);
				rowhead.createCell(44).setCellValue(ACQUIRER);
				rowhead.createCell(45).setCellValue("Tenure");
				rowhead.createCell(46).setCellValue("EMI Amount");
				rowhead.createCell(47).setCellValue("ROI");
				rowhead.createCell(48).setCellValue("Total Amount With Interest");
				rowhead.createCell(49).setCellValue("Cashback percentage");
				rowhead.createCell(50).setCellValue("Cashback Amount");
				rowhead.createCell(51).setCellValue("Processing Fee");
				rowhead.createCell(52).setCellValue("Total Effective Cost");
				rowhead.createCell(53).setCellValue("Auth Amount");
				rowhead.createCell(54).setCellValue("Debit EMI Amount");

				getConditionalRowDataForTxnTypeAll(sheet2, list, index);
			}
		}

		return hwb;

	}

	/**
	 * getConditionalRowDataForTxnTypeAll is used to set HSSFSheet sheet data on
	 * bases of conditions provide
	 * 
	 * @param sheet2
	 * @param list
	 * @param index
	 */
	public void getConditionalRowDataForTxnTypeAll(HSSFSheet sheet2, List<Map<Integer, String>> list, int index) {
		for (int i = 0; i < list.size(); i++) {
			Map<Integer, String> map = list.get(i);

			if ("EMI".equalsIgnoreCase(map.get(8))) {
				HSSFRow row = sheet2.createRow(index + 1);
				double amount = getConditionalAmount(map);

				row.createCell(0).setCellValue(map.get(1));
				row.createCell(1).setCellValue(map.get(2));
				row.createCell(2).setCellValue(map.get(4));
				row.createCell(3).setCellValue(map.get(5));
				row.createCell(4).setCellValue(map.get(6));
				row.createCell(5).setCellValue(map.get(7));
				row.createCell(6).setCellValue(map.get(8));

				String txnType = (map.get(8));
				if (txnType == null
						|| (!txnType.equals("Cash") && !txnType.equals(CHEQUE) && !txnType.equals(PAY_BY_LINK)))
					row.createCell(7).setCellValue("CARD");
				else
					row.createCell(7).setCellValue(txnType);

				row.createCell(8).setCellValue(amount);
				row.createCell(9).setCellValue(map.get(10));
				row.createCell(10).setCellValue("0");
				row.createCell(11).setCellValue(map.get(8));
				row.createCell(12).setCellValue(map.get(12));
				row.createCell(13).setCellValue(map.get(13));
				row.createCell(14).setCellValue(map.get(32));
				row.createCell(15).setCellValue(map.get(14));
				row.createCell(16).setCellValue(map.get(15));
				row.createCell(17).setCellValue(map.get(16));
				row.createCell(18).setCellValue(map.get(17));
				row.createCell(19).setCellValue(map.get(18));
				row.createCell(20).setCellValue(map.get(19));
				row.createCell(21).setCellValue(map.get(20));
				row.createCell(22).setCellValue(map.get(29));
				row.createCell(23).setCellValue(map.get(21));
				row.createCell(24).setCellValue(map.get(22));
				row.createCell(25).setCellValue(map.get(23));
				row.createCell(26).setCellValue(map.get(28));
				row.createCell(27).setCellValue("N/A");
				row.createCell(28).setCellValue("N/A");
				row.createCell(29).setCellValue("N/A");
				row.createCell(30).setCellValue("N/A");
				row.createCell(31).setCellValue("N/A");
				row.createCell(32).setCellValue("N/A");
				row.createCell(33).setCellValue("N/A");
				row.createCell(34).setCellValue(map.get(24));
				row.createCell(35).setCellValue(map.get(25));
				row.createCell(36).setCellValue(map.get(26));
				row.createCell(37).setCellValue(map.get(27));
				row.createCell(38).setCellValue(map.get(29));
				row.createCell(39).setCellValue("N/A");
				row.createCell(40).setCellValue("N/A");
				row.createCell(41).setCellValue(map.get(3));
				row.createCell(42).setCellValue(map.get(11));
				row.createCell(43).setCellValue(map.get(30));
				row.createCell(44).setCellValue(map.get(31));
				row.createCell(45).setCellValue(map.get(33));
				row.createCell(46).setCellValue(map.get(34));
				row.createCell(47).setCellValue(map.get(35));
				row.createCell(48).setCellValue(map.get(36));
				row.createCell(49).setCellValue(map.get(37));
				row.createCell(50).setCellValue(map.get(38));
				row.createCell(51).setCellValue(map.get(39));
				row.createCell(52).setCellValue(map.get(40));
				row.createCell(53).setCellValue(map.get(41));
				row.createCell(54).setCellValue(map.get(42));
				index++;
			}
		}

	}

	/**
	 * getConditionalAmount return amount on based on conditions provide
	 * 
	 * @param map
	 * @return
	 */
	public double getConditionalAmount(Map<Integer, String> map) {
		double amount = 0;
		if (map.get(9) != null) {
			amount = new Double((map.get(9)));
		}

		String txnType = (map.get(8));
		if (txnType != null && txnType.equals(REFUND))
			amount = amount * -1;

		return amount;

	}

	/**
	 * getConditionalDataForTypeFifteen sets data of excel on different different
	 * conditions provide
	 * 
	 * @param row
	 * @param txnType
	 * @param transactionSearchFormBean
	 * @param map
	 * @param amount
	 * @return
	 */
	public HSSFRow getConditionalDataForTypeFifteen(HSSFRow row, String txnType,
			TransactionSearchFormBean transactionSearchFormBean, Map<Integer, String> map, double amount) {
		if (txnType == null || (!txnType.equals("Cash") && !txnType.equals(CHQUE) && !txnType.equals(PAY_BY_LINK)))
			row.createCell(7).setCellValue("CARD");
		else
			row.createCell(7).setCellValue(txnType);

		if (transactionSearchFormBean.getTxnType().get(0).equals("27")) {
			double tip = 0;
			String chkTipAmt = map.get(10);

			if (null != chkTipAmt && !(chkTipAmt.isEmpty())) {
				tip = new Double(map.get(10));
				row.createCell(8).setCellValue(amount - tip);
			} else {
				row.createCell(8).setCellValue(amount);
			}
			row.createCell(9).setCellValue(map.get(10));
		} else {
			row.createCell(8).setCellValue(amount);
			row.createCell(9).setCellValue(map.get(10));
		}

		return row;

	}

	/**
	 * getResourceFromWorkbook converts workbook data into resource
	 * 
	 * @param HSSFWorkbook
	 *            responseWorkbook
	 * @return resource
	 */
	@Override
	public Resource getResourceFromWorkbook(HSSFWorkbook responseWorkbook) {
		try {
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			responseWorkbook.write(byteArrayOutputStream);
			ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
			return new InputStreamResource(byteArrayInputStream);
		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}

	/**
	 * getResourceFromCSV converts csv file into resource
	 * 
	 * @param File
	 * @return Resource
	 */
	@Override
	public Resource getResourceFromCSV(File file) {
		try {
			FileInputStream fin = new FileInputStream(file);
			return new InputStreamResource(fin);
		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}

	/**
	 * sendTransactionSMS sends transaction sms containg transaction info
	 * 
	 * @param long
	 *            transactionId,String mobile
	 * @return boolean
	 */
	@Override
	public boolean sendTransactionSMS(long transactionId, String mobile) {
		DecimalFormat df = new DecimalFormat("#0.00");

		TransactionSearchReportBean transactionForm = dao.getTransById(transactionId);
		String aquirerNameImagePath = "images/" + transactionForm.getAcuirerName() + ".png";
		log.info("aquirerNameImagePath: {}", aquirerNameImagePath);

		if (mobile != null) {
			StringBuilder message = new StringBuilder();
			message.append("\nThank you for using Mosambee. ");
			message.append(transactionForm.getType());
			message.append(" made at: ").append(transactionForm.getBusinessName());
			message.append(" is ").append(getTransactionStatus(transactionForm.getStatus()));

			if ("TIP ADJUST".equals(transactionForm.getType())) {
				message.append(" on " + transactionForm.getCurrencyCode() + ". ")
						.append(df.format(transactionForm.getAmount()));
				message.append(" of Tip Amt: " + transactionForm.getCurrencyCode() + ". ")
						.append(df.format(NumberUtils.toDouble(transactionForm.getTipAmt())));
			} else {
				message.append(" of " + transactionForm.getCurrencyCode() + ". ")
						.append(df.format(transactionForm.getAmount()));
			}

			String txnType = transactionForm.getType();

			message = setMessageConditions(transactionForm, message, txnType);

			log.info("SMS Message {} mobile {} ", message, mobile);

			sendSMSUtil.sendSms(mobile, message.toString());

			return true;

		}

		return false;
	}

	/**
	 * setMessageConditions sets sms message based on conditions provide
	 * 
	 * @param transactionForm
	 * @param message
	 * @param txnType
	 * @return StringBuilder
	 */
	public StringBuilder setMessageConditions(TransactionSearchReportBean transactionForm, StringBuilder message,
			String txnType) {

		if (!(CASH.equalsIgnoreCase(txnType) || CHEQUE.equalsIgnoreCase(txnType) || WALLET.equalsIgnoreCase(txnType)
				|| PAYBYLINK.equalsIgnoreCase(txnType) || UPI.equalsIgnoreCase(txnType))) {
			message.append(" Card No: ").append(
					(StringUtils.isNotBlank(transactionForm.getCardNumber()) ? transactionForm.getCardNumber() : "NA"));
			message.append(" Ref No: ")
					.append((StringUtils.isNotBlank(transactionForm.getRrn()) ? transactionForm.getRrn() : "NA"));
			message.append(" Auth code: ").append(
					(StringUtils.isNotBlank(transactionForm.getAuthCode()) ? transactionForm.getAuthCode() : "NA"));
		}

		if (CHEQUE.equalsIgnoreCase(txnType)) {
			message.append(" Cheque No: ").append(
					(StringUtils.isNotBlank(transactionForm.getCardNumber()) ? transactionForm.getCardNumber() : "NA"));
		}

		if (StringUtils.isNotBlank(transactionForm.getTxnDate())) {
			message.append(" at ").append(transactionForm.getTxnDate());

			if (StringUtils.isNotBlank(transactionForm.getTime())) {
				message.append(" ").append(transactionForm.getTime());
			}
		}

		return message;
	}

	/**
	 * processBillNumber process billNumber data
	 * 
	 * @param billNumber
	 * @return Map<String, String>
	 */
	public Map<String, String> processBillNumber(String billNumber) {

		Map<String, String> vals = new LinkedHashMap<>();

		if (billNumber != null) {

			String[] arr = billNumber.split("\\:");

			for (String val : arr) {

				String[] keyValue = val.split("=");

				if (keyValue.length == 2) {
					vals.put(keyValue[0], keyValue[1]);
				}
			}
		}

		return vals;
	}

	/**
	 * getTransactionStatus is used to get transaction status based on condition
	 * 
	 * @param status
	 * @return String
	 */
	public String getTransactionStatus(String status) {
		String txnStatus;
		switch (status) {
		case "1":
			txnStatus = DECLINED;
			break;
		case "2":
			txnStatus = "Approved";
			break;
		case "3":
			txnStatus = DECLINED;
			break;
		case "4":
			txnStatus = "Undersettlement";
			break;
		case "5":
			txnStatus = "Settled";
			break;
		case "6":
			txnStatus = "Settlement Failed";
			break;
		case "7":
			txnStatus = "Signature Pending";
			break;
		case "8":
			txnStatus = "Reversed";
			break;
		case "9":
			txnStatus = "Reversal";
			break;
		default:
			txnStatus = "NA";
		}
		return txnStatus;
	}

	/**
	 * getTransactionCSV converts list data into csv file
	 * 
	 * @param List<Map<Integer,
	 *            String>> list
	 * @return File
	 */
	@Override
	public Resource getTransactionCSV(List<Map<Integer, String>> list) {
		
		if(list.isEmpty()) {
			return null;
		}
		
		File file = null;
		Resource resource = null;

		String newLineSeparator = "\n";

		final Object[] fileHeader = { "ID ", "Date", "Mobile", "Email", "User", "Username", "Type", "Mode", "Amount",
				"Tip", CASHABCK, TXN_TYPE, AUTH_CODE, "Card", CARD_TYPE, "Brand Type", CARD_TXN_TYPE, "RRN", INVOICE,
				DEVICE_SERIAL, STATUS, SETTLED_ON, LABEL, "MID", "TID", BATCH, REFERENCE, REF_2, REF_3, REF_4, REF_5,
				CHEQUE_NO, BANK_CODE, RECEIPT_NO, ADDITIONAL_INFO, "Latitude", "Longitude", "Payer", TID_LOCATION,
				DX_MODE, CHEQUE_DATE, "Time", TXN_STATUS, ME_NAME, ACQUIRER };

		CSVFormat csvFileFormat = CSVFormat.EXCEL.withRecordSeparator(newLineSeparator);

		String tempDir = System.getProperty("java.io.tmpdir");
		String tempFileName = tempDir + PATH_DELIMETER + "Transaction.csv";

		file = new File(tempFileName);

		try (FileWriter fileWriter = new FileWriter(file);
				CSVPrinter csvFilePrinter = new CSVPrinter(fileWriter, csvFileFormat)) {

			csvFilePrinter.printRecord(fileHeader);

			for (int i = 0; i < list.size(); i++) {

				Map<Integer, String> map = list.get(i);

				double amount = getConditionalAmount(map);

				csvFilePrinter.print(checkDataForCsvPrinter(map.get(1)));
				csvFilePrinter.print(map.get(2) != null ? (map.get(2).replace("-", "/")) : "");
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(4)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(5)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(6)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(7)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(8)));

				String txnType = (map.get(8));
				if (txnType == null
						|| (!txnType.equals("Cash") && !txnType.equals(CHEQUE) && !txnType.equals(PAY_BY_LINK)))
					csvFilePrinter.print("CARD");
				else
					csvFilePrinter.print(txnType);

				csvFilePrinter.print(String.valueOf(amount));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(10)));
				csvFilePrinter.print("0");
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(8)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(12)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(13)));
				csvFilePrinter.print("N/A");
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(14)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(15)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(16)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(17)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(18)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(19)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(20)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(29)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(21)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(22)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(23)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(28)));
				csvFilePrinter.print("N/A");
				csvFilePrinter.print("N/A");
				csvFilePrinter.print("N/A");
				csvFilePrinter.print("N/A");
				csvFilePrinter.print("N/A");
				csvFilePrinter.print("N/A");
				csvFilePrinter.print("N/A");
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(24)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(25)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(26)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(27)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(29)));
				csvFilePrinter.print("N/A");
				csvFilePrinter.print("N/A");
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(3)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(11)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(30)));
				csvFilePrinter.print(checkDataForCsvPrinter(map.get(31)));
				csvFilePrinter.println();
			}

		} catch (IOException e) {
			log.error("exception occured while creating csv {}", e);
		}
		
		resource = getResourceFromCSV(file);

		return resource;
	}

	/**
	 * checkDataForCsvPrinter function used to check data is null or not
	 * 
	 * @param data
	 * @return String
	 */
	public String checkDataForCsvPrinter(String data) {
		return data != null ? data : "";
	}

	/**
	 * sendTransactionEmail is used to send transaction email of given transaction
	 * id with its details
	 * 
	 * @param long
	 *            transactionId,String emailId
	 * @return boolean
	 */
	@Override
	public boolean sendTransactionEmail(long transactionId, String emailId) {

		String imagePath = "";

		DecimalFormat df = new DecimalFormat("#0.00");

		TransactionSearchReportBean transactionForm = dao.getTransById(transactionId);

		log.info("Transaction details {}", transactionForm);

		String aquirerNameImagePath = imagePath + "images/" + transactionForm.getAcuirerName() + ".png";

		Map<String, String> descList = processBillNumber(transactionForm.getBillNumber());
		
		

		final Context context = new Context();

		context.setVariable("txnType", transactionForm.getType());
		context.setVariable("aquirerNameImagePath", aquirerNameImagePath);
		context.setVariable("descList", descList);
		context.setVariable("df", df);

		context.setVariable("businessName", transactionForm.getBusinessName());
		context.setVariable("securityToken", transactionForm.getSecurityToken());
		context.setVariable("line1", transactionForm.getLine1());
		context.setVariable("line2", transactionForm.getLine2());
		context.setVariable("countryName", transactionForm.getCountryName());
		context.setVariable("cityName", transactionForm.getCityName());
		context.setVariable("imageId", transactionForm.getImageId());
		context.setVariable("txnDate", transactionForm.getTxnDate());
		context.setVariable("time", transactionForm.getTime());
		context.setVariable("maskedCardNumber", transactionForm.getCardNumber());
		context.setVariable("cardType", transactionForm.getCardType());
		context.setVariable("txnType", transactionForm.getType());
		context.setVariable("refTransaction", transactionForm.getRefTransaction());
		context.setVariable("status", transactionForm.getStatus());
		context.setVariable("acuirerName", transactionForm.getAcuirerName());
		context.setVariable("merchantCode", transactionForm.getMerchantCode());
		context.setVariable("terminalId", transactionForm.getTerminalId());
		context.setVariable("authCode", transactionForm.getAuthCode());
		context.setVariable("rrn", transactionForm.getRrn());
		context.setVariable("tsi", transactionForm.getTsi());
		context.setVariable("tvr", transactionForm.getTvr());
		context.setVariable("appLabel", transactionForm.getAppLabel());
		context.setVariable("aid", transactionForm.getAid());
		context.setVariable("tgName", transactionForm.getTgName());
		context.setVariable("tgTransactionId", transactionForm.getTgTransactionId());
		context.setVariable("batchNo", transactionForm.getBatchNo());
		context.setVariable("invoiceNo", transactionForm.getInvoiceNo());
		context.setVariable("cashBackAmount", transactionForm.getCashBackAmount());
		context.setVariable("tipAmt", transactionForm.getTipAmt());
		context.setVariable("amount", transactionForm.getAmount());
		context.setVariable("baseamount", (transactionForm.getAmount() - transactionForm.getCashBackAmount()));
		context.setVariable("tenure", transactionForm.getTenure());
		context.setVariable("rateOfInterest", transactionForm.getRateOfInterest());
		context.setVariable("processingFee", transactionForm.getProcessingFee());
		context.setVariable("cashbackPercent", transactionForm.getCashbackPercent());
		context.setVariable("cashbackAmount", transactionForm.getCashBackAmount());
		context.setVariable("emiAmt", transactionForm.getEmiAmt());
		context.setVariable("emiAmtWithInterest", transactionForm.getEmiAmtWithInterest());
		context.setVariable("costToCust", transactionForm.getCostToCust());
		context.setVariable("mfgName", transactionForm.getMfgName());
		context.setVariable("prodCode", transactionForm.getProdCode());
		context.setVariable("prodCodeDescription", transactionForm.getProdCodeDescription());
		context.setVariable("custMobile", transactionForm.getCustMobile());
		context.setVariable("billNumber", transactionForm.getBillNumber());
		context.setVariable("pinVerified", transactionForm.getPinVerified());
		context.setVariable("cardHolderName", transactionForm.getCardHolderName());
		context.setVariable("emiDesclaimer", transactionForm.getEmiDesclaimer());
		context.setVariable("appVersion", transactionForm.getAppVersion());

		context.setVariable("signature", transactionForm.getSignature());

		String body = templateEngine.process("receipt", context);

		EmailBean email = new EmailBean();
		email.setToMail(emailId);
		email.setSubject("Receipt for Transaction Processed by Mosambee");
		email.setContent(body);
		emailService.sendHtmlEmail(email);

		return true;
	}

}
