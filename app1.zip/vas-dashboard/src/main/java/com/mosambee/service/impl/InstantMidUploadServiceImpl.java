package com.mosambee.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mosambee.bean.InstantMidUploadBean;
import com.mosambee.bean.MidDownloadBean;
import com.mosambee.constants.BulkUploadCategory;
import com.mosambee.constants.BulkUploadFileLocation;
import com.mosambee.constants.BulkUploadMessages;
import com.mosambee.dao.InstantMidUploadDao;
import com.mosambee.properties.ExcelHeaderProperties;
import com.mosambee.service.ExcelService;
import com.mosambee.service.InstantMidUploadService;
import com.mosambee.validator.InstantMidUploadValidator;

/**
 * This class is using for uploading mid and getting response corresponding mid
 * tid
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Service("instantMidUploadService")
public class InstantMidUploadServiceImpl implements InstantMidUploadService {
	private static final Logger log = LogManager.getLogger(InstantMidUploadServiceImpl.class);
	private static final DataFormatter dataFormatter = new DataFormatter();

	@Autowired
	private ExcelService excelService;
	
	@Autowired
	private ExcelHeaderProperties excelHeaderProperties;

	@Autowired
	private InstantMidUploadDao instantMidUploadDao;
	
	@Autowired
	private InstantMidUploadValidator instantMidUploadValidator;

	/**
	 * Responsible for processing {@link MultipartFile} ... Here we are validating
	 * the header, security issues, parsing the data from the {@link Workbook} &
	 * then again parsing the validated data from the {@link Workbook}
	 *
	 * @param file {@link MultipartFile}
	 * @return {@link Resource}
	 */
	@Override
	public Resource processInstantMidUploadExcel(MultipartFile file) {
		Workbook workbook = excelService.getWorkbookFromMultipartFile(file);
		List<InstantMidUploadBean> instantMidUploadBeanList = new ArrayList<>();
		List<InstantMidUploadBean> successRecordList = new ArrayList<>();
		List<InstantMidUploadBean> failedRecordList = new ArrayList<>();

		// VALIDATE THE HEADER & VALIDATE SECURITY ISSUES
		if (validateExcelFile(file, workbook) && validateSecurityIssues(file, workbook)) {

			// PARSE DATA FROM WORKBOOK
			List<MidDownloadBean> midDownloadBeanList = parseInstantMidUploadFields(workbook);

			// VALIDATE THE PARSED DATA FROM WORKBOOK INTO SUCCESS & FAILED RECORD LIST
			validateAndTransformParsedDataIntoLists(midDownloadBeanList, successRecordList, failedRecordList);

			// PERSIST THE MID/TIDS IN DATABASE
			persistInstantMid(successRecordList);

			// ADD ALL SUCCESS AND FAILED RECORDS IN A COMMON LIST
			instantMidUploadBeanList.addAll(failedRecordList);
			instantMidUploadBeanList.addAll(successRecordList);

			// GET THE EXCEL WITH RESPONSE
			Workbook responseWorkbook = writeInstantMidUploadBeanListToExcel(instantMidUploadBeanList);

			return excelService.getResourceFromWorkbook(responseWorkbook);

		} else {
			log.error("Excel file is not valid");
		}

		return null;
	}

	/**
	 * Performs validation for excel extension and validates the excel header.
	 * 
	 * @param file     MultipartFile
	 * @param workbook Workbook
	 * @return boolean
	 */
	private boolean validateExcelFile(MultipartFile file, Workbook workbook) {
		return excelService.validateExtension(file)
				&& excelService.validateHeader(workbook, BulkUploadCategory.INSTANT_MID_UPLOAD);
	}

	/**
	 * Performs validation for security issues in excel file. Mainly we are check
	 * for embedded object, macros and VB Scripts.
	 *
	 * @param file     MultipartFile
	 * @param workbook Workbook
	 * @return boolean
	 */
	private boolean validateSecurityIssues(MultipartFile file, Workbook workbook) {
		return excelService.checkForEmbeddedObjects(workbook) && excelService.checkForMacrosAndVbScript(file);
	}

	/**
	 * parseInstantMidUploadFields(...) is responsible to parsing the workbook. Here
	 * we are parsing the sheet present at 0th index and then iterating the rows and
	 * cells inside them to extract the values.
	 * 
	 * @param workbook {@link Workbook}
	 * @return {@link List} of {@link MidDownloadBean}
	 */
	private List<MidDownloadBean> parseInstantMidUploadFields(Workbook workbook) {
		Iterator<Row> rowIterator = workbook.getSheetAt(0).iterator();
		List<MidDownloadBean> midDownloadBeanList = new ArrayList<>();

		// SKIPING THE HEADER ROW
		rowIterator.next();

		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			MidDownloadBean midDownloadBean = parseRow(row);
			midDownloadBeanList.add(midDownloadBean);
		}

		return midDownloadBeanList;
	}

	/**
	 * {@link #parseRow(Row)} method is responsible for parsing the row and storing
	 * the parsed value in the object of {@link MidDownloadBean}
	 * 
	 * @param row
	 * @return {@link MidDownloadBean}
	 */
	private MidDownloadBean parseRow(Row row) {
		MidDownloadBean midDownloadBean = new MidDownloadBean();

		// SUBTRACT 1 FROM THE SIZE AS IT HAS STATUS HEADER.
		int sizeOfExcelHeader = excelHeaderProperties.getInstantMidUploadHeaders().size() - 1;

		for (int i = 0; i < sizeOfExcelHeader; ++i) {

			Cell cell = row.getCell(i);

			switch (i) {
			case 0:
				midDownloadBean.setPosId(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 1:
				midDownloadBean.setTempMerchantCode(dataFormatter.formatCellValue(cell));
				break;
			case 2:
				midDownloadBean.setTempTid(dataFormatter.formatCellValue(cell));
				break;
			case 3:
				midDownloadBean.setMid(dataFormatter.formatCellValue(cell));
				break;
			case 4:
				midDownloadBean.setTid(dataFormatter.formatCellValue(cell));
				break;
			default:
				String defaultCellValue = dataFormatter.formatCellValue(cell);
				log.info("Getting into the default case: {}", defaultCellValue);
				break;
			}
		}

		return midDownloadBean;

	}

	/**
	 * <strong>validateAndTransformParsedDataIntoLists(...)</strong> is responsible
	 * for iterating over the list of mid and then putting them into two separate
	 * list, on the basis of their success and failed validation status. <br>
	 * <br>
	 * 
	 * Here we are using two lists, i.e. successRecordList & failedRecordList for
	 * success and failed records. <br>
	 * 
	 * @param midDownloadBeanList {@link List} of all the mid.
	 * @param successRecordList   {@link List} of all the success records.
	 * @param failedRecordList    {@link List} of all the failed records.
	 * @return void
	 */
	private void validateAndTransformParsedDataIntoLists(List<MidDownloadBean> midDownloadBeanList,
			List<InstantMidUploadBean> successRecordList, List<InstantMidUploadBean> failedRecordList) {

		// LOOP OVER THE LIST OF MID
		for (MidDownloadBean midDownloadBean : midDownloadBeanList) {

			// VALIDATE THE BEAN
			InstantMidUploadBean instantMidUploadBean = instantMidUploadValidator
					.validateMidDownloadBean(midDownloadBean);

			// PUT THEM IN RESPECTIVE LIST.
			if (instantMidUploadBean.getStatus().equals("")) {
				successRecordList.add(instantMidUploadBean);
			} else {
				failedRecordList.add(instantMidUploadBean);
			}
		}
	}

	/**
	 * persistInstantMid(...) is responsible for getting the response from
	 * updateMidDownloadBean
	 * 
	 * @param successRecordList
	 * @return void
	 */
	private void persistInstantMid(List<InstantMidUploadBean> successRecordList) {

		// INSERT INTO THE DB
		for (InstantMidUploadBean instantMidUploadBean : successRecordList) {
			String response = instantMidUploadDao.uploadInstantMid(instantMidUploadBean);

			// PROCESS THE RESPONSE
			updateMidDownloadBean(response, instantMidUploadBean);
		}
	}

	/**
	 * updateOfferBean is responsible for checking the response coming from db and
	 * if response is null,that means exception has occurred on DB side update
	 * status according to response
	 */
	private void updateMidDownloadBean(String response, InstantMidUploadBean instantMidUploadBean) {

		if (null == response) {
			instantMidUploadBean.setStatus(BulkUploadMessages.EXCEPTION_OCCURED_WHILE_INSERTION.get());
		} else if (response.equals("1")) {
			instantMidUploadBean.setStatus(BulkUploadMessages.MID_ERROR_MESSAGE1.get());
		} else if (response.equals("2")) {
			instantMidUploadBean.setStatus(BulkUploadMessages.MID_ERROR_MESSAGE2.get());
		} else if (instantMidUploadBean.getStatus().equals("") && response.equals("0")) {
			instantMidUploadBean.setStatus(BulkUploadMessages.SUCCESS.get());
		}
	}

	/**
	 * {@link #writeInstantMidUploadBeanListToExcel(List)} is responsible for for
	 * creating the excel with the response after processing the instant mid upload
	 * excel file.
	 * 
	 * @param instantMidUploadBeanList
	 * @return {@link Workbook}
	 */
	private Workbook writeInstantMidUploadBeanListToExcel(List<InstantMidUploadBean> instantMidUploadBeanList) {

		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.INSTANT_MID_UPLOAD);
		Sheet sheet = workbook.getSheetAt(0);

		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		for (InstantMidUploadBean instantMidUploadBean : instantMidUploadBeanList) {
			Row row = sheet.createRow(rowNum++);

			row.createCell(0).setCellValue(instantMidUploadBean.getPosId());
			row.createCell(1).setCellValue(instantMidUploadBean.getTempMerchantCode());
			row.createCell(2).setCellValue(instantMidUploadBean.getTempTid());
			row.createCell(3).setCellValue(instantMidUploadBean.getMid());
			row.createCell(4).setCellValue(instantMidUploadBean.getTid());
			row.createCell(5).setCellValue(instantMidUploadBean.getStatus());

		}

		excelService.autoSizeExcel(workbook);
		return workbook;

	}

	/**
	 * getInstantMidUploadFormat() is responsible for converting the instant mid
	 * upload files present in {@link BulkUploadFileLocation} to {@link Resource}
	 */
	@Override
	public Resource getInstantMidUploadFormat() {
		ClassPathResource resource = null;
		resource = new ClassPathResource(BulkUploadFileLocation.INSTANT_MID_UPLOAD.get());
		return resource.exists() ? resource : null;
	}

}
