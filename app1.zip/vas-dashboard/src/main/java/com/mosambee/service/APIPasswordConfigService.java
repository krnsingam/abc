package com.mosambee.service;

import com.mosambee.bean.CreateAPIGroup;
import com.mosambee.bean.ListOfAPIGroup;
import com.mosambee.bean.MidTidBean;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.UpdateAPIPaswordConfigRequestFromList;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;

/**
 * This interface use to declare methods which we want to use in {@link APIPasswordConfigServiceImpl}
 * Here we declare(s) methods which we are using as a business logic.
 * @author mandar.chaudhari
 * @version 1.0
 */
public interface APIPasswordConfigService {
	public ResponseBean processCreateAPIGroupData(CreateAPIGroup createAPIGroup, ResponseBean responseBean);
	void  processUpdateAPIGroupData(CreateAPIGroup createAPIGroup, ResponseBean responseBean);
	DataTablesResponse<ListOfAPIGroup> getListOfAPIGroup(DataTablesRequest dtRequest);
	void processGetAPIGroupDataById(UpdateAPIPaswordConfigRequestFromList updateAPIPaswordConfigRequestFromList, CreateAPIGroup createAPIGroup,ResponseBean responseBean);
	public DataTablesResponse<MidTidBean> listMidTid(DataTablesRequest dtRequest, int id);
}
