package com.mosambee.service;

import com.mosambee.bean.ActiveProgramBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.service.impl.LaunchProgramServiceImpl;

/**
 * LaunchProgramService specification for {@link LaunchProgramServiceImpl} class
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 20-December-2019
 */
public interface LaunchProgramService {

	DataTablesResponse<ActiveProgramBean> getActiveProgramList(DataTablesRequest dtRequest);

}
