package com.mosambee.service;

import java.util.List;
import com.mosambee.bean.EnquiryBean;
import com.mosambee.bean.EnquiryDataTablesRequestBean;
import com.mosambee.bean.EnquiryDateBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import org.springframework.core.io.Resource;

/**
 * EnquiryReportingService provides specification for
 * {@link EnquiryReportingServiceImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 */
public interface EnquiryReportingService {
	DataTablesResponse<EnquiryBean> getEnquiryList(EnquiryDataTablesRequestBean dtRequest);

	List<EnquiryBean> downloadEnquiryReporting(EnquiryDateBean enquiryDateBean);
	Resource processEnquiryReporting(List<EnquiryBean> responseBean);

	EnquiryBean viewEnquiryDetail(long id);

}
