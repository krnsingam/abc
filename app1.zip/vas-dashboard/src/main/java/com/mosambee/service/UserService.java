package com.mosambee.service;

import java.util.Map;
import java.util.Set;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.web.bind.annotation.RequestParam;

import com.mosambee.bean.BlockedUserBean;
import com.mosambee.bean.BlockedUserDataTableBean;
import com.mosambee.bean.UserBean;
import com.mosambee.bean.UserCrudBean;
import com.mosambee.bean.UserCrudDataTableBean;
import com.mosambee.bean.UserExistAndNotBlockedBean;
import com.mosambee.bean.datatables.DataTablesResponse;

public interface UserService {

	void setRole(UserBean userBean);

	Set<SimpleGrantedAuthority> getAuthority(UserBean user);

	boolean checkIfUserIsBlocked(long userId);

	void addLoginLogs(String code, String remoteAddr, Long userId);

	UserExistAndNotBlockedBean checkIfUserExistsAndNotBlocked(String username);

	boolean checkWrongCredentialCount(long userId);
	
	DataTablesResponse<UserBean> getUsersList(UserCrudDataTableBean dtRequest);
	
	boolean  updateUserStatus(@RequestParam int status, @RequestParam int userId); 
	
	public Map<Integer, String> getRoles(); 
	
	boolean createUser(UserCrudBean userCrudBean);
	
	int updateUser(UserCrudBean userCrudBean);
    
	UserCrudBean getUserDetails(int userId);
	
	DataTablesResponse<BlockedUserBean> getWebBlockedUsers(BlockedUserDataTableBean dtRequest);
	
	boolean unblockBlockedUsers(long mUserId,String comment);
	
	boolean unblockMobileBlockedUsers(long mUserId,String comment);
	
	DataTablesResponse<BlockedUserBean> getMobileBlockedUsers(BlockedUserDataTableBean dtRequest);
}
