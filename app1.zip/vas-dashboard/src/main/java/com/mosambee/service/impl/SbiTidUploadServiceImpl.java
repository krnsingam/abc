package com.mosambee.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mosambee.bean.CustomUser;
import com.mosambee.bean.SBITidBean;
import com.mosambee.bean.SBITidUploadBean;
import com.mosambee.constants.BulkUploadCategory;
import com.mosambee.constants.BulkUploadFileLocation;
import com.mosambee.constants.BulkUploadMessages;
import com.mosambee.dao.SbiTidUploadDao;
import com.mosambee.properties.ExcelHeaderProperties;
import com.mosambee.service.ExcelService;
import com.mosambee.service.SbiTidUploadService;
import com.mosambee.validator.SbiTidUploadValidator;

import lombok.extern.log4j.Log4j2;

/**
 * This class is used for sbi-emi mid upload
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 */
@Log4j2
@Service("sbiTidUploadService")
public class SbiTidUploadServiceImpl implements SbiTidUploadService {

	private static final DataFormatter dataFormatter = new DataFormatter();

	@Autowired
	private ExcelService excelService;

	@Autowired
	private ExcelHeaderProperties excelHeaderProperties;

	@Autowired
	private SbiTidUploadValidator sbiTidUploadValidator;

	@Autowired
	private SbiTidUploadDao sbiTidUploadDao;

	/**
	 * Responsible for processing {@link MultipartFile} ... Here we are validating
	 * the header, security issues, parsing the data from the {@link Workbook} &
	 * then again parsing the validated data from the {@link Workbook}
	 *
	 * @param file {@link MultipartFile}
	 * @return {@link Resource}
	 */
	@Override
	public Resource processSbiEmiUploadExcel(MultipartFile file) {
		Workbook workbook = excelService.getWorkbookFromMultipartFile(file);
		List<SBITidUploadBean> sbiTidUploadBeanList = new ArrayList<>();
		List<SBITidUploadBean> successRecordList = new ArrayList<>();
		List<SBITidUploadBean> failedRecordList = new ArrayList<>();
		// VALIDATE THE HEADER & VALIDATE SECURITY ISSUES
		if (validateExcelFile(file, workbook) && validateSecurityIssues(file, workbook)) {

			// PARSE DATA FROM WORKBOOK
			List<SBITidBean> sbiTidBeanList = persistsSbiTidUploadFields(workbook);

			// VALIDATE THE PARSED DATA FROM WORKBOOK INTO SUCCESS & FAILED RECORD LIST
			validateAndTransformParsedDataIntoLists(sbiTidBeanList, successRecordList, failedRecordList);

			// PERSISTS EMI CONVERSION FIELDS IN DATABASE
			persistsSbiTid(successRecordList);

			// ADD ALL SUCCESS AND FAILED RECORDS IN A COMMON LIST
			sbiTidUploadBeanList.addAll(failedRecordList);
			sbiTidUploadBeanList.addAll(successRecordList);

			// GET THE EXCEL WITH RESPONSE
			Workbook responseWorkbook = writeSbiTidUploadBeanListToExcel(sbiTidUploadBeanList);

			return excelService.getResourceFromWorkbook(responseWorkbook);

		} else {
			log.error("Excel file is not valid");
		}

		return null;
	}
	
	/**
	 * {@link #writeSbiMidUploadBeanListToExcel(List)} is responsible for creating
	 * the excel with the response after processing the sbi mid upload excel file.
	 * 
	 * @param sbiMidUploadBeanList
	 * @return {@link Workbook}
	 */
	private Workbook writeSbiTidUploadBeanListToExcel(List<SBITidUploadBean> sbiTidUploadBeanList) {
		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.SBI_TID_UPLOAD);
		Sheet sheet = workbook.getSheetAt(0);

		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		for (SBITidUploadBean sBITidUploadBean : sbiTidUploadBeanList) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(sBITidUploadBean.getMPosMid());
			row.createCell(1).setCellValue(sBITidUploadBean.getMPosTid());
			row.createCell(2).setCellValue(sBITidUploadBean.getSkuName());
			row.createCell(3).setCellValue(sBITidUploadBean.getStoreName());
			row.createCell(4).setCellValue(sBITidUploadBean.getStoreCity());
			row.createCell(5).setCellValue(sBITidUploadBean.getStatus());
		}

		excelService.autoSizeExcel(workbook);
		return workbook;
	}

	/**
	 * persistsSbiTid is responsible for getting response from SBITidUploadBean
	 * 
	 * @param successRecordList
	 */
	private void persistsSbiTid(List<SBITidUploadBean> successRecordList) {
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Long userId = Long.parseLong(user.getMyMap().get("id"));

		// INSERT INTO DB
		for (SBITidUploadBean sBITidUploadBean : successRecordList) {
			String response = sbiTidUploadDao.uploadSbiTid(sBITidUploadBean, userId);

			// PROCESS THE RESPONSE
			updateSbiTidBean(response.trim(), sBITidUploadBean);
		}
	}

	private void updateSbiTidBean(String response, SBITidUploadBean sBITidUploadBean) {
		if (null == response) {
			sBITidUploadBean.setStatus(BulkUploadMessages.EXCEPTION_OCCURED_WHILE_INSERTION.get());
		} else if (response.equals("Terminal Id Already Exist")) {
			sBITidUploadBean.setStatus("Terminal Id Already Exist");
		} else if (response.equals("Please First Add MID")) {
			sBITidUploadBean.setStatus("Please First Add MID");
		} else if (response.equals("Merchant Not Active")) {
			sBITidUploadBean.setStatus("Merchant Not Active");
		} else if (response.equals("Invalid MID or TID")) {
			sBITidUploadBean.setStatus("Invalid MID or TID");
		} else if (sBITidUploadBean.getStatus().equals("") && response.equalsIgnoreCase("SBI TID Details Added Successfully")) {
			sBITidUploadBean.setStatus(BulkUploadMessages.SUCCESS.get());
		}

	}

	/**
	 * Performs validation for excel extension and validates the excel header.
	 * 
	 * @param file     MultipartFile
	 * @param workbook Workbook
	 * @return boolean
	 */
	private boolean validateExcelFile(MultipartFile file, Workbook workbook) {
		return excelService.validateExtension(file)
				&& excelService.validateHeader(workbook, BulkUploadCategory.SBI_TID_UPLOAD);
	}

	/**
	 * Performs validation for security issues in excel file. Mainly we are check
	 * for embedded object, macros and VB Scripts.
	 *
	 * @param file     MultipartFile
	 * @param workbook Workbook
	 * @return boolean
	 */
	private boolean validateSecurityIssues(MultipartFile file, Workbook workbook) {
		return excelService.checkForEmbeddedObjects(workbook) && excelService.checkForMacrosAndVbScript(file);
	}

	private List<SBITidBean> persistsSbiTidUploadFields(Workbook workbook) {
		Iterator<Row> rowIterator = workbook.getSheetAt(0).iterator();
		List<SBITidBean> sbiTidBeanList = new ArrayList<>();

		// SKIPING THE HEADER ROW
		rowIterator.next();

		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			SBITidBean sBITidBean = parseRow(row);
			sbiTidBeanList.add(sBITidBean);
		}

		return sbiTidBeanList;

	}

	/**
	 * {@link #parseRow(Row)} method is responsible for parsing the row and storing
	 * the parsed value in the object of {@link SBITidBean}
	 * 
	 * @param row
	 * @return {@link SBITidBean}
	 */
	private SBITidBean parseRow(Row row) {
		SBITidBean sBITidBean = new SBITidBean();

		// SUBTRACT 1 FROM THE SIZE AS IT HAS STATUS HEADER.
		int sizeOfExcelHeader = excelHeaderProperties.getSbiTidUploadHeaders().size() - 1;

		for (int i = 0; i < sizeOfExcelHeader; ++i) {

			Cell cell = row.getCell(i);

			switch (i) {
			case 0:
				sBITidBean.setMPosMid(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 1:
				sBITidBean.setMPosTid(dataFormatter.formatCellValue(cell));
				break;
			case 2:
				sBITidBean.setSkuName(dataFormatter.formatCellValue(cell));
				break;
			case 3:
				sBITidBean.setStoreName(dataFormatter.formatCellValue(cell));
				break;
			case 4:
				sBITidBean.setStoreCity(dataFormatter.formatCellValue(cell));
				break;

			default:
				String defaultCellValue = dataFormatter.formatCellValue(cell);
				log.info("Getting into the default case: {}", defaultCellValue);
				break;
			}
		}

		return sBITidBean;

	}

	/**
	 * validateAndTransformParsedDataIntoLists(...) is responsible for iterating
	 * over the list of SBI TID and then putting them into two separate list, on the
	 * basis of their success and failed validation status.
	 * 
	 * Here we are using two lists, i.e. successRecordList & failedRecordList for
	 * success and failed records.
	 * 
	 * @param sbiTidBeanList    {@link List} of all the mid.
	 * @param successRecordList {@link List} of all the success records.
	 * @param failedRecordList  {@link List} of all the failed records.
	 * @return void
	 */
	private void validateAndTransformParsedDataIntoLists(List<SBITidBean> sbiTidBeanList,
			List<SBITidUploadBean> successRecordList, List<SBITidUploadBean> failedRecordList) {

		// LOOP OVER THE LIST OF MID
		for (SBITidBean sBITidBean : sbiTidBeanList) {

			// VALIDATE THE BEAN
			SBITidUploadBean sBITidUploadBean = sbiTidUploadValidator.validateSBITidBean(sBITidBean);

			// PUT THEM IN RESPECTIVE LIST.
			if (sBITidUploadBean.getStatus().equals("")) {
				successRecordList.add(sBITidUploadBean);
			} else {
				failedRecordList.add(sBITidUploadBean);
			}
		}

	}
	
	@Override
	public Resource getSbiTidUploadFormat() {
		ClassPathResource resource = null;
		resource = new ClassPathResource(BulkUploadFileLocation.SBI_TID_UPLOAD.get());
		return resource.exists() ? resource : null;
	}

}
