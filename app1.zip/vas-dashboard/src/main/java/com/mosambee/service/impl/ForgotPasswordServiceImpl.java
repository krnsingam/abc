package com.mosambee.service.impl;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mosambee.bean.ForgotPasswordParams;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.RegexPatterns;
import com.mosambee.dao.ForgotPasswordDao;
import com.mosambee.service.EmailService;
import com.mosambee.service.ForgotPasswordService;
import com.mosambee.util.RandomPasswordGenerator;
import com.mosambee.util.SHA1;

/**
 * ForgotPasswordService responsible for providing methods to validate email
 * address.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 03-February-2020
 */
@Service("forgotPasswordService")
public class ForgotPasswordServiceImpl implements ForgotPasswordService {

	private static final Logger log = LogManager.getLogger(ForgotPasswordServiceImpl.class);

	@Autowired
	private RandomPasswordGenerator randomPasswordGenerator;

	@Autowired
	private ForgotPasswordDao forgotPasswordDao;

	@Autowired
	private EmailService emailService;

	/**
	 * processForgotPasswordRequest(...) is responsible for processing the forgot
	 * password request.<br/><br/>
	 * 
	 * In processing initially validation happens for email address, if validation
	 * is successful {@link ForgotPasswordParams} will be fetched from DB
	 * corresponding to provided user-name, then checks will be applied for DB
	 * error, user not in DB, change password limit exceed.<br/><br/>
	 * 
	 * If above checks are successful then new password & it's hash is generated
	 * which will be updated in DB, if that is successful an email will be sent to
	 * the user with new non-hashed password.<br/><br/>
	 * 
	 * @param email String
	 * @return String
	 */
	@Override
	public String processForgotPasswordRequest(String email) {

		// Validate the email address
		boolean emailValidationResult = isValidEmail(email);
		log.info("email validation result: {}", emailValidationResult);

		if (!emailValidationResult) {
			return CommonConstants.INVALID_EMAIL_ADDRESS.get();
		}

		// Get forgot password parameters corresponding to the provided user-name
		ForgotPasswordParams forgotPasswordParams = forgotPasswordDao.getForgotPasswordParams(email);
		log.info("forgot password parameters: {}", forgotPasswordParams);

		// Checks for DB error, user not present in DB, change password limit exceed
		if (null == forgotPasswordParams) {
			log.error("Exception occurred in database, getting forgotPasswordParams as {}", forgotPasswordParams);
			return CommonConstants.SOME_ERROR_OCCURRED.get();
		} else if (null != forgotPasswordParams.getMessage()) {

			if (forgotPasswordParams.getMessage().equalsIgnoreCase(CommonConstants.USER_NOT_PRESENT_IN_DB.get())) {
				return CommonConstants.USER_NOT_PRESENT_IN_DB.get();
			} else if (forgotPasswordParams.getMessage()
					.equalsIgnoreCase(CommonConstants.CHANGE_PASSWORD_LIMIT_EXCEEDED.get())) {
				return CommonConstants.CHANGE_PASSWORD_LIMIT_EXCEEDED.get();
			}

		}

		// Generate new password & it's SHA256 hash
		String newPassword = generateRandomPassword();
		String hashedNewPassword = getHashedPassword(newPassword);
		log.info("size of newPassword: {}, size of hashedPassword: {}", newPassword.length(),
				hashedNewPassword.length());

		// Update new password in DB, send email to user
		return updatedNewPasswordAndSendEmail(forgotPasswordParams, newPassword, hashedNewPassword);

	}

	/**
	 * Responsible for updating the new hashed password in database and sending
	 * email if password update in database is successful.
	 * 
	 * @param forgotPasswordParams
	 * @param newPassword
	 * @param hashedNewPassword
	 * @return String
	 */
	private String updatedNewPasswordAndSendEmail(ForgotPasswordParams forgotPasswordParams, String newPassword,
			String hashedNewPassword) {

		// Update new password in database, corresponding to the provided user-name
		boolean passwordUpdatedInDb = forgotPasswordDao.updatePasswordCorrespondingToEmailAddress(
				forgotPasswordParams.getUserId(), forgotPasswordParams.getUsername(), hashedNewPassword);

		if (passwordUpdatedInDb) {
			try {
				// Send email with new password
				boolean emailResponse = emailService.sendForgotPasswordEmail(forgotPasswordParams, newPassword);
				log.info("emailResponse: {}", emailResponse);
				return emailResponse ? CommonConstants.EMAIL_SENT_SUCCESS.get()
						: CommonConstants.EMAIL_SENT_FAILED.get();
			} catch (Exception e) {
				log.error("Exception occurred while sending forgot password email {}", e);
				return CommonConstants.EMAIL_SENT_FAILED.get();
			}
		} else {
			log.error("Unable to persist new password in database");
			return CommonConstants.UNABLE_TO_PERSIST_NEW_PASSWORD.get();
		}
	}

	/**
	 * Responsible for generating and returning the SHA256 hashed version of
	 * provided string.
	 * 
	 * @param newPassword
	 * @return String
	 */
	private String getHashedPassword(String newPassword) {
		return SHA1.getInstance().hash(newPassword);
	}

	/**
	 * Responsible for generating random passwords.
	 * 
	 * @return String
	 */
	private String generateRandomPassword() {
		return randomPasswordGenerator.generatePassword();
	}

	/**
	 * isValidEmail(...) is responsible for validating the incoming email address.
	 * 
	 * @param email
	 * @return boolean
	 */
	private boolean isValidEmail(String email) {
		Pattern pattern = Pattern.compile(RegexPatterns.FORGOT_PASSWORD_EMAIL.get());
		Matcher matcher = pattern.matcher(email);
		boolean isValidEmail = matcher.matches();
		log.info("isValidEmail: {}", isValidEmail);
		return isValidEmail;
	}

}
