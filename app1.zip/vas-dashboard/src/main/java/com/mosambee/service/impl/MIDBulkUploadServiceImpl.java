package com.mosambee.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mosambee.bean.CustomUser;
import com.mosambee.bean.MIDBulkUpload;
import com.mosambee.constants.APIPasswordConfigConstants;
import com.mosambee.constants.BulkUploadCategory;
import com.mosambee.constants.BulkUploadFileLocation;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ModuleName;
import com.mosambee.dao.APIPasswordConfigDao;
import com.mosambee.properties.ExcelHeaderProperties;
import com.mosambee.service.ExcelService;
import com.mosambee.service.MIDBulkUploadService;
import com.mosambee.validator.APIPasswordConfigValidator;

@Service
public class MIDBulkUploadServiceImpl implements MIDBulkUploadService {

	private static final Logger log = LogManager.getLogger(MIDBulkUploadServiceImpl.class);

	@Autowired
	private ExcelService excelService;

	@Autowired
	private ExcelHeaderProperties excelHeaderProperties;

	@Autowired
	@Qualifier("apiPasswordConfigValidator")
	APIPasswordConfigValidator apiPasswordConfigValidator;

	@Autowired
	@Qualifier("apiPasswordConfigDaoImpl")
	APIPasswordConfigDao apiPasswordConfigDao;
	
	private static final DataFormatter dataFormatter = new DataFormatter();
	
	/**
	 * Responsible for processing {@link MultipartFile} ... Here we are validating
	 * the header, security issues, parsing the data from the {@link Workbook} &
	 * then again parsing the validated data from the {@link Workbook}
	 *
	 * @param file {@link MultipartFile}
	 * @return 	   {@link Resource}
	 */
	@Override 
	public Resource processBulkUploadExcel(MultipartFile file) 
	{
	  Workbook workbook = excelService.getWorkbookFromMultipartFile(file);
	  List<MIDBulkUpload> midBulkUploadBeanList;
	  List<MIDBulkUpload> successRecordList = new ArrayList<>();
	  List<MIDBulkUpload> failedRecordList = new ArrayList<>();
	  
	  // VALIDATE THE HEADER & VALIDATE SECURITY ISSUES
	  if (validateExcelFile(file,workbook) && validateSecurityIssues(file, workbook)) {
	 
	  // PARSE DATA FROM WORKBOOK List<MIDBulkUpload>	  
	  midBulkUploadBeanList = parseMIDBulkUploadFields(workbook);
	  
	  // VALIDATE THE PARSED DATA FROM WORKBOOK INTO SUCCESS & FAILED RECORD LIST
	  validateMIDBulkUpload(midBulkUploadBeanList, successRecordList, failedRecordList);
	
	  // PERSIST THE PROGRAMS IN DATABASE 
	  persistMIDBulkUpload(successRecordList);
	  
	  // Cleared previous midBulkUploadBeanList to add new data otherwise data will be duplicate
	  midBulkUploadBeanList.clear();
	  
	  // ADD ALL SUCCESS AND FAILED RECORDS IN A COMMON LIST
	  midBulkUploadBeanList.addAll(failedRecordList);
	  midBulkUploadBeanList.addAll(successRecordList);
	 
	  // GET THE EXCEL WITH RESPONSE Workbook responseWorkbook =
	  Workbook responseWorkbook =  writeBulkUploadBeanListToExcel(midBulkUploadBeanList);
	  
	  return excelService.getResourceFromWorkbook(responseWorkbook);
	 }
	 else 
	 {
		log.error("Excel file is not valid"); 
	 }
	 return null;
	}
	 
	/**
	 * Performs validation for excel extension and validates the excel header.
	 * 
	 * @param  file     MultipartFile
	 * @param  workbook Workbook
	 * @return boolean
	 */
	private boolean validateExcelFile(MultipartFile file, Workbook workbook) {
		log.info("BulkUploadCategory.MID_BULK_UPLOAD {}",BulkUploadCategory.MID_BULK_UPLOAD);
		return excelService.validateExtension(file)
				&& excelService.validateHeader(workbook, BulkUploadCategory.MID_BULK_UPLOAD);
	}

	/**
	 * Performs validation for security issues in excel file. Mainly we are check
	 * for embedded object, macros and VB Scripts.
	 *
	 * @param file     MultipartFile
	 * @param workbook Workbook
	 * @return boolean
	 */
	private boolean validateSecurityIssues(MultipartFile file, Workbook workbook) {
		return excelService.checkForEmbeddedObjects(workbook) && excelService.checkForMacrosAndVbScript(file);
	}

	/**
	 * parseMIDBulkUploadFields(...) is responsible to parsing the workbook.
	 * Here we are parsing the sheet present at 0th index and then iterating the
	 * rows and cells inside them to extract the values.
	 * 
	 * @param  workbook {@link Workbook}
	 * @return {@link List} of {@link ProgramBean}
	 */
	private List<MIDBulkUpload> parseMIDBulkUploadFields(Workbook workbook) {
		Iterator<Row> rowIterator = workbook.getSheetAt(0).iterator();
		List<MIDBulkUpload> midBulkUploadList = new ArrayList<>();

		// SKIPING THE HEADER ROW
		rowIterator.next();

		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			MIDBulkUpload midBulkUpload = parseRow(row);
			midBulkUploadList.add(midBulkUpload);
		}

		return midBulkUploadList;
	}

	/**
	 * {@link #parseRow(Row)} method is responsible for parsing the row and storing
	 * the parsed value in the object of {@link MIDBulkUpload}
	 * 
	 * @param row
	 * @return {@link ProgramBean}
	 */
	private MIDBulkUpload parseRow(Row row) {
		MIDBulkUpload midBulkUpload = new MIDBulkUpload();

		// SUBTRACT 1 FROM THE SIZE AS IT HAS STATUS HEADER.
		int sizeOfExcelHeader = excelHeaderProperties.getMidBulkUploadHeaders().size() - 1;

		for (int i = 0; i < sizeOfExcelHeader; ++i) {
			
			Cell cell = row.getCell(i);

			switch (i) {
			case 0:
				midBulkUpload.setDivisionCode(dataFormatter.formatCellValue(cell));
				break;

			case 1:
				midBulkUpload.setMid(dataFormatter.formatCellValue(cell));
				break;
				
			case 2:
				midBulkUpload.setTid(dataFormatter.formatCellValue(cell));
				break;
				
			default:
				log.info("MIDBulkUpload default case for cell no : {} ", i);
			}
		}

		return midBulkUpload;

	}

	/**
	 * <strong>validateParsedDataIntoLists(...)</strong> is responsible for
	 * iterating over the list of mid and then putting them into two separate
	 * list, on the basis of their success and failed validation status. <br>
	 * <br>
	 * 
	 * Here we are using two lists, i.e. successRecordList & failedRecordList for
	 * success and failed records. <br>
	 * 
	 * @param midBulkUploadList     {@link List} of all the MID.
	 * @param successRecordList 	{@link List} of all the success records.
	 * @param failedRecordList  	{@link List} of all the failed records.
	 * @return void
	 */
	private void validateMIDBulkUpload(List<MIDBulkUpload> midBulkUploadList, List<MIDBulkUpload> successRecordList,
			List<MIDBulkUpload> failedRecordList) {

		// LOOP OVER THE LIST OF MIDs
		for (MIDBulkUpload midBulkUpload : midBulkUploadList) {

			// VALIDATE THE BEAN
			apiPasswordConfigValidator.validateMIDBulkUpload(midBulkUpload);
			log.info("divisionCode : {} mid : {}  tid : {} status : {} isValidate : {}", midBulkUpload.getDivisionCode(), midBulkUpload.getMid(), midBulkUpload.getTid(), midBulkUpload.getStatus(), midBulkUpload.isValidate());
			// PUT THEM IN RESPECTIVE LIST.
			if (midBulkUpload.isValidate()) {
				successRecordList.add(midBulkUpload);
			} else {
				failedRecordList.add(midBulkUpload);
			}
		}
	}

	/**
	 * persistPrograms(...) is responsible for getting the prefixName from
	 * {@link ModuleName} and then persist the program details into the database. We
	 * will get programCode after persisting a particular bean which is then set to
	 * the same record.
	 * 
	 * @param successRecordList
	 * @return void
	 */
	private void persistMIDBulkUpload(List<MIDBulkUpload> successRecordList) {

		for (MIDBulkUpload midBulkUpload : successRecordList) {
			MIDBulkUpload bulkup = apiPasswordConfigDao.validateMIDBulkUploadData(midBulkUpload);
			switch(bulkup.getErrCode()) {
			case 0:
				midBulkUpload.setStatus(APIPasswordConfigConstants.MSG0.get());
				break;
			case 1:
				midBulkUpload.setStatus(APIPasswordConfigConstants.MSG1.get());
				break;
			case 2:
				midBulkUpload.setStatus(APIPasswordConfigConstants.MSG2.get());
				break;
			case 3:
				midBulkUpload.setStatus(APIPasswordConfigConstants.MSG3.get());
				break;
			default:
				midBulkUpload.setStatus(APIPasswordConfigConstants.MSGD.get());
				break;
			}
			
			log.info("0 or 3 for inserted and updated value : {}",bulkup.getErrCode());
			if(bulkup.getErrCode() == 0 || bulkup.getErrCode() == 3) {
				apiPasswordConfigDao.insertMIDBulkUploadData(bulkup, getIdOfLoggedInUser());
			}
		}

	}
	
	/**This method returns id of user which are currently logged in.
	 * @return long : Returns user Id.
	 */
	private long getIdOfLoggedInUser()
	{
		long createdBy;
		// Get logged in user info.
		CustomUser customUser = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Map<String, String> myMap = customUser.getMyMap(); // Store logged in user info into hash map.
		
		log.info("myMap contents: {}", myMap);
		
		createdBy = Long.parseLong(myMap.get("id")); 
		return createdBy; 
	}
	
	/**
	 * {@link #writeBulkUploadBeanListToExcel(List)} is responsible for for creating
	 * the excel with the response after processing the program bulk upload excel
	 * file.
	 * 
	 * @param programBulkUploadBeanList
	 * @return {@link Workbook}
	 */
	private Workbook writeBulkUploadBeanListToExcel(List<MIDBulkUpload> midBulkUploadBeanList) {

		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.MID_BULK_UPLOAD);
		Sheet sheet = workbook.getSheetAt(0);

		log.info("midBulkUploadBeanList.size() : {} ",midBulkUploadBeanList.size());
		
		if(midBulkUploadBeanList.isEmpty())
		{
			MIDBulkUpload midBulkUploadTemp = new MIDBulkUpload();
			midBulkUploadTemp.setStatus(CommonConstants.NO_RECORD_IN_EXCEL.get());
			midBulkUploadBeanList.add(midBulkUploadTemp);
		}
		
		
		
		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		for (MIDBulkUpload midBulkUpload : midBulkUploadBeanList) {
			Row row = sheet.createRow(rowNum++);
			
			row.createCell(0).setCellValue(midBulkUpload.getDivisionCode());
			row.createCell(1).setCellValue(midBulkUpload.getMid());
			row.createCell(2).setCellValue(midBulkUpload.getTid());
			row.createCell(3).setCellValue(midBulkUpload.getStatus());
		}
		excelService.autoSizeExcel(workbook);
		return workbook;

	}
	
	/**
	 * getProgramBulkUploadFormat() is responsible for converting the bulk upload
	 * files present in {@link BulkUploadFileLocation} to {@link Resource}
	 */
	@Override
	public Resource getMIDBulkUploadFormat() {
		ClassPathResource resource = null;
		resource = new ClassPathResource(BulkUploadFileLocation.MID_BULK_UPLOAD_FILE.get());
		return resource.exists() ? resource : null;
	}
}
