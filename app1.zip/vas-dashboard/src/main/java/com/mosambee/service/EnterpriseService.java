package com.mosambee.service;

import java.util.List;
import java.util.Map;

import com.mosambee.bean.CityBean;
import com.mosambee.bean.CountryBean;
import com.mosambee.bean.EnterpriseBean;
import com.mosambee.bean.EnterpriseDataBean;
import com.mosambee.bean.EnterpriseListBean;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.StateBean;
import com.mosambee.bean.UpdateAPIPaswordConfigRequestFromList;
import com.mosambee.bean.datatables.DataTablesResponse;

public interface EnterpriseService {

	public ResponseBean processCreateEnterprise(EnterpriseBean enterprise, ResponseBean responseBean);
	
	public List<CountryBean> getCountry() ;
	
	public List<StateBean> getState(CountryBean country);
	
	public List<CityBean> getCity(StateBean state);
	
	public DataTablesResponse<EnterpriseListBean> enterpriseList(EnterpriseDataBean dtRequest);
	
	public List<EnterpriseListBean> getEnterpriseName(EnterpriseListBean bean);

	public void updateEnterprise(EnterpriseBean enterprise, ResponseBean responseBean);
	
	public void updateEnterpriseList(UpdateAPIPaswordConfigRequestFromList updateAPIPaswordConfigRequestFromList,
			EnterpriseBean enterprise, ResponseBean responseBean);
}
