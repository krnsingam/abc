package com.mosambee.service;

import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import com.mosambee.bean.MerchantKeyBean;
import com.mosambee.bean.MerchantKeyDataBean;
import com.mosambee.bean.MerchantMappingBean;
import com.mosambee.bean.MerchantMappingDataBean;
import com.mosambee.bean.MerchantNameBean;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.datatables.DataTablesResponse;

/**
 * MerchantSpecificService.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 27-February-2020
 */
public interface MerchantSpecificService {

	public ResponseBean createMerchantMapping(MerchantMappingBean merchantMapping);
	
	public ResponseBean updateMerchantMapping(MerchantMappingBean merchantMapping);
	
	public List<MerchantNameBean> getMerchantName(MerchantNameBean merchantbean);
	
	public DataTablesResponse<MerchantMappingBean> getMerchantMappingView(MerchantMappingDataBean dtRequest);
	
	public Resource downloadMerchantMapping(MerchantMappingBean report);
	
	public DataTablesResponse<MerchantKeyBean> getMerchantKey(MerchantKeyDataBean dtRequest);
	
	public Resource downloadMerchantKey(MerchantKeyBean report);
	
	public ResponseBean editMerchantKey(MerchantKeyBean merchantkey);
	
	public void processMappingById(MerchantMappingBean merchantMappingBean, MerchantMappingBean createMapping, ResponseBean responseBean);
	
	public void processKeyById(MerchantKeyBean merchantKeyBean, MerchantKeyBean createKey, ResponseBean responseBean);
	
	public Resource getBulkUploadFormat();
	
	public Resource processBulkUploadExcel(MultipartFile file);
	
	public Resource getKeyBulkUploadFormat();
	
	public Resource processKeyBulkUploadExcel(MultipartFile file);
	
}
