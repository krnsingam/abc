package com.mosambee.service.impl;

import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mosambee.bean.AddBqrMerchantsBean;
import com.mosambee.bean.BqrListDatatablesRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.AddBqrMerchantsDao;
import com.mosambee.service.AddBqrMerchantsService;
import com.mosambee.transformer.BqrMerchantListTransformer;
import com.mosambee.validator.AddBqrMerchantsValidator;

import lombok.extern.log4j.Log4j2;

/**
 * this class is responsible for implenting {@link AddBqrMerchantsService}
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
@Log4j2
@Service
public class AddBqrMerchantsServiceImpl implements AddBqrMerchantsService {
	@Autowired
	private AddBqrMerchantsDao addBqrMerchantsDao;
	@Autowired
	private AddBqrMerchantsValidator addBqrMerchantsValidator;
	@Autowired
	private BqrMerchantListTransformer transformer;

	/**
	 * insertBqrMerchants() is responsible for calling Dao to add bqr merchants.
	 *
	 */
	@Override
	public String insertBqrMerchants(AddBqrMerchantsBean addBqrMerchantsBean, String userId) {
		addBqrMerchantsValidator.validateAddBqrMerchantsBean(addBqrMerchantsBean);

		if (addBqrMerchantsBean.getMessage() == null) {

			addBqrMerchantsDao.addBqrMerchants(addBqrMerchantsBean, userId);
		}
		return addBqrMerchantsBean.getMessage();
	}

	/**
	 * getBqrMerchantsList(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request of
	 * 
	 * @param dtRequest {@link BqrListDatatablesRequestBean}
	 */
	@Override
	public DataTablesResponse<AddBqrMerchantsBean> getBqrMerchantsList(BqrListDatatablesRequestBean dtRequest) {
		// GET THE COLUMN NAME FROM COLUMN INDEX
		int orderingColumnIndex = dtRequest.getDtRequest().getOrder().get(0).getColumn();
		String orderingColumnName = getOrderingColumnName(orderingColumnIndex);
		log.info("orderingColumnIndexs: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);
		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ENQUIRY REPORTING
		Map<String, String> searchMap = transformer.transformBqrMerchantsListDataTablesRequest(dtRequest);
		log.info("size of searchMaps: {}", searchMap.size());
		DataTablesResponse<AddBqrMerchantsBean> dtResponse = addBqrMerchantsDao.getBqrMerchantsList(dtRequest,
				orderingColumnName, searchMap);
		dtResponse.setDraw(dtRequest.getDtRequest().getDraw());
		return dtResponse;

	}

	/**
	 * getOrderingColumnName (...) method is responsible for returning
	 * orderingColumnName of AddBqrMerchantsBean when it is provided with
	 * orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnName(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.ACQUIRER_NAME.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.MDAT_MERCHANTCODE.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.MMUT_TERMINALID.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.QRM_IFSCACCOUNTNO.get();
			break;
		case 4:
			orderingColumnName = ColumnNames.QRM_MERCHANTNAME.get();
			break;

		case 5:
			orderingColumnName = ColumnNames.QR_MERCHANTMAPPING.get();
			break;

		default:
			orderingColumnName = ColumnNames.ACQUIRER_NAME.get();
			break;
		}

		return orderingColumnName;
	}

	/**
	 * editBqrMerchants() is responsible for calling dao to get values to edit bqr
	 * merchants by id.
	 *
	 */
	@Override
	public AddBqrMerchantsBean editBqrMerchants(long id) {
		return addBqrMerchantsDao.editBqrMerchants(id);
	}

	/**
	 * updateBqrMerchants() is responsible for updating bqr merchants. and calling
	 * dao to update those values.
	 *
	 */
	@Override
	public String updateBqrMerchants(AddBqrMerchantsBean addBqrMerchantsBean, String userId) {
		addBqrMerchantsValidator.validateAddBqrMerchantsBean(addBqrMerchantsBean);
		if (addBqrMerchantsBean.getMessage() == null) {
			addBqrMerchantsDao.updateBqrMerchants(addBqrMerchantsBean, userId);
		}
		return addBqrMerchantsBean.getMessage();
	}

}
