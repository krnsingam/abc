package com.mosambee.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.mosambee.bean.EmiBean;
import com.mosambee.bean.EmiUploadBean;
import com.mosambee.constants.BulkUploadFileLocation;
import com.mosambee.constants.BulkUploadMessages;
import com.mosambee.dao.EmiUploadDao;
import com.mosambee.properties.ExcelHeaderProperties;
import com.mosambee.service.EmiUploadService;
import com.mosambee.service.ExcelService;
import com.mosambee.validator.EmiUploadValidator;

/**
 * This class is using for emi upload
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
@Service("emiUploadService")
public class EmiUploadServiceImpl implements EmiUploadService {

	private static final Logger log = LogManager.getLogger(EmiUploadServiceImpl.class);
	private static final DataFormatter dataFormatter = new DataFormatter();

	@Autowired
	private ExcelService excelService;

	@Autowired
	private ExcelHeaderProperties excelHeaderProperties;

	@Autowired
	private EmiUploadDao emiUploadDao;

	@Autowired
	private EmiUploadValidator emiUploadValidator;

	/**
	 * getEmiUploadFormat() is responsible for converting the emis upload files
	 * present in {@link BulkUploadFileLocation} to {@link Resource}
	 */
	@Override
	public Resource getEmiUploadFormat() {
		ClassPathResource resource = null;
		resource = new ClassPathResource(BulkUploadFileLocation.EMI_UPLOAD.get());
		return resource.exists() ? resource : null;
	}

	/**
	 * Responsible for processing {@link MultipartFile} ... Here we are validating
	 * the header, security issues, parsing the data from the {@link Workbook} &
	 * then again parsing the validated data from the {@link Workbook}
	 *
	 * @param file {@link MultipartFile}
	 * @return {@link Resource}
	 */
	@Override
	public Resource processEmiUploadExcel(MultipartFile file) {
		Workbook workbook = excelService.getWorkbookFromMultipartFile(file);
		if (workbook != null) {
			List<EmiUploadBean> emiUploadBeanList = new ArrayList<>();
			List<EmiUploadBean> successRecordList = new ArrayList<>();
			List<EmiUploadBean> failedRecordList = new ArrayList<>();
			// VALIDATE THE HEADER & VALIDATE SECURITY ISSUES
			if (validateExcelFile(file, workbook) && validateSecurityIssues(file, workbook)) {
				// PARSE DATA FROM WORKBOOK
				List<EmiBean> emiBeanList = parseEmiUploadFields(workbook);

				// VALIDATE THE PARSED DATA FROM WORKBOOK INTO SUCCESS & FAILED RECORD LIST
				validateAndTransformParsedDataIntoLists(emiBeanList, successRecordList, failedRecordList);
				// Persists emi upload fields in database
				persistsEmi(successRecordList);

				// ADD ALL SUCCESS AND FAILED RECORDS IN COMMON LIST
				emiUploadBeanList.addAll(failedRecordList);
				emiUploadBeanList.addAll(successRecordList);

				// GET THE EXCEL WITH RESPONSE
				Workbook responseWorkbook = writeEmiUploadBeanListToExcel(emiUploadBeanList);
				return excelService.getResourceFromWorkbook(responseWorkbook);

			} else {
				log.error("Excel file is not valid");
			}
		} else {
			log.error("workbook is null");

		}
		return null;

	}

	/**
	 * Performs validation for excel extension and validates the excel header.
	 * 
	 * @param file     MultipartFile
	 * @param workbook Workbook
	 * @return boolean
	 */
	private boolean validateExcelFile(MultipartFile file, Workbook workbook) {
		return excelService.validateExtension(file) && emiUploadValidator.validateHeader(workbook, 0)
				&& emiUploadValidator.validateHeader(workbook, 1);
	}

	/**
	 * Performs validation for security issues in excel file. Mainly we are check
	 * for embedded object, macros and VB Scripts.
	 *
	 * @param file     MultipartFile
	 * @param workbook Workbook
	 * @return boolean
	 */
	private boolean validateSecurityIssues(MultipartFile file, Workbook workbook) {
		return excelService.checkForEmbeddedObjects(workbook) && excelService.checkForMacrosAndVbScript(file);
	}

	/**
	 * parseEmiUploadFields(...) is responsible to parsing the workbook. Here we are
	 * parsing the sheet present at 0th index and then iterating the rows and cells
	 * inside them to extract the values.
	 * 
	 * @param workbook {@link Workbook}
	 * @return {@link List} of {@link EmiBean}
	 */
	private List<EmiBean> parseEmiUploadFields(Workbook workbook) {
		Iterator<Row> rowIterator = workbook.getSheetAt(0).iterator();
		List<EmiBean> emiBeanList = new ArrayList<>();
		// SKIPING THE HEADER ROW
		rowIterator.next();
		rowIterator.next();
		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			EmiBean emiBean = parseRow(row);
			emiBeanList.add(emiBean);

		}
		return emiBeanList;

	}

	/**
	 * {@link #parseRow(Row)} method is responsible for parsing the row and storing
	 * the parsed value in the object of {@link EmiBean}
	 * 
	 * @param row
	 * @return {@link EmiBean}
	 */
	private EmiBean parseRow(Row row) {
		EmiBean emiBean = new EmiBean();
		// SUBTRACT 1 FROM THE SIZE AS IT HAS STATUS HEADER.
		int sizeOfExcelHeader = excelHeaderProperties.getEmiUploadHeaders().size() - 1;

		for (int i = 0; i < sizeOfExcelHeader; ++i) {
			Cell cell = row.getCell(i);

			switch (i) {
			case 0:
				emiBean.setBaseMid(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 1:
				emiBean.setBaseTid(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 2:
				emiBean.setEmiType(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 3:
				emiBean.setEmiMatCode(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 4:
				emiBean.setEmiMid(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 5:
				emiBean.setEmiTid(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 6:
				emiBean.setMosambeeEmi(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 7:
				emiBean.setEmi(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 8:
				emiBean.setEmiEnquiry(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 9:
				emiBean.setEmiProgramEnquiry(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 10:
				emiBean.setEmiVoid(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 11:
				emiBean.setEmiSettlement(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 12:
				emiBean.setCcEmiFlag(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 13:
				emiBean.setDcEmiFlag(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 14:
				emiBean.setBrandEmiFlag(dataFormatter.formatCellValue(row.getCell(i)));
				break;

			default:
				String defaultCellValue = dataFormatter.formatCellValue(cell);
				log.info("Getting into the default case: {}", defaultCellValue);
				break;

			}

		}

		return emiBean;

	}

	/**
	 * <strong>validateAndTransformParsedDataIntoLists(...)</strong> is responsible
	 * for iterating over the list of emi and then putting them into two separate
	 * list, on the basis of their success and failed validation status. <br>
	 * <br>
	 * 
	 * Here we are using two lists, i.e. successRecordList & failedRecordList for
	 * success and failed records. <br>
	 * 
	 * @param emiBeanList       {@link List} of all the mid.
	 * @param successRecordList {@link List} of all the success records.
	 * @param failedRecordList  {@link List} of all the failed records.
	 * @return void
	 */
	private void validateAndTransformParsedDataIntoLists(List<EmiBean> emiBeanList,
			List<EmiUploadBean> successRecordList, List<EmiUploadBean> failedRecordList) {
		// LOOP OVER THE LIST OF Emi
		for (EmiBean emiBean : emiBeanList) {
			// VALIDATE THE BEAN
			EmiUploadBean emiUploadBean = emiUploadValidator.validateEmiBean(emiBean);

			// PUT THEM IN RESPECTIVE LIST.
			if (emiUploadBean.getStatus().equals("")) {
				successRecordList.add(emiUploadBean);
			} else {
				failedRecordList.add(emiUploadBean);
			}
		}
	}

	/**
	 * persistsEmi() is responsible for getting response from EmiUploadBean.if
	 * acquirer is Atos then excute updateEmiBean() AND if acquirer is HDFC then
	 * excute updateEmiBeanHDFC
	 * 
	 * @param successRecordList
	 */
	private void persistsEmi(List<EmiUploadBean> successRecordList) {
		for (EmiUploadBean emiUploadBean : successRecordList) {
			EmiUploadBean error = emiUploadDao.updateEmi(emiUploadBean);
			log.info(error.getTgName());
			if (error.getTgName() != null && error.getTgName().equalsIgnoreCase("ATOS") && error.getErrorCode() == 0) {
				String response = emiUploadDao.insertEmiUploadDataForAtos(error);
				log.info("Response from db for atos {}", response);
				updateEmiBeanForAtos(response, emiUploadBean);
			} else if (error.getTgName() != null && error.getTgName().equalsIgnoreCase("HDFC")
					&& error.getErrorCode() == 0) {
				String response = emiUploadDao.insertEmiUploadDataForHDFC(error);
				log.info("Response from db for hdfc {}", response);
				updateEmiBeanForHDFC(response, emiUploadBean);
			} else {
				log.info("error code from matCode {}", error.getErrorCode());
				switch (error.getErrorCode()) {
				case 0:
					emiUploadBean.setStatus(BulkUploadMessages.SUCCESS.get());
					break;
				case 1:
					emiUploadBean.setStatus(BulkUploadMessages.ERRORCODE1.get());
					break;
				case 2:
					emiUploadBean.setStatus(BulkUploadMessages.ERRORCODE2.get());
					break;
				default:
					emiUploadBean.setStatus(BulkUploadMessages.EXCEPTION_OCCURED_WHILE_INSERTION.get());
					break;
				}
			}
		}
	}

	/**
	 * updateEmiBean() is responsible for checking the response coming from db
	 * regarding ATOS acquirer.If response is null ,that means exception has occured
	 * on db side.if response is not null then we update status according to
	 * response.
	 * 
	 * @param response
	 * @param emiUploadBean
	 */
	private void updateEmiBeanForAtos(String response, EmiUploadBean emiUploadBean) {
		if (null == response) {
			emiUploadBean.setStatus(BulkUploadMessages.EXCEPTION_OCCURED_WHILE_INSERTION.get());
		} else if (response.equals("1")) {
			emiUploadBean.setStatus(BulkUploadMessages.SECONDMETHODCODE1.get());
		} else if (response.equals("2")) {
			emiUploadBean.setStatus(BulkUploadMessages.SECONDMETHODCODE2.get());
		} else if (response.equals("3")) {
			emiUploadBean.setStatus(BulkUploadMessages.SECONDMETHODCODE3.get());
		} else if (response.equals("4")) {
			emiUploadBean.setStatus(BulkUploadMessages.SECONDMETHODCODE4.get());
		} else if (emiUploadBean.getStatus().equals("") && response.equals("0")) {
			emiUploadBean.setStatus(BulkUploadMessages.SUCCESS.get());
		}
	}

	/**
	 * updateEmiBeanHDFC() is responsible for checking the response coming from db
	 * regarding HDFC.If response is null,that means exception has occured on db
	 * side.If response is not null then we update status according to response
	 * 
	 * @param response
	 * @param emiUploadBean
	 */
	private void updateEmiBeanForHDFC(String response, EmiUploadBean emiUploadBean) {
		if (null == response) {
			emiUploadBean.setStatus(BulkUploadMessages.EXCEPTION_OCCURED_WHILE_INSERTION.get());
		} else if (response.equals("1")) {
			emiUploadBean.setStatus(BulkUploadMessages.SECONDMETHODCODE1.get());
		} else if (response.equals("2")) {
			emiUploadBean.setStatus(BulkUploadMessages.SECONDMETHODCODE2.get());
		} else if (response.equals("3")) {
			emiUploadBean.setStatus(BulkUploadMessages.SECONDMETHODCODE3.get());
		} else if (response.equals("4")) {
			emiUploadBean.setStatus(BulkUploadMessages.THIRDMETHOD4.get());
		} else if (response.equals("5")) {
			emiUploadBean.setStatus(BulkUploadMessages.THIRDMETHOD5.get());
		} else if (response.equals("6")) {
			emiUploadBean.setStatus(BulkUploadMessages.THIRDMETHOD5.get());
		} else if (emiUploadBean.getStatus().equals("") && response.equals("0")) {
			emiUploadBean.setStatus(BulkUploadMessages.SUCCESS.get());
		}
	}

	/**
	 * {@link #writeEmiUploadBeanListToExcel(List)} is responsible for creating the
	 * excel with the response after processing the emi upload excel file.
	 * 
	 * @param emiUploadBeanList
	 * @return {@link Workbook}
	 */
	private Workbook writeEmiUploadBeanListToExcel(List<EmiUploadBean> emiUploadBeanList) {
		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = setWorkbookHeaderStyle();
		Sheet sheet = workbook.getSheetAt(0);
		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 2;
		for (EmiUploadBean emiUploadBean : emiUploadBeanList) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(emiUploadBean.getBaseMid());
			row.createCell(1).setCellValue(emiUploadBean.getBaseTid());
			row.createCell(2).setCellValue(emiUploadBean.getEmiType());
			row.createCell(3).setCellValue(emiUploadBean.getEmiMatCode());
			row.createCell(4).setCellValue(emiUploadBean.getEmiMid());
			row.createCell(5).setCellValue(emiUploadBean.getEmiTid());
			row.createCell(6).setCellValue(emiUploadBean.getMosambeeEmi());
			row.createCell(7).setCellValue(emiUploadBean.getEmi());
			row.createCell(8).setCellValue(emiUploadBean.getEmiEnquiry());
			row.createCell(9).setCellValue(emiUploadBean.getEmiProgramEnquiry());
			row.createCell(10).setCellValue(emiUploadBean.getEmiVoid());
			row.createCell(11).setCellValue(emiUploadBean.getEmiSettlement());
			row.createCell(12).setCellValue(emiUploadBean.getCcEmiFlag());
			row.createCell(13).setCellValue(emiUploadBean.getDcEmiFlag());
			row.createCell(14).setCellValue(emiUploadBean.getBrandEmiFlag());
			row.createCell(15).setCellValue(emiUploadBean.getStatus());
		}

		excelService.autoSizeExcel(workbook);
		return workbook;

	}

	/**
	 * {@link #setWorkbookHeaderStyle(Workbook, List)} is responsible to set the
	 * excelHeaderList to the workbook row along with the CellStyle obtained from
	 * {@link #getHeaderCellStyle(Workbook)}
	 * 
	 * @param workbook
	 * @param excelHeaderList1
	 * @param excelHeaderList2
	 * @return {@link Workbook}
	 */
	private Workbook setWorkbookHeaderStyle() {
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet();
		Row headerRow1 = sheet.createRow(0);
		Row headerRow2 = sheet.createRow(1);
		List<String> excelHeaderList1 = excelHeaderProperties.getFirstEmiUploadHeaders();
		List<String> excelHeaderList2 = excelHeaderProperties.getEmiUploadHeaders();

		// GET THE HEADER CELL STYLING VALUE
		CellStyle headerCellStyle = getHeaderCellStyle(workbook);

		// LOOP THROUGH THE EXCEL HEADER LIST, SET THE VALUE & STYLING TO THE CELL.
		for (int i = 0; i < excelHeaderList1.size(); ++i) {
			Cell cell = headerRow1.createCell(i);
			cell.setCellValue(excelHeaderList1.get(i));
			cell.setCellStyle(headerCellStyle);
		}

		// LOOP THROUGH THE EXCEL HEADER LIST, SET THE VALUE & STYLING TO THE CELL.
		for (int i = 0; i < excelHeaderList2.size(); ++i) {
			Cell cell = headerRow2.createCell(i);
			cell.setCellValue(excelHeaderList2.get(i));
			cell.setCellStyle(headerCellStyle);
		}

		Cell cell = sheet.getRow(0).getCell(0);
		cell.setCellValue("MPOS EMI CONFIGURATION");
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 7));
		Cell cell2 = sheet.getRow(0).getCell(8);
		cell2.setCellValue("TRANSACTION TYPE CONFIGURATION");
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 8, 11));
		Cell cell3 = sheet.getRow(0).getCell(12);
		cell3.setCellValue("VAS EMI CONFIGURATION");
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 12, 15));

		return workbook;

	}

	/**
	 * {@link #getHeaderCellStyle(Workbook)} is responsible to returning the header
	 * cell style that will be used to set the header font and color for emi upload
	 * excel response.
	 * 
	 * @param workbook
	 * @return {@link CellStyle}
	 */
	private CellStyle getHeaderCellStyle(Workbook workbook) {
		Font headerFont = workbook.createFont();

		headerFont.setBold(true);
		headerFont.setFontHeightInPoints((short) 13);
		headerFont.setColor(IndexedColors.BLACK.getIndex());

		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFont(headerFont);
		headerCellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		headerCellStyle.setBorderBottom(BorderStyle.THIN);
		headerCellStyle.setBorderRight(BorderStyle.THIN);
		headerCellStyle.setBorderLeft(BorderStyle.THIN);
		headerCellStyle.setBorderTop(BorderStyle.THIN);
		return headerCellStyle;
	}

}
