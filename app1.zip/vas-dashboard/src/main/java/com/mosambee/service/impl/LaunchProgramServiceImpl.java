package com.mosambee.service.impl;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mosambee.bean.ActiveProgramBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.LaunchProgramDao;
import com.mosambee.service.LaunchProgramService;
import com.mosambee.transformer.LaunchProgramTransformer;

/**
 * LaunchProgramServiceImpl class implementing {@link LaunchProgramService}
 * specification.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 20-December-2019
 */
@Service("launchProgramService")
public class LaunchProgramServiceImpl implements LaunchProgramService {

	private static final Logger log = LogManager.getLogger(LaunchProgramServiceImpl.class);

	@Autowired
	LaunchProgramDao dao;

	@Autowired
	LaunchProgramTransformer transformer;

	/**
	 * getActiveProgramBean(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request & then
	 * calling the DAO to get those values.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return DataTablesResponse of ActiveProgramBean
	 */
	@Override
	public DataTablesResponse<ActiveProgramBean> getActiveProgramList(DataTablesRequest dtRequest) {
		
		// GET THE COLUMN NAME FROM COLUMN INDEX
		int orderingColumnIndex = dtRequest.getOrder().get(0).getColumn();
		String orderingColumnName = getOrderingColumnName(orderingColumnIndex);
		log.info("orderingColumnIndex: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);

		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ACTIVE PROGRAMS
		Map<String, String> searchMap = transformer.transformProgramDataTableRequest(dtRequest);
		log.info("size of searchMap: {}", searchMap.size());
		return dao.getActiveProgramList(dtRequest, orderingColumnName, searchMap);
		
	}

	/**
	 * getOrderingColumnName(...) method is responsible for returning
	 * orderingColumnName when it is provided with orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnName(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.PROGRAM_NAME.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.PROGRAM_CODE.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.PROGRAM_PRIORITY.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.PROGRAM_START_TIME.get();
			break;
		case 4:
			orderingColumnName = ColumnNames.PROGRAM_END_TIME.get();
			break;
		case 5:
			orderingColumnName = ColumnNames.PROGRAM_DESCRIPTION.get();
			break;
		default:
			orderingColumnName = ColumnNames.PROGRAM_NAME.get();
			break;
		}

		return orderingColumnName;
	}

}
