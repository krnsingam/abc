package com.mosambee.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.poifs.eventfilesystem.POIFSReader;
import org.apache.poi.poifs.filesystem.OfficeXmlFileException;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.mosambee.constants.BulkUploadCategory;
import com.mosambee.properties.ExcelCommonProperties;
import com.mosambee.properties.ExcelHeaderProperties;
import com.mosambee.service.ExcelService;
import com.mosambee.util.MacroListener;

/**
 * ExcelServiceImpl consists of all the operations needs to process and extract
 * data from the excel files.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 24-December-2019
 */
@Repository("excelService")
public class ExcelServiceImpl implements ExcelService {

	private static final Logger log = LogManager.getLogger(ExcelServiceImpl.class);
	private static final DataFormatter dataFormatter = new DataFormatter();

	@Autowired
	ExcelHeaderProperties excelHeaderProperties;

	@Autowired
	ExcelCommonProperties excelCommonProperties;

	/**
	 * Handle nullpointer exception in case exception occurs here
	 */
	@Override
	public Workbook getWorkbookFromMultipartFile(MultipartFile file) {
		Workbook workbook = null;

		try (InputStream inputStream = file.getInputStream()) {
			workbook = WorkbookFactory.create(inputStream);
		} catch (Exception e) {
			log.error("Exeption occurred while getWorkBookFromMultipartFile(): {}", e);
		}

		return workbook;
	}

	/**
	 * Check for presence of embedded objects in the workbook that we are processing
	 * via bulk upload.
	 * 
	 * @param workbook Workbook that we are getting from the bulk upload.
	 * @return boolean true if the workbook has embedded objects.
	 */
	@Override
	public boolean checkForEmbeddedObjects(Workbook workbook) {
		boolean check = true;
		try {
			HSSFWorkbook hssfWorkbook = (HSSFWorkbook) workbook;
			if (!hssfWorkbook.getAllEmbeddedObjects().isEmpty()) {
				check = false;
			}
		} catch (ClassCastException e) {
			log.error(e.getMessage());
			XSSFWorkbook xssfWorkbook = (XSSFWorkbook) workbook;
			try {
				if (!xssfWorkbook.getAllEmbeddedParts().isEmpty()) {
					return false;
				}
			} catch (OpenXML4JException e1) {
				log.error(e1.getMessage());
				check = false;
			}
		}
		return check;
	}

	/**
	 * @param file MultipartFile which we are getting in the bulk upload.
	 * @return boolean true if the excel has macros or VB script.
	 */
	@Override
	public boolean checkForMacrosAndVbScript(MultipartFile file) {

		boolean check = false;

		POIFSReader r = new POIFSReader();
		MacroListener macroListener = new MacroListener();
		try {
			InputStream inputStream = file.getInputStream();
			r.read(inputStream);
		} catch (IOException e) {
			check = true;
			log.error(e.getMessage());
		} catch (OfficeXmlFileException e) {
			check = true;
			log.error("Please use latest version of office excel");
		}

		if (macroListener.isMacroOrVbScriptDetected()) {
			return true;
		}
		return check;

	}

	/**
	 * Validation method to validate the workbook header that we are getting in bulk
	 * upload corresponding to the header list we have specified in the
	 * configuration file.
	 * 
	 * @param workbook           Workbook that we are getting from the bulk upload,
	 * @param bulkUploadCategory is a constant that we are getting from the
	 *                           ExcelConstants file.
	 * @return boolean true if headers passes the validation
	 */
	@Override
	public boolean validateHeader(Workbook workbook, String bulkUploadCategory) {

		// Getting the excel header list from the configuration, corresponding to the
		// bulkUploadCategory.
		List<String> excelHeaderList = null;
		log.info("bulkUploadCategory : {}", bulkUploadCategory);
		switch (bulkUploadCategory) {
		case BulkUploadCategory.PROGRAM:
			excelHeaderList = excelHeaderProperties.getProgramBulkUploadHeaders().subList(0, 7);
			break;
		case BulkUploadCategory.ENQUIRY_REPORTING:
			excelHeaderList = excelHeaderProperties.getEnquiryReportingHeaders().subList(0, 8);
			break;
		case BulkUploadCategory.MID_DOWNLOAD:
			excelHeaderList = excelHeaderProperties.getBankMidDownloadHeaders().subList(0, 5);
			break;
		case BulkUploadCategory.MID_BULK_UPLOAD:
			excelHeaderList = excelHeaderProperties.getMidBulkUploadHeaders().subList(0, 3);
			break;
		case BulkUploadCategory.MAPPING_BULK_UPLOAD:
			excelHeaderList = excelHeaderProperties.getMappingBulkUploadHeaders().subList(0, 4);
			break;
		case BulkUploadCategory.KEY_BULK_UPLOAD:
			excelHeaderList = excelHeaderProperties.getKeyBulkUploadHeaders().subList(0, 4);
			break;
		case BulkUploadCategory.INSTANT_MID_UPLOAD:
			excelHeaderList = excelHeaderProperties.getInstantMidUploadHeaders().subList(0, 5);
			break;
		case BulkUploadCategory.EMI_BULK_UPLOAD:
			excelHeaderList = excelHeaderProperties.getEmiBulkUploadHeaders().subList(0, 5);
			break;
		case BulkUploadCategory.EMI_CONVERSION_UPLOAD:
			excelHeaderList = excelHeaderProperties.getEmiConversionUploadHeaders().subList(0, 4);
			break;		
		case BulkUploadCategory.EMI_FIRST_UPLOAD:
			excelHeaderList = excelHeaderProperties.getEmiFirstUploadHeaders().subList(0, 15);
			break;	
		case BulkUploadCategory.EMI_UPLOAD:
			excelHeaderList = excelHeaderProperties.getEmiUploadHeaders().subList(0, 15);
			break;
		case BulkUploadCategory.EMI_FIRST_ROW_UPLOAD:
			excelHeaderList = excelHeaderProperties.getFirstEmiUploadHeaders().subList(0, 3);
			break;
		case BulkUploadCategory.SBI_MID_UPLOAD:
			excelHeaderList = excelHeaderProperties.getSbiMidUploadHeaders().subList(0, 3);
			break;
		case BulkUploadCategory.SBI_TID_UPLOAD:
			excelHeaderList = excelHeaderProperties.getSbiTidUploadHeaders().subList(0, 5);
			break;
		default:
			break;
		}

		// validating the excelHeaderList.
		if (excelHeaderList == null) {
			log.error("Unable to get the excel header");
			return false;
		}

		return validateHeaderContents(workbook, excelHeaderList);
	}

	/**
	 * Validating the excel header contents with the contents coming from the
	 * configuration.
	 *
	 * @param workbook        Workbook instance that we are getting in bulk upload.
	 * @param excelHeaderList List of excel headers that we have specified in the
	 *                        configuration file.
	 * @return boolean returns true if contents of workbook header is equal to the
	 *         excelHeaderList, else it will return false.
	 */
	@Override
	public boolean validateHeaderContents(Workbook workbook, List<String> excelHeaderList) {

		// Getting the workbookHeaderList from that workbook that is coming from bulk
		// upload.
		List<String> workbookHeaderList = new ArrayList<>();

		Iterator<Row> rowIterator = workbook.getSheetAt(0).iterator();

		if (rowIterator.hasNext()) {
			Iterator<Cell> cellIterator = rowIterator.next().iterator();

			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				workbookHeaderList.add(dataFormatter.formatCellValue(cell));
			}
		}

		// if validation of size of excel header fails, we are returning the response as
		// false.
		if (!validateSizeOfExcelHeader(workbookHeaderList, excelHeaderList))
			return false;

		// Checking the workbook contents if they are equal or not.
		boolean flag = false;

		for (int i = 0; i < workbookHeaderList.size(); ++i) {
			if (!workbookHeaderList.get(i).equals(excelHeaderList.get(i))) {
				log.error("Content not equal at index: {}, workBookList content: {}, excelHeader content: {}", i,
						workbookHeaderList.get(i), excelHeaderList.get(i));
				log.error("size1: {}, size2: {}", workbookHeaderList.get(i).length(), excelHeaderList.get(i).length());
				flag = true;
				break;
			}
		}

		return !flag;
	}

	/**
	 * Validating the number of excel header length versus the size coming from
	 * configuration.
	 * 
	 * @param workbookHeaderList Header of workbook we are getting via bulk upload.
	 * @param excelHeaderList    We are reading this from configuration file.
	 * @return boolean returns true if column length in workbook is equal to the
	 *         size of excelHeaders specified in properties file, else returns
	 *         false.
	 */
	@Override
	public boolean validateSizeOfExcelHeader(List<String> workbookHeaderList, List<String> excelHeaderList) {
		if (workbookHeaderList.size() != excelHeaderList.size()) {
			log.info("workbookHeaderList size: {}, excelHeader list size: {}", workbookHeaderList.size(),
					excelHeaderList.size());
			log.error("Size of workbookHeaderList and excelHeaderList are not equal");
			return false;
		}
		log.info("validateSizeOfExcelHeader() is successful.");
		return true;
	}

	/**
	 * We are extracting the extension of file from the MultipartFile and we are
	 * validating it against the list of extensions that we are getting from the
	 * properties file.
	 * 
	 * @param file MultipartFile that we are getting in bulk upload.
	 * @return boolean
	 */
	@Override
	public boolean validateExtension(MultipartFile file) {
		List<String> validExtensionList = excelCommonProperties.getValidExtensionList();
		String extension = FilenameUtils.getExtension(file.getOriginalFilename());
		log.info("Extension of file is: {}", extension);
		return validExtensionList.contains(extension);
	}

	/**
	 * {@link #createHeaderRow(Workbook, String)} is responsible to filter out
	 * appropriate excelHeaderList from the bulkUploadCategory, i.e.
	 * {@link BulkUploadCategory} and then call the
	 * {@link #setWorkbookHeaderStyle(Workbook, List)} to set the appropriate style
	 * to the header and then return the workbook.
	 * 
	 * @param workbook
	 * @param bulkUploadCategory
	 * @return {@link Workbook}
	 */
	@Override
	public Workbook createHeaderRow(String bulkUploadCategory) {

		List<String> excelHeaderList = null;
		log.info("BulkUploadCategory is: {}", bulkUploadCategory);

		switch (bulkUploadCategory) {
		case BulkUploadCategory.PROGRAM:
			excelHeaderList = excelHeaderProperties.getProgramBulkUploadHeaders();
			break;
		case BulkUploadCategory.TRANSACTION_REPORT:
			excelHeaderList = excelHeaderProperties.getTransactionReportHeaders();
			break;
		case BulkUploadCategory.MERCHANT_MAPPING:
			excelHeaderList = excelHeaderProperties.getMerchantMappingHeaders();
			break;
		case BulkUploadCategory.MERCHANT_KEY:
			excelHeaderList = excelHeaderProperties.getMerchantKeyHeaders();
			break;
		case BulkUploadCategory.ACQUIRER_LIST:
			excelHeaderList = excelHeaderProperties.getAcquirerListHeaders();
			break;
		case BulkUploadCategory.ENQUIRY_REPORTING:
			excelHeaderList = excelHeaderProperties.getEnquiryReportingHeaders();
			break;
		case BulkUploadCategory.MID_DOWNLOAD:
			excelHeaderList = excelHeaderProperties.getBankMidDownloadHeaders();
			break;
		case BulkUploadCategory.MID_BULK_UPLOAD:
			excelHeaderList = excelHeaderProperties.getMidBulkUploadHeaders();
			break;
		case BulkUploadCategory.MAPPING_BULK_UPLOAD:
			excelHeaderList = excelHeaderProperties.getMappingBulkUploadHeaders();
			break;
		case BulkUploadCategory.KEY_BULK_UPLOAD:
			excelHeaderList = excelHeaderProperties.getKeyBulkUploadHeaders();
			break;
		case BulkUploadCategory.INSTANT_MID_UPLOAD:
			excelHeaderList = excelHeaderProperties.getInstantMidUploadHeaders();
			break;
		case BulkUploadCategory.EMI_BULK_UPLOAD:
			excelHeaderList = excelHeaderProperties.getEmiBulkUploadHeaders();
			break;
		case BulkUploadCategory.EMI_SEARCH_LIST:
			excelHeaderList = excelHeaderProperties.getEmiSearchListHeaders();
			break;
		case BulkUploadCategory.EMI_CONVERSION_UPLOAD:
			excelHeaderList = excelHeaderProperties.getEmiConversionUploadHeaders();
			break;
		case BulkUploadCategory.SBI_MID_UPLOAD:
			excelHeaderList = excelHeaderProperties.getSbiMidUploadHeaders();
			break;
		case BulkUploadCategory.SBI_TID_UPLOAD:
			excelHeaderList = excelHeaderProperties.getSbiTidUploadHeaders();
			break;

		case BulkUploadCategory.EMI_UPLOAD:
			excelHeaderList = excelHeaderProperties.getEmiUploadHeaders();
			break;
		case BulkUploadCategory.EMI_FIRST_ROW_UPLOAD:
			excelHeaderList = excelHeaderProperties.getFirstEmiUploadHeaders();
			break;
		case BulkUploadCategory.EMI_FIRST_UPLOAD:
			excelHeaderList = excelHeaderProperties.getEmiFirstUploadHeaders();
			break;
		case BulkUploadCategory.NETWORK_MESSAGES:
			excelHeaderList = excelHeaderProperties.getNetworkMessagesHeaders();
			break;
		case BulkUploadCategory.BUSINESS_MIS:
			excelHeaderList = excelHeaderProperties.getBusinessMisDownloadHeaders();
			break;
		default:
			break;
		}

		if (null == excelHeaderList) {
			log.error("Unable to get the header from the properties file");
			return null;
		}

		Workbook workbook = new XSSFWorkbook();
		return setWorkbookHeaderStyle(workbook, excelHeaderList);

	}

	/**
	 * {@link #setWorkbookHeaderStyle(Workbook, List)} is responsible to set the
	 * excelHeaderList to the workbook row along with the CellStyle obtained from
	 * {@link #getHeaderCellStyle(Workbook)}
	 * 
	 * @param workbook
	 * @param excelHeaderList
	 * @return {@link Workbook}
	 */
	private Workbook setWorkbookHeaderStyle(Workbook workbook, List<String> excelHeaderList) {
		Sheet sheet = workbook.createSheet();
		Row headerRow = sheet.createRow(0);

		// GET THE HEADER CELL STYLING VALUE
		CellStyle headerCellStyle = getHeaderCellStyle(workbook);

		// LOOP THROUGH THE EXCEL HEADER LIST, SET THE VALUE & STYLING TO THE CELL.
		for (int i = 0; i < excelHeaderList.size(); ++i) {
			Cell cell = headerRow.createCell(i);
			cell.setCellValue(excelHeaderList.get(i));
			cell.setCellStyle(headerCellStyle);
		}

		return workbook;

	}

	/**
	 * {@link #getHeaderCellStyle(Workbook)} is responsible to returning the header
	 * cell style that will be used to set the header font and color for bulk upload
	 * excel response.
	 * 
	 * @param workbook
	 * @return {@link CellStyle}
	 */
	private CellStyle getHeaderCellStyle(Workbook workbook) {
		Font headerFont = workbook.createFont();

		headerFont.setBold(true);
		headerFont.setFontHeightInPoints((short) 13);
		headerFont.setColor(IndexedColors.BLACK.getIndex());

		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFont(headerFont);
		headerCellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		headerCellStyle.setBorderBottom(BorderStyle.THIN);
		headerCellStyle.setBorderRight(BorderStyle.THIN);
		headerCellStyle.setBorderLeft(BorderStyle.THIN);
		headerCellStyle.setBorderTop(BorderStyle.THIN);
		return headerCellStyle;
	}

	/**
	 * {@link #autoSizeExcel(Workbook)} is responsible for looping through all the
	 * columns in the first row and automatically resize them according to the
	 * content length inside them.
	 * 
	 * @param workbook
	 * @return void
	 */
	@Override
	public void autoSizeExcel(Workbook workbook) {
		Sheet sheet = workbook.getSheetAt(0);
		int noOfColumns = sheet.getRow(0).getLastCellNum();
		for (int i = 0; i < noOfColumns; ++i) {
			sheet.autoSizeColumn(i);
		}
	}

	/**
	 * {@link #getResourceFromWorkbook(Workbook)} convert the {@link Workbook} to
	 * {@link Resource} so that it can be send over the network as response to the
	 * web-page.
	 * 
	 * @param responseWorkbook {@link Workbook}
	 * @return {@link Resource}
	 */
	@Override
	public Resource getResourceFromWorkbook(Workbook responseWorkbook) {
		try {
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			responseWorkbook.write(byteArrayOutputStream);
			ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
			return new InputStreamResource(byteArrayInputStream);
		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}

}
