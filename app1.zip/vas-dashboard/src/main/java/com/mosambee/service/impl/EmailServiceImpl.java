package com.mosambee.service.impl;

import java.nio.charset.StandardCharsets;
import java.util.Date;

import javax.mail.internet.MimeMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import com.mosambee.bean.EmailBean;
import com.mosambee.bean.ForgotPasswordParams;
import com.mosambee.constants.CommonConstants;
import com.mosambee.service.EmailService;

/**
 * @author karan.singam
 * @version 1.0
 * @since 30-January-2020
 */
@Service("emailService")
public class EmailServiceImpl implements EmailService {

	@Autowired
	private JavaMailSender javaMailSender;

	@Autowired
	private SpringTemplateEngine templateEngine;

	private static final Logger log = LogManager.getLogger(EmailServiceImpl.class);

	/**
	 * This method is used for sending email when all the conditions are satisfied.
	 * On call it triggers an email to be used as per needed.
	 * 
	 * @param EmailBean
	 * @return boolean : true.
	 */
	@Override
	public boolean sendEmail(EmailBean email) {

		try {
			SimpleMailMessage msg = new SimpleMailMessage();
			Date dt = new Date();
			msg.setFrom("noreply@mosambee.in");
			msg.setSentDate(dt);
			msg.setTo(email.getToMail());
			msg.setSubject(email.getSubject());
			msg.setText(email.getContent());
			
			javaMailSender.send(msg);
			return true;
		} catch (Exception e) {
			log.info(e.getMessage());
			return false;
		}

	}
	
	/**
	 * This method is used for sending email when all the conditions are satisfied.
	 * On call it triggers an email to be used as per needed.
	 * 
	 * @param EmailBean
	 * @return boolean : true.
	 */
	@Override
	public boolean sendHtmlEmail(EmailBean email) {

		try {
			Date dt = new Date();

            MimeMessage mail = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mail, true);
            helper.setFrom("noreply@mosambee.in");
            helper.setSentDate(dt);
            helper.setTo(email.getToMail());
            helper.setSubject(email.getSubject());
            helper.setText(email.getContent(), true);
            javaMailSender.send(mail);
			
			return true;
		} catch (Exception e) {
			log.info(e.getMessage());
			return false;
		}

	}

	@Override
	public boolean sendForgotPasswordEmail(ForgotPasswordParams forgotPasswordParams, String newPassword) {
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		try {
			MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage,
					MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());
			Context context = new Context();
			context.setVariable("firstName", forgotPasswordParams.getFirstName());
			context.setVariable("username", forgotPasswordParams.getUsername());
			context.setVariable("password", newPassword);

			String html = templateEngine.process("forgot-password", context);

			mimeMessageHelper.setTo(forgotPasswordParams.getUsername());
			mimeMessageHelper.setText(html, true);
			mimeMessageHelper.setSubject(CommonConstants.PASSWORD_CHANGED.get());
			mimeMessageHelper.setFrom(CommonConstants.NO_REPLY_MOSAMBEE_EMAIL.get());

			javaMailSender.send(mimeMessage);
			return true;
		} catch (Exception e) {
			log.error("{}", e);
		}
		return false;
	}

}
