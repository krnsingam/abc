package com.mosambee.service;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

/**
 * This class provides specification for {@link SbiTidUploadServiceImpl}
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 */
public interface SbiTidUploadService {

	Resource processSbiEmiUploadExcel(MultipartFile file);
	
	Resource getSbiTidUploadFormat();

}
