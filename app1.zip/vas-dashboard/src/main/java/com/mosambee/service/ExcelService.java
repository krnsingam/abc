package com.mosambee.service;

import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import com.mosambee.service.impl.ExcelServiceImpl;

/**
 * ExcelService defining the specification for {@link ExcelServiceImpl}
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 21-December-2019
 */
public interface ExcelService {

	Workbook getWorkbookFromMultipartFile(MultipartFile file);

	boolean checkForEmbeddedObjects(Workbook workbook);

	boolean checkForMacrosAndVbScript(MultipartFile file);

	boolean validateHeader(Workbook workbook, String bulkUploadCategory);

	boolean validateHeaderContents(Workbook workbook, List<String> excelHeader);

	boolean validateSizeOfExcelHeader(List<String> workbookList, List<String> excelHeaders);

	boolean validateExtension(MultipartFile file);

	Workbook createHeaderRow(String bulkUploadCategory);
	
	void autoSizeExcel(Workbook workbook);
	
	Resource getResourceFromWorkbook(Workbook responseWorkbook);

}
