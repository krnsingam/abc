package com.mosambee.service.impl;

import java.util.HashMap;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import com.mosambee.bean.CreateAPIGroup;
import com.mosambee.bean.CustomUser;
import com.mosambee.bean.EmailBean;
import com.mosambee.bean.ListOfAPIGroup;
import com.mosambee.bean.MidApiGroupDaetailBean;
import com.mosambee.bean.MidTidBean;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.UpdateAPIPaswordConfigRequestFromList;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.APIPasswordConfigConstants;
import com.mosambee.constants.ColumnNames;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ViewLayer;
import com.mosambee.dao.APIPasswordConfigDao;
import com.mosambee.service.APIPasswordConfigService;
import com.mosambee.service.EmailService;
import com.mosambee.transformer.APIPasswordConfigTransformer;
import com.mosambee.util.IOCLEncUtils;
import com.mosambee.util.MidBulkUploadCall;
import com.mosambee.validator.APIPasswordConfigValidator;

/**
 * This class provide implementations for all methods declared in
 * {@link APIPasswordConfigService}. This class is basically provide
 * functionality for actual request processing. All requests which are caught in
 * {@link APIPasswordConfigController} are transfered here for processing.
 * Basically it is implement business logics.
 * 
 * @author mandar.chaudhari
 * @version 1.0
 */
@Service
public class APIPasswordConfigServiceImpl implements APIPasswordConfigService {

	private static final Logger log = LogManager.getLogger(APIPasswordConfigServiceImpl.class);

	@Autowired
	@Qualifier("apiPasswordConfigValidator")
	private APIPasswordConfigValidator apiPasswordConfigValidator;

	@Autowired
	@Qualifier("apiPasswordConfigDaoImpl")
	private APIPasswordConfigDao apiPasswordConfigDao;

	@Autowired
	@Qualifier("apiPasswordConfigTransformer")
	private APIPasswordConfigTransformer apiPasswordConfigTransformer;

	@Autowired
	EmailService emailService;

	private static final String RECORD_ID = "recordId";
	
	private static final String STATUS = "Division status needs to be updated ";
	
	byte updateDivStatus = 0;
 
	/**
	 * This method returns id of user which are currently logged in.
	 * 
	 * @return long : Returns user Id.
	 */
	private long getIdOfLoggedInUser() {
		long createdBy;
		// Get logged in user info.
		CustomUser customUser = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Map<String, String> myMap = customUser.getMyMap(); // Store logged in user info into hash map.

		log.info("myMap contents: {}", myMap);

		createdBy = Long.parseLong(myMap.get("id"));
		return createdBy;
	}

	/**
	 * This method is used to call validation methods on {@link CreateAPIGroup}.
	 * Also this method checks that bean is validated or not if bean is validated it
	 * allows to insert record in database by calling
	 * {@link #createAPIGroup(createAPIGroup, responseBean, id)} of
	 * {@link APIPasswordConfigDao}. If bean failed in validation then it set
	 * {@link ResponseBean} class field "operationStatus" to 400, If data is
	 * successfully inserted then set "updateRequest" to "True" and
	 * "operationStatus" to 200 otherwise set "operationStatus" to 400 and
	 * "updateRequest" to "False".
	 * 
	 * @param responseBean   : Expect bean of "{@link ResponseBean}" which is used
	 *                       to set operation status message. We can use this to to
	 *                       render data related to status message to jsp.
	 * @param createAPIGroup : Expect bean of "{@link CreateAPIGroup}" from which
	 *                       data should be store.
	 * @return void
	 */
	@Override
	public ResponseBean processCreateAPIGroupData(CreateAPIGroup createAPIGroup, ResponseBean responseBean) {

		apiPasswordConfigValidator.validateCreateAPIGroupData(createAPIGroup); // This call is sued to validate
																				// "createAPIGroup" bean.
		boolean status;
		if (createAPIGroup.isValidate()) // If validation succeed then insert record.
		{
			apiPasswordConfigTransformer.transformMPOSAPIPasswordForDataInserting(createAPIGroup);
			responseBean = apiPasswordConfigDao.createAPIGroup(createAPIGroup, getIdOfLoggedInUser());
			status = responseBean.isUpdateRequest();
			long id = Long.parseLong(responseBean.getData().get(RECORD_ID).toString());

			if (status) // Checks that insert record operation successful or not.
			{
				if(createAPIGroup.getDivisionStatus()!=0) {
				// Mid call.
				boolean result = midApiEmailCall(createAPIGroup, id);
				log.info("Mid call succesful : {}", result);
				}

				responseBean.setUpdateRequest(true);
				responseBean.setOperationStatus(200);
				responseBean.setAction(ViewLayer.UPDATE_API_GROUP_ACTION.get()); // Set form action to update record.

			} else {

				responseBean.setUpdateRequest(false);
				responseBean.setOperationStatus(400);
				responseBean.setAction(ViewLayer.CREATE_API_GROUP_ACTION.get()); // Set form action to create record.
			}
			log.info("createAPIGroup validation status : {} ", createAPIGroup.isValidate());
			return responseBean;
		} else {
			responseBean.setMsg("Sorry, Data is not valid.");
			responseBean.setOperationStatus(400);
			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put(RECORD_ID, 0);
			responseBean.setAction(ViewLayer.CREATE_API_GROUP_ACTION.get());
			log.info("createAPIGroup validation status : {} ", createAPIGroup.isValidate());
			return responseBean;
		}

	}

	/**
	 * This method is used to call validation methods on {@link CreateAPIGroup}.
	 * Also this method checks that bean is validated or not if bean is validated it
	 * allows to update record in database by calling
	 * {@link #updateAPIGroup(createAPIGroup, responseBean, id)} of
	 * {@link APIPasswordConfigDao}. If bean failed in validation then it set
	 * {@link ResponseBean} class field "operationStatus" to 400, If data is
	 * successfully inserted then set "updateRequest" to "True" and
	 * "operationStatus" to 200 otherwise set "operationStatus" to 400 and
	 * "updateRequest" to "False".
	 * 
	 * @param responseBean   : Expect bean of "{@link ResponseBean}" which is used
	 *                       to set operation status message. We can use this to to
	 *                       render data related to status message to jsp.
	 * @param createAPIGroup : Expect bean of "{@link CreateAPIGroup}" from which
	 *                       data should be store.
	 * @return void
	 */
	@Override
	public void processUpdateAPIGroupData(CreateAPIGroup createAPIGroup, ResponseBean responseBean) {

		apiPasswordConfigValidator.validateCreateAPIGroupData(createAPIGroup); // This call is used to validate
																				// "createAPIGroup" bean.
		if (createAPIGroup.isValidate()) // Check that bean validation successful or not.
		{
			boolean status=false;
			responseBean.setUpdateRequest(true);
			responseBean.setAction(ViewLayer.UPDATE_API_GROUP_ACTION.get()); // Set form action to update record.
			log.info("update div flag : {}",updateDivStatus);
			if(createAPIGroup.getDivisionStatus()!=0 || updateDivStatus !=0) {
				apiPasswordConfigTransformer.transformMPOSAPIPasswordForDataUpdating(createAPIGroup);
				status = apiPasswordConfigDao.updateAPIGroup(createAPIGroup, responseBean, getIdOfLoggedInUser());
			}else {
				responseBean.setMsg(STATUS);
			}
			log.info("falg :{}", createAPIGroup.getFlag());

			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put(RECORD_ID, createAPIGroup.getId());
			if (status) // Checks that Update record operation successful or not.
			{
				if(createAPIGroup.getDivisionStatus()!=0) {
					// Mid call.
					boolean result = midApiEmailCall(createAPIGroup, 0);
					log.info("Mid call succesful : {}", result);
				}
				
				responseBean.setOperationStatus(200);
			} else {
				responseBean.setOperationStatus(400);
			}
		} else {
			responseBean.setMsg("Sorry, Data is not valid.");
			responseBean.setOperationStatus(400);
		}
		log.info("returning from processUpdateAPIGroupData {} ", createAPIGroup.isValidate());
	}

	/**
	 * getListOfAPIGroup(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request & then
	 * calling the DAO to get those values.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return DataTablesResponse of ActiveProgramBean
	 */
	@Override
	public DataTablesResponse<ListOfAPIGroup> getListOfAPIGroup(DataTablesRequest dtRequest) {

		// GET THE COLUMN NAME FROM COLUMN INDEX
		int orderingColumnIndex = dtRequest.getOrder().get(0).getColumn();
		String orderingColumnName = getOrderingColumnName(orderingColumnIndex);
		log.info("orderingColumnIndex: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);

		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ACTIVE PROGRAMS
		Map<String, String> searchMap = apiPasswordConfigTransformer.transformListOfAPIGroup(dtRequest);
		log.info("size of searchMap: {}", searchMap.size());
		return apiPasswordConfigDao.getListOfAPIGroup(dtRequest, orderingColumnName, searchMap);

	}

	/**
	 * getOrderingColumnName(...) method is responsible for returning
	 * orderingColumnName when it is provided with orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnName(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.ID.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.API_DIVISION_NAME.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.API_DIVISION_CODE.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.MPOS_API_PASSWORD.get();
			break;
		case 4:
			orderingColumnName = ColumnNames.API_URL_1.get();
			break;
		case 5:
			orderingColumnName = ColumnNames.API_URL_2.get();
			break;
		case 6:
			orderingColumnName = ColumnNames.DIVISION_REFERENCE_1.get();
			break;
		case 7:
			orderingColumnName = ColumnNames.DIVISION_REFERENCE_2.get();
			break;
		case 8:
			orderingColumnName = ColumnNames.DIVISION_REFERENCE_3.get();
			break;
		case 9:
			orderingColumnName = ColumnNames.DIVISION_REFERENCE_4.get();
			break;
		case 10:
			orderingColumnName = ColumnNames.DIVISION_STATUS.get();
			break;

		default:
			orderingColumnName = ColumnNames.ID.get();
			break;
		}

		return orderingColumnName;
	}

	/**
	 * getListOfAPIGroup(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request & then
	 * calling the DAO to get those values.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return DataTablesResponse of ActiveProgramBean
	 */
	@Override
	public DataTablesResponse<MidTidBean> listMidTid(DataTablesRequest dtRequest, int id) {

		// GET THE COLUMN NAME FROM COLUMN INDEX
		int orderingColumnIndex = dtRequest.getOrder().get(0).getColumn();
		String orderingColumnName = getOrderingColumnNameMidTid(orderingColumnIndex);
		log.info("orderingColumnIndex: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);

		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ACTIVE PROGRAMS
		Map<String, String> searchMap = apiPasswordConfigTransformer.transformMidTid(dtRequest);
		log.info("size of searchMap: {}", searchMap.size());
		return apiPasswordConfigDao.listMidTid(dtRequest, orderingColumnName, searchMap, id);

	}

	/**
	 * getOrderingColumnNameMidTid(...) method is responsible for returning
	 * orderingColumnName when it is provided with orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnNameMidTid(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.MID_TID_ID.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.MID_DETAIL.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.DIVISION_CODE_DETAIL.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.TID_DETAIL.get();
			break;

		default:
			orderingColumnName = ColumnNames.MID_TID_ID.get();
			break;
		}

		return orderingColumnName;
	}

	/**
	 * This method is basically calling {@link #getAPIGroupDataById()} of
	 * {@link APIPasswordConfigDao} if it return "True" then set
	 * {@link ResponseBean} "operationStatus" to 200 and "action" to "update action"
	 * otherwise set "operationStatus" to 400.
	 */
	@Override
	public void processGetAPIGroupDataById(UpdateAPIPaswordConfigRequestFromList updateAPIPaswordConfigRequestFromList,
			CreateAPIGroup createAPIGroup, ResponseBean responseBean) {
		responseBean.setData(new HashMap<String, Object>());
		responseBean.getData().put(RECORD_ID, createAPIGroup.getId()); // This id will render on jsp page which will be
																		// used for update APIPasswordConfig request.
		boolean status = apiPasswordConfigDao.getAPIGroupDataById(updateAPIPaswordConfigRequestFromList, createAPIGroup,
				responseBean); // Fetch APIPasswordConfig details by passing
								// updateAPIPaswordConfigRequestFromList.
		updateDivStatus = createAPIGroup.getDivisionStatus();
		log.info("update div flag : {}",updateDivStatus);
		if (status) {
			responseBean.setOperationStatus(200);
			responseBean.setAction(ViewLayer.UPDATE_API_GROUP_ACTION.get());
			responseBean.getData().put("breadCrumb", true);
			responseBean.setUpdateRequest(true);
		} else {
			responseBean.setOperationStatus(400);
		}

	}

	/**
	 * midApiEmailCall() is responsible for calling mid api call and email call with
	 * all the data per id.
	 * 
	 * @param Long
	 * @param CreateAPIGroup
	 * @return boolean
	 */
	@Async
	public boolean midApiEmailCall(CreateAPIGroup createAPIGroup, long id) {

		if (id == 0) {
			id = createAPIGroup.getId();
		}

		// Mid Check Code
		try {
			if (id != 0 && createAPIGroup.getFlag() == 1
					&& (createAPIGroup.getApiURL1() != null || !createAPIGroup.getApiURL1().isEmpty())) {
				createAPIGroup.setApiUpdateStat(getMIDBulkDetail(id, createAPIGroup));
			} else if (id != 0 && (createAPIGroup.getApiURL2() != null || !createAPIGroup.getApiURL2().isEmpty())) {
				EmailBean email = new EmailBean();
				email.setToMail(createAPIGroup.getApiURL2());
				email.setSubject(APIPasswordConfigConstants.MSG_SUBJECT.get());
				email.setContent(setContent(createAPIGroup));
				createAPIGroup.setApiUpdateStat(emailService.sendEmail(email));
			}
			boolean result = apiPasswordConfigDao.updateApiEmailCall(createAPIGroup, id);
			log.info("Value is update in database : {}", result);
		} catch (Exception e) {
			log.info(e.getMessage());
		}

		return true;
	}

	/**
	 * getMIDBulkDetail() is responsible for calling mid api call with all the data
	 * per id.
	 * 
	 * @param Long
	 * @param CreateAPIGroup
	 * @return boolean
	 */
	public boolean getMIDBulkDetail(Long id, CreateAPIGroup createAPIGroup) {
		MidApiGroupDaetailBean bean = apiPasswordConfigDao.isAPIDetailsPresent(id);
		MidBulkUploadCall midBulk = new MidBulkUploadCall();
		bean.setMPosApiPassword(IOCLEncUtils.encrypt(createAPIGroup.getPassMpos(), bean.getDivRefNo1()));
		return midBulk.midCall(bean);
	}

	/**
	 * setContent() is responsible for setting message content as per requirement.
	 * 
	 * @param CreateAPIGroup
	 * @return String
	 */
	public String setContent(CreateAPIGroup createAPIGroup) {

		StringBuilder content = new StringBuilder(APIPasswordConfigConstants.MSG_CONTENT.get());
		if (createAPIGroup.getPassMpos() != null && !createAPIGroup.getPassMpos().isEmpty()) {
			content.append(APIPasswordConfigConstants.MSG_PASS.get()).append(createAPIGroup.getPassMpos());
		}
		return content.append(APIPasswordConfigConstants.MSG_REGARD.get())
				.append(APIPasswordConfigConstants.MSG_NAME.get()).toString();
	}

}
