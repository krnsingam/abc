package com.mosambee.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.mosambee.bean.CustomUser;
import com.mosambee.bean.OfflineKeyBean;
import com.mosambee.bean.OfflineMerchantTerminalSearchBean;
import com.mosambee.bean.OfflineMerchantsListBean;
import com.mosambee.bean.OfflineMerchantsSearchBean;
import com.mosambee.bean.OfflineTerminalListBean;
import com.mosambee.bean.OfflineTerminalSearchBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.OfflineMerchantsDao;
import com.mosambee.service.OfflineMerchantsService;
import com.mosambee.util.OfflineKeyGenerator;

import lombok.extern.log4j.Log4j2;

/**
 * OfflineMerchantsServiceImpl class implementing {@link OfflineMerchantsService}
 * specification.
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 01-April-2020
 */

@Log4j2
@Service("offlineMerchantsService")
public class OfflineMerchantsServiceImpl implements OfflineMerchantsService{

	@Autowired
	private OfflineMerchantsDao dao;
	
	/**
	 * getOfflineMerchantsList(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request & then
	 * calling the DAO to get those values.
	 * 
	 * @param dtRequest {@link OfflineMerchantsSearchBean}
	 * @return DataTablesResponse of OfflineMerchantsListBean
	 */
	@Override
	public DataTablesResponse<OfflineMerchantsListBean> getOfflineMerchantsList(OfflineMerchantsSearchBean dtRequest) {
		// getting column index
		int orderingColumnIndex = dtRequest.getDtRequest().getOrder().get(0).getColumn();
		//getting columnName based on column index
		
		String orderingColumnName = getOrderingColumnNameOfOfflineMerchantsList(orderingColumnIndex);
		log.info("orderingColumnIndexs: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);
		
		return dao.getOfflineMerchantsList(dtRequest, orderingColumnName);
		
	}
	
	/**
	 * getOrderingColumnNameOfOfflineMerchantsList (...) method is responsible for returning
	 * orderingColumnName of OfflineMerchantsListBean when it is provided with
	 * orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnNameOfOfflineMerchantsList(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		
		case 1:
			orderingColumnName = ColumnNames.OFFLINE_MERCHANTS_MERCHANTNAME.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.OFFLINE_MERCHANTS_NOOFTERMINALS.get();
			break;
		default:
			orderingColumnName = ColumnNames.OFFLINE_MERCHANTS_MERCHANTNAME.get();
			break;
		}

		return orderingColumnName;
	}

	/**
	 * getOfflineTerminalList(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request & then
	 * calling the DAO to get those values.
	 * 
	 * @param dtRequest {@link getOfflineTerminalList}
	 * @return DataTablesResponse of OfflineTerminalListBean
	 */
	@Override
	public DataTablesResponse<OfflineTerminalListBean> getOfflineTerminalList(OfflineTerminalSearchBean searchBean) {
		
		// getting column index
		int orderingColumnIndex = searchBean.getDtRequest().getOrder().get(0).getColumn();
				
		//getting columnName based on column index
				
		String orderingColumnName = getOrderingColumnNameOfOfflineTerminalList(orderingColumnIndex);
		log.info("orderingColumnIndexs: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);
				
		return dao.getOfflineTerminalList(searchBean , orderingColumnName);
	}
	
	/**
	 * getOrderingColumnNameOfOfflineTerminalList (...) method is responsible for returning
	 * orderingColumnName of OfflineMerchantsListBean when it is provided with
	 * orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnNameOfOfflineTerminalList(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		
		case 1:
			orderingColumnName = ColumnNames.OFFLINE_TERMINALS_TERMINALID.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.OFFLINE_TERMINALS_USERNAME.get();
			break;
		default:
			orderingColumnName = ColumnNames.OFFLINE_TERMINALS_OFFLINEKEY.get();
			break;
		}

		return orderingColumnName;
	}

	/**
	 * getOfflineMerchantTerminalList(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request & then
	 * calling the DAO to get those values.
	 * 
	 * @param dtRequest {@link OfflineMerchantTerminalSearchBean}
	 * @return DataTablesResponse of OfflineTerminalListBean
	 */
	@Override
	public DataTablesResponse<OfflineTerminalListBean> getOfflineMerchantTerminalList(OfflineMerchantTerminalSearchBean searchBean) {
		// getting column index
		int orderingColumnIndex = searchBean.getDtRequest().getOrder().get(0).getColumn();
						
		//getting columnName based on column index
						
		String orderingColumnName = getOrderingColumnNameOfOfflineTerminalList(orderingColumnIndex);
		log.info("orderingColumnIndexs: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);
						
		return dao.getOfflineMerchantTerminalList(searchBean , orderingColumnName);
			
	}
	
	/**
	 * getMerchantsTerminalForOfflineKeySet(...) is responsible for 
	 * calling the DAO layer by passing request parameter.
	 * 
	 * @param merchantId {@link Long}
	 */
	@Override
	public boolean getMerchantsTerminalForOfflineKeySet(long merchantId) {
		
		boolean setKey = true;
		List<OfflineKeyBean> list = dao.getMerchantsTerminalForOfflineKeySet(merchantId);
		
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String userId = user.getMyMap().get("id");
		long loginUserId = Long.parseLong(userId);
		try {
			for (OfflineKeyBean bean : list) {
				dao.bulkUpdateOfflineKey(bean.getMerchantId(), bean.getTableTerminalId(), OfflineKeyGenerator.getOfflineKey(), loginUserId);
			}
		}
		catch (Exception e) {
			log.error("Error occurred" + e.getMessage());
			setKey = false;
		}
		return setKey;
	}

	/**
	 * updateOfflineKey(...) is responsible for 
	 * calling the DAO layer by passing request parameters.
	 * 
	 * @param terminalId 	  {@link String}
	 * @param offlineKey 	  {@link String}
	 * @param createdUserId   {@link Long}
	 */
	@Override
	public int updateOfflineKey(String terminalId, String offlineKey, long createdUserId) {
		return dao.updateOfflineKey(terminalId, offlineKey, createdUserId);
	}


	
}
