package com.mosambee.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mosambee.bean.AddSbiDetailsMidBean;
import com.mosambee.bean.EditSbiDetailsBean;
import com.mosambee.bean.AddSbiDetailsTidBean;
import com.mosambee.bean.SBIEMIListBean;
import com.mosambee.bean.SBIEMISearchDataTableBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.SBIEMIDao;
import com.mosambee.service.SBIEMIService;
import com.mosambee.transformer.SBIEMITransformer;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service("sBIEMIService")
public class SBIEMIServiceImpl implements SBIEMIService {

	@Autowired
	private SBIEMIDao sBIEMIDaoDao;
	
	@Autowired
	private SBIEMITransformer sbiTransformer;
	

	@Override
	public String addSbiEmiDetails(AddSbiDetailsMidBean sbiFormBean, long userId) {

		log.info("inside addSbiEmiDetails() with userId: {}", userId);
		return sBIEMIDaoDao.addSBITransaction(sbiFormBean, userId);
	}

	@Override
	public String addSbiEmiDetailsWithTid(AddSbiDetailsTidBean bean, Long userId) {
		return sBIEMIDaoDao.addSBITransactionWithTid(bean, userId);
	}

	@Override
	public DataTablesResponse<SBIEMIListBean> getSBITransactionList(SBIEMISearchDataTableBean dtRequest) {
		
		// GET THE COLUMN NAME FROM COLUMN INDEX
		int orderingColumnIndex = dtRequest.getDataTableParameters().getOrder().get(0).getColumn();
		String orderingColumnName = getOrderingColumnName(orderingColumnIndex, dtRequest.getType());
		log.info("orderingColumnIndex: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);

		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ACTIVE PROGRAMS
		Map<String, String> searchMap = sbiTransformer.transformSBIDetails(dtRequest);
		log.info("size of searchMap: {}", searchMap.size());

		return sBIEMIDaoDao.getSBITransactionList(dtRequest, orderingColumnName, searchMap);
	}
	
	/**
	 * getOrderingColumnName(...) method is responsible for returning
	 * orderingColumnName when it is provided with orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnName(int orderingColumnIndex, String type) {

		String orderingColumnName = "";
		
		if (type.equals("1")) {
			switch (orderingColumnIndex) {
			case 0:
				orderingColumnName = ColumnNames.SBI_ID.get();
				break;
			case 1:
				orderingColumnName = ColumnNames.MPOS_MERCHANT_ID.get();
				break;
			case 2:
				orderingColumnName = ColumnNames.SBI_MERCHANT_ID.get();
				break;
			case 3:
				orderingColumnName = ColumnNames.MERCHANT_NAME_SBI.get();
				break;
			case 4:
				orderingColumnName = ColumnNames.MERCHANT_CITY.get();
				break;
			case 5:
				orderingColumnName = ColumnNames.STATUS.get();
				break;
			case 6:
				orderingColumnName = ColumnNames.SETUP_FILE_STATUS.get();
				break;

			default:
				orderingColumnName = ColumnNames.MPOS_MERCHANT_ID.get();
				break;
			}
		}
		else {
			switch (orderingColumnIndex) {
			case 0:
				orderingColumnName = ColumnNames.SBI_TID_ID.get();
				break;
			case 1:
				orderingColumnName = ColumnNames.MPOS_TERMINAL_ID.get();
				break;
			case 2:
				orderingColumnName = ColumnNames.STORE_CITY.get();
				break;
			case 3:
				orderingColumnName = ColumnNames.TID_STATUS.get();
				break;
			case 4:
				orderingColumnName = ColumnNames.TID_SETUP_FILE_STATUS.get();
				break;
			case 5:
				orderingColumnName = ColumnNames.SKU_STATUS.get();
				break;
			case 6:
				orderingColumnName = ColumnNames.SKU_SETUP_FILE_STATUS.get();
				break;

			default:
				orderingColumnName = ColumnNames.MPOS_TERMINAL_ID.get();
				break;
			}
		}
		return orderingColumnName;
	}

	@Override
	public EditSbiDetailsBean getSBIDetailsToEdit(long type, long sbiId) {
		
		return sBIEMIDaoDao.getSBIDetailsToEdit(type, sbiId);
	}

	@Override
	public String updateSBITransactionList(long type, long sbiId, EditSbiDetailsBean addBeanData) {
		
		return sBIEMIDaoDao.updateSBITransactionList(type, sbiId, addBeanData);
	}

}
