package com.mosambee.service;

import com.mosambee.bean.SettlementBean;
import com.mosambee.bean.SettlementDataTableCrudBean;
import com.mosambee.bean.datatables.DataTablesResponse;

public interface SettlementService {
   public DataTablesResponse<SettlementBean> getSettlementList(SettlementDataTableCrudBean dtRequest);
   public void settleTransactionByTime(final int time, final String reason,String userId);
   public String settleTransaction(long mmutId);
}
