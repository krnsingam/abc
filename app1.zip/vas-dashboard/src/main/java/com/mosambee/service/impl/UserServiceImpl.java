package com.mosambee.service.impl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.mosambee.bean.BlockedUserBean;
import com.mosambee.bean.BlockedUserDataTableBean;

import com.mosambee.bean.CustomUser;
import com.mosambee.bean.EmailBean;
import com.mosambee.bean.UserBean;
import com.mosambee.bean.UserCrudBean;
import com.mosambee.bean.UserCrudDataTableBean;
import com.mosambee.bean.UserExistAndNotBlockedBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.BasicRoles;
import com.mosambee.constants.ColumnNames;
import com.mosambee.constants.CreateUser;
import com.mosambee.dao.UserDao;
import com.mosambee.service.EmailService;
import com.mosambee.service.UserService;
import com.mosambee.transformer.UserListTransformer;
import com.mosambee.util.SHA1;

/**
 * UserServiceImpl implements UserDetailsService. Basically used to load user by
 * providing user-name. Here we are using UserDetailsService for this purpose.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 02-December-2019
 */
@Service("userServiceImpl")
public class UserServiceImpl implements UserDetailsService, UserService {

	private static final Logger log = LogManager.getLogger(UserServiceImpl.class);

	@Autowired
	private UserDao userDao;
	
	@Autowired
	private UserListTransformer userListTransformer; 
	
	@Autowired
	private EmailService emailService;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		UserBean userBean = userDao.loadUserByUsername(username);

		if (userBean == null) {
			throw new UsernameNotFoundException("User " + username + " was not found in the database.");
		}

		boolean cpStatus = userDao.checkCpStatus(username);

		if (cpStatus) {
			userBean.getRole().setName(BasicRoles.SITE_CP_USER.get());
		} else {
			setRole(userBean);
		}

		Map<String, String> myMap = new HashMap<>();
		myMap.put("id", String.valueOf(userBean.getId()));
		myMap.put("firstName", String.valueOf(userBean.getFirstName()));
		return new CustomUser(userBean.getUsername(), userBean.getPassword(), getAuthority(userBean), myMap);
	}

	/**
	 * setRole() method is basically used to set the role.
	 * 
	 */
	@Override
	public void setRole(UserBean userBean) {

		int roleId = userBean.getRole().getId();

		switch (roleId) {
		case 2:
			userBean.getRole().setName(BasicRoles.SITE_ADMIN.get());
			break;
		case 3:
			userBean.getRole().setName(BasicRoles.SITE_USER.get());
			break;
		default:
			break;
		}

		log.info("roleId: {}, roleName: {}", roleId, userBean.getRole().getName());

	}

	@Override
	public Set<SimpleGrantedAuthority> getAuthority(UserBean user) {
		Set<SimpleGrantedAuthority> authorities = new HashSet<>();
		authorities.add(new SimpleGrantedAuthority(user.getRole().getName()));
		return authorities;
	}

	@Override
	public boolean checkIfUserIsBlocked(long userId) {
		return userDao.checkIfUserIsBlocked(userId);
	}

	@Override
	public void addLoginLogs(String code, String remoteAddr, Long userId) {
		userDao.addLoginLogs(code, remoteAddr, userId);
	}

	@Override
	public UserExistAndNotBlockedBean checkIfUserExistsAndNotBlocked(String username) {
		return userDao.checkIfUserExistsAndNotBlocked(username);
	}

	@Override
	public boolean checkWrongCredentialCount(long userId) {
		return userDao.checkWrongCredentialCount(userId);
	}
	
	
	/**
	 * getUsersList is used to get list of users from userDao and send to controller
	 * @param DataTablesRequest 
	 * @return DataTablesResponse<UserBean>
	 */
	@Override
	public DataTablesResponse<UserBean> getUsersList(UserCrudDataTableBean dtRequest){
		int orderingColumnIndex = dtRequest.getDtRequest().getOrder().get(0).getColumn();
		String orderingColumnName = getOrderingColumnName(orderingColumnIndex);
		log.info("orderingColumnIndex: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);

		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ACTIVE PROGRAMS
		Map<String, String> searchMap = userListTransformer.transformUserDataTableRequest(dtRequest);
		log.info("size of searchMap : {}", searchMap.size());
		return userDao.getUserList(dtRequest, orderingColumnName, searchMap);
	}
	
	/**
	 * getOrderingColumnName(...) method is responsible for returning
	 * orderingColumnName when it is provided with orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnName(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.USERNAME.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.USR_STATUS.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.PROGRAM_START_TIME.get();
			break;
		default:
			orderingColumnName = ColumnNames.USR_ROLE.get();
			break;
		}

		return orderingColumnName;
	}
	
	
	/**
	 * getWebBlockedUsersOrderingColumnName(...) method is responsible for returning
	 * orderingColumnName when it is provided with orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getWebBlockedUsersOrderingColumnName(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.WEB_BLOCKED_USERNAME.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.WEB_BLOCKED_FIRSTNAME.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.WEB_BLOCKED_EMAIL.get();
			break;
		case 4:
			orderingColumnName = ColumnNames.WEB_BLOCKED_BLOCKED_DATE.get();
			break;
		case 5:
			orderingColumnName = ColumnNames.WEB_BLOCKED_EXPIRY_DATE.get();
			break;
		default:
			orderingColumnName = ColumnNames.USR_ROLE.get();
			break;
		}

		return orderingColumnName;
	}
	
	/**
	 * updateUserStatus is used to update user status 
	 * @param int status,int userId
	 * @return boolean
	 */
	public boolean  updateUserStatus(int status,int userId) {
		log.info("calling updateUserStatus");
		return userDao.updateUserStatus(status,userId);
	}
    
	/**
	 * getRoles is used to get roles information from userDao
	 * @return Map<Integer,String>
	 */
	public Map<Integer, String> getRoles() {
		 return userDao.getRoles();
	} 
	
	/**
	 * createUser is used to create new user 
	 * @return boolean
	 */
	public boolean createUser(UserCrudBean userCrudBean) {
		String password = SHA1.generateRandomNumber();
		userCrudBean.setPassword(SHA1.getInstance().hash(password));
		
		if(userDao.createUser(userCrudBean)) {
			EmailBean email = new EmailBean();
			email.setToMail(userCrudBean.getEmail());
			email.setSubject(CreateUser.CREATE_USER_EMAIL_SUBJECT.get());
			email.setContent(setContent(userCrudBean,password));
			return emailService.sendEmail(email);
		}else {
			return false;
		}
	}
	
	/**
	 * setContent() is responsible for setting message content as per requirement.
	 * 
	 * @param userCrudBean
	 * @return String
	 */
	public String setContent(UserCrudBean userCrudBean,String password) {
		
		StringBuilder content = new StringBuilder(CreateUser.CREATE_USER_EMAIL_1.get());
        content.append(userCrudBean.getFirstName()).append(CreateUser.CREATE_USER_EMAIL_2.get()).append(userCrudBean.getEmail())
        .append(CreateUser.CREATE_USER_EMAIL_3.get()).append(password).append(CreateUser.CREATE_USER_EMAIL_4.get());
        
		return content.toString();
	}
	
	/**
	 * updateUser is used to update  user 
	 * @return boolean
	 */
	public int updateUser(UserCrudBean userCrudBean) {
		return userDao.updateUser(userCrudBean);
	}
	
	/**
	 * getUserDetails is used to get user information from userDao
	 * @param int userId
	 * @return UserCrudBean 
	 */
	public UserCrudBean getUserDetails(int userId) {
		return userDao.getUserDetails(userId);
	}
	
	/**
	 * getWebBlockedUsers is used to get data of web blocked users from dao
	 * @param BlockedUserDataTableBean dtRequest
	 * @return DataTablesResponse<BlockedUserBean> 
	 */
	@Override
	public DataTablesResponse<BlockedUserBean> getWebBlockedUsers(BlockedUserDataTableBean dtRequest) {
		int orderingColumnIndex = dtRequest.getDtRequest().getOrder().get(0).getColumn();
		String orderingColumnName = getWebBlockedUsersOrderingColumnName(orderingColumnIndex);
		log.info("orderingColumnIndex: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);

		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ACTIVE PROGRAMS
		Map<String, String> searchMap = userListTransformer.transformWebBlockedUserDataTableRequest(dtRequest);
		log.info("size of searchMap: {}", searchMap.size());
		return userDao.getWebBlockedUsers(dtRequest, orderingColumnName, searchMap);
	}
	
	/**
	 * unblockBlockedUsers is used to unblock user 
	 * @param long mUserId,String comment
	 * @return boolean
	 */
	@Override
	public boolean unblockBlockedUsers(long mUserId,String comment) {
		return userDao.unblockBlockedUsers(mUserId, comment);
	}
	
	/**
	 * unblockMobileBlockedUsers is used to unblock mobile user 
	 * @param long mUserId,String comment
	 * @return boolean
	 */
	@Override
	public boolean unblockMobileBlockedUsers(long mUserId,String comment) {
		return userDao.unblockMobileBlockedUsers(mUserId, comment);
	}
	
	/**
	 * getMobilebBlockedUsers is used to get data of web blocked users from dao
	 * @param BlockedUserDataTableBean dtRequest
	 * @return DataTablesResponse<BlockedUserBean> 
	 */
	@Override
	public DataTablesResponse<BlockedUserBean> getMobileBlockedUsers(BlockedUserDataTableBean dtRequest) {
		int orderingColumnIndex = dtRequest.getDtRequest().getOrder().get(0).getColumn();
		String orderingColumnName = getWebBlockedUsersOrderingColumnName(orderingColumnIndex);
		log.info("orderingColumnIndex: {} , orderingColumnName: {}", orderingColumnIndex, orderingColumnName);

		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ACTIVE PROGRAMS
		Map<String, String> searchMap = userListTransformer.transformWebBlockedUserDataTableRequest(dtRequest);
		log.info("size of searchMap: {}", searchMap.size());
		return userDao.getMobileBlockedUsers(dtRequest, orderingColumnName, searchMap);
	}
}
