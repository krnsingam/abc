package com.mosambee.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mosambee.bean.ProgramBean;
import com.mosambee.bean.ProgramBulkUploadBean;
import com.mosambee.constants.BulkUploadCategory;
import com.mosambee.constants.BulkUploadFileLocation;
import com.mosambee.constants.BulkUploadMessages;
import com.mosambee.constants.ModuleName;
import com.mosambee.dao.CommonDao;
import com.mosambee.dao.LaunchProgramDao;
import com.mosambee.properties.ExcelHeaderProperties;
import com.mosambee.service.ExcelService;
import com.mosambee.service.ProgramBulkUploadService;
import com.mosambee.validator.ProgramBulkUploadValidator;

/**
 * ProgramBulkUploadServiceImpl dealing with bulk upload for processing offers
 * done via bulk upload.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 24-December-2014
 */
@Service("programBulkUploadService")
public class ProgramBulkUploadServiceImpl implements ProgramBulkUploadService {

	private static final Logger log = LogManager.getLogger(ProgramBulkUploadServiceImpl.class);
	private static final DataFormatter dataFormatter = new DataFormatter();

	@Autowired
	private ExcelService excelService;

	@Autowired
	private ProgramBulkUploadValidator programBulkUploadValidator;

	@Autowired
	private LaunchProgramDao launchProgramDao;

	@Autowired
	private ExcelHeaderProperties excelHeaderProperties;

	@Autowired
	private CommonDao commonDao;

	/**
	 * Responsible for processing {@link MultipartFile} ... Here we are validating
	 * the header, security issues, parsing the data from the {@link Workbook} &
	 * then again parsing the validated data from the {@link Workbook}
	 *
	 * @param file {@link MultipartFile}
	 * @return {@link Resource}
	 */
	@Override
	public Resource processBulkUploadExcel(MultipartFile file) {
		Workbook workbook = excelService.getWorkbookFromMultipartFile(file);
		List<ProgramBulkUploadBean> programBulkUploadBeanList = new ArrayList<>();
		List<ProgramBulkUploadBean> successRecordList = new ArrayList<>();
		List<ProgramBulkUploadBean> failedRecordList = new ArrayList<>();

		// VALIDATE THE HEADER & VALIDATE SECURITY ISSUES
		if (validateExcelFile(file, workbook) && validateSecurityIssues(file, workbook)) {

			// PARSE DATA FROM WORKBOOK
			List<ProgramBean> programList = parseProgramBulkUploadFields(workbook);

			// VALIDATE THE PARSED DATA FROM WORKBOOK INTO SUCCESS & FAILED RECORD LIST
			validateAndTransformParsedDataIntoLists(programList, successRecordList, failedRecordList);

			// PERSIST THE PROGRAMS IN DATABASE AND ADD PROGRAM CODE CORRESPONDING TO THEM
			persistPrograms(successRecordList);

			// ADD ALL SUCCESS AND FAILED RECORDS IN A COMMON LIST
			programBulkUploadBeanList.addAll(failedRecordList);
			programBulkUploadBeanList.addAll(successRecordList);

			// GET THE EXCEL WITH RESPONSE
			Workbook responseWorkbook = writeBulkUploadBeanListToExcel(programBulkUploadBeanList);

			return excelService.getResourceFromWorkbook(responseWorkbook);

		} else {
			log.error("Excel file is not valid");
		}

		return null;
	}

	/**
	 * Performs validation for excel extension and validates the excel header.
	 * 
	 * @param file     MultipartFile
	 * @param workbook Workbook
	 * @return boolean
	 */
	private boolean validateExcelFile(MultipartFile file, Workbook workbook) {
		return excelService.validateExtension(file)
				&& excelService.validateHeader(workbook, BulkUploadCategory.PROGRAM);
	}

	/**
	 * Performs validation for security issues in excel file. Mainly we are check
	 * for embedded object, macros and VB Scripts.
	 *
	 * @param file     MultipartFile
	 * @param workbook Workbook
	 * @return boolean
	 */
	private boolean validateSecurityIssues(MultipartFile file, Workbook workbook) {
		return excelService.checkForEmbeddedObjects(workbook) && excelService.checkForMacrosAndVbScript(file);
	}

	/**
	 * parseProgramBulkUploadFields(...) is responsible to parsing the workbook.
	 * Here we are parsing the sheet present at 0th index and then iterating the
	 * rows and cells inside them to extract the values.
	 * 
	 * @param workbook {@link Workbook}
	 * @return {@link List} of {@link ProgramBean}
	 */
	private List<ProgramBean> parseProgramBulkUploadFields(Workbook workbook) {
		Iterator<Row> rowIterator = workbook.getSheetAt(0).iterator();
		List<ProgramBean> programBeanList = new ArrayList<>();

		// SKIPING THE HEADER ROW
		rowIterator.next();

		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			ProgramBean programBean = parseRow(row);
			programBeanList.add(programBean);
		}

		return programBeanList;
	}

	/**
	 * {@link #parseRow(Row)} method is responsible for parsing the row and storing
	 * the parsed value in the object of {@link ProgramBean}
	 * 
	 * @param row
	 * @return {@link ProgramBean}
	 */
	private ProgramBean parseRow(Row row) {
		ProgramBean programBean = new ProgramBean();

		// SUBTRACT 1 FROM THE SIZE AS IT HAS STATUS HEADER.
		int sizeOfExcelHeader = excelHeaderProperties.getProgramBulkUploadHeaders().size() - 2;

		for (int i = 0; i < sizeOfExcelHeader; ++i) {

			Cell cell = row.getCell(i);

			switch (i) {
			case 0:
				programBean.setProgramName(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 1:
				programBean.setProgramDescription(dataFormatter.formatCellValue(cell));
				break;
			case 2:
				programBean.setProgramPriority(dataFormatter.formatCellValue(cell));
				break;
			case 3:
				programBean.setProgramStartDateTime(dataFormatter.formatCellValue(cell));
				break;
			case 4:
				programBean.setProgramEndDateTime(dataFormatter.formatCellValue(cell));
				break;
			case 5:
				programBean.setProgramCumulativeCount(dataFormatter.formatCellValue(cell));
				break;
			case 6:
				programBean.setProgramCumulativeCountMode(dataFormatter.formatCellValue(cell));
				break;
			default:
				String defaultCellValue = dataFormatter.formatCellValue(cell);
				log.info("Getting into the default case: {}", defaultCellValue);
				break;
			}
		}

		return programBean;

	}

	/**
	 * <strong>validateParsedDataIntoLists(...)</strong> is responsible for
	 * iterating over the list of programs and then putting them into two separate
	 * list, on the basis of their success and failed validation status. <br>
	 * <br>
	 * 
	 * Here we are using two lists, i.e. successRecordList & failedRecordList for
	 * success and failed records. <br>
	 * 
	 * @param programList       {@link List} of all the programs.
	 * @param successRecordList {@link List} of all the success records.
	 * @param failedRecordList  {@link List} of all the failed records.
	 * @return void
	 */
	private void validateAndTransformParsedDataIntoLists(List<ProgramBean> programList,
			List<ProgramBulkUploadBean> successRecordList, List<ProgramBulkUploadBean> failedRecordList) {

		// LOOP OVER THE LIST OF PROGRAMS
		for (ProgramBean programBean : programList) {

			// VALIDATE THE BEAN
			ProgramBulkUploadBean programBulkUploadBean = programBulkUploadValidator.validateProgramBean(programBean);

			// PUT THEM IN RESPECTIVE LIST.
			if (programBulkUploadBean.getStatus().equals("")) {
				successRecordList.add(programBulkUploadBean);
			} else {
				failedRecordList.add(programBulkUploadBean);
			}
		}
	}

	/**
	 * persistPrograms(...) is responsible for getting the prefixName from
	 * {@link ModuleName} and then persist the program details into the database. We
	 * will get programCode after persisting a particular bean which is then set to
	 * the same record.
	 * 
	 * @param successRecordList
	 * @return void
	 */
	private void persistPrograms(List<ProgramBulkUploadBean> successRecordList) {
		// GET THE PREFIX NAME
		String prefixName = commonDao.getPrefixName(ModuleName.PROGRAM_GROUP.get());

		// INSERT INTO THE DB
		for (ProgramBulkUploadBean programBulkUploadBean : successRecordList) {
			String programCode = launchProgramDao.addProgramAndGetProgramCode(programBulkUploadBean, prefixName);

			// PROCESS THE RESPONSE PROGRAM CODE
			processProgramCodeAndUpdateBean(programCode, programBulkUploadBean);
		}

	}

	/**
	 * processProgramCodeAndUpdateBean(...) method is responsible for processing the
	 * program code. Here if programCode is null, that means exception has occurred
	 * on DB side, else we will simply update the status of the bean to
	 * 
	 * @param programCode
	 * @param programBulkUploadBean
	 */
	private void processProgramCodeAndUpdateBean(String programCode, ProgramBulkUploadBean programBulkUploadBean) {
		if (null == programCode) {
			programBulkUploadBean.setStatus(BulkUploadMessages.EXCEPTION_OCCURED_WHILE_INSERTION.get());
		} else if (programBulkUploadBean.getStatus().equals("")) {
			programBulkUploadBean.setStatus(BulkUploadMessages.SUCCESS.get());
			programBulkUploadBean.setProgramCode(programCode);
		}
	}

	/**
	 * {@link #writeBulkUploadBeanListToExcel(List)} is responsible for for creating
	 * the excel with the response after processing the program bulk upload excel
	 * file.
	 * 
	 * @param programBulkUploadBeanList
	 * @return {@link Workbook}
	 */
	private Workbook writeBulkUploadBeanListToExcel(List<ProgramBulkUploadBean> programBulkUploadBeanList) {

		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.PROGRAM);
		Sheet sheet = workbook.getSheetAt(0);

		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		for (ProgramBulkUploadBean programBulkUploadBean : programBulkUploadBeanList) {
			Row row = sheet.createRow(rowNum++);

			row.createCell(0).setCellValue(programBulkUploadBean.getProgramName());
			row.createCell(1).setCellValue(programBulkUploadBean.getProgramDescription());
			row.createCell(2).setCellValue(programBulkUploadBean.getProgramPriority());
			row.createCell(3).setCellValue(programBulkUploadBean.getProgramStartDateTime());
			row.createCell(4).setCellValue(programBulkUploadBean.getProgramEndDateTime());
			row.createCell(5).setCellValue(programBulkUploadBean.getProgramCumulativeCount());
			row.createCell(6).setCellValue(programBulkUploadBean.getProgramCumulativeCountMode());
			row.createCell(7).setCellValue(programBulkUploadBean.getProgramCode());
			row.createCell(8).setCellValue(programBulkUploadBean.getStatus());

		}

		excelService.autoSizeExcel(workbook);
		return workbook;

	}

	/**
	 * getProgramBulkUploadFormat() is responsible for converting the bulk upload
	 * files present in {@link BulkUploadFileLocation} to {@link Resource}
	 */
	@Override
	public Resource getProgramBulkUploadFormat() {
		ClassPathResource resource = null;
		resource = new ClassPathResource(BulkUploadFileLocation.PROGRAM_BULK_UPLOAD_FILE.get());
		return resource.exists() ? resource : null;
	}

}
