package com.mosambee.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mosambee.bean.AdminAcquirerBean;
import com.mosambee.bean.AdminAcquirerDataTablesRequestBean;
import com.mosambee.bean.AdminAcquirerListBean;
import com.mosambee.bean.AdminAddAcquirerBean;
import com.mosambee.bean.EditAcquirerDetailsBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.AdminAcquirerDao;
import com.mosambee.service.AdminAcquirerService;
import com.mosambee.transformer.AdminAcquirerTransformer;
import com.mosambee.validator.CommonValidator;

import lombok.extern.log4j.Log4j2;

/**
 * AdminAcquirerServiceImpl class implementing {@link AdminAcquirerService}
 * specification.
 * 
 * @author mariam.siddique
 * @author saurabhkant.shukla
 * @version 1.0
 * @since 18-March-2020
 */

@Log4j2
@Service("adminAcquirerService")
public class AdminAcquirerServiceImpl implements AdminAcquirerService {

	@Autowired
	private AdminAcquirerDao dao;

	@Autowired
	private CommonValidator commonValidator;

	@Autowired
	private AdminAcquirerTransformer transformer;

	/**
	 * getAdminAcquirerList(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request & then
	 * calling the DAO to get those values.
	 * 
	 * @param dtRequest {@link AdminAcquirerDataTablesRequestBean}
	 * @return DataTablesResponse of BAdminAcquirerBean
	 */
	@Override
	public DataTablesResponse<AdminAcquirerBean> getAdminAcquirerList(
			 AdminAcquirerDataTablesRequestBean dtRequest) {

		// getting column index
		int orderingColumnIndex = dtRequest.getDtRequest().getOrder().get(0).getColumn();

		// getting columnName based on column index
		String orderingColumnName = getOrderingColumnNameOfAdminAcquirerList(orderingColumnIndex);
		log.info("orderingColumnIndexs: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);
		log.info("fromdate {} ", dtRequest.getFromDate());
		log.info("todate {} ", dtRequest.getToDate());
		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ADMIN ACQUIRER
		Map<String, String> searchMap = transformer.transformAdminAcquirerDataTableRequest(dtRequest);
		log.info("size of searchMap: {}", searchMap.size());
		log.info("fromdate {}", searchMap.get(ColumnNames.ADMIN_ACQUIRER_FROMDATE.get()));
		log.info("todate {}", searchMap.get(ColumnNames.ADMIN_ACQUIRER_TODATE.get()));
		// Setting up date format
		dtRequest.setFromDate(
				commonValidator.dateTimeValidator(searchMap.get(ColumnNames.ADMIN_ACQUIRER_FROMDATE.get())));
		dtRequest.setToDate(commonValidator.timeValidator(searchMap.get(ColumnNames.ADMIN_ACQUIRER_TODATE.get())));

		return dao.getAdminAcquirerList(dtRequest, orderingColumnName, searchMap);

	}

	/**
	 * getOrderingColumnNameOfEnquiryList (...) method is responsible for returning
	 * orderingColumnName of enquiryBean when it is provided with
	 * orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnNameOfAdminAcquirerList(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.ADMIN_ACQUIRER_NAME.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.ADMIN_ACQUIRER_MIDCOUNT.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.ADMIN_ACQUIRER_USERSCOUNT.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.ADMIN_ACQUIRER_SALETXN.get();
			break;
		case 4:
			orderingColumnName = ColumnNames.ADMIN_ACQUIRER_SALETXNVALUE.get();
			break;
		case 5:
			orderingColumnName = ColumnNames.ADMIN_ACQUIRER_DECLINEDTXN.get();
			break;
		case 6:
			orderingColumnName = ColumnNames.ADMIN_ACQUIRER_LASTTXNDATE.get();
			break;
		default:
			orderingColumnName = ColumnNames.ADMIN_ACQUIRER_NAME.get();
			break;
		}

		return orderingColumnName;
	}

	/**
	 * getCurrencyList(...) is responsible for calling the DAO layer to get List of
	 * Currency.
	 * 
	 * @return Map<Integer, String>
	 */
	@Override
	public Map<Integer, String> getCurrencyList() {

		return dao.getCurrencyList();
	}

	/**
	 * addNewAcquirer(...) is responsible for calling the DAO layer to Add Acquirer
	 * Details.
	 * 
	 * @return String
	 */
	@Override
	public String addNewAcquirer(AdminAddAcquirerBean bean, long userId) {
		return dao.addNewAcquirer(bean, userId);
	}

	@Override
	public DataTablesResponse<AdminAcquirerListBean> getSiteAcquirerList(DataTablesRequest dtRequest) {

		// getting column index
		int orderingColumnIndex = dtRequest.getOrder().get(0).getColumn();

		// getting columnName based on column index
		String orderingColumnName = getColumnNameOfAdminAcquirerList(orderingColumnIndex);
		log.info("orderingColumnIndexes: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);

		return dao.getSiteAcquirerList(dtRequest, orderingColumnName);
	}

	private String getColumnNameOfAdminAcquirerList(int orderingColumnIndex) {
		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		
		case 0: 
			orderingColumnName = ColumnNames.SITE_ACQUIRER_ID.get(); 
			break;
		case 1:
			orderingColumnName = ColumnNames.SITE_ACQUIRER_NAME.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.SITE_ACQUIRER_ZMK.get();
			break;
		/*
		 * case 3: orderingColumnName = ColumnNames.SITE_ACQUIRER_ZPK.get(); break; case
		 * 4: orderingColumnName = ColumnNames.SITE_ACQUIRER_ZEK.get(); break;
		 */
		case 3:
			orderingColumnName = ColumnNames.SITE_ACQUIRER_TIP_PERCENT.get();
			break;
		case 4:
			orderingColumnName = ColumnNames.SITE_ACQUIRER_CURRENCYCODE.get();
			break;
		case 5:
			orderingColumnName = ColumnNames.SITE_ACQUIRER_DECIMAL_AMOUNT_LENGTH.get();
			break;
		case 6:
			orderingColumnName = ColumnNames.SITE_ACQUIRER_SERVER_TIME_IN_MIN.get();
			break;
		case 7:
			orderingColumnName = ColumnNames.SITE_ACQUIRER_MOBILE_NO_LENGTH.get();
			break;
		default:
			orderingColumnName = ColumnNames.SITE_ACQUIRER_NAME.get();
			break;
		}

		return orderingColumnName;
	}

	@Override
	public EditAcquirerDetailsBean getSiteAcquirerData(long acqId) {
		return dao.getSiteAcquirerData(acqId);
	}

	@Override
	public String updateAcquirer(EditAcquirerDetailsBean updateBeanData, long acqId, long userId) {
		
		return dao.updateAcquirer(updateBeanData, acqId, userId);
	}

}
