
package com.mosambee.service;

import org.springframework.core.io.Resource;

import com.mosambee.bean.NetworkMessagesDataTablesRequestBean;
import com.mosambee.bean.NetworkMessagesDownloadBean;
import com.mosambee.bean.NetworkMessagesListBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.service.impl.NetworkMessagesServiceImpl;

/**
 * NetworkMessagesService specification for {@link NetworkMessagesServiceImpl} class
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 27-March-2020
 */
public interface NetworkMessagesService {
	
	DataTablesResponse<NetworkMessagesListBean> getNetworkMessagesList(NetworkMessagesDataTablesRequestBean dtRequest);
	
	public Resource downloadNetworkMessagesList(NetworkMessagesDownloadBean bean);

}
