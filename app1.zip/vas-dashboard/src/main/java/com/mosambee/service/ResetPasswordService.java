package com.mosambee.service;

import com.mosambee.bean.ResetPasswordBean;

public interface ResetPasswordService {

	String processPasswords(ResetPasswordBean resetPassword);

}
