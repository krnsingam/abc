package com.mosambee.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.mosambee.bean.AcquirerBean;
import com.mosambee.bean.BusinessMISCrudBean;
import com.mosambee.bean.BusinessMISDownloadCrudBean;
import com.mosambee.bean.BusinessMISDownloadResponseBean;
import com.mosambee.constants.BulkUploadCategory;
import com.mosambee.dao.MISReportDao;
import com.mosambee.service.ExcelService;
import com.mosambee.service.MISReportService;
import com.mosambee.validator.CommonValidator;

import lombok.extern.log4j.Log4j2;
/**
 * MISReportServiceImpl class implementing {@link MISReportService}
 * specification.
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 15-April-2020
 */

@Log4j2
@Service("misReportService")
public class MISReportServiceImpl implements MISReportService{
	
	
	@Autowired
	private MISReportDao dao;
	
	@Autowired
	private CommonValidator commonValidator;
	
	@Autowired
	private ExcelService excelService;

	@Override
	public String updateBusinessMIS(BusinessMISCrudBean businessMISCrudBean) {
		
		String msg = "";
		String fromDate = businessMISCrudBean.getActivationRequestDate();
		String toDate = businessMISCrudBean.getActivationConfirmationDate();
		log.info("businessMISCrudBean {}",businessMISCrudBean);
		// Setting up date format
		businessMISCrudBean.setActivationRequestDate(commonValidator.dateTimeValidator(fromDate));
		businessMISCrudBean.setActivationConfirmationDate(commonValidator.timeValidator(toDate));
		
		int exist = dao.checkUserNameExist(businessMISCrudBean.getUserNumber().trim());
		if(exist == 1) {
		boolean updated = dao.updateBusinessMIS(businessMISCrudBean);
		if(updated) { msg = "success";}
		else { msg = "failed"; }
		}else if(exist == 0) {
			msg = "Invalid UserNumber";
		}else {
			msg = "failed";
		}
		return msg;
	}

	@Override
	public List<AcquirerBean> getListOfAcquirer() {
		return dao.getListOfAcquirer();	
	}

	@Override
	public Resource downloadBusinessMIS(List<BusinessMISDownloadResponseBean> list) {
		Resource res = null;
		
			res = process(list);
			return res;
	}
	/**
	 * process(...) method is responsible for returning Resource as workbook.
	 * 
	 * @param List<BusinessMISDownloadResponseBean>
	 * @return Resource
	 */
	public Resource process(List<BusinessMISDownloadResponseBean> responseBean) {

		// GET THE EXCEL WITH RESPONSE
		Workbook responseWorkbook = writeListToExcel(responseBean);

		return excelService.getResourceFromWorkbook(responseWorkbook);
	}

	/**
	 * writeListToExcel(...) method is responsible for returning Workbook as after
	 * parsing data for excel and seting it.
	 * 
	 * @param List<BusinessMISDownloadResponseBean>
	 * @return Workbook
	 */
	private Workbook writeListToExcel(List<BusinessMISDownloadResponseBean> responseBean) {
		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.BUSINESS_MIS);
		Sheet sheet = workbook.getSheetAt(0);

		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		int i = 1;
		Date installRequestDate = null;
		Date installDate = null;
		for (BusinessMISDownloadResponseBean bean : responseBean) {
			
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(i++);
			row.createCell(1).setCellValue(bean.getMId());
			row.createCell(2).setCellValue((bean.getMerchantPhone() != null)? bean.getMerchantPhone() : "NA");
			row.createCell(3).setCellValue((bean.getMerchantEmail() != null)? bean.getMerchantEmail() : "NA");
			row.createCell(4).setCellValue(bean.getMerchantName());
			row.createCell(5).setCellValue(bean.getMerchantContactPerson());
			row.createCell(6).setCellValue(bean.getMerchantAddress());
			row.createCell(7).setCellValue(bean.getMerchantState());
			row.createCell(8).setCellValue(bean.getMerchantCity());
			row.createCell(9).setCellValue(bean.getMerchantPin());
			row.createCell(10).setCellValue(bean.getMerchantUser());
			row.createCell(11).setCellValue(bean.getMerchantUserName());
			row.createCell(12).setCellValue(bean.getMerchantDebitTid());
			row.createCell(13).setCellValue(bean.getMerchantCreditTid());
			row.createCell(14).setCellValue(bean.getMerchantAcq());
			row.createCell(15).setCellValue(bean.getMonth());
			row.createCell(16).setCellValue(bean.getReqDateAcq());
			row.createCell(17).setCellValue(bean.getConfirmDateAcq());
			row.createCell(18).setCellValue(bean.getInstallReqDate());
			row.createCell(19).setCellValue(bean.getInstallDate());
			
			if((!"NA".equals(bean.getInstallReqDate())) && bean.getInstallReqDate() != null && bean.getInstallReqDate().length() != 0){
				installRequestDate = commonValidator.dateConverter(bean.getInstallReqDate());
			}
			
			if((!"NA".equals(bean.getInstallDate())) && bean.getInstallDate() != null && bean.getInstallDate().length() != 0) {
				installDate = commonValidator.dateConverter(bean.getInstallDate()); 
			}
			
			if( installRequestDate != null  && installDate != null && (!"NA".equals(bean.getInstallReqDate()))) {

				long diff = Math.abs(installRequestDate.getTime() - installDate.getTime());
				long diffDays = diff / (24 * 60 * 60 * 1000);
				bean.setWithingTAT(diffDays > 1 ? "NO" : "YES");
			}
			else {
				bean.setWithingTAT("NA");
			}

			row.createCell(20).setCellValue(bean.getWithingTAT());
			row.createCell(21).setCellValue(bean.getSerialNo());
			row.createCell(22).setCellValue(bean.getMerchantUserStatus());
			row.createCell(23).setCellValue("Active".equalsIgnoreCase(bean.getMerchantUserStatus()) ? "" : bean.getDeactivationDate());
			row.createCell(24).setCellValue(bean.getDeactivationComment());
			}
		excelService.autoSizeExcel(workbook);
		return workbook;
	}

	/**
	 * getDataToDownloadBusinessMIS(...) method is responsible for getting data from DAO layer to fill download file.
	 * 
	 * @param businessMISDownloadCrudBean {@link BusinessMISDownloadCrudBean}
	 * @return List<BusinessMISDownloadResponseBean>
	 */
	@Override
	public List<BusinessMISDownloadResponseBean> getDataToDownloadBusinessMIS(BusinessMISDownloadCrudBean businessMISDownloadCrudBean) {
		
		String fromDate = businessMISDownloadCrudBean.getFromDate();
		String toDate = businessMISDownloadCrudBean.getToDate();
		// Date-time check
		businessMISDownloadCrudBean.setFromDate(commonValidator.dateTimeValidator(fromDate));
		businessMISDownloadCrudBean.setToDate(commonValidator.timeValidator(toDate));
		return dao.getDataToDownloadBusinessMIS(businessMISDownloadCrudBean);
	}

}
