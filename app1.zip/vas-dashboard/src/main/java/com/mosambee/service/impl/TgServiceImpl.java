package com.mosambee.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mosambee.bean.TgBean;
import com.mosambee.bean.TgCrudBean;
import com.mosambee.bean.TgDataTableRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.TgDao;
import com.mosambee.service.TgService;

import lombok.extern.log4j.Log4j2;

/**
 * TgServiceImpl class implementing {@link TgService}
 * specification.
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 08-April-2020
 */
@Log4j2
@Service("tgService")
public class TgServiceImpl implements TgService{

	@Autowired
	private TgDao dao;
	
	/**
	 * getTgList(...) is responsible for passing input fields in the data-tables request & then
	 * calling the DAO to get those values.
	 * 
	 * @param dtRequest {@link TgDataTableRequestBean}
	 * @return DataTablesResponse of TgBean
	 */
	@Override
	public DataTablesResponse<TgBean> getTgList(TgDataTableRequestBean dtRequest) {
		// getting column index
		int orderingColumnIndex = dtRequest.getDtRequest().getOrder().get(0).getColumn();
		
		//getting columnName based on column index
		String orderingColumnName = getOrderingColumnNameOfTgList(orderingColumnIndex);
		log.info("orderingColumnIndexs: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);
		
		return dao.getTgList(dtRequest, orderingColumnName);
		
	}
	
	/**
	 * getOrderingColumnNameOfTgList (...) method is responsible for returning
	 * orderingColumnName when it is provided with
	 * orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnNameOfTgList(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.TG_NAME.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.TG_IPADDRESS.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.TG_PORT.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.TG_URL.get();
			break;
		default:
			orderingColumnName = ColumnNames.TG_NAME.get();
			break;
		}

		return orderingColumnName;
	}

	@Override
	public boolean addTg(TgCrudBean tgCrudBean) {
		return dao.addTg(tgCrudBean);
	}

	@Override
	public TgCrudBean getTgDetails(int tgId) {
		return dao.getTgDetails(tgId);
	}

	@Override
	public boolean updateTg(TgCrudBean tgCrudBean) {
		return dao.updateTg(tgCrudBean);
	}


}
