package com.mosambee.service.impl;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mosambee.bean.BillNumberBean;
import com.mosambee.bean.BillNumberDataTablesRequestBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.SearchByBillNumberDao;
import com.mosambee.service.SearchByBillNumberService;
import com.mosambee.transformer.SearchByBillNumberTransformer;

import lombok.extern.log4j.Log4j2;

/**
 * SearchByBillNumberServiceImpl class implementing {@link SearchByBillNumberService}
 * specification.
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 23-March-2020
 */
@Log4j2
@Service("searchByBillNumberService")
public class SearchByBillNumberServiceImpl implements SearchByBillNumberService{

	@Autowired
	private SearchByBillNumberDao dao;
	
	@Autowired
	private SearchByBillNumberTransformer transformer;
	
	/**
	 * getBillNumberTransactionList(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request & then
	 * calling the DAO to get those values.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return DataTablesResponse of BillNumberBean
	 */
	@Override
	public DataTablesResponse<BillNumberBean> getBillNumberTransactionList(@Valid BillNumberDataTablesRequestBean dtRequest) {
		// getting column index
				int orderingColumnIndex = dtRequest.getDtRequest().getOrder().get(0).getColumn();
				
				//getting columnName based on column index
				String orderingColumnName = getOrderingColumnNameOfTransactionList(orderingColumnIndex);
				log.info("orderingColumnIndexs: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);
	
				// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF TRANSACTION
				Map<String, String> searchMap = transformer.transformBillNumberDataTableRequest(dtRequest);
				log.info("size of searchMap: {}", searchMap.size());
				
				return dao.getBillNumberTransactionList(dtRequest, orderingColumnName, searchMap);
				
			}
			
			/**
			 * getOrderingColumnNameOfTransactionList (...) method is responsible for returning
			 * orderingColumnName of BillNumberBean when it is provided with
			 * orderingColumnIndex.
			 * 
			 * @param orderingColumnIndex
			 * @return String orderingColumnName
			 */
			private String getOrderingColumnNameOfTransactionList(int orderingColumnIndex) {

				String orderingColumnName = "";

				switch (orderingColumnIndex) {
				case 0:
					orderingColumnName = ColumnNames.SEARCHBY_BILLNUMBER_USERNAME.get();
					break;
				case 1:
					orderingColumnName = ColumnNames.SEARCHBY_BILLNUMBER_TXNTYPE.get();
					break;
				case 2:
					orderingColumnName = ColumnNames.SEARCHBY_BILLNUMBER_TERMINALID.get();
					break;
				case 3:
					orderingColumnName = ColumnNames.SEARCHBY_BILLNUMBER_CARDNUMBER.get();
					break;
				case 4:
					orderingColumnName = ColumnNames.SEARCHBY_BILLNUMBER_RRN.get();
					break;
				case 5:
					orderingColumnName = ColumnNames.SEARCHBY_BILLNUMBER_AMOUNT.get();
					break;
				case 6:
					orderingColumnName = ColumnNames.SEARCHBY_BILLNUMBER_RESPONSECODE.get();
					break;
				case 7:
					orderingColumnName = ColumnNames.SEARCHBY_BILLNUMBER_AUTHCODE.get();
					break;
				case 8:
					orderingColumnName = ColumnNames.SEARCHBY_BILLNUMBER_STATUS.get();
					break;
				case 9:
					orderingColumnName = ColumnNames.SEARCHBY_BILLNUMBER_SETTLEMENTSTATUS.get();
					break;
				default:
					orderingColumnName = ColumnNames.SEARCHBY_BILLNUMBER_USERNAME.get();
					break;
				}

				return orderingColumnName;
			}


}
