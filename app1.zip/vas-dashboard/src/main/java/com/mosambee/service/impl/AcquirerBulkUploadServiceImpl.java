package com.mosambee.service.impl;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.mosambee.bean.AcquirerBulkDataBean;
import com.mosambee.bean.AcquirerBulkUploadBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.BulkUploadCategory;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.AcquirerBulkUploadDao;
import com.mosambee.service.AcquirerBulkUploadService;
import com.mosambee.service.ExcelService;
import com.mosambee.transformer.AcquirerBulkUploadTransformer;

@Service("acquirerBulkUploadService")
public class AcquirerBulkUploadServiceImpl implements AcquirerBulkUploadService{

	private static final Logger log = LogManager.getLogger(AcquirerBulkUploadServiceImpl.class);
	
	@Autowired
	AcquirerBulkUploadDao acqDao;
	
	@Autowired
	ExcelService excelService;
	
	@Autowired
	AcquirerBulkUploadTransformer acqTransformer;
	
	/**
	 * getListOfAPIGroup(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request & then
	 * calling the DAO to get those values.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return DataTablesResponse of ActiveProgramBean
	 */
	@Override
	public DataTablesResponse<AcquirerBulkUploadBean> getListOfAcquirer(AcquirerBulkDataBean dtRequest) {
		
		// GET THE COLUMN NAME FROM COLUMN INDEX
		int orderingColumnIndex = dtRequest.getDataTable().getOrder().get(0).getColumn();
		String orderingColumnName = getOrderingColumnName(orderingColumnIndex);
		log.info("orderingColumnIndex: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);

		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ACTIVE PROGRAMS
		Map<String, String> searchMap = acqTransformer.transformListOfAcquirer(dtRequest);
		log.info("size of searchMap: {}", searchMap.size());
		return acqDao.getListOfAcquirer(dtRequest.getDataTable(), orderingColumnName, searchMap);
		
	}
	
	/**
	 * getOrderingColumnName(...) method is responsible for returning
	 * orderingColumnName when it is provided with orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnName(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.ACQ_ID.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.ACQIRER.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.ACQ_MAT_CODE.get();
			break;	
			
		default:
			orderingColumnName =  ColumnNames.ACQ_ID.get();
			break;
		}

		return orderingColumnName;
	}
	
	/**
	 * downloadActiveAcquirerList(...) method is responsible for returning
	 * Resource in byte stream for download. Used for downloading all the
	 * acquirer for Report.
	 * 
	 * @param DataTablesRequest
	 * @return Resource
	 */
	@Override
	public Resource downloadActiveAcquirerList(AcquirerBulkUploadBean report) {

		Resource res = null;

		// GET DOWNLOAD LIST FROM DAO LAYER
		List<AcquirerBulkUploadBean> response = acqDao.downloadActiveAcquirerList(report);
		if(!response.isEmpty()) {
		res = process(response);
		}
		return res;

	}

	/**
	 * process(...) method is responsible for returning Resource as workbook.
	 * 
	 * @param List<TransactionReportBean>
	 * @return Resource
	 */
	public Resource process(List<AcquirerBulkUploadBean> responseBean) {

		// GET THE EXCEL WITH RESPONSE
		Workbook responseWorkbook = writeListToExcel(responseBean);

		return excelService.getResourceFromWorkbook(responseWorkbook);
	}

	/**
	 * writeListToExcel(...) method is responsible for returning Workbook as after
	 * parsing data for excel and seting it.
	 * 
	 * @param List<TransactionReportBean>
	 * @return Workbook
	 */
	private Workbook writeListToExcel(List<AcquirerBulkUploadBean> responseBean) {
		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.ACQUIRER_LIST);
		Sheet sheet = workbook.getSheetAt(0);

		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		int i = 1;
		for (AcquirerBulkUploadBean bean : responseBean) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(i++);
			row.createCell(1).setCellValue(bean.getAcquirer());
			row.createCell(2).setCellValue(bean.getMatcode());
		}
		excelService.autoSizeExcel(workbook);
		return workbook;
	}
	
}
