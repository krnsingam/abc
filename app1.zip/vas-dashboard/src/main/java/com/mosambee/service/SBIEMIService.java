package com.mosambee.service;

import com.mosambee.bean.AddSbiDetailsMidBean;
import com.mosambee.bean.EditSbiDetailsBean;
import com.mosambee.bean.AddSbiDetailsTidBean;
import com.mosambee.bean.SBIEMIListBean;
import com.mosambee.bean.SBIEMISearchDataTableBean;
import com.mosambee.bean.datatables.DataTablesResponse;

public interface SBIEMIService {
	
	public String addSbiEmiDetails(AddSbiDetailsMidBean sbiFormBean, long userId);

	public String addSbiEmiDetailsWithTid(AddSbiDetailsTidBean bean, Long userId);

	public DataTablesResponse<SBIEMIListBean> getSBITransactionList(SBIEMISearchDataTableBean dtRequest);

	public EditSbiDetailsBean getSBIDetailsToEdit(long type, long sbiId);

	public String updateSBITransactionList(long type, long sbiId, EditSbiDetailsBean addBeanData);   
}
