package com.mosambee.service;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

/**
 * This class provides specification for {@link SbiMidUploadServiceImpl}
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 */
public interface SbiMidUploadService {

	Resource processSbiEmiUploadExcel(MultipartFile file);

	Resource getSbiMidUploadFormat(); 
 
}
