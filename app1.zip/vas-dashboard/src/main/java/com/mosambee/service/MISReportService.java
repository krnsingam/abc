package com.mosambee.service;

import java.util.List;

import org.springframework.core.io.Resource;

import com.mosambee.bean.AcquirerBean;
import com.mosambee.bean.BusinessMISCrudBean;
import com.mosambee.bean.BusinessMISDownloadCrudBean;
import com.mosambee.bean.BusinessMISDownloadResponseBean;
import com.mosambee.service.impl.MISReportServiceImpl;

/**
 * MISReportService specification for {@link MISReportServiceImpl} class
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 15-April-2020
 */
public interface MISReportService {

	String updateBusinessMIS(BusinessMISCrudBean businessMISCrudBean);
	
	public List<AcquirerBean> getListOfAcquirer();
	
	List<BusinessMISDownloadResponseBean> getDataToDownloadBusinessMIS(BusinessMISDownloadCrudBean businessMISDownloadCrudBean);
	
	public Resource downloadBusinessMIS(List<BusinessMISDownloadResponseBean> list);
}
