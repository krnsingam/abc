package com.mosambee.service;

import com.mosambee.bean.AddBqrMerchantsBean;
import com.mosambee.bean.BqrListDatatablesRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;

/**
 * This class provides specification for {@link AddBqrMerchantsServiceImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
public interface AddBqrMerchantsService {
	String insertBqrMerchants(AddBqrMerchantsBean addBqrMerchantsBean, String userId);

	String updateBqrMerchants(AddBqrMerchantsBean addBqrMerchantsBean, String userId);

	AddBqrMerchantsBean editBqrMerchants(long id);

	DataTablesResponse<AddBqrMerchantsBean> getBqrMerchantsList(BqrListDatatablesRequestBean dtRequest);

}
