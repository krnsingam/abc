package com.mosambee.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.mosambee.bean.EmiBulkUploadBean;
import com.mosambee.bean.EmiDownloadBean;
import com.mosambee.bean.EmiMidTidBean;
import com.mosambee.bean.EmiSearchDatatablesRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.BulkUploadCategory;
import com.mosambee.constants.BulkUploadFileLocation;
import com.mosambee.constants.BulkUploadMessages;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.EmiBulkUploadDao;
import com.mosambee.properties.ExcelHeaderProperties;
import com.mosambee.service.EmiBulkUploadService;
import com.mosambee.service.ExcelService;
import com.mosambee.transformer.EmiBulkUploadTransformer;
import com.mosambee.validator.CommonValidator;
import com.mosambee.validator.EmiBulkUploadValidator;

/**
 * This class is using for uploading emi bulk upload file and getting response
 * corresponding this file
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Service("emiBulkUploadService")
public class EmiBulkUploadServiceImpl implements EmiBulkUploadService {
	private static final Logger log = LogManager.getLogger(EmiBulkUploadServiceImpl.class);
	private static final DataFormatter dataFormatter = new DataFormatter();

	@Autowired
	private ExcelService excelService;

	@Autowired
	private ExcelHeaderProperties excelHeaderProperties;

	@Autowired
	private EmiBulkUploadDao emiBulkUploadDao;

	@Autowired
	private EmiBulkUploadValidator emiBulkUploadValidator;

	@Autowired
	private EmiBulkUploadTransformer emiBulkUploadTransformer;

	@Autowired
	CommonValidator commonValidator;

	/**
	 * Responsible for processing {@link MultipartFile} ... Here we are validating
	 * the header, security issues, parsing the data from the {@link Workbook} &
	 * then again parsing the validated data from the {@link Workbook}
	 *
	 * @param file {@link MultipartFile}
	 * @return {@link Resource}
	 */
	@Override
	public Resource processEmiBulkUploadExcel(MultipartFile file, String createdBy) {
		Workbook workbook = excelService.getWorkbookFromMultipartFile(file);

		List<EmiBulkUploadBean> emiBulkUploadBeanList = new ArrayList<>();
		List<EmiBulkUploadBean> successRecordList = new ArrayList<>();
		List<EmiBulkUploadBean> failedRecordList = new ArrayList<>();
		// VALIDATE THE HEADER & VALIDATE SECURITY ISSUES
		if (validateExcelFile(file, workbook) && validateSecurityIssues(file, workbook)) {

			// PARSE DATA FROM WORKBOOK
			List<EmiMidTidBean> emiMidTidBeanList = parseEmiBulkUploadFields(workbook);

			// VALIDATE THE PARSED DATA FROM WORKBOOK INTO SUCCESS & FAILED RECORD LIST
			validateAndTransformParsedDataIntoLists(emiMidTidBeanList, successRecordList, failedRecordList);
			// PERSIST THE PROGRAMS IN DATABASE AND ADD PROGRAM CODE CORRESPONDING TO THEM
			persistEmiMidTid(successRecordList, createdBy);

			// ADD ALL SUCCESS AND FAILED RECORDS IN A COMMON LIST
			emiBulkUploadBeanList.addAll(failedRecordList);
			emiBulkUploadBeanList.addAll(successRecordList);

			// GET THE EXCEL WITH RESPONSE
			Workbook responseWorkbook = writeEmiBulkUploadBeanListToExcel(emiBulkUploadBeanList);

			return excelService.getResourceFromWorkbook(responseWorkbook);

		} else {
			log.error("Excel file is not valid");
		}

		return null;
	}

	/**
	 * Performs validation for excel extension and validates the excel header.
	 * 
	 * @param file     MultipartFile
	 * @param workbook Workbook
	 * @return boolean
	 */
	private boolean validateExcelFile(MultipartFile file, Workbook workbook) {
		return excelService.validateExtension(file)
				&& excelService.validateHeader(workbook, BulkUploadCategory.EMI_BULK_UPLOAD);
	}

	/**
	 * Performs validation for security issues in excel file. Mainly we are check
	 * for embedded object, macros and VB Scripts.
	 *
	 * @param file     MultipartFile
	 * @param workbook Workbook
	 * @return boolean
	 */
	private boolean validateSecurityIssues(MultipartFile file, Workbook workbook) {
		return excelService.checkForEmbeddedObjects(workbook) && excelService.checkForMacrosAndVbScript(file);
	}

	/**
	 * parseEmiBulkUploadFields(...) is responsible to parsing the workbook. Here we
	 * are parsing the sheet present at 0th index and then iterating the rows and
	 * cells inside them to extract the values.
	 * 
	 * @param workbook {@link Workbook}
	 * @return {@link List} of {@link EmiMidTidBean}
	 */
	private List<EmiMidTidBean> parseEmiBulkUploadFields(Workbook workbook) {
		Iterator<Row> rowIterator = workbook.getSheetAt(0).iterator();
		List<EmiMidTidBean> emiMidTidBeanList = new ArrayList<>();

		// SKIPING THE HEADER ROW
		rowIterator.next();
		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			EmiMidTidBean emiMidTidBean = parseRow(row);
			emiMidTidBeanList.add(emiMidTidBean);
		}

		return emiMidTidBeanList;
	}

	/**
	 * {@link #parseRow(Row)} method is responsible for parsing the row and storing
	 * the parsed value in the object of {@link EmiMidTidBean}
	 * 
	 * @param row
	 * @return {@link EmiMidTidBean}
	 */
	private EmiMidTidBean parseRow(Row row) {
		EmiMidTidBean emiMidTidBean = new EmiMidTidBean();

		// SUBTRACT 1 FROM THE SIZE AS IT HAS STATUS HEADER.
		int sizeOfExcelHeader = excelHeaderProperties.getEmiBulkUploadHeaders().size() - 1;

		for (int i = 0; i < sizeOfExcelHeader; ++i) {

			Cell cell = row.getCell(i);

			switch (i) {
			case 0:
				emiMidTidBean.setAcquirer(dataFormatter.formatCellValue(cell));
				break;
			case 1:
				emiMidTidBean.setMid(dataFormatter.formatCellValue(cell));
				break;
			case 2:
				emiMidTidBean.setTid(dataFormatter.formatCellValue(cell));
				break;
			case 3:
				emiMidTidBean.setCredit(dataFormatter.formatCellValue(cell));
				break;
			case 4:
				emiMidTidBean.setDebit(dataFormatter.formatCellValue(cell));
				break;
			default:
				String defaultCellValue = dataFormatter.formatCellValue(cell);
				log.info("Getting into the default case: {}", defaultCellValue);
				break;
			}
		}

		return emiMidTidBean;

	}

	/**
	 * <strong>validateAndTransformParsedDataIntoLists(...)</strong> is responsible
	 * for iterating over the list of emi upload and then putting them into two
	 * separate list, on the basis of their success and failed validation status.
	 * <br>
	 * <br>
	 * 
	 * Here we are using two lists, i.e. successRecordList & failedRecordList for
	 * success and failed records. <br>
	 * 
	 * @param emiMidTidBeanList {@link List} of all the mid.
	 * @param successRecordList {@link List} of all the success records.
	 * @param failedRecordList  {@link List} of all the failed records.
	 * @return void
	 */
	private void validateAndTransformParsedDataIntoLists(List<EmiMidTidBean> emiMidTidBeanList,
			List<EmiBulkUploadBean> successRecordList, List<EmiBulkUploadBean> failedRecordList) {

		// LOOP OVER THE LIST OF MID
		for (EmiMidTidBean emiMidTidBean : emiMidTidBeanList) {

			// VALIDATE THE BEAN
			EmiBulkUploadBean emiBulkUploadBean = emiBulkUploadValidator.validateEmiMidTidBean(emiMidTidBean);

			// PUT THEM IN RESPECTIVE LIST.
			if (emiBulkUploadBean.getStatus().equals("")) {
				successRecordList.add(emiBulkUploadBean);
			} else {
				failedRecordList.add(emiBulkUploadBean);
			}
		}
	}

	/**
	 * persistEmiMidTid(...) is responsible for getting the response from
	 * updateMidDownloadBean
	 * 
	 * @param successRecordList
	 * @return void
	 */
	private void persistEmiMidTid(List<EmiBulkUploadBean> successRecordList, String createdBy) {

		// INSERT INTO THE DB
		for (EmiBulkUploadBean emiBulkUploadBean : successRecordList) {
			String response = emiBulkUploadDao.uploadEmiMidTid(emiBulkUploadBean, createdBy);

			// PROCESS THE RESPONSE
			updateEmiMidTidBean(response, emiBulkUploadBean);
		}
	}

	/**
	 * updateEmiMidTidBean is responsible for checking the response coming from db
	 * and if response is null,that means exception has occurred on DB side update
	 * status according to response
	 */
	private void updateEmiMidTidBean(String response, EmiBulkUploadBean emiBulkUploadBean) {

		if (null == response) {
			emiBulkUploadBean.setStatus(BulkUploadMessages.EXCEPTION_OCCURED_WHILE_INSERTION.get());
		} else if (response.equals("1")) {
			emiBulkUploadBean.setStatus(BulkUploadMessages.RESPONSE_ERROR_MESSAGE1.get());
		} else if (response.equals("2")) {
			emiBulkUploadBean.setStatus(BulkUploadMessages.RESPONSE_ERROR_MESSAGE2.get());
		} else if (response.equals("9")) {
			emiBulkUploadBean.setStatus(BulkUploadMessages.RESPONSE_ERROR_MESSAGE9.get());
		} else if (response.equals("3")) {
			emiBulkUploadBean.setStatus(BulkUploadMessages.RESPONSE_ERROR_MESSAGE3.get());
		} else if (response.equals("10")) {
			emiBulkUploadBean.setStatus(BulkUploadMessages.RESPONSE_ERROR_MESSAGE10.get());
		} else if (emiBulkUploadBean.getStatus().equals("") && response.equals("0")) {
			emiBulkUploadBean.setStatus(BulkUploadMessages.SUCCESS.get());
		}
	}

	/**
	 * {@link #writeInstantMidUploadBeanListToExcel(List)} is responsible for for
	 * creating the excel with the response after processing the instant mid upload
	 * excel file.
	 * 
	 * @param instantMidUploadBeanList
	 * @return {@link Workbook}
	 */
	private Workbook writeEmiBulkUploadBeanListToExcel(List<EmiBulkUploadBean> emiBulkUploadBeanList) {

		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.EMI_BULK_UPLOAD);
		Sheet sheet = workbook.getSheetAt(0);

		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		for (EmiBulkUploadBean emiBulkUploadBean : emiBulkUploadBeanList) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(emiBulkUploadBean.getAcquirer());
			row.createCell(1).setCellValue(emiBulkUploadBean.getMid());
			row.createCell(2).setCellValue(emiBulkUploadBean.getTid());
			row.createCell(3).setCellValue(emiBulkUploadBean.getCredit());
			row.createCell(4).setCellValue(emiBulkUploadBean.getDebit());
			row.createCell(5).setCellValue(emiBulkUploadBean.getStatus());

		}

		excelService.autoSizeExcel(workbook);
		return workbook;

	}

	/**
	 * getEmiBulkUploadFormat() is responsible for converting the emi bulk upload
	 * files present in {@link BulkUploadFileLocation} to {@link Resource}
	 */
	@Override
	public Resource getEmiBulkUploadFormat() {
		ClassPathResource resource = null;
		resource = new ClassPathResource(BulkUploadFileLocation.EMI_BULK_UPLOAD.get());
		return resource.exists() ? resource : null;
	}

	/**
	 * getEmiSearchList(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request of
	 * EmiMidTidBean & then and formatting date in mySQLFormat and compare date
	 * means only one month data will search and then calling the DAO to get those
	 * values.
	 * 
	 * @param dtRequest {@link EmiSearchDatatablesRequestBean}
	 */
	@Override
	public DataTablesResponse<EmiMidTidBean> getEmiSearchList(EmiSearchDatatablesRequestBean dtRequest) {
		// GET THE COLUMN NAME FROM COLUMN INDEX
		int orderingColumnIndex = dtRequest.getDtRequest().getOrder().get(0).getColumn();
		String orderingColumnName = getOrderingColumnNameOfEmiSearchList(orderingColumnIndex);
		log.info("orderingColumnIndexs: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);
		// checking if fromDate and toDate is null
		SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date currentDate = new Date();

		String from = dtRequest.getFromDate();
		String to = dtRequest.getToDate();
		if (from.equals("") || to.equals("")) {
			dtRequest.setFromDate(simpleFormat.format(currentDate));
			dtRequest.setToDate(simpleFormat.format(currentDate));
		}

		// calling commonValidator to format date in MySQLFormate
		dtRequest.setFromDate(commonValidator.dateTimeValidator(dtRequest.getFromDate()));
		dtRequest.setToDate(commonValidator.timeValidator(dtRequest.getToDate()));

		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ENQUIRY REPORTING
		Map<String, String> searchMap = emiBulkUploadTransformer.transformEmiSearchListDataTablesRequest(dtRequest);
		log.info("size of searchMaps: {}", searchMap.size());
		DataTablesResponse<EmiMidTidBean> dtResponse = emiBulkUploadDao.getEmiSearchList(dtRequest, orderingColumnName,
				searchMap);
		dtResponse.setDraw(dtRequest.getDtRequest().getDraw());
		return dtResponse;

	}

	/**
	 * getOrderingColumnNameOfEmiSearchList (...) method is responsible for
	 * returning orderingColumnName of EmiMidTidBean when it is provided with
	 * orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnNameOfEmiSearchList(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.ACQUIRER.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.MERCHANT_CODE.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.TID.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.CREDIT.get();
			break;
		case 4:
			orderingColumnName = ColumnNames.DEBIT.get();
			break;

		default:
			orderingColumnName = ColumnNames.ACQUIRER.get();
			break;
		}

		return orderingColumnName;
	}

	@Override
	public List<EmiMidTidBean> downloadEmiSearchList(EmiDownloadBean emiDownloadBean) {

		SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date currentDate = new Date();
		String from = emiDownloadBean.getFromDate();
		String to = emiDownloadBean.getToDate();
		if (from.equals("") || to.equals("")) {
			emiDownloadBean.setFromDate(simpleFormat.format(currentDate));
			emiDownloadBean.setToDate(simpleFormat.format(currentDate));
		}
		// calling commonValidator to format date in MySQLFormate
		emiDownloadBean.setFromDate(commonValidator.dateTimeValidator(emiDownloadBean.getFromDate()));
		emiDownloadBean.setToDate(commonValidator.timeValidator(emiDownloadBean.getToDate()));

		return emiBulkUploadDao.downloadEmiSearchList(emiDownloadBean);

	}

	@Override
	public Resource processEmiSearchList(List<EmiMidTidBean> responseBean) {
		// GET THE EXCEL OF emi search list WITH RESPONSE
		Workbook responseWorkbook = writeEmiSearchListToExcel(responseBean);
		return getResourceFromWorkbook(responseWorkbook);

	}

	private Workbook writeEmiSearchListToExcel(List<EmiMidTidBean> responseBean) {

		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.EMI_SEARCH_LIST);
		Sheet sheet = workbook.getSheetAt(0);

		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		for (EmiMidTidBean emiMidTidBean : responseBean) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(emiMidTidBean.getAcquirer());
			row.createCell(1).setCellValue(emiMidTidBean.getMid());
			row.createCell(2).setCellValue(emiMidTidBean.getTid());
			row.createCell(3).setCellValue(emiMidTidBean.getCredit());
			row.createCell(4).setCellValue(emiMidTidBean.getDebit());
			row.createCell(5).setCellValue(emiMidTidBean.getCreatedTime());

		}
		excelService.autoSizeExcel(workbook);
		return workbook;
	}

	/**
	 * {@link #getResourceFromWorkbook(Workbook)} convert the {@link Workbook} to
	 * {@link Resource} so that it can be send over the network as response to the
	 * web-page.
	 * 
	 * @param responseWorkbook {@link Workbook}
	 * @return {@link Resource}
	 */
	private Resource getResourceFromWorkbook(Workbook responseWorkbook) {
		try {
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			responseWorkbook.write(byteArrayOutputStream);
			ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
			return new InputStreamResource(byteArrayInputStream);
		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}

}
