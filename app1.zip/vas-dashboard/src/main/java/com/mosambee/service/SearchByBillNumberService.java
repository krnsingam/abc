package com.mosambee.service;

import com.mosambee.bean.BillNumberBean;
import com.mosambee.bean.BillNumberDataTablesRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.service.impl.SearchByBillNumberServiceImpl;

/**
 * SearchByBillNumberService specification for {@link SearchByBillNumberServiceImpl} class
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 23-March-2020
 */
public interface SearchByBillNumberService {
	
	DataTablesResponse<BillNumberBean> getBillNumberTransactionList(BillNumberDataTablesRequestBean dtRequest);


}
