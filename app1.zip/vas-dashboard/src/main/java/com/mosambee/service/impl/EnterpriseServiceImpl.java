package com.mosambee.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mosambee.bean.CityBean;
import com.mosambee.bean.CountryBean;
import com.mosambee.bean.EnterpriseBean;
import com.mosambee.bean.EnterpriseDataBean;
import com.mosambee.bean.EnterpriseListBean;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.StateBean;
import com.mosambee.bean.UpdateAPIPaswordConfigRequestFromList;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.constants.ViewLayer;
import com.mosambee.dao.EnterpriseDao;
import com.mosambee.service.EnterpriseService;
import com.mosambee.transformer.EnterpriseTransformer;
import com.mosambee.validator.CommonValidator;
import com.mosambee.validator.EnterpriseValidator;

import lombok.extern.log4j.Log4j2;

/**
 * EnterpriseServiceImpl class implementing {@link EnterpriseService}
 * specification.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 24-March-2020
 */
@Log4j2
@Service(value = "enterpriseService")
public class EnterpriseServiceImpl implements EnterpriseService{

	@Autowired
	EnterpriseDao dao;
	
	@Autowired
	CommonValidator commonValidator;
	
	@Autowired
	EnterpriseValidator validator;
	
	@Autowired
	EnterpriseTransformer transformer;

	private static final String RECORD_ID = "recordId";
	
	/**
	 * This method is used to call validation methods on {@link EnterpriseBean}.
	 * Also this method checks that bean is validated or not if bean is validated it
	 * allows to insert record in database by calling
	 * {@link #EnterpriseBean(EnterpriseBean, responseBean, id)} of
	 * {@link EnterpriseDao}. If bean failed in validation then it set
	 * {@link ResponseBean} class field "operationStatus" to 400, If data is
	 * successfully inserted then set "updateRequest" to "True" and
	 * "operationStatus" to 200 otherwise set "operationStatus" to 400 and
	 * "updateRequest" to "False".
	 * 
	 * @param responseBean   : Expect bean of "{@link ResponseBean}" which is used
	 *                       to set operation status message. We can use this to to
	 *                       render data related to status message to jsp.
	 * @param EnterpriseBean : Expect bean of "{@link EnterpriseBean}" from which
	 *                       data should be store.
	 * @return void
	 */
	@Override
	public ResponseBean processCreateEnterprise(EnterpriseBean enterprise, ResponseBean responseBean) {

		validator.validateCreateEnterprise(enterprise); // This call is sued to validate
																				// "createAPIGroup" bean.
		boolean status;
		if (enterprise.isValidate()) // If validation succeed then insert record.
		{
			//apiPasswordConfigTransformer.transformMPOSAPIPasswordForDataInserting(enterprise);
			responseBean = dao.createEnterprise(enterprise);
			status = responseBean.isUpdateRequest();
			long id = Long.parseLong(responseBean.getData().get(RECORD_ID).toString());

			if (status) // Checks that insert record operation successful or not.
			{
				responseBean.setUpdateRequest(true);
				responseBean.setOperationStatus(200);
				responseBean.setAction(ViewLayer.UPDATE_API_GROUP_ACTION.get()); // Set form action to update record.

			} else {

				responseBean.setUpdateRequest(false);
				responseBean.setOperationStatus(400);
				responseBean.setAction(ViewLayer.CREATE_API_GROUP_ACTION.get()); // Set form action to create record.
			}
			log.info("createAPIGroup validation status : {} ", enterprise.isValidate());
			return responseBean;
		} else {
			responseBean.setMsg("Sorry, Data is not valid.");
			responseBean.setOperationStatus(400);
			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put(RECORD_ID, 0);
			responseBean.setAction(ViewLayer.CREATE_API_GROUP_ACTION.get());
			log.info("createAPIGroup validation status : {} ", enterprise.isValidate());
			return responseBean;
		}
	}
	
	/**
	 * This method is used to get country detail record for Enterprise
	 * 
	 * @return List<CountryBean>
	 * @author karan.singam
	 */
	@Override
	public List<CountryBean> getCountry() {
		return dao.getCountry();
	}
	
	/**
	 * This method is used to get State detail record for Enterprise
	 * 
	 * @return List<StateBean>
	 * @author karan.singam
	 */
	@Override
	public List<StateBean> getState(CountryBean country) {
		return dao.getState(country);
	}
	
	/**
	 * This method is used to get city detail record for Enterprise
	 * 
	 * @return List<CityBean>
	 * @author karan.singam
	 */
	@Override
	public List<CityBean> getCity(StateBean state) {
		return dao.getCity(state);
	}
	
	
	/**
	 * getActiveTransactionList(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request & then
	 * calling the DAO to get those values.
	 * 
	 * @param dtRequest
	 *            {@link DataTablesRequest}
	 * @return DataTablesResponse of TransactionReportBean
	 */
	@Override
	public DataTablesResponse<EnterpriseListBean> enterpriseList(EnterpriseDataBean dtRequest) {

		// GET THE COLUMN NAME FROM COLUMN INDEX
		int orderingColumnIndex = dtRequest.getDataTable().getOrder().get(0).getColumn();
		String orderingColumnName = getOrderingColumnName(orderingColumnIndex);
		log.info("orderingColumnIndex: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);

		// Setting up date format
		dtRequest.setFromDate(commonValidator.dateTimeValidator(dtRequest.getFromDate()));
		dtRequest.setToDate(commonValidator.timeValidator(dtRequest.getToDate()));

		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ACTIVE TRANSACTION
		Map<String, String> searchMap = transformer.transformEnterprise(dtRequest);
		log.info("size of searchMap: {}", searchMap.size());

		return dao.enterpriseList(dtRequest, orderingColumnName, searchMap);
	}

	/**
	 * getOrderingColumnName(...) method is responsible for returning
	 * orderingColumnName when it is provided with orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnName(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.ENTERPRISE_NAME.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.ENTERPRIS_NUMBER_TERMINAL.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.ENTERPRISE_TOTAL_SALES.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.ENTERPRISE_TOTAL_TRANSACTION.get();
			break;
		case 4:
			orderingColumnName = ColumnNames.ENTERPRISE_DECLINED_TRANSACTION.get();
			break;
		case 5:
			orderingColumnName = ColumnNames.ENTERPRISE_VIEW.get();

		default:
			orderingColumnName = ColumnNames.ENTERPRISE_ID.get();
			break;
		}

		return orderingColumnName;
	}
	
	/**
	 * getEnterpriseName(...) is responsible for 
	 * calling the DAO to get Id and Name as values.
	 * 
	 * @return List<EnterpriseListBean>
	 */
	@Override
	public List<EnterpriseListBean> getEnterpriseName(EnterpriseListBean bean) {
	
		return dao.getEnterpriseName(bean);
	}

	/**
	 * This method is used to call validation methods on {@link EnterpriseBean}.
	 * Also this method checks that bean is validated or not if bean is validated it
	 * allows to update record in database by calling
	 * {@link #updateEnterprise(EnterpriseBean, responseBean, id)} of
	 * {@link EnterpriseDao}. If bean failed in validation then it set
	 * {@link ResponseBean} class field "operationStatus" to 400, If data is
	 * successfully inserted then set "updateRequest" to "True" and
	 * "operationStatus" to 200 otherwise set "operationStatus" to 400 and
	 * "updateRequest" to "False".
	 * 
	 * @param responseBean   : Expect bean of "{@link ResponseBean}" which is used
	 *                       to set operation status message. We can use this to to
	 *                       render data related to status message to jsp.
	 * @param EnterpriseBean : Expect bean of "{@link EnterpriseBean}" from which
	 *                       data should be store.
	 * @return void
	 */
	@Override
	public void updateEnterprise(EnterpriseBean enterprise, ResponseBean responseBean) {

		//apiPasswordConfigValidator.validateCreateAPIGroupData(enterprise); // This call is used to validate
																				// "createAPIGroup" bean.
		if (enterprise.isValidate()) // Check that bean validation successful or not.
		{
			responseBean.setUpdateRequest(true);
			responseBean.setAction(ViewLayer.ENTERPRISE_UPDATE.get()); // Set form action to update record.
			//apiPasswordConfigTransformer.transformMPOSAPIPasswordForDataUpdating(enterprise);
			boolean status = dao.updateEnterprise(enterprise, responseBean);

			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put(RECORD_ID, enterprise.getEId());
			if (status) // Checks that Update record operation successful or not.
			{
				
				responseBean.setOperationStatus(200);
			} else {
				responseBean.setOperationStatus(400);
			}
		} else {
			responseBean.setMsg("Sorry, Data is not valid.");
			responseBean.setOperationStatus(400);
		}
		log.info("returning from processUpdateAPIGroupData {} ", enterprise.isValidate());
	}

	/**
	 * This method is basically calling {@link #getAPIGroupDataById()} of
	 * {@link EnterpriseDao} if it return "True" then set
	 * {@link ResponseBean} "operationStatus" to 200 and "action" to "update action"
	 * otherwise set "operationStatus" to 400.
	 */
	@Override
	public void updateEnterpriseList(UpdateAPIPaswordConfigRequestFromList updateAPIPaswordConfigRequestFromList,
			EnterpriseBean enterprise, ResponseBean responseBean) {
		responseBean.setData(new HashMap<String, Object>());
		responseBean.getData().put(RECORD_ID, enterprise.getEId()); // This id will render on jsp page which will be
																		// used for update APIPasswordConfig request.
		boolean status = dao.updateEnterpriseList(updateAPIPaswordConfigRequestFromList, enterprise,
				responseBean); // Fetch APIPasswordConfig details by passing
								// updateAPIPaswordConfigRequestFromList.
		if (status) {
			responseBean.setOperationStatus(200);
			responseBean.setAction(ViewLayer.ENTERPRISE_UPDATE.get());
			responseBean.getData().put("breadCrumb", true);
			responseBean.setUpdateRequest(true);
		} else {
			responseBean.setOperationStatus(400);
		}

	}
}
