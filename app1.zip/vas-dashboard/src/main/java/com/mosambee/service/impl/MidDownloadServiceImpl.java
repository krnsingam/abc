package com.mosambee.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import com.mosambee.bean.MidDateBean;
import com.mosambee.bean.MidDownloadBean;
import com.mosambee.constants.BulkUploadCategory;
import com.mosambee.dao.MidDownloadDao;
import com.mosambee.service.ExcelService;
import com.mosambee.service.MidDownloadService;
import com.mosambee.validator.CommonValidator;

/**
 * This class provides specification for {@link MidDownloadService} and
 * basically used to download mid
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Service("midDownloadServiceImpl")
public class MidDownloadServiceImpl implements MidDownloadService {
	private static final Logger log = LogManager.getLogger(MidDownloadServiceImpl.class);

	@Autowired
	ExcelService excelService;

	@Autowired
	MidDownloadService midDownloadService;

	@Autowired
	MidDownloadDao midDownloadDao;

	@Autowired
	CommonValidator commonValidator;

	/**
	 * downloadMid() is responsible for download mid and formate fromDate and toDate
	 * in mySqlFormat and calling the dao to get values.
	 *
	 */
	@Override
	public List<MidDownloadBean> downloadMid(MidDateBean midDateBean) {
		SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date currentDate = new Date();
		// checking if fromDate and toDate is null
		String from = midDateBean.getFromDate();
		String to = midDateBean.getToDate();
		if (from.equals("") || to.equals("")) {
			midDateBean.setFromDate(simpleFormat.format(currentDate));
			midDateBean.setToDate(simpleFormat.format(currentDate));
		}
		// calling commonValidator to format date in MySQLFormate
		midDateBean.setFromDate(commonValidator.dateTimeValidator(midDateBean.getFromDate()));
		midDateBean.setToDate(commonValidator.timeValidator(midDateBean.getToDate()));
		return midDownloadDao.downloadMid(midDateBean);
	}

	public Resource processMidDownload(List<MidDownloadBean> responseBean) {
		// GET THE EXCEL OF MID DOWNLOAD WITH RESPONSE
		Workbook responseWorkbook = writeMidDownloadListToExcel(responseBean);
		return getResourceFromWorkbook(responseWorkbook);
	}

	private Workbook writeMidDownloadListToExcel(List<MidDownloadBean> responseBean) {
		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.MID_DOWNLOAD);
		Sheet sheet = workbook.getSheetAt(0);

		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		for (MidDownloadBean midDownloadBean : responseBean) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(midDownloadBean.getAcquirer());
			row.createCell(1).setCellValue(midDownloadBean.getPosId());
			row.createCell(2).setCellValue(midDownloadBean.getMid());
			row.createCell(3).setCellValue(midDownloadBean.getTempMerchantCode());
			row.createCell(4).setCellValue(midDownloadBean.getTempTid());
			row.createCell(5).setCellValue(midDownloadBean.getTypeId());
		}
		excelService.autoSizeExcel(workbook);
		return workbook;
	}

	/**
	 * {@link #getResourceFromWorkbook(Workbook)} convert the {@link Workbook} to
	 * {@link Resource} so that it can be send over the network as response to the
	 * web-page.
	 * 
	 * @param responseWorkbook {@link Workbook}
	 * @return {@link Resource}
	 */
	private Resource getResourceFromWorkbook(Workbook responseWorkbook) {
		try {
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			responseWorkbook.write(byteArrayOutputStream);
			ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
			return new InputStreamResource(byteArrayInputStream);
		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}

}
