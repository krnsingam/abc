package com.mosambee.service;

import org.springframework.core.io.Resource;

import com.mosambee.bean.AcquirerBulkDataBean;
import com.mosambee.bean.AcquirerBulkUploadBean;
import com.mosambee.bean.datatables.DataTablesResponse;

/**
 * AcquirerBulkUploadService.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 27-February-2020
 */
public interface AcquirerBulkUploadService {

	public DataTablesResponse<AcquirerBulkUploadBean> getListOfAcquirer(AcquirerBulkDataBean dtRequest);
	
	public Resource downloadActiveAcquirerList(AcquirerBulkUploadBean report);
}
