package com.mosambee.service;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

/**
 * ProgramBulkUploadService.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 28-December-2019
 */
public interface ProgramBulkUploadService {

	Resource processBulkUploadExcel(MultipartFile file);

	Resource getProgramBulkUploadFormat();

}
