package com.mosambee.service;

public interface ForgotPasswordService {

	String processForgotPasswordRequest(String email);

}
