package com.mosambee.service;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

/**
 * This provides specification for {@link EmiUploadServiceImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 */
public interface EmiUploadService {

	Resource getEmiUploadFormat();

	Resource processEmiUploadExcel(MultipartFile file);

}
