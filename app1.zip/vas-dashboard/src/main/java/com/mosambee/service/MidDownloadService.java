package com.mosambee.service;

import java.util.List;

import org.springframework.core.io.Resource;
import com.mosambee.bean.MidDateBean;
import com.mosambee.bean.MidDownloadBean;

/**
 * This class provides specification for {@link MidDownloadServiceImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 */
public interface MidDownloadService {

	List<MidDownloadBean> downloadMid(MidDateBean midDateBean);

	Resource processMidDownload(List<MidDownloadBean> responseBean);

}
