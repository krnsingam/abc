package com.mosambee.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mosambee.bean.CustomUser;
import com.mosambee.bean.SBIMidBean;
import com.mosambee.bean.SBIMidUploadBean;
import com.mosambee.constants.BulkUploadCategory;
import com.mosambee.constants.BulkUploadFileLocation;
import com.mosambee.constants.BulkUploadMessages;
import com.mosambee.dao.SbiEmiUploadDao;
import com.mosambee.properties.ExcelHeaderProperties;
import com.mosambee.service.ExcelService;
import com.mosambee.service.SbiMidUploadService;
import com.mosambee.validator.SbiMidUploadValidator;

import lombok.extern.log4j.Log4j2;

/**
 * This class is used for sbi-emi mid upload
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 */
@Log4j2
@Service("sbiMidUploadService")
public class SbiMidUploadServiceImpl implements SbiMidUploadService {

	private static final DataFormatter dataFormatter = new DataFormatter();

	@Autowired
	private ExcelService excelService;

	@Autowired
	private ExcelHeaderProperties excelHeaderProperties;

	@Autowired
	private SbiMidUploadValidator sbiMidUploadValidator;

	@Autowired
	private SbiEmiUploadDao sbiEmiUploadDao;

	/**
	 * Responsible for processing {@link MultipartFile} ... Here we are validating
	 * the header, security issues, parsing the data from the {@link Workbook} &
	 * then again parsing the validated data from the {@link Workbook}
	 *
	 * @param file {@link MultipartFile}
	 * @return {@link Resource}
	 */
	@Override
	public Resource processSbiEmiUploadExcel(MultipartFile file) {
		Workbook workbook = excelService.getWorkbookFromMultipartFile(file);
		List<SBIMidUploadBean> sbiMidUploadBeanList = new ArrayList<>();
		List<SBIMidUploadBean> successRecordList = new ArrayList<>();
		List<SBIMidUploadBean> failedRecordList = new ArrayList<>();
		// VALIDATE THE HEADER & VALIDATE SECURITY ISSUES
		if (validateExcelFile(file, workbook) && validateSecurityIssues(file, workbook)) {

			// PARSE DATA FROM WORKBOOK
			List<SBIMidBean> sbiMidBeanList = persistsSbiMidUploadFields(workbook);

			// VALIDATE THE PARSED DATA FROM WORKBOOK INTO SUCCESS & FAILED RECORD LIST
			validateAndTransformParsedDataIntoLists(sbiMidBeanList, successRecordList, failedRecordList);

			// PERSISTS EMI CONVERSION FIELDS IN DATABASE
			persistsSbiMid(successRecordList);

			// ADD ALL SUCCESS AND FAILED RECORDS IN A COMMON LIST
			sbiMidUploadBeanList.addAll(failedRecordList);
			sbiMidUploadBeanList.addAll(successRecordList);

			// GET THE EXCEL WITH RESPONSE
			Workbook responseWorkbook = writeSbiMidUploadBeanListToExcel(sbiMidUploadBeanList);

			return excelService.getResourceFromWorkbook(responseWorkbook);

		} else {
			log.error("Excel file is not valid");
		}

		return null;
	}

	/**
	 * {@link #writeSbiMidUploadBeanListToExcel(List)} is responsible for creating
	 * the excel with the response after processing the sbi mid upload excel file.
	 * 
	 * @param sbiMidUploadBeanList
	 * @return {@link Workbook}
	 */
	private Workbook writeSbiMidUploadBeanListToExcel(List<SBIMidUploadBean> sbiMidUploadBeanList) {
		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.SBI_MID_UPLOAD);
		Sheet sheet = workbook.getSheetAt(0);

		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		for (SBIMidUploadBean sBIMidUploadBean : sbiMidUploadBeanList) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(sBIMidUploadBean.getMPosMid());
			row.createCell(1).setCellValue(sBIMidUploadBean.getMerchantName());
			row.createCell(2).setCellValue(sBIMidUploadBean.getMerchantCity());
			row.createCell(3).setCellValue(sBIMidUploadBean.getStatus());
		}

		excelService.autoSizeExcel(workbook);
		return workbook;
	}

	/**
	 * persistsSbiMid is responsible for getting response from
	 * SBIMidUploadBean
	 * 
	 * @param successRecordList
	 */
	private void persistsSbiMid(List<SBIMidUploadBean> successRecordList) {
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Long userId = Long.parseLong(user.getMyMap().get("id"));

		// INSERT INTO DB
		for (SBIMidUploadBean sBIMidUploadBean : successRecordList) {
			String response = sbiEmiUploadDao.uploadSbiMid(sBIMidUploadBean, userId);

			// PROCESS THE RESPONSE
			updateSbiMidBean(response.trim(), sBIMidUploadBean);
		}

	}

	private void updateSbiMidBean(String response, SBIMidUploadBean sBIMidUploadBean) {
		if (null == response) {
			sBIMidUploadBean.setStatus(BulkUploadMessages.EXCEPTION_OCCURED_WHILE_INSERTION.get());
		} else if (response.equals("Merchant Id Already Exist")) {
			sBIMidUploadBean.setStatus("Merchant Id Already Exist");
		} else if (response.equals("Invalid MID")) {
			sBIMidUploadBean.setStatus("Invalid MID");
		} else if (sBIMidUploadBean.getStatus().equals("") && response.equals("SBI MID details added successfully")) {
			sBIMidUploadBean.setStatus(BulkUploadMessages.SUCCESS.get());
		}

	}

	/**
	 * validateAndTransformParsedDataIntoLists(...) is responsible for iterating
	 * over the list of SBI MID and then putting them into two separate list, on the
	 * basis of their success and failed validation status.
	 * 
	 * Here we are using two lists, i.e. successRecordList & failedRecordList for
	 * success and failed records.
	 * 
	 * @param sbiMidBeanList    {@link List} of all the mid.
	 * @param successRecordList {@link List} of all the success records.
	 * @param failedRecordList  {@link List} of all the failed records.
	 * @return void
	 */
	private void validateAndTransformParsedDataIntoLists(List<SBIMidBean> sbiMidBeanList,
			List<SBIMidUploadBean> successRecordList, List<SBIMidUploadBean> failedRecordList) {

		// LOOP OVER THE LIST OF MID
		for (SBIMidBean sBIMidBean : sbiMidBeanList) {

			// VALIDATE THE BEAN
			SBIMidUploadBean sBIMidUploadBean = sbiMidUploadValidator.validateSBIMidBean(sBIMidBean);

			// PUT THEM IN RESPECTIVE LIST.
			if (sBIMidUploadBean.getStatus().equals("")) {
				successRecordList.add(sBIMidUploadBean);
			} else {
				failedRecordList.add(sBIMidUploadBean);
			}
		}

	}

	private List<SBIMidBean> persistsSbiMidUploadFields(Workbook workbook) {
		Iterator<Row> rowIterator = workbook.getSheetAt(0).iterator();
		List<SBIMidBean> sbiMidBeanList = new ArrayList<>();

		// SKIPING THE HEADER ROW
		rowIterator.next();

		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			SBIMidBean sBIMidBean = parseRow(row);
			sbiMidBeanList.add(sBIMidBean);
		}

		return sbiMidBeanList;

	}

	/**
	 * {@link #parseRow(Row)} method is responsible for parsing the row and storing
	 * the parsed value in the object of {@link SBIMidBean}
	 * 
	 * @param row
	 * @return {@link SBIMidBean}
	 */
	private SBIMidBean parseRow(Row row) {
		SBIMidBean sBIMidBean = new SBIMidBean();

		// SUBTRACT 1 FROM THE SIZE AS IT HAS STATUS HEADER.
		int sizeOfExcelHeader = excelHeaderProperties.getSbiMidUploadHeaders().size() - 1;

		for (int i = 0; i < sizeOfExcelHeader; ++i) {

			Cell cell = row.getCell(i);

			switch (i) {
			case 0:
				sBIMidBean.setMPosMid(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 1:
				sBIMidBean.setMerchantName(dataFormatter.formatCellValue(cell));
				break;
			case 2:
				sBIMidBean.setMerchantCity(dataFormatter.formatCellValue(cell));
				break;

			default:
				String defaultCellValue = dataFormatter.formatCellValue(cell);
				log.info("Getting into the default case: {}", defaultCellValue);
				break;
			}
		}

		return sBIMidBean;

	}

	/**
	 * Performs validation for excel extension and validates the excel header.
	 * 
	 * @param file     MultipartFile
	 * @param workbook Workbook
	 * @return boolean
	 */
	private boolean validateExcelFile(MultipartFile file, Workbook workbook) {
		return excelService.validateExtension(file)
				&& excelService.validateHeader(workbook, BulkUploadCategory.SBI_MID_UPLOAD);
	}

	/**
	 * Performs validation for security issues in excel file. Mainly we are check
	 * for embedded object, macros and VB Scripts.
	 *
	 * @param file     MultipartFile
	 * @param workbook Workbook
	 * @return boolean
	 */
	private boolean validateSecurityIssues(MultipartFile file, Workbook workbook) {
		return excelService.checkForEmbeddedObjects(workbook) && excelService.checkForMacrosAndVbScript(file);
	}

	@Override
	public Resource getSbiMidUploadFormat() {
		ClassPathResource resource = null;
		resource = new ClassPathResource(BulkUploadFileLocation.SBI_MID_UPLOAD.get());
		return resource.exists() ? resource : null;
	}
}
