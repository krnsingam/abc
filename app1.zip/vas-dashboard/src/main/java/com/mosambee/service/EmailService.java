package com.mosambee.service;

import com.mosambee.bean.EmailBean;
import com.mosambee.bean.ForgotPasswordParams;

/**
 * @author karan.singam
 * @version 1.0
 * @since 30-January-2020
 */
public interface EmailService {

	boolean sendEmail(EmailBean email);
	
	boolean sendHtmlEmail(EmailBean email);
	
	boolean sendForgotPasswordEmail(ForgotPasswordParams forgotPasswordParams, String newPassword);
	
}
