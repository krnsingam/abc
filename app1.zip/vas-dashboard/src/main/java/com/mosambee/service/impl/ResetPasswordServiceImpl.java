package com.mosambee.service.impl;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.mosambee.bean.CustomUser;
import com.mosambee.bean.ResetPasswordBean;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.RegexPatterns;
import com.mosambee.dao.ResetPasswordDao;
import com.mosambee.service.ResetPasswordService;
import com.mosambee.util.SHA1;

import lombok.extern.log4j.Log4j2;

/**
 * Responsible for interacting with DAO layer as well as providing utility
 * methods for resetting the password.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 05-February-2020
 */
@Log4j2
@Service("resetPasswordService")
public class ResetPasswordServiceImpl implements ResetPasswordService {

	@Autowired
	private ResetPasswordDao resetPasswordDao;

	/**
	 * Responsible for processing the incoming passwords. <br/>
	 * <br/>
	 * 
	 * Firstly validation happens by checking the equality of the incoming
	 * passwords. We are not applying any other validation checks here as we have
	 * already done that in {@link ResetPasswordBean} bean validation. <br/>
	 * <br/>
	 * 
	 * Secondly we will call the database if validation is successful, persist the
	 * incoming passwords.<br/>
	 * <br/>
	 * 
	 * At-last we will get the incoming response from DAO layer and apply checks and
	 * return the response to the controller layer.
	 * 
	 * @param resetPassword {@link ResetPasswordBean}
	 * @return String
	 */
	@Override
	public String processPasswords(ResetPasswordBean resetPassword) {
		log.info("resetPassword bean: {}", resetPassword);

		// validate the incoming passwords for equality
		boolean arePasswordsEqual = transformAndValidatePasswords(resetPassword);
		log.info("validation result: {}", arePasswordsEqual);

		if (!arePasswordsEqual) {
			log.error("password validation failed");
			return CommonConstants.PASSWORDS_NOT_EQUAL.get();
		}

		// Call the DAO layer and update the password and other fields
		CustomUser customUser = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String dbResponse = resetPasswordDao.updateNewPassword(getHashedPassword(resetPassword.getNewPassword()),
				Long.parseLong(customUser.getMyMap().get("id")));
		log.info("{}", dbResponse);

		// Check dbResponse and appropriately return the response to controller
		if (null == dbResponse) {
			return CommonConstants.DB_ERROR_OCCURED.get();
		} else if (CommonConstants.UNABLE_TO_UPDATE_USER_CHANGE_PASSWORD_TABLE.get().equalsIgnoreCase(dbResponse)
				|| CommonConstants.UNABLE_TO_UPDATE_USERS_TABLE.get().equalsIgnoreCase(dbResponse)) {
			return CommonConstants.SOME_ERROR_OCCURRED.get();
		} else if (CommonConstants.BOTH_TABLES_UPDATED_SUCCESSFULLY.get().equalsIgnoreCase(dbResponse)) {
			return dbResponse;
		}

		return dbResponse;
	}

	/**
	 * transformAndValidatePasswords(...) is responsible for calling the transformer
	 * and validation functions on incoming resetPassword POJO bean and then
	 * returning appropriate boolean response whether the incoming passwords are
	 * validate or not.
	 * 
	 * @param resetPassword
	 * @return boolean
	 */
	private boolean transformAndValidatePasswords(ResetPasswordBean resetPassword) {
		// transform the incoming password bean
		transformIncomingPasswords(resetPassword);

		// validate the incoming transformed POJO and return response
		return validateIncomingPasswords(resetPassword);
	}

	/**
	 * transformIncomingPasswords(...) is responsible for logging the lengths of
	 * incoming passwords before and after trimming them and then setting the
	 * updated passwords to the incoming resetPassword parameter bean.
	 * 
	 * @param resetPassword
	 * @return void
	 */
	private void transformIncomingPasswords(ResetPasswordBean resetPassword) {
		// Log incoming password lengths
		String newPassword = resetPassword.getNewPassword();
		String confirmNewPassword = resetPassword.getConfirmNewPassword();
		log.info("length of newPassword: {}, confirmNewPassword: {}", newPassword.length(),
				confirmNewPassword.length());

		// Trim spaces in password & log new lengths
		newPassword = newPassword.trim();
		confirmNewPassword = confirmNewPassword.trim();

		log.info("After trimming length of newPassword: {}, confirmNewPassword: {}", newPassword.length(),
				confirmNewPassword.length());

		// Set new values to the incoming POJO
		resetPassword.setNewPassword(newPassword);
		resetPassword.setConfirmNewPassword(confirmNewPassword);
	}

	/**
	 * Responsible for validating the incoming passwords against various checks like
	 * empty, equal and password policy.
	 * 
	 * @param resetPassword
	 * @return boolean
	 */
	private boolean validateIncomingPasswords(ResetPasswordBean resetPassword) {
		// Check if the incoming passwords are not empty
		if (resetPassword.getNewPassword().length() < 1 || resetPassword.getConfirmNewPassword().length() < 1) {
			log.error("passwords are empty");
			return false;
		}

		// Check if both the passwords are equal
		if (!resetPassword.getNewPassword().equals(resetPassword.getConfirmNewPassword())) {
			log.info("incoming passwords are not equal");
			return false;
		}

		// Check the password against password policy
		return validatePasswordPolicy(resetPassword);
	}

	/**
	 * Responsible for validating the incoming password against the password policy
	 * present here {@link RegexPatterns#RESET_PASSWORD_PATTERN}
	 * 
	 * @param resetPassword
	 * @return boolean
	 */
	private boolean validatePasswordPolicy(ResetPasswordBean resetPassword) {
		Pattern pattern = Pattern.compile(RegexPatterns.RESET_PASSWORD_PATTERN.get());
		Matcher matcher = pattern.matcher(resetPassword.getNewPassword());
		boolean passwordPolicyResponse = matcher.matches();
		log.info("password policy response: {}", passwordPolicyResponse);
		return passwordPolicyResponse;
	}

	/**
	 * Responsible for generating and returning the SHA256 hashed version of
	 * provided string.
	 * 
	 * @param newPassword
	 * @return String
	 */
	private String getHashedPassword(String newPassword) {
		return SHA1.getInstance().hash(newPassword);
	}

}
