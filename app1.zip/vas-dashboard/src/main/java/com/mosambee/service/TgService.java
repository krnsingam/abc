package com.mosambee.service;

import com.mosambee.bean.TgBean;
import com.mosambee.bean.TgCrudBean;
import com.mosambee.bean.TgDataTableRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.service.impl.TgServiceImpl;

/**
 * TgService specification for {@link TgServiceImpl} class
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 08-April-2020
 */
public interface TgService {

	DataTablesResponse<TgBean> getTgList(TgDataTableRequestBean dtRequest);
	
	boolean addTg(TgCrudBean tgCrudBean);
	
	TgCrudBean getTgDetails(int tgId);

	boolean updateTg(TgCrudBean tgCrudBean);
}
