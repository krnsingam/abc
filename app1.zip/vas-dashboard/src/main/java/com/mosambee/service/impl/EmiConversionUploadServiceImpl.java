package com.mosambee.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.mosambee.bean.EmiConversionBean;
import com.mosambee.bean.EmiConversionUploadBean;
import com.mosambee.constants.BulkUploadCategory;
import com.mosambee.constants.BulkUploadFileLocation;
import com.mosambee.constants.BulkUploadMessages;
import com.mosambee.dao.EmiConversionUploadDao;
import com.mosambee.properties.ExcelHeaderProperties;
import com.mosambee.service.EmiConversionUploadService;
import com.mosambee.service.ExcelService;
import com.mosambee.validator.EmiConversionUploadValidator;

/**
 * This class is using for emi conversion upload
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Service("emiConversionUploadService")
public class EmiConversionUploadServiceImpl implements EmiConversionUploadService {
	private static final Logger log = LogManager.getLogger(EmiConversionUploadServiceImpl.class);
	private static final DataFormatter dataFormatter = new DataFormatter();

	@Autowired
	private ExcelService excelService;

	@Autowired
	private ExcelHeaderProperties excelHeaderProperties;

	@Autowired
	private EmiConversionUploadDao emiConversionUploadDao;

	@Autowired
	private EmiConversionUploadValidator emiConversionUploadValidator;

	/**
	 * Responsible for processing {@link MultipartFile} ... Here we are validating
	 * the header, security issues, parsing the data from the {@link Workbook} &
	 * then again parsing the validated data from the {@link Workbook}
	 *
	 * @param file {@link MultipartFile}
	 * @return {@link Resource}
	 */
	@Override
	public Resource processEmiConversionUploadExcel(MultipartFile file) {
		Workbook workbook = excelService.getWorkbookFromMultipartFile(file);
		List<EmiConversionUploadBean> emiConversionUploadBeanList = new ArrayList<>();
		List<EmiConversionUploadBean> successRecordList = new ArrayList<>();
		List<EmiConversionUploadBean> failedRecordList = new ArrayList<>();
		// VALIDATE THE HEADER & VALIDATE SECURITY ISSUES
		if (validateExcelFile(file, workbook) && validateSecurityIssues(file, workbook)) {

			// PARSE DATA FROM WORKBOOK
			List<EmiConversionBean> emiConversionBeanList = parseEmiConversionUploadFields(workbook);

			// VALIDATE THE PARSED DATA FROM WORKBOOK INTO SUCCESS & FAILED RECORD LIST
			validateAndTransformParsedDataIntoLists(emiConversionBeanList, successRecordList, failedRecordList);

			// PERSISTS EMI CONVERSION FIELDS IN DATABASE
			persistsEmiConversion(successRecordList);

			// ADD ALL SUCCESS AND FAILED RECORDS IN A COMMON LIST
			emiConversionUploadBeanList.addAll(failedRecordList);
			emiConversionUploadBeanList.addAll(successRecordList);

			// GET THE EXCEL WITH RESPONSE
			Workbook responseWorkbook = writeEmiConversionUploadBeanListToExcel(emiConversionUploadBeanList);

			return excelService.getResourceFromWorkbook(responseWorkbook);

		} else {
			log.error("Excel file is not valid");
		}

		return null;
	}

	/**
	 * Performs validation for excel extension and validates the excel header.
	 * 
	 * @param file     MultipartFile
	 * @param workbook Workbook
	 * @return boolean
	 */
	private boolean validateExcelFile(MultipartFile file, Workbook workbook) {
		return excelService.validateExtension(file)
				&& excelService.validateHeader(workbook, BulkUploadCategory.EMI_CONVERSION_UPLOAD);
	}

	/**
	 * Performs validation for security issues in excel file. Mainly we are check
	 * for embedded object, macros and VB Scripts.
	 *
	 * @param file     MultipartFile
	 * @param workbook Workbook
	 * @return boolean
	 */
	private boolean validateSecurityIssues(MultipartFile file, Workbook workbook) {
		return excelService.checkForEmbeddedObjects(workbook) && excelService.checkForMacrosAndVbScript(file);
	}

	/**
	 * parseEmiConversionUploadFields(...) is responsible to parsing the workbook.
	 * Here we are parsing the sheet present at 0th index and then iterating the
	 * rows and cells inside them to extract the values.
	 * 
	 * @param workbook {@link Workbook}
	 * @return {@link List} of {@link EmiConversionBean}
	 */
	private List<EmiConversionBean> parseEmiConversionUploadFields(Workbook workbook) {
		Iterator<Row> rowIterator = workbook.getSheetAt(0).iterator();
		List<EmiConversionBean> emiConversionBeanList = new ArrayList<>();
		// SKIPING THE HEADER ROW
		rowIterator.next();

		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			EmiConversionBean emiConversionBean = parseRow(row);
			emiConversionBeanList.add(emiConversionBean);
		}

		return emiConversionBeanList;

	}

	/**
	 * {@link #parseRow(Row)} method is responsible for parsing the row and storing
	 * the parsed value in the object of {@link EmiConversionBean}
	 * 
	 * @param row
	 * @return {@link EmiConversionBean}
	 */
	private EmiConversionBean parseRow(Row row) {
		EmiConversionBean emiConversionBean = new EmiConversionBean();

		// SUBTRACT 1 FROM THE SIZE AS IT HAS STATUS HEADER.
		int sizeOfExcelHeader = excelHeaderProperties.getEmiConversionUploadHeaders().size() - 1;

		for (int i = 0; i < sizeOfExcelHeader; ++i) {

			Cell cell = row.getCell(i);

			switch (i) {			
			case 0:
				emiConversionBean.setIssuer(dataFormatter.formatCellValue(row.getCell(i)));
				break;
			case 1:
				emiConversionBean.setTxnRefId(dataFormatter.formatCellValue(cell));
				break;
			case 2:
				emiConversionBean.setMessage(dataFormatter.formatCellValue(cell));
				break;
			case 3:
				emiConversionBean.setComment(dataFormatter.formatCellValue(cell));
				break;
			default:
				String defaultCellValue = dataFormatter.formatCellValue(cell);
				log.info("Getting into the default case: {}", defaultCellValue);				
				break;			
			}
		}

		return emiConversionBean;

	}

	/**
	 * <strong>validateAndTransformParsedDataIntoLists(...)</strong> is responsible
	 * for iterating over the list of emi conversion and then putting them into two
	 * separate list, on the basis of their success and failed validation status.
	 * <br>
	 * <br>
	 * 
	 * Here we are using two lists, i.e. successRecordList & failedRecordList for
	 * success and failed records. <br>
	 * 
	 * @param emiConversionBeanList {@link List} of all the mid.
	 * @param successRecordList     {@link List} of all the success records.
	 * @param failedRecordList      {@link List} of all the failed records.
	 * @return void
	 */
	private void validateAndTransformParsedDataIntoLists(List<EmiConversionBean> emiConversionBeanList,
			List<EmiConversionUploadBean> successRecordList, List<EmiConversionUploadBean> failedRecordList) {

		// LOOP OVER THE LIST OF MID
		for (EmiConversionBean emiConversionBean : emiConversionBeanList) {

			// VALIDATE THE BEAN
			EmiConversionUploadBean emiConversionUploadBean = emiConversionUploadValidator
					.validateEmiConversionBean(emiConversionBean);

			// PUT THEM IN RESPECTIVE LIST.
			if (emiConversionUploadBean.getStatus().equals("")) {
				successRecordList.add(emiConversionUploadBean);
			} else {
				failedRecordList.add(emiConversionUploadBean);
			}
		}
	}

	/**
	 * persistsEmiConversion is responsible for getting response from
	 * EmiConversionUploadBean
	 * 
	 * @param successRecordList
	 */
	private void persistsEmiConversion(List<EmiConversionUploadBean> successRecordList) {
		// INSERT INTO DB
		for (EmiConversionUploadBean emiConversionUploadBean : successRecordList) {
			String response = emiConversionUploadDao.uploadEmiConversion(emiConversionUploadBean);

			// PROCESS THE RESPONSE
			updateEmiConversionBean(response, emiConversionUploadBean);
		}
	}

	/**
	 * updateEmiConversionBean is responsible for checking the response coming from
	 * db and if response is null,that means exception has occurred on DB side
	 * update status according to response
	 */
	private void updateEmiConversionBean(String response, EmiConversionUploadBean emiConversionUploadBean) {
		if (null == response) {
			emiConversionUploadBean.setStatus(BulkUploadMessages.EXCEPTION_OCCURED_WHILE_INSERTION.get());
		} else if (response.equals("1")) {
			emiConversionUploadBean.setStatus(BulkUploadMessages.TXN_RESPONSE_ERROR.get());
		} else if (response.equals("2")) {
			emiConversionUploadBean.setStatus(BulkUploadMessages.TXN_RESPONSE_ERROR2.get());
		} else if (response.equals("3")) {
			emiConversionUploadBean.setStatus(BulkUploadMessages.TXN_RESPONSE_ERROR3.get());
		} else if (emiConversionUploadBean.getStatus().equals("") && response.equals("0")) {
			emiConversionUploadBean.setStatus(BulkUploadMessages.SUCCESS.get());
		}
	}

	/**
	 * {@link #writeEmiConversionUploadBeanListToExcel(List)} is responsible for
	 * creating the excel with the response after processing the emi conversion
	 * upload excel file.
	 * 
	 * @param emiConversionUploadBeanList
	 * @return {@link Workbook}
	 */
	private Workbook writeEmiConversionUploadBeanListToExcel(
			List<EmiConversionUploadBean> emiConversionUploadBeanList) {
		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.EMI_CONVERSION_UPLOAD);
		Sheet sheet = workbook.getSheetAt(0);

		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		for (EmiConversionUploadBean emiConversionUploadBean : emiConversionUploadBeanList) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(emiConversionUploadBean.getIssuer());
			row.createCell(1).setCellValue(emiConversionUploadBean.getTxnRefId());
			row.createCell(2).setCellValue(emiConversionUploadBean.getMessage());
			row.createCell(3).setCellValue(emiConversionUploadBean.getComment());
			row.createCell(4).setCellValue(emiConversionUploadBean.getStatus());
		}

		excelService.autoSizeExcel(workbook);
		return workbook;

	}

	/**
	 * getEmiConversionUploadFormat() is responsible for converting the emi
	 * conversion upload files present in {@link BulkUploadFileLocation} to
	 * {@link Resource}
	 */
	@Override
	public Resource getEmiConversionUploadFormat() {
		ClassPathResource resource = null;
		resource = new ClassPathResource(BulkUploadFileLocation.EMI_CONVERSION_UPLOAD.get());
		return resource.exists() ? resource : null;
	}

}
