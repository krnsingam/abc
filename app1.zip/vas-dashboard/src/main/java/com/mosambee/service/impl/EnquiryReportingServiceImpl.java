package com.mosambee.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.validation.Valid;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mosambee.bean.EnquiryBean;
import com.mosambee.bean.EnquiryDataTablesRequestBean;
import com.mosambee.bean.EnquiryDateBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ColumnNames;
import com.mosambee.dao.EnquiryReportingDao;
import com.mosambee.service.EnquiryReportingService;
import com.mosambee.service.ExcelService;
import com.mosambee.transformer.EnquiryReportingTransformer;
import com.mosambee.validator.CommonValidator;
import org.springframework.core.io.Resource;
import com.mosambee.constants.BulkUploadCategory;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import org.springframework.core.io.InputStreamResource;

/**
 * This class is using for display enquiry list,download enquiry report and view
 * enquiry detail
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Service("enquiryReportingService")
public class EnquiryReportingServiceImpl implements EnquiryReportingService {

	private static final Logger log = LogManager.getLogger(EnquiryReportingServiceImpl.class);

	@Autowired
	EnquiryReportingDao enquiryReprtingDao;

	@Autowired
	EnquiryReportingTransformer transformer;

	@Autowired
	ExcelService excelService;

	@Autowired
	CommonValidator commonValidator;

	/**
	 * getEnquiryList(...) is responsible for calling the transformer for
	 * transforming the incoming input fields in the data-tables request of
	 * enquiryBean & then and formatting date in mySQLFormat and compare date means
	 * only one month data will search and then calling the DAO to get those values.
	 * 
	 * @param dtRequest {@link EnquiryDataTablesRequestBean}
	 */
	@Override
	public DataTablesResponse<EnquiryBean> getEnquiryList(@Valid EnquiryDataTablesRequestBean dtRequest) {
		// GET THE COLUMN NAME FROM COLUMN INDEX
		int orderingColumnIndex = dtRequest.getDtRequest().getOrder().get(0).getColumn();
		String orderingColumnName = getOrderingColumnNameOfEnquiryList(orderingColumnIndex);
		log.info("orderingColumnIndexs: {}, orderingColumnName: {}", orderingColumnIndex, orderingColumnName);
		// checking if fromDate and toDate is null
		SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date currentDate = new Date();

		String from = dtRequest.getFromDate();
		String to = dtRequest.getToDate();
		if (from.equals("") || to.equals("")) {
			dtRequest.setFromDate(simpleFormat.format(currentDate));
			dtRequest.setToDate(simpleFormat.format(currentDate));
		}

		// calling commonValidator to format date in MySQLFormate
		dtRequest.setFromDate(commonValidator.dateTimeValidator(dtRequest.getFromDate()));
		dtRequest.setToDate(commonValidator.timeValidator(dtRequest.getToDate()));

		// TRANSFORM THE INPUT FIELDS AND GET & RETURN THE LIST OF ENQUIRY REPORTING
		Map<String, String> searchMap = transformer.transformEnquiryListDataTablesRequest(dtRequest);
		log.info("size of searchMaps: {}", searchMap.size());
		DataTablesResponse<EnquiryBean> dtResponse = enquiryReprtingDao.getEnquiryList(dtRequest, orderingColumnName,
				searchMap);
		dtResponse.setDraw(dtRequest.getDtRequest().getDraw());
		return dtResponse;

	}

	/**
	 * getOrderingColumnNameOfEnquiryList (...) method is responsible for returning
	 * orderingColumnName of enquiryBean when it is provided with
	 * orderingColumnIndex.
	 * 
	 * @param orderingColumnIndex
	 * @return String orderingColumnName
	 */
	private String getOrderingColumnNameOfEnquiryList(int orderingColumnIndex) {

		String orderingColumnName = "";

		switch (orderingColumnIndex) {
		case 0:
			orderingColumnName = ColumnNames.ENQUIRY_ID.get();
			break;
		case 1:
			orderingColumnName = ColumnNames.ENQUIRY_ISSUER.get();
			break;
		case 2:
			orderingColumnName = ColumnNames.ENQUIRY_MERCHANTREFNO.get();
			break;
		case 3:
			orderingColumnName = ColumnNames.ENQUIRY_BANKREFNO.get();
			break;
		case 4:
			orderingColumnName = ColumnNames.ENQUIRY_CARDBIN.get();
			break;
		case 5:
			orderingColumnName = ColumnNames.ENQUIRY_AMOUNT.get();
			break;
		case 6:
			orderingColumnName = ColumnNames.ENQUIRY_CARDTYPEID.get();
			break;
		case 7:
			orderingColumnName = ColumnNames.ENQUIRY_STATUS.get();
			break;
		case 8:
			orderingColumnName = ColumnNames.ENQUIRY_CREATEDTIME.get();
			break;
		default:
			orderingColumnName = ColumnNames.ENQUIRY_ID.get();
			break;
		}

		return orderingColumnName;
	}

	/**
	 * Api to download the enquiryReporting this method is convering date in mySql
	 * formate and then compares date for one month means for only one month data
	 * will download.
	 * 
	 */
	@Override
	public List<EnquiryBean> downloadEnquiryReporting(EnquiryDateBean enquiryDateBean) {

		// checking if fromDate and toDate is null
		SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date currentDate = new Date();
		String from = enquiryDateBean.getFromDate();
		String to = enquiryDateBean.getToDate();
		if (from.equals("") || to.equals("")) {
			enquiryDateBean.setFromDate(simpleFormat.format(currentDate));
			enquiryDateBean.setToDate(simpleFormat.format(currentDate));
		}

		// calling commonValidator to format date in MySQLFormate
		enquiryDateBean.setFromDate(commonValidator.dateTimeValidator(enquiryDateBean.getFromDate()));
		enquiryDateBean.setToDate(commonValidator.timeValidator(enquiryDateBean.getToDate()));
		return enquiryReprtingDao.downloadEnquiryReporting(enquiryDateBean);
	}

	public Resource processEnquiryReporting(List<EnquiryBean> responseBean) {
		// GET THE EXCEL OF Enquiry Reporting WITH RESPONSE
		Workbook responseWorkbook = writeEnquiryReportingListToExcel(responseBean);
		return getResourceFromWorkbook(responseWorkbook);

	}

	private Workbook writeEnquiryReportingListToExcel(List<EnquiryBean> responseBean) {
		// CREATE THE WORKBOOK AND WRITE THE HEADER WITH CUSTOM STYLING
		Workbook workbook = excelService.createHeaderRow(BulkUploadCategory.ENQUIRY_REPORTING);
		Sheet sheet = workbook.getSheetAt(0);

		// WRITE THE DATA TO THE EXCEL FILE
		int rowNum = 1;
		for (EnquiryBean enquiryBean : responseBean) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(enquiryBean.getId());
			row.createCell(1).setCellValue(enquiryBean.getIssuer());
			row.createCell(2).setCellValue(enquiryBean.getMerchantRefNo());
			row.createCell(3).setCellValue(enquiryBean.getBankRefNo());
			row.createCell(4).setCellValue(enquiryBean.getCardBin());
			row.createCell(5).setCellValue(enquiryBean.getAmount());
			row.createCell(6).setCellValue(enquiryBean.getCardTypeId());
			row.createCell(7).setCellValue(enquiryBean.getStatus());
			row.createCell(8).setCellValue(enquiryBean.getCreatedTime());

		}
		excelService.autoSizeExcel(workbook);
		return workbook;

	}

	/**
	 * {@link #getResourceFromWorkbook(Workbook)} convert the {@link Workbook} to
	 * {@link Resource} so that it can be send over the network as response to the
	 * web-page.
	 * 
	 * @param responseWorkbook {@link Workbook}
	 * @return {@link Resource}
	 */
	private Resource getResourceFromWorkbook(Workbook responseWorkbook) {
		try {
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			responseWorkbook.write(byteArrayOutputStream);
			ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
			return new InputStreamResource(byteArrayInputStream);
		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}

	/**
	 * to view the enquiry reporting details
	 *
	 */
	@Override
	public EnquiryBean viewEnquiryDetail(long id) {
		return enquiryReprtingDao.viewEnquiryDetail(id);

	}
}
