package com.mosambee.service;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

/**
 * This interface use to declare methods which we want to use in {@link MIDBulkUploadServiceImpl}
 * Here we declare(s) methods which we are using as a business logic.
 * @author mandar.chaudhari
 * @version 1.0
 */
public interface MIDBulkUploadService
{
	public Resource processBulkUploadExcel(MultipartFile file);
	public Resource getMIDBulkUploadFormat(); 
}
