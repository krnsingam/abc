package com.mosambee.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.mosambee.properties.SendSMSConfig;

import lombok.extern.log4j.Log4j2;

/**
 * SendSMSUtil is design for handling sms  sending operations
 * @author rahul.mishra
 *
 */

@Log4j2
@Component
public class SendSMSUtil {

	@Autowired
	private SendSMSConfig sendSms;
    
	/**
	 * sendSms is used to send sms
	 * @param to
	 * @param text
	 */
	public void sendSms(String to, String text) {

		log.info("sendSms bean: {}", sendSms);

		String url = "";
		String userId;
		String password;
		String senderId;
		String httpGetParams = "";

		log.info("data for sms {} {}", to, text);
		log.info("gateway {}", sendSms.getUseSmsGateway());

		try {

			String gatewayId = sendSms.getUseSmsGateway();

			log.info("gatewayId {}", gatewayId);

			switch (gatewayId) {
			case "1":
				url = sendSms.getSmsGateway1Url();
				password = sendSms.getSmsGateway1WorkingKey();
				senderId = sendSms.getSmsGateway1SenderId();
				httpGetParams = "method=sms&api_key=" + password + "&sender=" + senderId + "&to=" + to
						+ "&format=json&message=" + text;
				break;
			case "2":
				url = sendSms.getSmsGateway2Url();
				userId = sendSms.getSmsGateway2UserId();
				password = sendSms.getSmsGateway2Password();
				senderId = sendSms.getSmsGateway2Senderid();
				httpGetParams = "userId=" + userId + "&password=" + password + "&senderId=" + senderId
						+ "&sendMethod=simpleMsg&msgType=TEXT&format=json&mobile=" + to + "&msg=" + text;

				break;
			default:
				break;
			}

			RestTemplate restTemplate = new RestTemplate();
			String res = restTemplate.getForObject(url + httpGetParams, String.class);
			log.info("response {}", res);
		} catch (Exception e) {
			log.error("Error occured while sending sms to {} error {}", to, e);
		}
	}
}
