package com.mosambee.util;

import java.security.Key;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class IOCLEncUtils {
	private IOCLEncUtils() {}

	private static final String ALGORITHM = "AES";

	public static String encrypt(String valueToEnc, String salt) {
		try {
			Key key = new SecretKeySpec(salt.getBytes(), ALGORITHM);
			Cipher c = Cipher.getInstance(ALGORITHM);
			c.init(1, key);
			byte[] encValue = c.doFinal(valueToEnc.getBytes());

			return String.valueOf(Base64.getEncoder().encode(encValue));
		} catch (Exception e) {
			return null;
		}
	}

	public static String decrypt(String encryptedValue, String salt) {
		try {
			Key key = new SecretKeySpec(salt.getBytes(), ALGORITHM);

			Cipher c = Cipher.getInstance(ALGORITHM);
			c.init(2, key);

			byte[] decordedValue = Base64.getDecoder().decode(encryptedValue);
			byte[] decValue = c.doFinal(decordedValue);

			return String.valueOf(decValue);
		} catch (Exception e) {
			return null;
		}
	}
}