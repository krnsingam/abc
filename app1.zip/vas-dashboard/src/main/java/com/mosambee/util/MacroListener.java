package com.mosambee.util;

import org.apache.poi.poifs.eventfilesystem.POIFSReaderEvent;
import org.apache.poi.poifs.eventfilesystem.POIFSReaderListener;

/**
 * @author swapnil.singh
 * @version 1.0
 * @since 24-December-2019
 */
public class MacroListener implements POIFSReaderListener {

	boolean macroDetected;

	public boolean isMacroOrVbScriptDetected() {
		return macroDetected;
	}

	@Override
	public void processPOIFSReaderEvent(POIFSReaderEvent event) {
		if (event.getPath().toString().startsWith("\\Macros") 
				|| event.getPath().toString().startsWith("\\_VBA")) {
			macroDetected = true;
		}
	}
}