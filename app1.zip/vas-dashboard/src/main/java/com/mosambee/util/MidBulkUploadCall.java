package com.mosambee.util;

import java.net.URI;
import java.util.Arrays;
import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.mosambee.bean.MidApiGroupDaetailBean;
import com.mosambee.bean.MidBulkResponseList;
import com.mosambee.constants.APIPasswordConfigConstants;

/**
 * @author karan.singam
 * @version 1.0
 * @since 29-January-2020
 */
@Component
public class MidBulkUploadCall {

	private static final Logger log = LoggerFactory.getLogger(MidBulkUploadCall.class);

	/**This method is used for api call when all the conditions are satisfied.
	 * On call it hits an api url as post method call and stores data for further use. 
	 * 
	 * @param MidApiGroupDaetailBean
	 * @return boolean : true.
	 */
	public boolean midCall(MidApiGroupDaetailBean bean) {
		
		ResponseEntity<MidBulkResponseList> responseEntity = null;
		
		try {
		log.info("Bean : {}",bean);
		
		URI uri = new URI(bean.getApiUrl1());	
		
		//setting up the request headers
		HttpHeaders headers = new HttpHeaders();
		
		StringBuilder s = new StringBuilder("Basic "); 
		StringBuilder auth = new StringBuilder(bean.getDivRefNo2()).append(":").append(bean.getDivRefNo3());
		
		s.append(new String(Base64.getEncoder().encode((auth.toString()).getBytes())));
	
		log.info("Basic Auth : {}", s);
		
		headers.add(HttpHeaders.AUTHORIZATION, s.toString());
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		
		log.info("Headers : {}",headers);
		
		//setting mutivalued body
		StringBuilder body = new StringBuilder(APIPasswordConfigConstants.BODY_BEGIN.get())
				.append(bean.getMPosApiPassword()).append(APIPasswordConfigConstants.BODY_END.get());
		
		log.info("Body : {}",body);
		
		//merging headers and body into a request
		HttpEntity<String> request = new HttpEntity<>(body.toString(), headers);
		
		//Initializing rest template
		RestTemplate restTemplate = new RestTemplate();
		
		//Calling rest template and storing response
		responseEntity = restTemplate.postForEntity(uri, request, MidBulkResponseList.class);
		
		MidBulkResponseList midbean = responseEntity.getBody();
		
        log.info("Calling rest template succesfull.. : {}",midbean);

        return true;
        
	} catch (Exception e) {	
		log.info(e.getMessage());
		return false;
	}
	}
}