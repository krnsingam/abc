package com.mosambee.util;

import java.util.Random;

/**
 * OfflineKeyGenerator is responsible for generating offline keys for offline Merchants.
 * @author mariam.siddique
 * @version 1.0
 * @since 01-April-2020
 */
public class OfflineKeyGenerator {

	private OfflineKeyGenerator() {}

	public static String getOfflineKey() 
	{
		String str = "0123456789ABCDEF";
		StringBuilder sb = new StringBuilder();
		Random r = new Random();
		for (int i = 1; i <= 48; i++)
		{
			int index = r.nextInt(15);
			sb.append(str.charAt(index));
		}
		return sb.toString();
	}
}
