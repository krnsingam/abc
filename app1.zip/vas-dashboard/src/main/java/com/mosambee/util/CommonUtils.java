package com.mosambee.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import lombok.extern.log4j.Log4j2;

/**
 * Responsible for providing common utilities that can be used throughout the
 * application.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 06-February-2020
 */
@Log4j2
@Component
public class CommonUtils {

	/**
	 * Responsible for clearing the SecurityContextHolder and invalidating the
	 * HttpSession.
	 * 
	 * @param request HttpServletRequest
	 * @return void
	 */
	public void clearSecurityContextHolderAndInvalidateSession(HttpServletRequest request) {
		log.info("clearing the security-context-holder & invalidating the session");
		HttpSession session = request.getSession(false);
		SecurityContextHolder.clearContext();
		if (null != session) {
			session.invalidate();
		}
	}

	/**
	 * Responsible for clearing the SecurityContextHolder.
	 */
	public void clearSecurityContextHolder() {
		SecurityContextHolder.clearContext();
	}
}
