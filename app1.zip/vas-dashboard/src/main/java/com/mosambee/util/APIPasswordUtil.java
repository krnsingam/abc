package com.mosambee.util;

import org.springframework.stereotype.Component;

@Component
public class APIPasswordUtil {
	private APIPasswordUtil() {}

	/** 
	 *   this function converts a plain string to a hash string.
	 *   The unicode string is converted to a byte array in
	 *   big-endian order; the SHA1 is then executed.
	 *   @param plain the original message
	 *   @return hexadecimal number as string, 40 characters
	 */
	public String hash( String plain) {
		int bitLength = plain.length() * 16;
		int totalBitLength = ( bitLength + 1 + 64 + 511 ) & -512;   
		int msgLength = totalBitLength/32;
		int[] message = new int[ msgLength];

		//  fill the Message integers:
		for ( int pos = 0; pos < msgLength; pos ++ ) {
			//  higher 16 bits:
			if ( pos*32 < bitLength) {
				int unicode = (int) plain.charAt( pos*2);
				message[pos] = ( unicode << 16);
			} else if ( pos*32 == bitLength) {
				message[pos] = 0x80000000;
			}

			//  lower 16 bits
			if ( (pos*32+16) < bitLength) {
				int unicode2 = (int) plain.charAt( pos*2+1);
				message[pos] = message[pos] | ( unicode2 & 0x0000ffff);
			} else if ( (pos*32+16) == bitLength) {
				message[pos] = message[pos] | 0x00008000;
			}
		}

		message[msgLength-1] = bitLength;
		return doHashing(message);
	}

	//  required constants:
	private static final int H_1 = 0x67452301;
	private static final int H_2 = 0xefcdab89;
	private static final int H_3 = 0x98badcfe;
	private static final int H_4 = 0x10325476;
	private static final int H_5 = 0xc3d2e1f0;
	private static final int Y1 = 0x5a827999;
	private static final int Y2 = 0x6ed9eba1;
	private static final int Y3 = 0x8f1bbcdc;
	private static final int Y4 = 0xca62c1d6;

	/** rotate left */
	private int rol ( int x, int shift ) {
		return (( x << shift ) | ( x >>> ( 32-shift )));
	}

	/** 
	 *   this method calculates the SHA1 digest
	 *   
	 *   @param Message precalculated array on 32 bit values; 
	 *       the length is a multiple of 16, the bit after
	 *       the last message bit is set, the last 64 bits
	 *       represent the message length in big endian order
	 *   @return hexadecimal representation of the result, 40 characters
	 */
	private String doHashing(int[] message) {
		int h1 = APIPasswordUtil.H_1;
		int h2 = APIPasswordUtil.H_2;
		int h3 = APIPasswordUtil.H_3;
		int h4 = APIPasswordUtil.H_4;
		int h5 = APIPasswordUtil.H_5;

		int integerCount = message.length;
		int[] x = new int[80];

		int j;

		for ( int block_start = 0; block_start < integerCount; block_start += 16 ) {
			for ( j = 0; j < 16; j ++ ) { 
				x[j] = message[block_start+j];
			}

			for ( j = 16; j < 80; j ++ ) {
				x[j] = rol(x[j-3]^x[j-8]^x[j-14]^x[j-16],1);
			}
			//  calculate A,B,C,D,E:
			int a=h1; 
			int b=h2; 
			int c=h3; 
			int d=h4; 
			int e=h5; 
			int t;

			for ( j = 0; j < 20; j ++ ) {
				t = rol(a,5)+((b&c)|((~b)&d))+e+x[j]+Y1;
				e=d; d=c; c=rol(b,30); b=a; a=t;
			}

			for ( j = 20; j < 40; j ++ ) {
				t = rol(a,5)+(b^c^d)+e+x[j]+Y2;
				e=d; d=c; c=rol(b,30); b=a; a=t;
			}

			for ( j = 40; j < 60; j ++ ) {
				t = rol(a,5)+((b&c)|(b&d)|(c&d))+e+x[j]+Y3;
				e=d; d=c; c=rol(b,30); b=a; a=t;
			}

			for ( j = 60; j < 80; j ++ ) {
				t = rol(a,5)+(b^c^d)+e+x[j]+Y4;
				e=d; d=c; c=rol(b,30); b=a; a=t;
			}
			h1+=a; h2+=b; h3+=c; h4+=d; h5+=e;
		}

		//  convert result to hexadecimal string:
		StringBuilder result = new StringBuilder(40);

		intToHex(h1, result);
		intToHex(h2, result);
		intToHex(h3, result);
		intToHex(h4, result);
		intToHex(h5, result);

		return result.toString();
	}

	/**
	 * converts an int number to hexadecimal representation
	 */
	private void intToHex(int x, StringBuilder out) {
		for (int pos = 0; pos < 8; pos++)
			out.append(intToChar((x >>> (28 - (pos * 4))) & 0xf));
	}

	/**
	 * converts an int number between 0 and 36 to a char (base 36) <br />
	 * Note: the result is undefined, if parameter is out of range
	 * 
	 */
	private char intToChar(int zeroTo36) {
		if (zeroTo36 <= 9) {
			if (zeroTo36 >= 0) {
				return (char) (zeroTo36 + ((int) '0'));
			} else {
				return 0;
			}
		} else if (zeroTo36 < 36) {
			return (char) (zeroTo36 - 10 + ((int) 'a'));
		} else {
			return 0;
		}
	}
	
	
	
}