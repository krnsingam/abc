package com.mosambee.util;

import org.springframework.security.crypto.password.PasswordEncoder;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class SHAPasswordEncoder implements PasswordEncoder {

	@Override
	public String encode(CharSequence rawPassword) {
		return SHA1.getInstance().hash(String.valueOf(rawPassword));
	}

	@Override
	public boolean matches(CharSequence rawPassword, String encodedPassword) {
		String genPass = SHA1.getInstance().hash(String.valueOf(rawPassword));

		return genPass.equalsIgnoreCase(encodedPassword);
	}

	public static PasswordEncoder getInstance() {
		return INSTANCE;
	}

	private static final PasswordEncoder INSTANCE = new SHAPasswordEncoder();

	private SHAPasswordEncoder() {
	}
}
