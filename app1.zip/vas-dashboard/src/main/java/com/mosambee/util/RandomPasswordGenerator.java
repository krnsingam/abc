package com.mosambee.util;

import org.passay.CharacterData;
import org.passay.CharacterRule;
import org.passay.EnglishCharacterData;
import org.passay.PasswordGenerator;
import org.springframework.stereotype.Component;

@Component
public class RandomPasswordGenerator {
	private static final String ERROR_CODE = "-1";

	public String generatePassword() {
		PasswordGenerator generator = new PasswordGenerator();
		return generator.generatePassword(10, lowerCaseRule(), upperCaseRule(), digitCharRule(), specialCharRule());
	}

	/*
	 * Rule for digit characters inside password In this implementation it should be
	 * greater than or equal to 2
	 */
	private CharacterRule digitCharRule() {
		CharacterData digitChars = EnglishCharacterData.Digit;
		CharacterRule digitRule = new CharacterRule(digitChars);
		digitRule.setNumberOfCharacters(2);
		return digitRule;
	}

	/*
	 * Rule for special characters inside password In this implementation it should
	 * be greater than or equal to 2
	 */
	private CharacterRule specialCharRule() {
		CharacterData specialChars = new CharacterData() {

			@Override
			public String getErrorCode() {
				return ERROR_CODE;
			}

			@Override
			public String getCharacters() {
				return "@#$%!";
			}
		};
		CharacterRule specialCharRule = new CharacterRule(specialChars);
		specialCharRule.setNumberOfCharacters(2);
		return specialCharRule;
	}

	/*
	 * Rule for upper case alphabets inside password In this implementation it
	 * should be greater than or equal to 2
	 */
	private CharacterRule upperCaseRule() {
		CharacterData upperCaseChars = EnglishCharacterData.UpperCase;
		CharacterRule upperCaseRule = new CharacterRule(upperCaseChars);
		upperCaseRule.setNumberOfCharacters(2);
		return upperCaseRule;
	}

	/*
	 * Rule for lower case alphabets inside password In this implementation it
	 * should be greater than or equal to 2
	 */
	private CharacterRule lowerCaseRule() {
		CharacterData lowerCaseChars = EnglishCharacterData.LowerCase;
		CharacterRule lowerCaseRule = new CharacterRule(lowerCaseChars);
		lowerCaseRule.setNumberOfCharacters(2);
		return lowerCaseRule;
	}

}
