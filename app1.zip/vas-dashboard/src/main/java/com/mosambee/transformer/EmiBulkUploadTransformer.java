package com.mosambee.transformer;

import java.util.Map;

import com.mosambee.bean.EmiBulkUploadBean;
import com.mosambee.bean.EmiDownloadBean;
import com.mosambee.bean.EmiSearchDatatablesRequestBean;

/**
 * This class provides specification for {@link EmiBulkUploadTransformerImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 */
public interface EmiBulkUploadTransformer {
	void transformTid(EmiBulkUploadBean emiBulkUploadBean);

	void transformMid(EmiBulkUploadBean emiBulkUploadBean);

	void transformCredit(EmiBulkUploadBean emiBulkUploadBean);

	void transformDebit(EmiBulkUploadBean emiBulkUploadBean);

	void transformAcquirer(EmiBulkUploadBean emiBulkUploadBean);

	void transformTid(EmiDownloadBean emiDownloadBean);

	void transformMid(EmiDownloadBean emiDownloadBean);

	void transformCredit(EmiDownloadBean emiDownloadBean);

	void transformDebit(EmiDownloadBean emiDownloadBean);

	void transformAcquirer(EmiDownloadBean emiDownloadBean);

	Map<String, String> transformEmiSearchListDataTablesRequest(EmiSearchDatatablesRequestBean dtRequest);

}
