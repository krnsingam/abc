package com.mosambee.transformer;

import com.mosambee.bean.EmiConversionUploadBean;

/**
 * This class provides specification for
 * {@link EmiConversionUploadTransformerImpl}}
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
public interface EmiConversionUploadTransformer {

	void transformIssuer(EmiConversionUploadBean emiConversionUploadBean);

	void transformTxnRefId(EmiConversionUploadBean emiConversionUploadBean);

	void transformStatus(EmiConversionUploadBean emiConversionUploadBean);

	void transformComment(EmiConversionUploadBean emiConversionUploadBean);

}
