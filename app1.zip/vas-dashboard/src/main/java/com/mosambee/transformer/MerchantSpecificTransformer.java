package com.mosambee.transformer;

import java.util.Map;

import com.mosambee.bean.MerchantKeyDataBean;
import com.mosambee.bean.MerchantMappingDataBean;

/**
 * MerchantSpecificTransformer is basically used to transform bean field
 * values.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 27-February-2020
 */
public interface MerchantSpecificTransformer {

	public Map<String, String> transformMerchantMappingView(MerchantMappingDataBean dtRequest);
	
	public Map<String, String> transformMerchantKey(MerchantKeyDataBean dtRequest);
}
