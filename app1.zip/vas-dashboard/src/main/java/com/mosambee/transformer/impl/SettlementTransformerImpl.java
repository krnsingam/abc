package com.mosambee.transformer.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.mosambee.bean.SettlementDataTableCrudBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.constants.ColumnNames;
import com.mosambee.transformer.SettlementTransformer;

/**
 * SettlementTransformerImpl is responsible for transforming the SettlementDataTableCrudBean
 * fields ... Mainly implemented for transforming the search inputs coming via
 * data-tables.
 * 
 * @author rahul.mishra
 * @version 1.0
 * @since 24-02-2020
 */
@Component("settlementTransformer")
public class SettlementTransformerImpl implements SettlementTransformer {
    
	
	
	/**
	 * transformSettlementDataTableRequest(...) is responsible for transforming incoming
	 * {@link SettlementDataTableCrudBean} ... We are mainly trimming values here.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return Map<String, String>
	 */
	@Override
	public Map<String, String> transformSettlementDataTableRequest(SettlementDataTableCrudBean dtRequest) {
		Map<String, String> searchMap = new HashMap<>();

		searchMap.put(ColumnNames.SETTLEMENT_FIRSTNAME.get(), transformFirstName(dtRequest));
		searchMap.put(ColumnNames.SETTLEMENT_TYPE.get(), transformType(dtRequest));
		searchMap.put(ColumnNames.SETTLEMENT_START_TIME.get(), transformStartTime(dtRequest));
		searchMap.put(ColumnNames.SETTLEMENT_END_TIME.get(), transformEndTime(dtRequest));
		searchMap.put(ColumnNames.SETTLEMENT_REASON.get(), transformReason(dtRequest));

		return searchMap;
	}
	
	/**
	 * transformFirstName(...) is responsible for trimming the firstName
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformFirstName(SettlementDataTableCrudBean dtRequest) {
		String firstName = dtRequest.getFirstName();
		return firstName.trim();
	}

	/**
	 * transformType(...) is responsible for trimming the type
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformType(SettlementDataTableCrudBean dtRequest) {
		String type = dtRequest.getType();
		return type.trim();
	}
	
	/**
	 * transformStartTime(...) is responsible for trimming the start time
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformStartTime(SettlementDataTableCrudBean dtRequest) {
		String startTime = dtRequest.getStartTime();
		
		if(startTime == null || startTime.isEmpty()) {
			return null;
		}
		
		return startTime.trim();
	}
	
	/**
	 * transformEndTime(...) is responsible for trimming the end time
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformEndTime(SettlementDataTableCrudBean dtRequest) {
		String endTime = dtRequest.getEndTime().trim();
		
		if(endTime == null || endTime.isEmpty()) {
			return null;
		}
		
		return endTime;
	}
	
	/**
	 * transformReason(...) is responsible for trimming the reason
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformReason(SettlementDataTableCrudBean dtRequest) {
		String reason = dtRequest.getReason();
		return reason.trim();
	}

}
