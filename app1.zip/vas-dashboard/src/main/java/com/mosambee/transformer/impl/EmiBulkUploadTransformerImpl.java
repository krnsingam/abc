package com.mosambee.transformer.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.mosambee.bean.EmiBulkUploadBean;
import com.mosambee.bean.EmiDownloadBean;
import com.mosambee.bean.EmiSearchDatatablesRequestBean;
import com.mosambee.constants.ColumnNames;
import com.mosambee.transformer.EmiBulkUploadTransformer;

/**
 * This class is basically used to transform values of {@link EmiBulkUploadBean}
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Component("emiBulkUploadTransformer")
public class EmiBulkUploadTransformerImpl implements EmiBulkUploadTransformer {

	/**
	 * transformTid()is responsible for trimming the space coming from tid
	 * 
	 * @param emiBulkUploadBean
	 * @return void
	 */
	@Override
	public void transformTid(EmiBulkUploadBean emiBulkUploadBean) {
		String tid = emiBulkUploadBean.getTid();
		tid = tid.trim();
		emiBulkUploadBean.setTid(tid);
	}

	/**
	 * transformMid()is responsible for trimming the space coming from mid
	 * 
	 * @param emiBulkUploadBean
	 * @return void
	 */
	@Override
	public void transformMid(EmiBulkUploadBean emiBulkUploadBean) {
		String mid = emiBulkUploadBean.getMid();
		mid = mid.trim();
		emiBulkUploadBean.setMid(mid);
	}

	/**
	 * transformCredit()is responsible for trimming the space coming from credit
	 * 
	 * @param emiBulkUploadBean
	 * @return void
	 */
	@Override
	public void transformCredit(EmiBulkUploadBean emiBulkUploadBean) {
		String credit = emiBulkUploadBean.getCredit();
		credit = credit.toUpperCase().trim();
		emiBulkUploadBean.setCredit(credit);
	}

	/**
	 * transformDebit()is responsible for trimming the space coming from debit
	 * 
	 * @param emiBulkUploadBean
	 * @return void
	 */
	@Override
	public void transformDebit(EmiBulkUploadBean emiBulkUploadBean) {
		String debit = emiBulkUploadBean.getDebit();
		debit = debit.toUpperCase().trim();
		emiBulkUploadBean.setDebit(debit);
	}

	/**
	 * transformAcquirer()is responsible for trimming the space coming from acquirer
	 * 
	 * @param emiBulkUploadBean
	 * @return void
	 */
	@Override
	public void transformAcquirer(EmiBulkUploadBean emiBulkUploadBean) {
		String acquirer = emiBulkUploadBean.getAcquirer();
		acquirer = acquirer.toUpperCase().trim();
		emiBulkUploadBean.setAcquirer(acquirer);
	}

	@Override
	public Map<String, String> transformEmiSearchListDataTablesRequest(EmiSearchDatatablesRequestBean dtRequest) {
		Map<String, String> searchMap = new HashMap<>();
		searchMap.put(ColumnNames.ACQUIRER.get(), transformAcquirer(dtRequest));
		searchMap.put(ColumnNames.MERCHANT_CODE.get(), transformMid(dtRequest));
		searchMap.put(ColumnNames.TID.get(), transformTid(dtRequest));
		searchMap.put(ColumnNames.CREDIT.get(), transformCredit(dtRequest));
		searchMap.put(ColumnNames.DEBIT.get(), transformDebit(dtRequest));
		return searchMap;
	}

	/**
	 * transformAcquirer() is responsible for trimming acquirer
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformAcquirer(EmiSearchDatatablesRequestBean dtRequest) {
		String acquirer = dtRequest.getAcquirer();
		return acquirer.trim();
	}

	/**
	 * transformMid() is responsible for trimming mid
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformMid(EmiSearchDatatablesRequestBean dtRequest) {
		String mid = dtRequest.getMid();
		return mid.trim();
	}

	/**
	 * transformTid() is responsible for trimming tid
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformTid(EmiSearchDatatablesRequestBean dtRequest) {
		String tid = dtRequest.getTid();
		return tid.trim();
	}

	/**
	 * transformCredit() is responsible for trimming credit
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformCredit(EmiSearchDatatablesRequestBean dtRequest) {
		String credit = dtRequest.getCredit();
		return credit.trim();
	}

	/**
	 * transformDebit() is responsible for trimming debit
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformDebit(EmiSearchDatatablesRequestBean dtRequest) {
		String debit = dtRequest.getDebit();
		return debit.trim();
	}

	
	
	
	/**
	 * transformTid()is responsible for trimming the space coming from tid
	 * 
	 * @param emiDownloadBean
	 * @return void
	 */
	@Override
	public void transformTid(EmiDownloadBean emiDownloadBean) {
		String tid = emiDownloadBean.getTid();
		tid = tid.trim();
		emiDownloadBean.setTid(tid);
	}

	/**
	 * transformMid()is responsible for trimming the space coming from mid
	 * 
	 * @param emiDownloadBean
	 * @return void
	 */
	@Override
	public void transformMid(EmiDownloadBean emiDownloadBean) {
		String mid = emiDownloadBean.getMid();
		mid = mid.trim();
		emiDownloadBean.setMid(mid);
	}

	/**
	 * transformCredit()is responsible for trimming the space coming from credit
	 * 
	 * @param emiDownloadBean
	 * @return void
	 */
	@Override
	public void transformCredit(EmiDownloadBean emiDownloadBean) {
		String credit = emiDownloadBean.getCredit();
		credit = credit.toUpperCase().trim();
		emiDownloadBean.setCredit(credit);
	}

	/**
	 * transformDebit()is responsible for trimming the space coming from debit
	 * 
	 * @param emiDownloadBean
	 * @return void
	 */
	@Override
	public void transformDebit(EmiDownloadBean emiDownloadBean) {
		String debit = emiDownloadBean.getDebit();
		debit = debit.toUpperCase().trim();
		emiDownloadBean.setDebit(debit);
	}

	/**
	 * transformAcquirer()is responsible for trimming the space coming from acquirer
	 * 
	 * @param emiDownloadBean
	 * @return void
	 */
	@Override
	public void transformAcquirer(EmiDownloadBean emiDownloadBean) {
		String acquirer = emiDownloadBean.getAcquirer();
		acquirer = acquirer.toUpperCase().trim();
		emiDownloadBean.setAcquirer(acquirer);
	}
}
