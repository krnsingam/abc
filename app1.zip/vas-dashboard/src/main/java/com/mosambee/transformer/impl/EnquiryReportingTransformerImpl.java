package com.mosambee.transformer.impl;

import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Component;
import com.mosambee.bean.EnquiryDataTablesRequestBean;
import com.mosambee.constants.ColumnNames;
import com.mosambee.transformer.EnquiryReportingTransformer;

/**
 * EnquiryReportingTransformerImpl is responsible for transforming the
 * EnquiryBean fields ... Mainly implemented for transforming the search inputs
 * coming via data-tables.
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Component("enquiryReportingTransformer")
public class EnquiryReportingTransformerImpl implements EnquiryReportingTransformer {

	@Override
	public Map<String, String> transformEnquiryListDataTablesRequest(EnquiryDataTablesRequestBean dtRequest) {
		Map<String, String> searchMap = new HashMap<>();
		searchMap.put(ColumnNames.ENQUIRY_ISSUER.get(), transformIssuer(dtRequest));
		searchMap.put(ColumnNames.ENQUIRY_MERCHANTREFNO.get(), transformMerchantRefNo(dtRequest));
		searchMap.put(ColumnNames.ENQUIRY_BANKREFNO.get(), transformBankRefNo(dtRequest));
		searchMap.put(ColumnNames.ENQUIRY_AMOUNT.get(), transformAmount(dtRequest));
		searchMap.put(ColumnNames.ENQUIRY_CARDTYPEID.get(), transformCardType(dtRequest));
		return searchMap;
	}

	/**
	 * transformIssuer() is responsible for trimming issuer
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformIssuer(EnquiryDataTablesRequestBean dtRequest) {
		String issuer = dtRequest.getIssuer();
		return issuer.trim();
	}

	/**
	 * transformMerchantRefNo() is responsible for trimming merchantRefNo
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformMerchantRefNo(EnquiryDataTablesRequestBean dtRequest) {
		String merchantRefNo = dtRequest.getDtRequest().getColumns().get(2).getSearch().getValue();
		return merchantRefNo.trim();
	}

	/**
	 * transformBankRefNo() is responsible for trimming bankRefNo
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformBankRefNo(EnquiryDataTablesRequestBean dtRequest) {
		String bankRefNo = dtRequest.getDtRequest().getColumns().get(3).getSearch().getValue();
		return bankRefNo.trim();
	}

	/**
	 * transformAmount() is responsible for trimming amount
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformAmount(EnquiryDataTablesRequestBean dtRequest) {
		String amount = dtRequest.getDtRequest().getColumns().get(5).getSearch().getValue();
		if ("".equals(amount.trim())) {
			amount = "0";
		}
		return amount;
	}

	/**
	 * transformCardType() is responsible for trimming cardType
	 * 
	 * @param dtRequest
	 * @return
	 */
	private String transformCardType(EnquiryDataTablesRequestBean dtRequest) {
		String cardTypeId = dtRequest.getDtRequest().getColumns().get(6).getSearch().getValue();
		return cardTypeId.trim();
	}

}
