package com.mosambee.transformer.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.mosambee.bean.TransactionDateReportBean;
import com.mosambee.bean.TransactionSearchFormDataTableBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.constants.ColumnNames;
import com.mosambee.transformer.TransactionReportTransformer;

/**
 * TransactionReportTransformerImpl is responsible for transforming the TransactionReportBean
 * fields ... Mainly implemented for transforming the search inputs coming via
 * data-tables.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 10-January-2020
 */
@Component("transactionReportTransformer")
public class TransactionReportTransformerImpl implements TransactionReportTransformer{
	
	private static final Logger log = LogManager.getLogger(TransactionReportTransformerImpl.class);

	/**
	 * transformTransactionReportDataTableRequest(...) is responsible for transforming incoming
	 * {@link DataTablesRequest} ... We are mainly trimming values here.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return Map<String, String>
	 */
	@Override
	public Map<String, String> transformTransactionReportDataTableRequest(TransactionDateReportBean dtRequest) {
		Map<String, String> searchMap = new HashMap<>();

		searchMap.put(ColumnNames.TRANSACTION_FROM_DATE.get(), transformTransactionReportFromDate(dtRequest));
		searchMap.put(ColumnNames.TRANSACTION_TO_DATE.get(), transformTransactionReportToDate(dtRequest));
		searchMap.put(ColumnNames.TRANSACTION_AUTH_CODE.get(), transformTransactionReportAuthCode(dtRequest));
		searchMap.put(ColumnNames.TRANSACTION_BIN_VALUE.get(), transformTransactionReportBinValue(dtRequest));
		searchMap.put(ColumnNames.TRANSACTION_TXN_AMOUNT.get(), transformTransactionReportTxnAmount(dtRequest));
		searchMap.put(ColumnNames.TRANSACTION_ISSUER.get(), transformTransactionReportIssuer(dtRequest));
		searchMap.put(ColumnNames.TRANSACTION_STATUS.get(), transformTransactionReportStatus(dtRequest));
		searchMap.put(ColumnNames.TRANSACTION_CONVERSION_STATUS.get(), transformTransactionReportConvStatus(dtRequest));
		searchMap.put(ColumnNames.TRANSACTION_REFERENCE_NO.get(), transformTransactionReferenceNumber(dtRequest));
		
		return searchMap;
	}
	
	/**
	 * transformTransactionListDataTableRequest(...) is responsible for transforming incoming
	 * {@link TransactionSearchFormDataTableBean} ... We are mainly trimming values here.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return Map<String, String>
	 */
	@Override
	public Map<String, String> transformTransactionListDataTableRequest(TransactionSearchFormDataTableBean dtRequest) {
		Map<String, String> searchMap = new HashMap<>();

		searchMap.put(ColumnNames.TXN_LIST_USER_ID.get(), transformTxnUserId(dtRequest));
		searchMap.put(ColumnNames.TXN_LIST_MERCHANT_NAME.get(), transformTxnMerchantName(dtRequest));
		searchMap.put(ColumnNames.TXN_LIST_TXN_ID.get(), transformTxnTxnId(dtRequest));
		searchMap.put(ColumnNames.TXN_LIST_RRN.get(), transformTxnRRN(dtRequest));
		searchMap.put(ColumnNames.TXN_LIST_AUTOCODE.get(), transformTxnAuthCode(dtRequest));
		searchMap.put(ColumnNames.TXN_LIST_CARD_NUMBER.get(), transformTxnCardNumber(dtRequest));
		searchMap.put(ColumnNames.TXN_LIST_CARD_HOLDER_NAME.get(), transformTxnCardHolderName(dtRequest));
		searchMap.put(ColumnNames.TXN_LIST_ACQUIRER.get(), transformTxnAcquirer(dtRequest));
		searchMap.put(ColumnNames.TXN_LIST_MID.get(), transformTxnMID(dtRequest));
		searchMap.put(ColumnNames.TXN_LIST_TID.get(), transformTxnTID(dtRequest));
		searchMap.put(ColumnNames.TXN_LIST_DATE_FROM.get(), transformTxnDateFrom(dtRequest));
		searchMap.put(ColumnNames.TXN_LIST_DATE_TO.get(), transformTxnDateTo(dtRequest));
		searchMap.put(ColumnNames.TXN_LIST_TXN_TYPE.get(), transformTxnTxnType(dtRequest));

		return searchMap;
	}
	
	/**
	 * transformTxnUserId is responsible for trimming the userid 
	 * @param dtRequest
	 * @return
	 */
	private String transformTxnUserId(TransactionSearchFormDataTableBean dtRequest) {
		return dtRequest.getUserId().trim();
	}
	
	/**
	 * transformTxnUserId is responsible for trimming the MerchantName 
	 * @param dtRequest
	 * @return
	 */
	private String transformTxnMerchantName(TransactionSearchFormDataTableBean dtRequest) {
		return dtRequest.getMerchantName().trim();
	}
	
	/**
	 * transformTxnUserId is responsible for trimming the transaction id 
	 * @param dtRequest
	 * @return
	 */
	private String transformTxnTxnId(TransactionSearchFormDataTableBean dtRequest) {	    	
	    return dtRequest.getTransactionId().trim();
	}
	
	/**
	 * transformTxnUserId is responsible for trimming the rrn 
	 * @param dtRequest
	 * @return
	 */
	private String transformTxnRRN(TransactionSearchFormDataTableBean dtRequest) {
		return dtRequest.getRrn().trim();
	}
	
	/**
	 * transformTxnUserId is responsible for trimming the auth code 
	 * @param dtRequest
	 * @return
	 */
	private String transformTxnAuthCode(TransactionSearchFormDataTableBean dtRequest) {
		return dtRequest.getAuthCode().trim();
	}
	
	/**
	 * transformTxnUserId is responsible for trimming the msked card number 
	 * @param dtRequest
	 * @return
	 */
	private String transformTxnCardNumber(TransactionSearchFormDataTableBean dtRequest) {
		return dtRequest.getMaskedCardNumber().trim();
	}
	
	/**
	 * transformTxnUserId is responsible for trimming the card holder name 
	 * @param dtRequest
	 * @return
	 */
	private String transformTxnCardHolderName(TransactionSearchFormDataTableBean dtRequest) {
		return dtRequest.getCardHolderName().trim();
	}
	
	/**
	 * transformTxnUserId is responsible for trimming the acquirer
	 * @param dtRequest
	 * @return
	 */
	private String transformTxnAcquirer(TransactionSearchFormDataTableBean dtRequest) {
		return dtRequest.getAcquirer().trim();
	}
	
	
	/**
	 * transformTxnUserId is responsible for trimming the mid
	 * @param dtRequest
	 * @return
	 */
	private String transformTxnMID(TransactionSearchFormDataTableBean dtRequest) {
		return dtRequest.getMid().trim();
	}
	
	/**
	 * transformTxnUserId is responsible for trimming the tid
	 * @param dtRequest
	 * @return
	 */
	private String transformTxnTID(TransactionSearchFormDataTableBean dtRequest) {
		return dtRequest.getTid().trim();
	}
	
	/**
	 * transformTxnUserId is responsible for trimming the date from
	 * @param dtRequest
	 * @return
	 */
	private String transformTxnDateFrom(TransactionSearchFormDataTableBean dtRequest) {
		return dtRequest.getTransactionDateFrom().trim();
	}
	
	/**
	 * transformTxnUserId is responsible for trimming the date to
	 * @param dtRequest
	 * @return
	 */
	private String transformTxnDateTo(TransactionSearchFormDataTableBean dtRequest) {
		return dtRequest.getTransactionDateTo().trim();
	}
	
	
	/**
	 * transformTxnUserId is responsible for trimming the txn type
	 * @param dtRequest
	 * @return
	 */
	private String transformTxnTxnType(TransactionSearchFormDataTableBean dtRequest) {
		log.info("txn type {}",dtRequest.getTxnType());
		String txnType="";
		if(dtRequest.getTxnType().equals("101")) {
			txnType = "3"; 
		}
		
		if(dtRequest.getTxnType().equals("102")) {
			txnType = "-2"; 
		}
		
		if(dtRequest.getTxnType().equals("103")) {
			txnType = "0"; 
		}
		
		if(dtRequest.getTxnType().equals("104")) {
			txnType = "20"; 
		}
		
		if(!dtRequest.getTxnType().equals("101") && !dtRequest.getTxnType().equals("102") && !dtRequest.getTxnType().equals("103") && !dtRequest.getTxnType().equals("104")) {
		   return dtRequest.getTxnType().trim();
		}else {
			return txnType;
		}
	} 
	
	/**
	 * transformTransactionReportFromDate(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformTransactionReportFromDate(TransactionDateReportBean dtRequest) {
		String transactionFromDate = dtRequest.getFromDate();
		return transactionFromDate.trim();
	}
	
	/**
	 * transformTransactionReportToDate(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformTransactionReportToDate(TransactionDateReportBean dtRequest) {
		String transactionToDate = dtRequest.getToDate();
		return transactionToDate.trim();
	}
	
	/**
	 * transformTransactionReportAuthCode(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformTransactionReportAuthCode(TransactionDateReportBean dtRequest) {
		String transactionAuthCode = dtRequest.getAuthCode();
		return transactionAuthCode.trim();
	}
	
	/**
	 * transformTransactionReportBinValue(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformTransactionReportBinValue(TransactionDateReportBean dtRequest) {
		String transactionBinValue = dtRequest.getBinValue();
		return transactionBinValue.trim();
	}
	
	/**
	 * transformTransactionReportTxnAmount(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformTransactionReportTxnAmount(TransactionDateReportBean dtRequest) {
		String transactionTxnAmount = dtRequest.getTxnAmount();
		return transactionTxnAmount.trim();
	}
	
	/**
	 * transformTransactionReportIssuer(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformTransactionReportIssuer(TransactionDateReportBean dtRequest) {
		String transactionIssuer = dtRequest.getIssuer();
		return transactionIssuer.trim();
	}
	
	/**
	 * transformTransactionReportStatus(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformTransactionReportStatus(TransactionDateReportBean dtRequest) {
		String transactionStatus = dtRequest.getStatus();
		return transactionStatus.trim();
	}
	
	/**
	 * transformTransactionReportConvStatus(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformTransactionReportConvStatus(TransactionDateReportBean dtRequest) {
		String transactionConvStatus = dtRequest.getEmiStatus();
		return transactionConvStatus.trim();
	}
	
	/**
	 * transformTransactionReferenceNumber(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformTransactionReferenceNumber(TransactionDateReportBean dtRequest) {
		String transactionRefNo = dtRequest.getTxnRefNo();
		return transactionRefNo.trim();
	}

}
