package com.mosambee.transformer;

import java.util.Map;

import com.mosambee.bean.AdminAcquirerDataTablesRequestBean;

public interface AdminAcquirerTransformer {

	public Map<String, String> transformAdminAcquirerDataTableRequest(AdminAcquirerDataTablesRequestBean dtRequest);
}
