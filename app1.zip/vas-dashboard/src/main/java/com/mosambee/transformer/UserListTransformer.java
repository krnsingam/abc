package com.mosambee.transformer;

import java.util.Map;

import com.mosambee.bean.BlockedUserDataTableBean;
import com.mosambee.bean.UserCrudDataTableBean;

/**
 * UserListTransformer is specification for {@link UserListTransformerImpl}
 * 
 * @author rahul.mishra
 * @version 1.0
 * @since 24-02-2020
 */

public interface UserListTransformer {
	Map<String, String> transformUserDataTableRequest(UserCrudDataTableBean dtRequest);
	Map<String, String> transformWebBlockedUserDataTableRequest(BlockedUserDataTableBean dtRequest);
}
