package com.mosambee.transformer;

import java.util.Map;

import com.mosambee.bean.BqrListDatatablesRequestBean;


/**
 * This class provides specification for {@link BqrMerchantListTransformerImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
public interface BqrMerchantListTransformer {
	 Map<String, String> transformBqrMerchantsListDataTablesRequest(BqrListDatatablesRequestBean dtRequest);
	 
}
