package com.mosambee.transformer;

import java.util.Date;

import com.mosambee.bean.ProgramBulkUploadBean;

/**
 * ProgramBulkUploadTransformer is basically used to transform bean field
 * values.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 30-December-2019
 */
public interface ProgramBulkUploadTransformer {

	void transformProgramName(ProgramBulkUploadBean programBulkUploadBean);

	void transformProgramDescription(ProgramBulkUploadBean programBulkUploadBean);

	void transformProgramPriority(ProgramBulkUploadBean programBulkUploadBean);

	void transformProgramDomain(ProgramBulkUploadBean programBulkUploadBean);

	void transformProgramStartDateTime(ProgramBulkUploadBean programBulkUploadBean, Date date);

	void transformProgramEndDateTime(ProgramBulkUploadBean programBulkUploadBean, Date date);

	void transformProgramCumulativeCount(ProgramBulkUploadBean programBulkUploadBean);

	void transformProgramCumulativeCountMode(ProgramBulkUploadBean programBulkUploadBean);

}
