package com.mosambee.transformer.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.mosambee.bean.AdminAcquirerDataTablesRequestBean;
import com.mosambee.constants.ColumnNames;
import com.mosambee.transformer.AdminAcquirerTransformer;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component("adminAcquirerTransformer")
public class AdminAcquirerTransformerImpl implements AdminAcquirerTransformer{

	@Override
	public Map<String, String> transformAdminAcquirerDataTableRequest(AdminAcquirerDataTablesRequestBean dtRequest) {
		
		Map<String, String> searchMap = new HashMap<>();

		searchMap.put(ColumnNames.ADMIN_ACQUIRER_FROMDATE.get(), transformAdminAcquirerFromDate(dtRequest));
		searchMap.put(ColumnNames.ADMIN_ACQUIRER_TODATE.get(), transformAdminAcquirerToDate(dtRequest));
		return searchMap;
	}

	/**
	 * transformTransactionReportFromDate(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformAdminAcquirerFromDate(AdminAcquirerDataTablesRequestBean dtRequest) {
		log.info("transactionFromDate {}",dtRequest.getFromDate());
		String transactionFromDate = dtRequest.getFromDate();
		return transactionFromDate.trim();
	}
	
	/**
	 * transformTransactionReportToDate(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformAdminAcquirerToDate(AdminAcquirerDataTablesRequestBean dtRequest) {
		String transactionToDate = dtRequest.getToDate();
		return transactionToDate.trim();
	}
}
