package com.mosambee.transformer;

import java.util.Map;

import com.mosambee.bean.BillNumberDataTablesRequestBean;

public interface SearchByBillNumberTransformer {
	
	public Map<String, String> transformBillNumberDataTableRequest(BillNumberDataTablesRequestBean dtRequest);


}
