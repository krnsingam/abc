package com.mosambee.transformer.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.mosambee.bean.BlockedUserDataTableBean;
import com.mosambee.bean.UserCrudDataTableBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.constants.ColumnNames;
import com.mosambee.transformer.UserListTransformer;

/**
 * UserListTransformerImpl is responsible for transforming the userBean
 * fields ... Mainly implemented for transforming the search inputs coming via
 * data-tables.
 * 
 * @author rahul.mishra
 * @version 1.0
 * @since 24-02-2020
 */

@Component("userListTransformer")
public class UserListTransformerImpl implements UserListTransformer{
	/**
	 * transformUserDataTableRequest(...) is responsible for transforming incoming
	 * {@link UserCrudDataTableBean} ... We are mainly trimming values here.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return Map<String, String>
	 */
	@Override
	public Map<String, String> transformUserDataTableRequest(UserCrudDataTableBean dtRequest) {
		Map<String, String> searchMap = new HashMap<>();

		searchMap.put(ColumnNames.USERNAME.get(), transformUserName(dtRequest));
		searchMap.put(ColumnNames.USR_STATUS.get(), transformUserStatus(dtRequest));
		searchMap.put(ColumnNames.USR_ROLE.get(), transformUserRole(dtRequest));

		return searchMap;
	}
	
	/**
	 * transformWebBlockedUserDataTableRequest(...) is responsible for transforming incoming
	 * {@link BlockedUserDataTableBean} ... We are mainly trimming values here.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return Map<String, String>
	 */
	@Override
	public Map<String, String> transformWebBlockedUserDataTableRequest(BlockedUserDataTableBean dtRequest) {
		Map<String, String> searchMap = new HashMap<>();

		searchMap.put(ColumnNames.WEB_BLOCKED_USERNAME.get(), transformWebBlockedUserName(dtRequest));
		searchMap.put(ColumnNames.WEB_BLOCKED_FIRSTNAME.get(), transformWebBlockedFirstName(dtRequest));
		searchMap.put(ColumnNames.WEB_BLOCKED_EMAIL.get(), transformWebBlockedEmail(dtRequest));
		searchMap.put(ColumnNames.WEB_BLOCKED_BLOCKED_DATE.get(), transformWebBlockedDate(dtRequest));
		searchMap.put(ColumnNames.WEB_BLOCKED_EXPIRY_DATE.get(), transformWebBlockedExpiryDate(dtRequest));

		return searchMap;
	}
	
	/**
	 * transformWebBlockedUserName(...) is responsible for trimming the username
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformWebBlockedUserName(BlockedUserDataTableBean dtRequest) {
		String username = dtRequest.getUsername();
		return username.trim();
	}

	/**
	 * transformWebBlockedFirstName(...) is responsible for trimming the first name
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformWebBlockedFirstName(BlockedUserDataTableBean dtRequest) {
		String firstName = dtRequest.getFirstName();
		return firstName.trim();
	}
	
	/**
	 * transformWebBlockedEmail(...) is responsible for trimming the email
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformWebBlockedEmail(BlockedUserDataTableBean dtRequest) {
		String email = dtRequest.getEmail();
		return email.trim();
	}
	
	/**
	 * transformWebBlockedDate(...) is responsible for trimming the block date
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformWebBlockedDate(BlockedUserDataTableBean dtRequest) {
		String blockDate = dtRequest.getBlockDate().trim();
		if(blockDate.isEmpty()) {
			return null;
		}
		return blockDate;
	}
	
	/**
	 * transformWebBlockedDate(...) is responsible for trimming the block date
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformWebBlockedExpiryDate(BlockedUserDataTableBean dtRequest) {
		String expiryDate = dtRequest.getExpiryDate().trim();
		if(expiryDate.isEmpty()) {
			return null;
		}
		return expiryDate;
	}

	
	/**
	 * transformUserName(...) is responsible for trimming the username
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformUserName(UserCrudDataTableBean dtRequest) {
		String username = dtRequest.getUsername();
		return username.trim();
	}
	
	/**
	 * transformUserStatus(...) is responsible for trimming the user status
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformUserStatus(UserCrudDataTableBean dtRequest) {
		String userStatus = dtRequest.getStatus().trim();
		if(userStatus == null || userStatus.isEmpty()) {
			return null;
		}
		return userStatus;
	}
	
	/**
	 * transformUserRole(...) is responsible for trimming the user role
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformUserRole(UserCrudDataTableBean dtRequest) {
		String role = dtRequest.getRole();
		return role.trim();
	}
}
