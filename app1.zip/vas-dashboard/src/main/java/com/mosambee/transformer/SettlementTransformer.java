package com.mosambee.transformer;

import java.util.Map;

import com.mosambee.bean.SettlementDataTableCrudBean;

/**
 * SettlementTransformer is specification for {@link SettlementTransformerImpl}
 * 
 * @author rahul.mishra
 * @version 1.0
 * @since 24-02-2020
 */

public interface SettlementTransformer {
	Map<String, String> transformSettlementDataTableRequest(SettlementDataTableCrudBean dtRequest);
}
