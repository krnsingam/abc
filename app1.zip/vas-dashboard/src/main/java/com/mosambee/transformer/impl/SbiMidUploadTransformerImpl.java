package com.mosambee.transformer.impl;

import org.springframework.stereotype.Component;

import com.mosambee.bean.SBIMidUploadBean;
import com.mosambee.transformer.SbiMidUploadTransformer;

/**
 * This class is used for trimming spaces coming from SBI MID upload
 * fields
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 */
@Component("sbiMidUploadTransformer")
public class SbiMidUploadTransformerImpl implements SbiMidUploadTransformer{

	@Override
	public void transformMposMid(SBIMidUploadBean sBIMidUploadBean) {
		String mid = sBIMidUploadBean.getMPosMid();
		mid = mid.trim();
		sBIMidUploadBean.setMPosMid(mid);
	}

	@Override
	public void transformMerchantName(SBIMidUploadBean sBIMidUploadBean) {
		String merchantName = sBIMidUploadBean.getMerchantName();
		merchantName = merchantName.trim();
		sBIMidUploadBean.setMerchantName(merchantName);
		
	}

	@Override
	public void transformMerchantCity(SBIMidUploadBean sBIMidUploadBean) {
		String merchantCity = sBIMidUploadBean.getMerchantCity();
		merchantCity = merchantCity.trim();
		sBIMidUploadBean.setMerchantName(merchantCity);
		
	}

}
