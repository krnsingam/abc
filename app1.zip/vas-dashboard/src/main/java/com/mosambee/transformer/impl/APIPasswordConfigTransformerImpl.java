package com.mosambee.transformer.impl;

import java.util.HashMap;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.mosambee.bean.CreateAPIGroup;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.constants.ColumnNames;
import com.mosambee.constants.CommonConstants;
import com.mosambee.dao.APIPasswordConfigDao;
import com.mosambee.transformer.APIPasswordConfigTransformer;
import com.mosambee.util.APIPasswordUtil;
import com.mosambee.util.SHA1;

/**
 * {@link APIPasswordConfigTransformerImpl} provide implementation for all
 * methods define in {@link APIPasswordConfigTransformer} interface. fields ...
 * Mainly implemented for transforming the search inputs coming via API Password
 * Config modules data-tables as well API Password Config modules forms.
 * 
 * @author mandar.chaudhari
 * @version 1.0
 */

@Component("apiPasswordConfigTransformer")
public class APIPasswordConfigTransformerImpl implements APIPasswordConfigTransformer {

	private static final Logger log = LogManager.getLogger(APIPasswordConfigTransformerImpl.class);

	@Autowired
	private APIPasswordUtil apiPasswordUtil;

	@Autowired
	@Qualifier("apiPasswordConfigDaoImpl")
	APIPasswordConfigDao apiPasswordConfigDao;

	/**
	 * transformTransactionReportDataTableRequest(...) is responsible for
	 * transforming incoming {@link DataTablesRequest} ... We are mainly trimming
	 * values here.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return Map<String, String>
	 */
	@Override
	public Map<String, String> transformListOfAPIGroup(DataTablesRequest dtRequest) {
		Map<String, String> searchMap = new HashMap<>();

		searchMap.put(ColumnNames.ID.get(), transformId(dtRequest));
		searchMap.put(ColumnNames.API_DIVISION_NAME.get(), transformAPIDivisionName(dtRequest));
		searchMap.put(ColumnNames.API_DIVISION_CODE.get(), transformAPIDivisionCode(dtRequest));
		searchMap.put(ColumnNames.MPOS_API_PASSWORD.get(), transformMPOSAPIPassword(dtRequest));
		searchMap.put(ColumnNames.API_URL_1.get(), transformAPIURL1(dtRequest));
		searchMap.put(ColumnNames.DIVISION_STATUS.get(), transformDivisionStatus(dtRequest));
		return searchMap;
	}

	/**
	 * This method is used when {@link DataTablesRequest} comes from "List of API
	 * Group" module to take transformation actions such as if "dtRequest" field
	 * "id" is present then set value as it if not available then set it to "-1". -1
	 * indicates filter should not consider "id" otherwise consider.
	 * 
	 * @param dtRequest : {@link DataTablesRequest} bean.
	 * @return String : "id" value with trim.
	 */
	private String transformId(DataTablesRequest dtRequest) {
		String id = dtRequest.getColumns().get(0).getSearch().getValue();
		try {
			Integer.parseInt(id);
		} catch (Exception e) {
			log.info("Handled exception 'id' is not number. e : {}", e.getMessage());
			id = "-1";
		}
		return id.trim();
	}

	/**
	 * This method is used when {@link DataTablesRequest} comes from "List of API
	 * Group" module to take transformation actions such as This method used to
	 * transform "API Division Name" field of dtRequest in which field is only trim.
	 * 
	 * @param dtRequest : {@link DataTablesRequest} bean.
	 * @return String : "API Division Name" value with trim.
	 */
	private String transformAPIDivisionName(DataTablesRequest dtRequest) {
		String apiDivisionName = dtRequest.getColumns().get(1).getSearch().getValue();
		return apiDivisionName.trim();
	}

	/**
	 * This method is used when {@link DataTablesRequest} comes from "List of API
	 * Group" module to take transformation actions such as This method used to
	 * transform "API Division Code" field of dtRequest in which field is only trim.
	 * 
	 * @param dtRequest : {@link DataTablesRequest} bean.
	 * @return String : "API Division Code" value with trim.
	 */
	private String transformAPIDivisionCode(DataTablesRequest dtRequest) {
		String apiDivisionCode = dtRequest.getColumns().get(2).getSearch().getValue();
		return apiDivisionCode.trim();
	}

	/**
	 * transformListOfMidTid(...) is responsible for transforming incoming
	 * {@link DataTablesRequest} ... We are mainly trimming values here.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return Map<String, String>
	 */
	@Override
	public Map<String, String> transformMidTid(DataTablesRequest dtRequest) {
		Map<String, String> searchMap = new HashMap<>();
		log.info(dtRequest.getColumns());
		searchMap.put(ColumnNames.MID_DETAIL.get(), transformMid(dtRequest));
		searchMap.put(ColumnNames.DIVISION_CODE_DETAIL.get(), transformDivisionCode(dtRequest));
		searchMap.put(ColumnNames.TID_DETAIL.get(), transformTid(dtRequest));

		return searchMap;
	}

	/**
	 * This method is used when {@link DataTablesRequest} comes from "Mid Tid"
	 * module to take transformation actions such as This method used to transform
	 * "Mid" field of dtRequest in which field is only trim.
	 * 
	 * @param dtRequest : {@link DataTablesRequest} bean.
	 * @return String : "API Division Name" value with trim.
	 */
	private String transformMid(DataTablesRequest dtRequest) {

		String mid = dtRequest.getColumns().get(1).getSearch().getValue();
		log.info(mid);
		return mid.trim();
	}

	/**
	 * This method is used when {@link DataTablesRequest} comes from "Mid Tid"
	 * module to take transformation actions such as This method used to transform
	 * "Division Code" field of dtRequest in which field is only trim.
	 * 
	 * @param dtRequest : {@link DataTablesRequest} bean.
	 * @return String : "API Division Code" value with trim.
	 */
	private String transformDivisionCode(DataTablesRequest dtRequest) {
		String divisionCode = dtRequest.getColumns().get(2).getSearch().getValue();
		log.info(divisionCode);
		return divisionCode.trim();
	}

	/**
	 * This method is used when {@link DataTablesRequest} comes from "Mid Tid"
	 * module to take transformation actions such as This method used to transform
	 * "Division Code" field of dtRequest in which field is only trim.
	 * 
	 * @param dtRequest : {@link DataTablesRequest} bean.
	 * @return String : "API Division Code" value with trim.
	 */
	private String transformTid(DataTablesRequest dtRequest) {
		String tid = dtRequest.getColumns().get(3).getSearch().getValue();
		log.info(tid);
		return tid.trim();
	}

	/**
	 * This method is used when {@link DataTablesRequest} comes from "List of API
	 * Group" module to take transformation actions such as This method used to
	 * transform "MPOS API Password" field of dtRequest in which field is only trim.
	 * 
	 * @param dtRequest : {@link DataTablesRequest} bean.
	 * @return String : "MPOS API Password" value with trim.
	 */
	private String transformMPOSAPIPassword(DataTablesRequest dtRequest) {
		String mPOSAPIPassword = dtRequest.getColumns().get(3).getSearch().getValue();
		return mPOSAPIPassword.trim();
	}

	/**
	 * This method is used when {@link DataTablesRequest} comes from "List of API
	 * Group" module to take transformation actions such as This method used to
	 * transform "API URL 1" field of dtRequest in which field is only trim.
	 * 
	 * @param dtRequest : {@link DataTablesRequest} bean.
	 * @return String : "API URL 1" value with trim.
	 */
	private String transformAPIURL1(DataTablesRequest dtRequest) {
		String apiURL1 = dtRequest.getColumns().get(4).getSearch().getValue();
		return apiURL1.trim();
	}

	/**
	 * This method is used when {@link DataTablesRequest} comes from "List of API
	 * Group" module to take transformation actions such as if "dtRequest" field
	 * "Division Status" is present then set value as it if not available then set
	 * it to "-1". -1 indicates filter should not consider "Division Status"
	 * otherwise consider.
	 * 
	 * @param dtRequest : {@link DataTablesRequest} bean.
	 * @return String : "Division Status" value with trim.
	 */
	private String transformDivisionStatus(DataTablesRequest dtRequest) {
		String divisionStatus = dtRequest.getColumns().get(5).getSearch().getValue();
		try {
			Integer.parseInt(divisionStatus);
		} catch (Exception e) {
			log.info("Handled exception 'id' is not number. e : {}", e.getMessage());
			divisionStatus = "-1";
		}
		return divisionStatus.trim();
	}

	/**
	 * This method is used to transform "API Password field" when creating API
	 * PAssword Config. This method internally calling hashing function on "API
	 * Password" of {@link CreateAPIGroup}
	 * 
	 * @param createAPIGroup : {@link CreateAPIGroup} bean.
	 *
	 */
	public void transformMPOSAPIPasswordForDataInserting(CreateAPIGroup createAPIGroup) {
		createAPIGroup.setPassMpos(createAPIGroup.getApiPassword());
		createAPIGroup.setApiPassword(getHashedString(createAPIGroup.getApiPassword(), createAPIGroup));
	}

	/**
	 * This method is used to transform "API Password field" when updating API
	 * Password Config. This method internally calling hashing function on "API
	 * Password" of {@link CreateAPIGroup}
	 * 
	 * @param createAPIGroup : {@link CreateAPIGroup} bean.
	 *
	 */
	public void transformMPOSAPIPasswordForDataUpdating(CreateAPIGroup createAPIGroup) {
		boolean isPresentPassword = apiPasswordConfigDao
				.isAPIPasswordConfigPasswordPresent(createAPIGroup.getApiPassword(), createAPIGroup.getId());
		log.info("Password is change for this id : {}", isPresentPassword);
		if (!isStringPresent(createAPIGroup.getApiPassword())) {
			createAPIGroup.setApiPassword(getHashedString(CommonConstants.EMPTY_STRING.get(), createAPIGroup));
		} else {
			if (isPresentPassword) {
				createAPIGroup.setPassMpos("");
			} else {
				createAPIGroup.setPassMpos(createAPIGroup.getApiPassword());
				createAPIGroup.setApiPassword(getHashedString(createAPIGroup.getApiPassword(), createAPIGroup));
			}
		}
	}

	/**
	 * This method is used apply hashing on string which is comes as parameter
	 * "str". If we pass empty string then this functions return own generated hash
	 * string otherwise if we passed any string then it apply hashing on that
	 * string.
	 * 
	 * @param str : String on which we want to apply hashing.
	 * @return Hashed string.
	 */

	private String getHashedString(String str, CreateAPIGroup createAPIGroup) {
		if (str.equals(CommonConstants.EMPTY_STRING.get())) {
			str = SHA1.generateOtp();
			createAPIGroup.setPassMpos(str);
			str = apiPasswordUtil.hash(str);
			return str;
		}
		return apiPasswordUtil.hash(str);
	}

	/**
	 * This method is used check whether the string "str" is "null" or "". If
	 * parameter "str" is null or "" then it will return false otherwise return
	 * true. This method is useful to avoid "NullPointerException", or validate
	 * string is "" or not.
	 * 
	 * @param str : String to be checked.
	 * @return boolean : Return "True" if string present Return "False" is string is
	 *         not present or null.
	 * @author mandar.chaudhari
	 */
	private boolean isStringPresent(String str) {
		if (str == null) {
			return false;
		} else {
			if (str.equals("")) {
				return false;
			}
		}
		return true;
	}
}
