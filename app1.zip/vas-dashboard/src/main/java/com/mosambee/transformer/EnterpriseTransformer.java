package com.mosambee.transformer;

import java.util.Map;

import com.mosambee.bean.EnterpriseDataBean;

public interface EnterpriseTransformer {

	public Map<String, String> transformEnterprise(EnterpriseDataBean dtRequest) ;
	
}
