package com.mosambee.transformer;

import java.util.Map;

import com.mosambee.bean.ApiPasswordDataBean;

public interface ApiPasswordTransformer {

	public Map<String, String> transformApiPasswordDataTableRequest(ApiPasswordDataBean dtRequest);
	
}
