package com.mosambee.transformer.impl;

import org.springframework.stereotype.Component;

import com.mosambee.bean.EmiUploadBean;
import com.mosambee.transformer.EmiUploadTransformer;

/**
 * This class is using for trimming space coming from emi upload
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
@Component("emiUploadTransformer")
public class EmiUploadTransformerImpl implements EmiUploadTransformer {
	/**
	 * transformBaseTid() is responsible for trimming space coming from baseTid in
	 * emi upload
	 * 
	 * @param emiUploadBean
	 */
	@Override
	public void transformBaseTid(EmiUploadBean emiUploadBean) {
		String baseTid = emiUploadBean.getBaseTid();
		baseTid = baseTid.trim();
		emiUploadBean.setBaseTid(baseTid);

	}

	/**
	 * transformBaseMid() is responsible for trimming space coming from baseMid in
	 * emi Upload
	 * 
	 * @param emiUploadBean
	 */
	@Override
	public void transformBaseMid(EmiUploadBean emiUploadBean) {
		String baseMid = emiUploadBean.getBaseMid();
		baseMid = baseMid.trim();
		emiUploadBean.setBaseMid(baseMid);
	}

	/**
	 * transformEmiType() is responsible for trimming space coming from emiType in
	 * emi upload and converting emiType in uppercase .
	 * 
	 * @param emiUploadBean
	 */
	@Override
	public void transformEmiType(EmiUploadBean emiUploadBean) {
		String emiType = emiUploadBean.getEmiType();
		emiType = emiType.toUpperCase().trim();
		emiUploadBean.setEmiType(emiType);
	}

	/**
	 * transformEmiMid() is responsible for trimming space coming from emiType
	 * 
	 * @param emiUploadBean
	 */
	@Override
	public void transformEmiMid(EmiUploadBean emiUploadBean) {
		String emiMid = emiUploadBean.getEmiMid();
		emiMid = emiMid.trim();
		emiUploadBean.setEmiMid(emiMid);

	}

	/**
	 * transformEmiTid() is respinsible for trimming space coming from emiTid in emi
	 * Upload
	 * 
	 * @param emiUploadBean
	 */
	@Override
	public void transformEmiTid(EmiUploadBean emiUploadBean) {
		String emiTid = emiUploadBean.getEmiTid();
		emiTid = emiTid.trim();
		emiUploadBean.setEmiTid(emiTid);
	}

	/**
	 * transformMosambeeEmi() is responsible for trimming space coming from
	 * mosambeeEmi in emi upload and converting mosambeeEmi in uppercase
	 * 
	 * @param emiUploadBean
	 */
	@Override
	public void transformMosambeeEmi(EmiUploadBean emiUploadBean) {
		String mosambeeEmi = emiUploadBean.getMosambeeEmi();
		mosambeeEmi = mosambeeEmi.toUpperCase().trim();
		emiUploadBean.setMosambeeEmi(mosambeeEmi);
	}

	/**
	 * transformEmi() is responsible for trimming space coming from emi in emiUpload
	 * and converting emi in uppercase
	 * 
	 * @param emiUploadBean
	 */
	@Override
	public void transformEmi(EmiUploadBean emiUploadBean) {
		String emi = emiUploadBean.getEmi();
		emi = emi.toUpperCase().trim();
		emiUploadBean.setEmi(emi);
	}

	/**
	 * transformEmiEnquiry() is responsible for trimming space coming from
	 * emiEnquiry in emi upload and converting emiEnquiry in uppercase
	 * 
	 * @param emiUploadBean
	 */
	@Override
	public void transformEmiEnquiry(EmiUploadBean emiUploadBean) {
		String emiEnquiry = emiUploadBean.getEmiEnquiry();
		emiEnquiry = emiEnquiry.toUpperCase().trim();
		emiUploadBean.setEmiEnquiry(emiEnquiry);
	}

	/**
	 * transformProgramEnquiry() is responsible for trimming space coming from
	 * emiProgramEnquiry and converting in uppercase
	 * 
	 * @param emiUploadBean
	 */
	@Override
	public void transformProgramEnquiry(EmiUploadBean emiUploadBean) {
		String emiProgramEnquiry = emiUploadBean.getEmiProgramEnquiry();
		emiProgramEnquiry = emiProgramEnquiry.toUpperCase().trim();
		emiUploadBean.setEmiProgramEnquiry(emiProgramEnquiry);

	}

	/**
	 * transformEmiVoid() is responsible for trimming space coming from emiVoid and
	 * converting emiVoid in uppercase
	 * 
	 * @param emiUploadBean
	 */
	@Override
	public void transformEmiVoid(EmiUploadBean emiUploadBean) {
		String emiVoid = emiUploadBean.getEmiVoid();
		emiVoid = emiVoid.toUpperCase().trim();
		emiUploadBean.setEmiVoid(emiVoid);
	}

	/**
	 * transformEmiSettlement() is responsible for trimming space coming from
	 * emiSettlement and converting emiSettlement in uppercase
	 * 
	 * @param emiUploadBean
	 */
	@Override
	public void transformEmiSettlement(EmiUploadBean emiUploadBean) {
		String emiSettlement = emiUploadBean.getEmiSettlement();
		emiSettlement = emiSettlement.toUpperCase().trim();
		emiUploadBean.setEmiSettlement(emiSettlement);
	}

	/**
	 * transformCcEmiFlag() is responsible for trimming space coming from ccEmiFlag
	 * and converting ccEmiFlag in uppercase
	 * 
	 * @param emiUploadBean
	 */
	@Override
	public void transformCcEmiFlag(EmiUploadBean emiUploadBean) {
		String ccEmiFlag = emiUploadBean.getCcEmiFlag();
		ccEmiFlag = ccEmiFlag.toUpperCase().trim();
		emiUploadBean.setCcEmiFlag(ccEmiFlag);
	}

	/**
	 * transformDcEmiFlag() is responsible for trimming space coming from dcEmiFlag
	 * and converting in uppercase
	 * 
	 * @param emiUploadBean
	 */
	@Override
	public void transformDcEmiFlag(EmiUploadBean emiUploadBean) {
		String dcEmiFlag = emiUploadBean.getDcEmiFlag();
		dcEmiFlag = dcEmiFlag.toUpperCase().trim();
		emiUploadBean.setDcEmiFlag(dcEmiFlag);
	}

	/**
	 * transformBrandEmiFlag() is responsible for trimming space coming from
	 * brandEmiFlag and converting brandEmiFlag in uppercase
	 * 
	 * @param emiUploadBean
	 */
	@Override
	public void transformBrandEmiFlag(EmiUploadBean emiUploadBean) {
		String brandEmiFlag = emiUploadBean.getBrandEmiFlag();
		brandEmiFlag = brandEmiFlag.toUpperCase().trim();
		emiUploadBean.setBrandEmiFlag(brandEmiFlag);
	}

	

	/**
	 * transformEmiMatCode() is responsible for trimming space coming from
	 * emiMatCode and converting emiMatCode in uppercase
	 * 
	 * @param emiUploadBean
	 */
	@Override
	public void transformEmiMatCode(EmiUploadBean emiUploadBean) {
		String emiMatCode = emiUploadBean.getMosambeeEmi();
		emiMatCode = emiMatCode.toUpperCase().trim();
		emiUploadBean.setMosambeeEmi(emiMatCode);
	}

}
