package com.mosambee.transformer;

import com.mosambee.bean.InstantMidUploadBean;

/**
 * This class is basically used for transform InstantMidUploadBean field Values
 * 
 * @author pooja.singh
 * @version 1.0
 */
public interface InstantMidUploadTransformer {
	void transformPosId(InstantMidUploadBean instantMidUploadBean);

	void transformTempMid(InstantMidUploadBean instantMidUploadBean);

	void transformTempTid(InstantMidUploadBean instantMidUploadBean);

	void transformTid(InstantMidUploadBean instantMidUploadBean);

	void transformMid(InstantMidUploadBean instantMidUploadBean);

}
