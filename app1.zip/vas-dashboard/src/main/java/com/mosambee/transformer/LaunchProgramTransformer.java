package com.mosambee.transformer;

import java.util.Map;

import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.transformer.impl.LaunchProgramTransformerImpl;

/**
 * LaunchProgramTransformer is specification for {@link LaunchProgramTransformerImpl}
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 03-January-2020
 */
public interface LaunchProgramTransformer {
	
	Map<String, String> transformProgramDataTableRequest(DataTablesRequest dtRequest);

}
