package com.mosambee.transformer.impl;

import org.springframework.stereotype.Component;

import com.mosambee.bean.EmiConversionUploadBean;
import com.mosambee.transformer.EmiConversionUploadTransformer;

/**
 * This class is using for trimming space coming from emi conversion upload
 * fields
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Component("emiConversionUploadTransformer")
public class EmiConversionUploadTransformerImpl implements EmiConversionUploadTransformer {

	/**
	 * transformIssuer() is using for trimming space coming from field issuer in emi
	 * conversion upload
	 *
	 */
	@Override
	public void transformIssuer(EmiConversionUploadBean emiConversionUploadBean) {
		String issuer = emiConversionUploadBean.getIssuer();
		issuer = issuer.toUpperCase().trim();
		emiConversionUploadBean.setIssuer(issuer);
	}

	/**
	 * transformTxnRefId() is responsible for trimming space coming from fields
	 * txnRefId
	 *
	 */
	@Override
	public void transformTxnRefId(EmiConversionUploadBean emiConversionUploadBean) {
		String txnRefId = emiConversionUploadBean.getTxnRefId();
		txnRefId = txnRefId.trim();
		emiConversionUploadBean.setTxnRefId(txnRefId);

	}

	/**
	 * transformStatus() is responsible for trimming space coming from field status
	 * in emi conversion upload
	 *
	 */
	@Override
	public void transformStatus(EmiConversionUploadBean emiConversionUploadBean) {
		String message = emiConversionUploadBean.getMessage();
		message = message.toUpperCase().trim();
		emiConversionUploadBean.setMessage(message);

	}

	/**
	 * transformComment() is responsible for trimming space coming from field
	 * comment in emi conversion upload
	 *
	 */
	@Override
	public void transformComment(EmiConversionUploadBean emiConversionUploadBean) {
		String comment = emiConversionUploadBean.getComment();
		comment = comment.trim();
		emiConversionUploadBean.setComment(comment);

	}

}
