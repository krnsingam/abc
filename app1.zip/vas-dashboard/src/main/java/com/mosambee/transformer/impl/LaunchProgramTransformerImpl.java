package com.mosambee.transformer.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.constants.ColumnNames;
import com.mosambee.transformer.LaunchProgramTransformer;

/**
 * LaunchProgramTransformerImpl is responsible for transforming the programBean
 * fields ... Mainly implemented for transforming the search inputs coming via
 * data-tables.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 03-January-2020
 */
@Component("launchProgramTransformer")
public class LaunchProgramTransformerImpl implements LaunchProgramTransformer {

	/**
	 * transformDataTableRequest(...) is responsible for transforming incoming
	 * {@link DataTablesRequest} ... We are mainly trimming values here.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return Map<String, String>
	 */
	@Override
	public Map<String, String> transformProgramDataTableRequest(DataTablesRequest dtRequest) {
		Map<String, String> searchMap = new HashMap<>();

		searchMap.put(ColumnNames.PROGRAM_NAME.get(), transformProgramName(dtRequest));
		searchMap.put(ColumnNames.PROGRAM_CODE.get(), transformProgramCode(dtRequest));
		searchMap.put(ColumnNames.PROGRAM_PRIORITY.get(), transformProgramPriority(dtRequest));
		searchMap.put(ColumnNames.PROGRAM_START_TIME.get(), transformProgramStartTime(dtRequest));
		searchMap.put(ColumnNames.PROGRAM_END_TIME.get(), transformProgramEndTime(dtRequest));
		searchMap.put(ColumnNames.PROGRAM_DESCRIPTION.get(), transformProgramDescription(dtRequest));

		return searchMap;
	}

	/**
	 * transformProgramDescription(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformProgramDescription(DataTablesRequest dtRequest) {
		String programDescription = dtRequest.getColumns().get(5).getSearch().getValue();
		return programDescription.trim();
	}

	/**
	 * transformProgramEndTime(...) is responsible for trimming the program end time
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformProgramEndTime(DataTablesRequest dtRequest) {
		String programEndTime = dtRequest.getColumns().get(4).getSearch().getValue();
		return programEndTime.trim();
	}

	/**
	 * transformProgramStartTime(...) is responsible for trimming the program start
	 * time field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformProgramStartTime(DataTablesRequest dtRequest) {
		String programStartTime = dtRequest.getColumns().get(3).getSearch().getValue();
		return programStartTime.trim();
	}

	/**
	 * transformProgramPriority(...) is responsible for trimming the program
	 * priority field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformProgramPriority(DataTablesRequest dtRequest) {
		String programPriority = dtRequest.getColumns().get(2).getSearch().getValue();
		return programPriority.trim();
	}

	/**
	 * transformProgramCode(...) is responsible for trimming the program code field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformProgramCode(DataTablesRequest dtRequest) {
		String programCode = dtRequest.getColumns().get(1).getSearch().getValue();
		return programCode.trim();
	}

	/**
	 * transformProgramName(...) is responsible for trimming the programName field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformProgramName(DataTablesRequest dtRequest) {
		String programName = dtRequest.getColumns().get(0).getSearch().getValue();
		return programName.trim();
	}

}
