package com.mosambee.transformer;

import com.mosambee.bean.EmiUploadBean;

/**
 * This class provides specification for {@link EmiUploadTransformerImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 */
public interface EmiUploadTransformer {
	void transformBaseTid(EmiUploadBean emiUploadBean);

	void transformBaseMid(EmiUploadBean emiUploadBean);

	void transformEmiType(EmiUploadBean emiUploadBean);

	void transformEmiMid(EmiUploadBean emiUploadBean);

	void transformEmiTid(EmiUploadBean emiUploadBean);

	void transformMosambeeEmi(EmiUploadBean emiUploadBean);

	void transformEmi(EmiUploadBean emiUploadBean);

	void transformEmiEnquiry(EmiUploadBean emiUploadBean);

	void transformProgramEnquiry(EmiUploadBean emiUploadBean);

	void transformEmiVoid(EmiUploadBean emiUploadBean);

	void transformEmiSettlement(EmiUploadBean emiUploadBean);

	void transformCcEmiFlag(EmiUploadBean emiUploadBean);

	void transformDcEmiFlag(EmiUploadBean emiUploadBean);

	void transformBrandEmiFlag(EmiUploadBean emiUploadBean);

	void transformEmiMatCode(EmiUploadBean emiUploadBean);

	

}
