package com.mosambee.transformer.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.mosambee.bean.ProgramBulkUploadBean;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.DateConstants;
import com.mosambee.transformer.ProgramBulkUploadTransformer;

/**
 * ProgramBulkUploadTransformerImpl is responsible for transforming existing
 * value of the {@link ProgramBulkUploadBean}.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 31-December-2019
 */
@Component("programBulkUploadTransformer")
public class ProgramBulkUploadTransformerImpl implements ProgramBulkUploadTransformer {

	/**
	 * transformProgramName(...) is responsible to normalizing the programName value
	 * String
	 * 
	 * @param programBulkUploadBean
	 * @return void
	 */
	@Override
	public void transformProgramName(ProgramBulkUploadBean programBulkUploadBean) {
		String normalizedProgramName = StringUtils.normalizeSpace(programBulkUploadBean.getProgramName());
		programBulkUploadBean.setProgramName(normalizedProgramName);
	}

	/**
	 * transformProgramDescription(...) is responsible for normalizing the
	 * programDescription value String
	 *
	 * @param programBulkUploadBean
	 * @return void
	 */
	@Override
	public void transformProgramDescription(ProgramBulkUploadBean programBulkUploadBean) {
		String normalizedProgramDescription = programBulkUploadBean.getProgramDescription();
		programBulkUploadBean.setProgramDescription(normalizedProgramDescription);
	}

	/**
	 * transformProgramPriority(...) is responsible for trimming the leading and
	 * trailing whitespace characters. trim() is necessary so that we can parse
	 * integer value from the string.
	 * 
	 * @param programBulkUploadBean
	 * @return void
	 */
	@Override
	public void transformProgramPriority(ProgramBulkUploadBean programBulkUploadBean) {
		String programPriority = programBulkUploadBean.getProgramPriority();
		programPriority = programPriority.trim();
		programBulkUploadBean.setProgramPriority(programPriority);
	}

	/**
	 * transformProgramDomain(...) is responsible for making the incoming program
	 * domain in lower case and then trimming the leading and trailing whitespace
	 * characters.
	 *
	 * @param programBulkUploadBean
	 * @return void
	 */
	@Override
	public void transformProgramDomain(ProgramBulkUploadBean programBulkUploadBean) {
		String programDomain = programBulkUploadBean.getProgramDomain();
		programDomain = programDomain.toLowerCase().trim();
		programBulkUploadBean.setProgramDomain(
				programDomain.equals("") ? CommonConstants.DEFAULT_PROGRAM_DOMAIN.get() : programDomain);
	}

	/**
	 * transformProgramStartDateTime(...) is responsible for converting the existing
	 * DATETIME format to MySQL specific DATETIME format ... so that it can be
	 * inserted into the database.
	 * 
	 * @param programBulkUploadBean
	 * @return void
	 */
	@Override
	public void transformProgramStartDateTime(ProgramBulkUploadBean programBulkUploadBean, Date date) {
		// CONVERT TO MySQL SPECIFIC DATETIME FORMAT
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DateConstants.YYYY_MM_DD_HH_MM_SS.get());
		String mysqlFormattedDate = simpleDateFormat.format(date);
		programBulkUploadBean.setProgramStartDateTime(mysqlFormattedDate);
	}

	/**
	 * transformProgramEndDateTime(...) is responsible for converting the existing
	 * DATETIME format to MySQL specific DATETIME format ... so that it can be
	 * inserted into the database.
	 * 
	 * @param programBulkUploadBean
	 * @return void
	 */
	@Override
	public void transformProgramEndDateTime(ProgramBulkUploadBean programBulkUploadBean, Date date) {
		// CONVERT TO MySQL SPECIFIC DATETIME FORMAT
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DateConstants.YYYY_MM_DD_HH_MM_SS.get());
		String mysqlFormattedDate = simpleDateFormat.format(date);
		programBulkUploadBean.setProgramEndDateTime(mysqlFormattedDate);
	}

	/**
	 * transformProgramCumulativeCount(...) is responsible for trimming the leading
	 * and trailing whitespace characters from the cumulative count.
	 * 
	 * @param programBulkUploadBean
	 * @return void
	 */
	@Override
	public void transformProgramCumulativeCount(ProgramBulkUploadBean programBulkUploadBean) {
		String cumulativeCount = programBulkUploadBean.getProgramCumulativeCount();
		cumulativeCount = cumulativeCount.trim();
		programBulkUploadBean.setProgramCumulativeCount(cumulativeCount);
	}

	/**
	 * transformProgramCumulativeCountMode(...) is responsible for making the
	 * cumulativeCountMode as lower-case and then trimming the leading and traling
	 * whitespace characters.
	 * 
	 * @param programBulkUploadBean
	 * @return void
	 */
	@Override
	public void transformProgramCumulativeCountMode(ProgramBulkUploadBean programBulkUploadBean) {
		String cumulativeCountMode = programBulkUploadBean.getProgramCumulativeCountMode();
		cumulativeCountMode = cumulativeCountMode.toLowerCase().trim();
		programBulkUploadBean.setProgramCumulativeCountMode(cumulativeCountMode);
	}


}
