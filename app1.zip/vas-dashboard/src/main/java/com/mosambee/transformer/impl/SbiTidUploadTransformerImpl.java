package com.mosambee.transformer.impl;

import org.springframework.stereotype.Component;

import com.mosambee.bean.SBITidUploadBean;
import com.mosambee.transformer.SbiTidUploadTransformer;
/**
 * This class is used for trimming spaces coming from SBI TID upload
 * fields
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 */
@Component("sbiTidUploadTransformer")
public class SbiTidUploadTransformerImpl implements SbiTidUploadTransformer{

	@Override
	public void transformMposMid(SBITidUploadBean sBITidUploadBean) {
		String mid = sBITidUploadBean.getMPosMid();
		mid = mid.trim();
		sBITidUploadBean.setMPosMid(mid);
		
	}

	@Override
	public void transformMposTid(SBITidUploadBean sBITidUploadBean) {
		String tid = sBITidUploadBean.getMPosTid();
		tid = tid.trim();
		sBITidUploadBean.setMPosTid(tid);
		
	}

	@Override
	public void transformSkuName(SBITidUploadBean sBITidUploadBean) {
		String skuname = sBITidUploadBean.getSkuName();
		skuname = skuname.trim();
		sBITidUploadBean.setSkuName(skuname);
		
	}

	@Override
	public void transformStoreName(SBITidUploadBean sBITidUploadBean) {

		String storename = sBITidUploadBean.getStoreName();
		storename = storename.trim();
		sBITidUploadBean.setStoreName(storename);
		
	}

	@Override
	public void transformStoreCity(SBITidUploadBean sBITidUploadBean) {
		String storecity = sBITidUploadBean.getStoreCity();
		storecity = storecity.trim();
		sBITidUploadBean.setStoreCity(storecity);
		
	}

}
