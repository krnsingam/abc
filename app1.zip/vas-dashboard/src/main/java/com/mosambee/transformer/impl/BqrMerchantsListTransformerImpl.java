package com.mosambee.transformer.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.mosambee.bean.BqrListDatatablesRequestBean;
import com.mosambee.constants.ColumnNames;
import com.mosambee.transformer.BqrMerchantListTransformer;

/**
 * this class is using for transform values coming from datatables request from
 * search fields in bqrMerchantList
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
@Component("bqrMerchantListTransformer")
public class BqrMerchantsListTransformerImpl implements BqrMerchantListTransformer {

	@Override
	public Map<String, String> transformBqrMerchantsListDataTablesRequest(BqrListDatatablesRequestBean dtRequest) {
		Map<String, String> searchMap = new HashMap<>();
		searchMap.put(ColumnNames.ACQUIRER_NAME.get(), transformAcquirer(dtRequest));
		searchMap.put(ColumnNames.MDAT_MERCHANTCODE.get(), transformMerchantCode(dtRequest));
		searchMap.put(ColumnNames.MMUT_TERMINALID.get(), transformTerminalId(dtRequest));
		return searchMap;
	}

	/**
	 * This method is responsible for trimming space of acquirer coming in searcha
	 * field
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformAcquirer(BqrListDatatablesRequestBean dtRequest) {
		String acquirer = dtRequest.getAcquirer();
		return acquirer.trim();
	}

	/**
	 * This method is responsible for trimming space coming from merchantCode search
	 * field
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformMerchantCode(BqrListDatatablesRequestBean dtRequest) {
		String merchantCode = dtRequest.getMerchantId();
		return merchantCode.trim();
	}

	/**
	 * This method is responsible for trimming space coming from search filed
	 * terminalId
	 * 
	 * @param dtRequest
	 * @return
	 */
	private String transformTerminalId(BqrListDatatablesRequestBean dtRequest) {
		String terminalId = dtRequest.getTerminalId();
		return terminalId.trim();
	}
}
