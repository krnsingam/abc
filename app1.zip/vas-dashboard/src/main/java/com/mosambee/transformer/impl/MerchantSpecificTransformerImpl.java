package com.mosambee.transformer.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.mosambee.bean.MerchantKeyDataBean;
import com.mosambee.bean.MerchantMappingDataBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.constants.ColumnNames;
import com.mosambee.transformer.MerchantSpecificTransformer;

/**
 * MerchantSpecificTransformerImpl is responsible for transforming the MerchantMappingBean
 * fields ... Mainly implemented for transforming the search inputs coming via
 * data-tables.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 03-March-2020
 */
@Component("merchantSpecificTransformer")
public class MerchantSpecificTransformerImpl implements MerchantSpecificTransformer{

	/**
	 * transformMerchantMappingView(...) is responsible for transforming incoming
	 * {@link DataTablesRequest} ... We are mainly trimming values here.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return Map<String, String>
	 */
	@Override
	public Map<String, String> transformMerchantMappingView(MerchantMappingDataBean dtRequest) {
		Map<String, String> searchMap = new HashMap<>();

		searchMap.put(ColumnNames.MERCHANT_NAME.get(), transformMerchantName(dtRequest));
		searchMap.put(ColumnNames.MERCHANT_CLASSPATH.get(), transformMerchantClassPath(dtRequest));
		searchMap.put(ColumnNames.MERCHANT_URL.get(), transformMerchantUrl(dtRequest));
		
		return searchMap;
	}
	
	/**
	 * transformMerchantName(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformMerchantName(MerchantMappingDataBean dtRequest) {
		String transformMerchantName = dtRequest.getMerchantName();
		return transformMerchantName.trim();
	}
	
	/**
	 * transformMerchantClassPath(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformMerchantClassPath(MerchantMappingDataBean dtRequest) {
		String transformMerchantClassPath = dtRequest.getClassPath();
		return transformMerchantClassPath.trim();
	}
	
	/**
	 * transformMerchantUrl(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformMerchantUrl(MerchantMappingDataBean dtRequest) {
		String transformMerchantUrl = dtRequest.getUrl();
		return transformMerchantUrl.trim();
	}
	
	/**
	 * transformMerchantKey(...) is responsible for transforming incoming
	 * {@link DataTablesRequest} ... We are mainly trimming values here.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return Map<String, String>
	 */
	@Override
	public Map<String, String> transformMerchantKey(MerchantKeyDataBean dtRequest) {
		Map<String, String> searchMap = new HashMap<>();

		searchMap.put(ColumnNames.MERCHANT.get(), transformMerchant(dtRequest));
		searchMap.put(ColumnNames.MERCHANT_CODE.get(), transformMerchantCode(dtRequest));
		searchMap.put(ColumnNames.MERCHANT_KEY.get(), transformMerchantKeyData(dtRequest));
		
		return searchMap;
	}
	
	/**
	 * transformMerchant(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformMerchant(MerchantKeyDataBean dtRequest) {
		String transformMerchantName = dtRequest.getMerchant();
		return transformMerchantName.trim();
	}
	
	/**
	 * transformMerchantCode(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformMerchantCode(MerchantKeyDataBean dtRequest) {
		String transformMerchantClassPath = dtRequest.getMerchantCode();
		return transformMerchantClassPath.trim();
	}
	
	/**
	 * transformMerchantKeyData(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformMerchantKeyData(MerchantKeyDataBean dtRequest) {
		String transformMerchantUrl = dtRequest.getMerchantKey();
		return transformMerchantUrl.trim();
	}
	
}
