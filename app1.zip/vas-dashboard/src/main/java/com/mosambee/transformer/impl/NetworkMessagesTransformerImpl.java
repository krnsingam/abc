package com.mosambee.transformer.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.mosambee.bean.NetworkMessagesDataTablesRequestBean;
import com.mosambee.transformer.NetworkMessagesTransformer;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component("networkMessagesTransformer")
public class NetworkMessagesTransformerImpl implements NetworkMessagesTransformer{
	
	@Override
	public Map<String, String> transformNetworkMessagesRequest(NetworkMessagesDataTablesRequestBean dtRequest) {
	Map<String, String> map = new HashMap<>();

	map.put("networkMessagesFromDate", transformNetworkMessagesFromDate(dtRequest));
	map.put("networkMessagesToDate", transformNetworkMessagesToDate(dtRequest));
	map.put("networkMessagesUserId", transformNetworkMessagesUserId(dtRequest));
	return map;
	}
	
	/**
	 * transformNetworkMessagesFromDate(...) is responsible for trimming the fromdate
	 * field in networkMessages Tab.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformNetworkMessagesFromDate(NetworkMessagesDataTablesRequestBean dtRequest) {
		log.info("networkMessagesFromDate {}",dtRequest.getFromDate());
		String networkMessagesFromDate = dtRequest.getFromDate();
		return networkMessagesFromDate.trim();
	}
	
	/**
	 * transformNetworkMessagesToDate(...) is responsible for trimming the todate
	 * field in networkMessages Tab.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformNetworkMessagesToDate(NetworkMessagesDataTablesRequestBean dtRequest) {
		log.info("networkMessagesToDate {}",dtRequest.getToDate());
		String networkMessagesToDate = dtRequest.getToDate();
		return networkMessagesToDate.trim();
	}

	/**
	 * transformNetworkMessagesUserId(...) is responsible for trimming the userId
	 * field in networkMessages Tab.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformNetworkMessagesUserId(NetworkMessagesDataTablesRequestBean dtRequest) {
		log.info("networkMessagesUserId {}",dtRequest.getUserId());
		String networkMessagesUserId = dtRequest.getUserId();
		return networkMessagesUserId.trim();
	}
}
