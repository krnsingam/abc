package com.mosambee.transformer.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.mosambee.bean.SBIEMISearchDataTableBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.constants.ColumnNames;
import com.mosambee.transformer.SBIEMITransformer;

/**
 * SBIEMITransformerImpl is responsible for transforming the SBIEMISearchDataTableBean
 * fields ... Mainly implemented for transforming the search inputs coming via
 * data-tables.
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 * @since 30-March-2020
 */
@Component("sBIEMITransformer")
public class SBIEMITransformerImpl implements SBIEMITransformer{

	/**
	 * transformSBIDetails(...) is responsible for transforming incoming
	 * {@link DataTablesRequest} ... We are mainly trimming values here.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return Map<String, String>
	 */
	@Override
	public Map<String, String> transformSBIDetails(SBIEMISearchDataTableBean dtRequest) {
		Map<String, String> searchMap = new HashMap<>();

		searchMap.put(ColumnNames.MPOS_MID.get(), transformMposMid(dtRequest));
		searchMap.put(ColumnNames.MPOS_TID.get(), transformMposTid(dtRequest));
		searchMap.put(ColumnNames.TYPE.get(), transformType(dtRequest));
		
		return searchMap;
	}

	/**
	 * transformType(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformType(SBIEMISearchDataTableBean dtRequest) {
		String type = dtRequest.getType();
		return type.trim();
	}

	/**
	 * transformMposTid(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformMposTid(SBIEMISearchDataTableBean dtRequest) {
		String terminalId = dtRequest.getTerminalId();
		return terminalId.trim();
	}

	/**
	 * transformMposMid(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformMposMid(SBIEMISearchDataTableBean dtRequest) {
		String merchantId = dtRequest.getMerchantId();
		return merchantId.trim();
	}

}
