package com.mosambee.transformer;

import java.util.Map;

import com.mosambee.bean.AcquirerBulkDataBean;

/**
 * AcquirerBulkUploadTransformer is basically used to transform bean field
 * values.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 27-February-2020
 */
public interface AcquirerBulkUploadTransformer {

	public Map<String, String> transformListOfAcquirer(AcquirerBulkDataBean dtRequest);
}
