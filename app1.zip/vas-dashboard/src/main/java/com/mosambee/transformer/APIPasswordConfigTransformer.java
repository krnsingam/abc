package com.mosambee.transformer;

import java.util.Map;
import com.mosambee.bean.CreateAPIGroup;
import com.mosambee.bean.datatables.DataTablesRequest;

/**
 * This interface use to declare methods which we want to use in
 * {@link APIPasswordConfigTransformerImpl} Here we declare(s) methods which we
 * are using as a business logic.
 * 
 * @author mandar.chaudhari
 * @version 1.0
 */
public interface APIPasswordConfigTransformer {
	public Map<String, String> transformListOfAPIGroup(DataTablesRequest dtRequest);

	public void transformMPOSAPIPasswordForDataInserting(CreateAPIGroup createAPIGroup);

	public void transformMPOSAPIPasswordForDataUpdating(CreateAPIGroup createAPIGroup);

	public Map<String, String> transformMidTid(DataTablesRequest dtRequest);
}
