package com.mosambee.transformer;

import com.mosambee.bean.SBITidUploadBean;

/**
 * This class provides specification for * {@link SbiTidUploadTransformerImpl}}
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 *
 */
public interface SbiTidUploadTransformer {

	void transformMposMid(SBITidUploadBean sBITidUploadBean);

	void transformMposTid(SBITidUploadBean sBITidUploadBean);

	void transformSkuName(SBITidUploadBean sBITidUploadBean);

	void transformStoreName(SBITidUploadBean sBITidUploadBean);

	void transformStoreCity(SBITidUploadBean sBITidUploadBean); 
   
}
