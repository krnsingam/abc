package com.mosambee.transformer;

import java.util.Map;
import com.mosambee.bean.EnquiryDataTablesRequestBean;

/**
 * EnquiryReportingTransformer provides specification for
 * {@link EnquiryReportingTransformerImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 */
public interface EnquiryReportingTransformer {
	Map<String, String> transformEnquiryListDataTablesRequest(EnquiryDataTablesRequestBean dtRequest);

}
