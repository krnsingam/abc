package com.mosambee.transformer.impl;

import org.springframework.stereotype.Component;

import com.mosambee.bean.InstantMidUploadBean;
import com.mosambee.transformer.InstantMidUploadTransformer;

/**
 * This class is basically used to transform values of InstantMidUploadBean
 * field values
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Component("instantMidUploadTransformer")
public class InstantMidUploadTransformerImpl implements InstantMidUploadTransformer {

	/**
	 * transformPosId(...) is responsible for trimming the space coming from posId
	 * 
	 * @param instantMidUploadBean
	 * @return void
	 */
	@Override
	public void transformPosId(InstantMidUploadBean instantMidUploadBean) {
		String posId = instantMidUploadBean.getPosId();
		posId = posId.trim();
		instantMidUploadBean.setPosId(posId);
	}

	/**
	 * transformTempMid(...) is responsible for trimming the space coming from
	 * tempMid
	 * 
	 * @param instantMidUploadBean
	 * @return void
	 */
	@Override
	public void transformTempMid(InstantMidUploadBean instantMidUploadBean) {
		String tempMid = instantMidUploadBean.getTempMerchantCode();
		tempMid = tempMid.trim();
		instantMidUploadBean.setTempMerchantCode(tempMid);
	}

	/**
	 * transformTempTid()is responsible for trimming the space coming from tempTid
	 * 
	 * @param instantMidUploadBean
	 * @return void
	 */
	@Override
	public void transformTempTid(InstantMidUploadBean instantMidUploadBean) {
		String tempTid = instantMidUploadBean.getTempTid();
		tempTid = tempTid.trim();
		instantMidUploadBean.setTempTid(tempTid);
	}

	/**
	 * transformTid()is responsible for trimming the space coming from tid
	 * 
	 * @param instantMidUploadBean
	 * @return void
	 */
	@Override
	public void transformTid(InstantMidUploadBean instantMidUploadBean) {
		String tid = instantMidUploadBean.getTid();
		tid = tid.trim();
		instantMidUploadBean.setTid(tid);
	}

	/**
	 * transformMid()is responsible for trimming the space coming from mid
	 * 
	 * @param instantMidUploadBean
	 * @return void
	 */
	@Override
	public void transformMid(InstantMidUploadBean instantMidUploadBean) {
		String mid = instantMidUploadBean.getMid();
		mid = mid.trim();
		instantMidUploadBean.setMid(mid);
	}

}
