package com.mosambee.transformer.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.mosambee.bean.EnterpriseDataBean;
import com.mosambee.bean.TransactionDateReportBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.constants.ColumnNames;
import com.mosambee.transformer.EnterpriseTransformer;

/**
 * EnterpriseTransformerImpl is responsible for transforming the EnterpriseBean
 * fields ... Mainly implemented for transforming the search inputs coming via
 * data-tables.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 01-April-2020
 */
@Component("enterpriseTransformer")
public class EnterpriseTransformerImpl implements EnterpriseTransformer{

	/**
	 * transformEnterprise(...) is responsible for transforming incoming
	 * {@link DataTablesRequest} ... We are mainly trimming values here.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return Map<String, String>
	 */
	@Override
	public Map<String, String> transformEnterprise(EnterpriseDataBean dtRequest) {
		Map<String, String> searchMap = new HashMap<>();

		searchMap.put(ColumnNames.ENTERPRISE_FROM_DATE.get(), transformEnterpriseFromDate(dtRequest));
		searchMap.put(ColumnNames.ENTERPRISE_TO_DATE.get(), transformEnterpriseToDate(dtRequest));
		
		return searchMap;
	}
	
	/**
	 * transformEnterpriseFromDate(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformEnterpriseFromDate(EnterpriseDataBean dtRequest) {
		String transactionFromDate = dtRequest.getFromDate();
		return transactionFromDate.trim();
	}
	
	/**
	 * transformEnterpriseToDate(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformEnterpriseToDate(EnterpriseDataBean dtRequest) {
		String transactionToDate = dtRequest.getToDate();
		return transactionToDate.trim();
	}
	
	
}
