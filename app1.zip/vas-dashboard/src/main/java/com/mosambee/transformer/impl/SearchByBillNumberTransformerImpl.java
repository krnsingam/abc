package com.mosambee.transformer.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.mosambee.bean.BillNumberDataTablesRequestBean;
import com.mosambee.transformer.SearchByBillNumberTransformer;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class SearchByBillNumberTransformerImpl implements SearchByBillNumberTransformer{

	@Override
	public Map<String, String> transformBillNumberDataTableRequest(BillNumberDataTablesRequestBean dtRequest) {
		Map<String, String> searchMap = new HashMap<>();

		searchMap.put("billNumber", transformBillNumber(dtRequest));
		return searchMap;
	}

	/**
	 * transformTransactionReportFromDate(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformBillNumber(BillNumberDataTablesRequestBean dtRequest) {
		log.info("billNumber {}",dtRequest.getBillNumber());
		String billNumber = dtRequest.getBillNumber();
		return billNumber.trim();
	}
	
	
	

}
