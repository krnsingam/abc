package com.mosambee.transformer;

import java.util.Map;

import com.mosambee.bean.NetworkMessagesDataTablesRequestBean;

public interface NetworkMessagesTransformer {

	public Map<String, String> transformNetworkMessagesRequest(NetworkMessagesDataTablesRequestBean dtRequest);

}
