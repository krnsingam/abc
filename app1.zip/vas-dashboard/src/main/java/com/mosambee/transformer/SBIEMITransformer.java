package com.mosambee.transformer;

import java.util.Map;

import com.mosambee.bean.SBIEMISearchDataTableBean;

/**
 * SBIEMITransformer is basically used to transform bean field
 * values.
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 * @since 30th-March-2020
 */
public interface SBIEMITransformer {

	Map<String, String> transformSBIDetails(SBIEMISearchDataTableBean dtRequest);

} 
