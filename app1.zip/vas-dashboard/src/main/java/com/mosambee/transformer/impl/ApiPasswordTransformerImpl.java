package com.mosambee.transformer.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.mosambee.bean.ApiPasswordDataBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.constants.ColumnNames;
import com.mosambee.transformer.ApiPasswordTransformer;

/**
 * ApiPasswordTransformerImpl is responsible for transforming the ApiPasswordDataBean
 * fields ... Mainly implemented for transforming the search inputs coming via
 * data-tables.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 16-March-2020
 */
@Component("apiPasswordTransformer")
public class ApiPasswordTransformerImpl implements ApiPasswordTransformer{

	/**
	 * transformTransactionReportDataTableRequest(...) is responsible for transforming incoming
	 * {@link DataTablesRequest} ... We are mainly trimming values here.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return Map<String, String>
	 */
	@Override
	public Map<String, String> transformApiPasswordDataTableRequest(ApiPasswordDataBean dtRequest) {
		Map<String, String> searchMap = new HashMap<>();

		searchMap.put(ColumnNames.API_PASSWORD.get(), transformApiPassword(dtRequest));
		searchMap.put(ColumnNames.API_PASSWORD_BUSINESS_NAME.get(), transformBusinessName(dtRequest));
		searchMap.put(ColumnNames.API_PASSWORD_MERCHANT_CODE.get(), transformMerchantCode(dtRequest));
		
		return searchMap;
	}
	
	/**
	 * transformApiPassword(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformApiPassword(ApiPasswordDataBean dtRequest) {
		String transactionApiPassword = dtRequest.getApiPassword();
		return transactionApiPassword.trim();
	}
	
	/**
	 * transformBusinessName(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformBusinessName(ApiPasswordDataBean dtRequest) {
		String transactionApiPassword = dtRequest.getBusinessName();
		return transactionApiPassword.trim();
	}
	
	/**
	 * transformMerchantCode(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformMerchantCode(ApiPasswordDataBean dtRequest) {
		String transactionApiPassword = dtRequest.getMerchantCode();
		return transactionApiPassword.trim();
	}
}
