package com.mosambee.transformer;

import java.util.Map;

import com.mosambee.bean.TransactionDateReportBean;
import com.mosambee.bean.TransactionSearchFormDataTableBean;

/**
 * TransactionReportTransformer is basically used to transform bean field
 * values.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 10-January-2020
 */
public interface TransactionReportTransformer {

	public Map<String, String> transformTransactionReportDataTableRequest(TransactionDateReportBean dtRequest);
	
	public Map<String, String> transformTransactionListDataTableRequest(TransactionSearchFormDataTableBean dtRequest);
}
