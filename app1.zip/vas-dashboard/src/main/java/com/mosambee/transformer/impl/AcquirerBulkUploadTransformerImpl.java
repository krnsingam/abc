package com.mosambee.transformer.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.mosambee.bean.AcquirerBulkDataBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.constants.ColumnNames;
import com.mosambee.transformer.AcquirerBulkUploadTransformer;

/**
 * AcquirerBulkUploadTransformerImpl is responsible for transforming the AcquirerBulkDataBean
 * fields ... Mainly implemented for transforming the search inputs coming via
 * data-tables.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 10-February-2020
 */
@Component("acquirerBulkUploadTransformer")
public class AcquirerBulkUploadTransformerImpl implements AcquirerBulkUploadTransformer{

	/**
	 * transformListOfAcquirer(...) is responsible for transforming incoming
	 * {@link DataTablesRequest} ... We are mainly trimming values here.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * @return Map<String, String>
	 */
	@Override
	public Map<String, String> transformListOfAcquirer(AcquirerBulkDataBean dtRequest) {
		Map<String, String> searchMap = new HashMap<>();

		searchMap.put(ColumnNames.ACQIRER.get(), transformAcquirerBulkName(dtRequest));
		searchMap.put(ColumnNames.ACQ_MAT_CODE.get(), transformAcquirerBulkMatCode(dtRequest));
		
		return searchMap;
	}
	
	/**
	 * transformAcquirerBulkName(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformAcquirerBulkName(AcquirerBulkDataBean dtRequest) {
		String transactionFromDate = dtRequest.getAcquirer();
		return transactionFromDate.trim();
	}
	
	/**
	 * transformAcquirerBulkMatCode(...) is responsible for trimming the description
	 * field.
	 * 
	 * @param dtRequest
	 * @return String
	 */
	private String transformAcquirerBulkMatCode(AcquirerBulkDataBean dtRequest) {
		String transactionToDate = dtRequest.getMatcode();
		return transactionToDate.trim();
	}
	

	
}
