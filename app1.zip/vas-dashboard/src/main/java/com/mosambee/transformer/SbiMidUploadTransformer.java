package com.mosambee.transformer;

import com.mosambee.bean.SBIMidUploadBean;

/**
 * This class provides specification for * {@link SbiMidUploadTransformerImpl}}
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 *
 */
public interface SbiMidUploadTransformer {

	void transformMposMid(SBIMidUploadBean sBIMidUploadBean);

	void transformMerchantName(SBIMidUploadBean sBIMidUploadBean);

	void transformMerchantCity(SBIMidUploadBean sBIMidUploadBean); 
 
} 
