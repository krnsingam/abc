package com.mosambee.validator;

import com.mosambee.bean.KeyBulkUploadBean;
import com.mosambee.bean.MappingBulkUpload;
import com.mosambee.bean.MerchantKeyBean;
import com.mosambee.bean.MerchantMappingBean;

/**
 * MerchantSpecificValidator provides specification for {@link MerchantSpecificValidatorImpl}
 * 
 * @author karan.singam
 * @version 1.0
 * @since 27-February-2020
 */
public interface MerchantSpecificValidator {

	public void validateMerchantMapping(MerchantMappingBean merchantMapping);
	
	public void validateMerchantKey(MerchantKeyBean merchantkey);
	
	public void validateBulkUpload(MappingBulkUpload bulkUpload);
	
	public void validateKeyBulkUpload(KeyBulkUploadBean bulkUpload);
	
}
