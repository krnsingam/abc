package com.mosambee.validator.impl;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mosambee.bean.SBIMidUploadBean;
import com.mosambee.bean.SBITidBean;
import com.mosambee.bean.SBITidUploadBean;
import com.mosambee.constants.BulkUploadMessages;
import com.mosambee.constants.RegexPatterns;
import com.mosambee.transformer.SbiMidUploadTransformer;
import com.mosambee.transformer.SbiTidUploadTransformer;
import com.mosambee.validator.SbiTidUploadValidator;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component("sbiTidUploadValidator")
public class SbiTidUploadValidatorImpl implements SbiTidUploadValidator{

	@Autowired
	private SbiTidUploadTransformer sbiTidUploadTransformer;

	
	/**
	 * validateSBITidBean() is responsible for validating SBITidBean
	 * fields for SBI TID upload
	 *
	 */
	@Override
	public SBITidUploadBean validateSBITidBean(SBITidBean sBITidBean) {
		SBITidUploadBean sBITidUploadBean = new SBITidUploadBean();

		BeanUtils.copyProperties(sBITidBean, sBITidUploadBean);
		sBITidUploadBean.setStatus("");
		
		validateMposMid(sBITidUploadBean);
		validateMposTid(sBITidUploadBean);
		validateSkuName(sBITidUploadBean);
		validateStoreName(sBITidUploadBean);
		validateStoreCity(sBITidUploadBean);
		
		log.info("bean after validation completion: {}", sBITidUploadBean);
		return sBITidUploadBean;
	}

	/**
	 * validateStoreCity() is validating Store City coming in SBI MID upload.First
	 * it validates Store city against {@RegexPattern CHARACTERS_ONLY} and then it
	 * validates min and max length. Minimum length should be 1 and maximum length should be
	 * 45.
	 * 
	 * @param sBITidUploadBean
	 */
	private void validateStoreCity(SBITidUploadBean sBITidUploadBean) {
		sbiTidUploadTransformer.transformStoreCity(sBITidUploadBean);

		// VALIDATE THE CHARACTERS_ONLY PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.CHARACTERS_ONLY.get());
		Matcher matcher = pattern.matcher(sBITidUploadBean.getStoreCity());
		int Length = sBITidUploadBean.getStoreCity().length();
		if (!matcher.matches() || Length < 1 || Length > 45) {
			log.info("Store City regex failed in validateStoreCity(): {}, for value: {}",
					BulkUploadMessages.STORE_CITY_REGEX_ERROR.get(), sBITidUploadBean.getStoreCity());
			sBITidUploadBean.appendStatus(BulkUploadMessages.STORE_CITY_REGEX_ERROR.get());
		}
		
	}

	/**
	 * validateStoreName() is validating SKU Name coming in SBI TID upload.First
	 * it validates Store Name against {@RegexPattern ALPHA_NUMERIC_WITH_SPACE} and then it
	 * validates min and max length. Minimum length should be 1 and maximum length should be
	 * 45.
	 * 
	 * @param sBITidUploadBean
	 */
	private void validateStoreName(SBITidUploadBean sBITidUploadBean) {
		sbiTidUploadTransformer.transformStoreName(sBITidUploadBean);

		// VALIDATE THE ALPHA NUMERIC PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(sBITidUploadBean.getStoreName());
		int Length = sBITidUploadBean.getStoreName().length();
		if (!matcher.matches() || Length < 1 || Length > 45) {
			log.info("Store Name regex failed in validateStoreName(): {}, for value: {}",
					BulkUploadMessages.STORE_NAME_REGEX_ERROR.get(), sBITidUploadBean.getStoreName());
			sBITidUploadBean.appendStatus(BulkUploadMessages.STORE_NAME_REGEX_ERROR.get());
		}
		
	}

	/**
	 * validateSkuName() is validating SKU Name coming in SBI TID upload.First
	 * it validates SKU Name against {@RegexPattern ALPHA_NUMERIC_WITH_SPACE} and then it
	 * validates min and max length. Minimum length should be 1 and maximum length should be
	 * 45.
	 * 
	 * @param sBITidUploadBean
	 */
	private void validateSkuName(SBITidUploadBean sBITidUploadBean) {
		sbiTidUploadTransformer.transformSkuName(sBITidUploadBean);

		// VALIDATE THE ALPHA NUMERIC PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(sBITidUploadBean.getSkuName());
		int Length = sBITidUploadBean.getSkuName().length();
		if (!matcher.matches() || Length < 1 || Length > 45) {
			log.info("Sku Name regex failed in validateSkuName(): {}, for value: {}",
					BulkUploadMessages.SKU_NAME_REGEX_ERROR.get(), sBITidUploadBean.getSkuName());
			sBITidUploadBean.appendStatus(BulkUploadMessages.SKU_NAME_REGEX_ERROR.get());
		}
		
	}

	/**
	 * validateMposTid() is validating TID coming in SBI TID upload.First
	 * it validates Tid against {@RegexPattern ALPHA_NUMERIC_WITHOUT_SPACE} and then it
	 * validates min and max length. Minimum length should be 1 and maximum length should be
	 * 45.
	 * 
	 * @param sBITidUploadBean
	 */
	private void validateMposTid(SBITidUploadBean sBITidUploadBean) {
		sbiTidUploadTransformer.transformMposTid(sBITidUploadBean);

		// VALIDATE THE ALPHA NUMERIC PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITHOUT_SPACE.get());
		Matcher matcher = pattern.matcher(sBITidUploadBean.getMPosTid());
		int Length = sBITidUploadBean.getMPosTid().length();
		if (!matcher.matches() || Length < 1 || Length > 45) {
			log.info("MposTid regex failed in validateMposTid(): {}, for value: {}",
					BulkUploadMessages.MPOS_TID_REGEX_ERROR.get(), sBITidUploadBean.getMPosTid());
			sBITidUploadBean.appendStatus(BulkUploadMessages.MPOS_TID_REGEX_ERROR.get());
		}
		
	}

	/**
	 * validateMposMid() is validating MID coming in SBI TID upload.First
	 * it validates Mid against {@RegexPattern ALPHA_NUMERIC_WITHOUT_SPACE} and then it
	 * validates min and max length. Minimum length should be 1 and maximum length should be
	 * 45.
	 * 
	 * @param sBITidUploadBean
	 */
	private void validateMposMid(SBITidUploadBean sBITidUploadBean) {
		
		sbiTidUploadTransformer.transformMposMid(sBITidUploadBean);

		// VALIDATE THE ALPHA NUMERIC PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITHOUT_SPACE.get());
		Matcher matcher = pattern.matcher(sBITidUploadBean.getMPosMid());
		int Length = sBITidUploadBean.getMPosMid().length();
		if (!matcher.matches() || Length < 1 || Length > 45) {
			log.info("MposMid regex failed in validateMposMid(): {}, for value: {}",
					BulkUploadMessages.MPOS_MID_REGEX_ERROR.get(), sBITidUploadBean.getMPosMid());
			sBITidUploadBean.appendStatus(BulkUploadMessages.MPOS_MID_REGEX_ERROR.get());
		}
		
	}

}
