package com.mosambee.validator;

import com.mosambee.bean.ProgramBean;
import com.mosambee.bean.ProgramBulkUploadBean;
import com.mosambee.validator.impl.ProgramBulkUploadValidatorImpl;

/**
 * ProgramBulkUploadValidator provides specification for {@link ProgramBulkUploadValidatorImpl}
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 28-December-2019
 */
public interface ProgramBulkUploadValidator {
	
	ProgramBulkUploadBean validateProgramBean(ProgramBean programBean);

}
