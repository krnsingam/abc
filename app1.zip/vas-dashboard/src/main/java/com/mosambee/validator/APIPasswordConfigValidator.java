package com.mosambee.validator;

import com.mosambee.bean.CreateAPIGroup;
import com.mosambee.bean.MIDBulkUpload;


public interface APIPasswordConfigValidator {
	public void validateCreateAPIGroupData(CreateAPIGroup createAPIGroup);
	public void validateMIDBulkUpload(MIDBulkUpload midBulkUpload);
}
