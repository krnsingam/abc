package com.mosambee.validator.impl;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

import com.mosambee.bean.AddBqrMerchantsBean;
import com.mosambee.constants.BulkUploadMessages;
import com.mosambee.constants.RegexPatterns;
import com.mosambee.validator.AddBqrMerchantsValidator;

import lombok.extern.log4j.Log4j2;

/**
 * This class is responsible for validating field of AddBqrMerchantsBean coming
 * in addBqr Merchant and update bqr Merchant
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
@Log4j2
@Component("addBqrMerchantsValidator")
public class AddBqrMerchantsValidatorImpl implements AddBqrMerchantsValidator {

	@Override
	public void validateAddBqrMerchantsBean(AddBqrMerchantsBean addBqrMerchantsBean) {
		validateMerchantId(addBqrMerchantsBean);
		validateTerminalId(addBqrMerchantsBean);
		validateVisaNetworkId1(addBqrMerchantsBean);
		validateVisaNetworkId2(addBqrMerchantsBean);
		validateMasterCardNetworkId1(addBqrMerchantsBean);
		validateMasterCardNetworkId2(addBqrMerchantsBean);
		validateNpciNetworkId1(addBqrMerchantsBean);
		validateNpciNetworkId2(addBqrMerchantsBean);
		validateReferenceTag09(addBqrMerchantsBean);
		validateReferenceTag10(addBqrMerchantsBean);
		validateIfscAccountNo(addBqrMerchantsBean);
		validateAmexNetworkId1(addBqrMerchantsBean);
		validateAmexNetworkId2(addBqrMerchantsBean);
		validateMerchantCategoriesCode(addBqrMerchantsBean);
		validateCurrecyCode(addBqrMerchantsBean);
		validateCountryCode(addBqrMerchantsBean);
		validateQrmerchantName(addBqrMerchantsBean);
		validateMerchantCity(addBqrMerchantsBean);
		validatePostalCode(addBqrMerchantsBean);
		validateStatus(addBqrMerchantsBean);
		validateSmsFlag(addBqrMerchantsBean);
		validateTipIndicator(addBqrMerchantsBean);
		validataeAcquirerName(addBqrMerchantsBean);

	}

	/**
	 * validateMerchantId() is responsible for trimming space and validating
	 * merchantId length.And Validating field
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE }
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateMerchantId(AddBqrMerchantsBean addBqrMerchantsBean) {
		String merchantId = addBqrMerchantsBean.getMerchantId();
		merchantId = merchantId.trim();
		addBqrMerchantsBean.setMerchantId(merchantId);

		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(merchantId);
		int merchantIdLength = merchantId.length();
		if (!matcher.matches() || merchantIdLength < 1 || merchantIdLength > 100) {
			log.info("MerchantId failed in validateMerchantId(): {}, for value: {}",
					BulkUploadMessages.MERCHANTID_ERROR.get(), addBqrMerchantsBean.getMerchantId());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.MERCHANTID_ERROR.get());
		}
	}

	/**
	 * validateTerminalId() is responsible for validating field terminalId against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateTerminalId(AddBqrMerchantsBean addBqrMerchantsBean) {
		String terminalId = addBqrMerchantsBean.getTerminalId();
		terminalId = terminalId.trim();
		addBqrMerchantsBean.setTerminalId(terminalId);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(terminalId);
		int terminalIdLength = terminalId.length();
		if (!matcher.matches() || terminalIdLength < 8 || terminalIdLength > 30) {
			log.info("TerminalId failed in validateTerminalId(): {}, for value: {}",
					BulkUploadMessages.TERMINALID_ERROR.get(), addBqrMerchantsBean.getTerminalId());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.TERMINALID_ERROR.get());
		}

	}

	/**
	 * This method is responsible for validating visaNetworkId1 against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateVisaNetworkId1(AddBqrMerchantsBean addBqrMerchantsBean) {
		String visaNetworkId1 = addBqrMerchantsBean.getVisaNetworkId1();
		visaNetworkId1 = visaNetworkId1.trim();
		addBqrMerchantsBean.setVisaNetworkId1(visaNetworkId1);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(visaNetworkId1);
		int visaNetworkId1Length = visaNetworkId1.length();
		if (!matcher.matches() || visaNetworkId1Length < 1 || visaNetworkId1Length > 45) {
			log.info("visaNetworkId1 failed in validateVisaNetworkId1(): {}, for value: {}",
					BulkUploadMessages.VISANETWORKID1.get(), addBqrMerchantsBean.getVisaNetworkId1());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.VISANETWORKID1.get());
		}

	}

	/**
	 * This method is responsible for validating visaNetworkId2 against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateVisaNetworkId2(AddBqrMerchantsBean addBqrMerchantsBean) {
		String visaNetworkId2 = addBqrMerchantsBean.getVisaNetworkId2();
		visaNetworkId2 = visaNetworkId2.trim();
		addBqrMerchantsBean.setVisaNetworkId2(visaNetworkId2);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(visaNetworkId2);
		int visaNetworkId1Length = visaNetworkId2.length();

		if (isStringPresent(visaNetworkId2)
				&& (!matcher.matches() || visaNetworkId1Length < 1 || visaNetworkId1Length > 45)) {
			log.info("visaNetworkId1 failed in validateVisaNetworkId1(): {}, for value: {}",
					BulkUploadMessages.VISANETWORKID2.get(), addBqrMerchantsBean.getVisaNetworkId2());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.VISANETWORKID2.get());
		}
	}

	/**
	 * This method is responsible for validating MasterCardNetworkId1 against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateMasterCardNetworkId1(AddBqrMerchantsBean addBqrMerchantsBean) {
		String master = addBqrMerchantsBean.getMasterCardNetworkId1();
		master = master.trim();
		addBqrMerchantsBean.setMasterCardNetworkId1(master);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(master);
		int masterLength = master.length();
		if (!matcher.matches() || masterLength < 1 || masterLength > 45) {
			log.info("MasterCardId1 failed in validateMasterCardNetworkId1(): {}, for value: {}",
					BulkUploadMessages.MASTERCARDID1.get(), addBqrMerchantsBean.getMasterCardNetworkId1());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.MASTERCARDID1.get());
		}
	}

	/**
	 * This method is responsible for validating MasterCardNetworkId2 against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateMasterCardNetworkId2(AddBqrMerchantsBean addBqrMerchantsBean) {
		String master2 = addBqrMerchantsBean.getMasterCardNetworkId2();
		master2 = master2.trim();
		addBqrMerchantsBean.setMasterCardNetworkId2(master2);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(master2);
		int master2Length = master2.length();
		if (isStringPresent(master2) && (!matcher.matches() || master2Length < 1 || master2Length > 45)) {
			log.info("MasterCardId2 failed in validateMasterCardNetworkId2(): {}, for value: {}",
					BulkUploadMessages.MASTERCARDID2.get(), addBqrMerchantsBean.getMasterCardNetworkId2());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.MASTERCARDID2.get());
		}
	}

	/**
	 * This method is responsible for validating NPCINetworkId1 against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateNpciNetworkId1(AddBqrMerchantsBean addBqrMerchantsBean) {
		String npci = addBqrMerchantsBean.getNpciNetworkId1();
		npci = npci.trim();
		addBqrMerchantsBean.setNpciNetworkId1(npci);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(npci);
		int npciLength = npci.length();
		if (!matcher.matches() || npciLength < 1 || npciLength > 45) {
			log.info("NPCI Networkid 1 failed in validateNpciNetworkId1(): {}, for value: {}",
					BulkUploadMessages.NPCIID1_ERROR.get(), addBqrMerchantsBean.getNpciNetworkId1());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.NPCIID1_ERROR.get());
		}
	}

	/**
	 * This method is responsible for validating MasterCardNetworkId2 against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateNpciNetworkId2(AddBqrMerchantsBean addBqrMerchantsBean) {
		String npci2 = addBqrMerchantsBean.getNpciNetworkId2();
		npci2 = npci2.trim();
		addBqrMerchantsBean.setNpciNetworkId2(npci2);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(npci2);
		int npci2Length = npci2.length();
		if (isStringPresent(npci2) && (!matcher.matches() || npci2Length < 1 || npci2Length > 45)) {
			log.info("NPCI Networkid ID 2 failed in validateNpciNetworkId2(): {}, for value: {}",
					BulkUploadMessages.NPCIID2_ERROR.get(), addBqrMerchantsBean.getNpciNetworkId2());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.NPCIID2_ERROR.get());
		}
	}

	/**
	 * This method is responsible for validating ReferenceTag09 against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateReferenceTag09(AddBqrMerchantsBean addBqrMerchantsBean) {
		String reference = addBqrMerchantsBean.getReferenceTag09();
		reference = reference.trim();
		addBqrMerchantsBean.setReferenceTag09(reference);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(reference);
		int referenceLength = reference.length();
		if (isStringPresent(reference) && (!matcher.matches() || referenceLength < 1 || referenceLength > 45)) {
			log.info("Reference Tag09 failed in validateReferenceTag09(): {}, for value: {}",
					BulkUploadMessages.REFERENCETAF09_ERROR.get(), addBqrMerchantsBean.getReferenceTag09());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.REFERENCETAF09_ERROR.get());
		}
	}

	/**
	 * This method is responsible for validating ReferenceTag10 against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateReferenceTag10(AddBqrMerchantsBean addBqrMerchantsBean) {
		String reference1 = addBqrMerchantsBean.getReferenceTag10();
		reference1 = reference1.trim();
		addBqrMerchantsBean.setReferenceTag10(reference1);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(reference1);
		int reference1Length = reference1.length();
		if (isStringPresent(reference1) && (!matcher.matches() || reference1Length < 1 || reference1Length > 45)) {
			log.info("Reference Tag10 failed in validateReferenceTag10(): {}, for value: {}",
					BulkUploadMessages.REFERENCETAF10_ERROR.get(), addBqrMerchantsBean.getReferenceTag10());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.REFERENCETAF10_ERROR.get());
		}
	}

	/**
	 * This method is responsible for validating ifscAccountNo against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateIfscAccountNo(AddBqrMerchantsBean addBqrMerchantsBean) {
		String ifsc = addBqrMerchantsBean.getIfscAccountNo();
		ifsc = ifsc.trim();
		addBqrMerchantsBean.setIfscAccountNo(ifsc);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(ifsc);
		int ifsceLength = ifsc.length();
		if (!matcher.matches() || ifsceLength < 1 || ifsceLength > 45) {
			log.info("IFSC Account No failed in validateIfscAccountNo(): {}, for value: {}",
					BulkUploadMessages.IFSC_ERROR.get(), addBqrMerchantsBean.getIfscAccountNo());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.IFSC_ERROR.get());
		}
	}

	/**
	 * This method is responsible for validating AmexNetworkId1 against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateAmexNetworkId1(AddBqrMerchantsBean addBqrMerchantsBean) {
		String amex = addBqrMerchantsBean.getAmexNetworkId1();
		amex = amex.trim();
		addBqrMerchantsBean.setAmexNetworkId1(amex);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(amex);
		int amexLength = amex.length();
		if (isStringPresent(amex) && (!matcher.matches() || amexLength < 1 || amexLength > 45)) {
			log.info("AMEX Network ID 1 failed in validateAmexNetworkId1(): {}, for value: {}",
					BulkUploadMessages.AMEXNETWORKID1_ERROR.get(), addBqrMerchantsBean.getAmexNetworkId1());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.AMEXNETWORKID1_ERROR.get());
		}

	}

	/**
	 * This method is responsible for validating AmexNetworkId2 against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateAmexNetworkId2(AddBqrMerchantsBean addBqrMerchantsBean) {
		String amex1 = addBqrMerchantsBean.getAmexNetworkId2();
		amex1 = amex1.trim();
		addBqrMerchantsBean.setAmexNetworkId2(amex1);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(amex1);
		int amexLength = amex1.length();
		if (isStringPresent(amex1) && (!matcher.matches() || amexLength < 1 || amexLength > 45)) {
			log.info("AMEX Network ID 2 failed in validateAmexNetworkId1(): {}, for value: {}",
					BulkUploadMessages.AMEXNETWORKID2_ERROR.get(), addBqrMerchantsBean.getAmexNetworkId2());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.AMEXNETWORKID2_ERROR.get());
		}

	}

	/**
	 * This method is responsible for validating merchantCategoriesCode against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateMerchantCategoriesCode(AddBqrMerchantsBean addBqrMerchantsBean) {
		String merchant = addBqrMerchantsBean.getMerchantCategoriesCode();
		merchant = merchant.trim();
		addBqrMerchantsBean.setMerchantCategoriesCode(merchant);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(merchant);
		int merchantLength = merchant.length();
		if (!matcher.matches() || merchantLength < 2 || merchantLength > 4) {
			log.info("Merchant Categories Code failed in validateMerchantCategoriesCode(): {}, for value: {}",
					BulkUploadMessages.MCC_ERROR.get(), addBqrMerchantsBean.getMerchantCategoriesCode());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.MCC_ERROR.get());
		}

	}

	/**
	 * This method is responsible for validating CurrencyCode against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateCurrecyCode(AddBqrMerchantsBean addBqrMerchantsBean) {
		String currency = addBqrMerchantsBean.getCurrencyCode();
		currency = currency.trim();
		addBqrMerchantsBean.setCurrencyCode(currency);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(currency);
		int currencytLength = currency.length();
		if (!matcher.matches() || currencytLength < 1 || currencytLength > 3) {
			log.info("Currency Code  failed in validateCurrecyCode(): {}, for value: {}",
					BulkUploadMessages.CURRENCY_ERROR.get(), addBqrMerchantsBean.getCurrencyCode());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.CURRENCY_ERROR.get());
		}
	}

	/**
	 * This method is responsible for validating CountryCode against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateCountryCode(AddBqrMerchantsBean addBqrMerchantsBean) {
		String country = addBqrMerchantsBean.getCountryCode();
		country = country.trim();
		addBqrMerchantsBean.setCountryCode(country);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(country);
		int countrytLength = country.length();
		if (!matcher.matches() || countrytLength < 1 || countrytLength > 3) {
			log.info("country Code  failed in validateCountryCode(): {}, for value: {}",
					BulkUploadMessages.COUNTRY_ERROR.get(), addBqrMerchantsBean.getCountryCode());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.COUNTRY_ERROR.get());
		}

	}

	/**
	 * This method is responsible for validating qrMerchantName against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateQrmerchantName(AddBqrMerchantsBean addBqrMerchantsBean) {
		String name = addBqrMerchantsBean.getQrMerchantName();
		name = name.trim();
		addBqrMerchantsBean.setQrMerchantName(name);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(name);
		int nameLength = name.length();
		if (!matcher.matches() || nameLength < 2 || nameLength > 23) {
			log.info("QR Merchant Name  failed in validateQrmerchantName(): {}, for value: {}",
					BulkUploadMessages.QRMERCHANT_ERROR.get(), addBqrMerchantsBean.getQrMerchantName());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.QRMERCHANT_ERROR.get());
		}

	}

	/**
	 * This method is responsible for validating MerchantCity against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateMerchantCity(AddBqrMerchantsBean addBqrMerchantsBean) {
		String city = addBqrMerchantsBean.getMerchantCity();
		city = city.trim();
		addBqrMerchantsBean.setMerchantCity(city);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(city);
		int cityLength = city.length();
		if (!matcher.matches() || cityLength < 2 || cityLength > 15) {
			log.info("Merchant City  failed in validateMerchantCity(): {}, for value: {}",
					BulkUploadMessages.MERCHANTCITY_ERROR.get(), addBqrMerchantsBean.getMerchantCity());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.MERCHANTCITY_ERROR.get());
		}
	}

	/**
	 * This method is responsible for validating PostalCode against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and its length
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validatePostalCode(AddBqrMerchantsBean addBqrMerchantsBean) {
		String postalCode = addBqrMerchantsBean.getPostalCode();
		postalCode = postalCode.trim();
		addBqrMerchantsBean.setPostalCode(postalCode);
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(postalCode);
		int postalCodeLength = postalCode.length();
		if (!matcher.matches() || postalCodeLength < 2 || postalCodeLength > 10) {
			log.info("Postal Code failed in validatePostalCode(): {}, for value: {}",
					BulkUploadMessages.POSTALCODE_ERROR.get(), addBqrMerchantsBean.getPostalCode());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.POSTALCODE_ERROR.get());
		}
	}

	/**
	 * This method is responsible for validating Acquirer .This is a required field
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validataeAcquirerName(AddBqrMerchantsBean addBqrMerchantsBean) {
		String acquirer = addBqrMerchantsBean.getAcquirer();
		acquirer = acquirer.trim();
		addBqrMerchantsBean.setAcquirer(acquirer);
		if (!isStringPresent(acquirer)) {
			log.info("Acquirer failed in validataeAcquirerName(): {}, for value: {}",
					BulkUploadMessages.ACQUIRER_ERROR.get(), addBqrMerchantsBean.getAcquirer());
			addBqrMerchantsBean.setMessage(BulkUploadMessages.ACQUIRER_ERROR.get());
		}
	}

	void validateStatus(AddBqrMerchantsBean addBqrMerchantsBean) {
		String status = addBqrMerchantsBean.getStatus();
		if (status.equalsIgnoreCase("Yes")) {
			addBqrMerchantsBean.setStatus("1");
		} else if (status.equalsIgnoreCase("No")) {
			addBqrMerchantsBean.setStatus("0");
		}
	}

	/**
	 * This method is responsisble for setting values according coming from smsFlag
	 * field
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateSmsFlag(AddBqrMerchantsBean addBqrMerchantsBean) {
		String sms = addBqrMerchantsBean.getSmsFlag();
		if (sms.equalsIgnoreCase("None")) {
			addBqrMerchantsBean.setSmsFlag("0");
		} else if (sms.equalsIgnoreCase("Merchant")) {
			addBqrMerchantsBean.setSmsFlag("1");
		} else if (sms.equalsIgnoreCase("Terminal")) {
			addBqrMerchantsBean.setSmsFlag("2");
		}
	}

	/**
	 * This method is responsible for setting values according coming values of
	 * tipIndicator.This is also a requires field
	 * 
	 * @param addBqrMerchantsBean
	 */
	void validateTipIndicator(AddBqrMerchantsBean addBqrMerchantsBean) {
		String tip = addBqrMerchantsBean.getTipIndicator();
		if (tip.equalsIgnoreCase("Yes")) {
			addBqrMerchantsBean.setTipIndicator("1");
		} else if (tip.equalsIgnoreCase("No")) {
			addBqrMerchantsBean.setTipIndicator("0");
		}
	}

	/**
	 * This method is responsible to check string is present or not
	 * 
	 * @param str
	 * @return boolean
	 */
	private boolean isStringPresent(String str) {
		if (str == null) {
			return false;
		} else {
			if (str.equals("")) {
				return false;
			}
		}
		return true;
	}
}
