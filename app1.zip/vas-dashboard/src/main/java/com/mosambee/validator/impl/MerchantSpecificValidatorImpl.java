package com.mosambee.validator.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.mosambee.bean.KeyBulkUploadBean;
import com.mosambee.bean.MIDBulkUpload;
import com.mosambee.bean.MappingBulkUpload;
import com.mosambee.bean.MerchantKeyBean;
import com.mosambee.bean.MerchantMappingBean;
import com.mosambee.constants.APIPasswordConfigConstants;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.RegexPatterns;
import com.mosambee.validator.MerchantSpecificValidator;

@Component("merchantSpecificValidator")
public class MerchantSpecificValidatorImpl implements MerchantSpecificValidator{

	private static final Logger log = LogManager.getLogger(MerchantSpecificValidatorImpl.class);

	/**
	 *  This method is basically used to call validate methods on fields of MerchantMappingBean bean.
	 *  This method is responsible to validate and set validation status for bean MerchantMappingBean bean.
	 *  @param  MerchantMappingBean : The bean which you want to validate.
	 *	@author karan.singam
	 */ 
	@Override
	public void validateMerchantMapping(MerchantMappingBean merchantMapping) {
		merchantMapping.setValidate(true);
		merchantMapping.setValidationMsg(CommonConstants.EMPTY_STRING.get());
		validateURL(merchantMapping);
		validateClassPath(merchantMapping);
		
		 	
		log.info("validation status : {}",merchantMapping.isValidate());
	}
	
	/**This method is use to validate "URL" field of {@link MerchantMappingBean} object
	 * This method checks that whether field is null or not.
	 * Length should be less than or equal to 300.
	 * Field value should be URL.
	 * @param createAPIGroup : Is the object of {@link MerchantMappingBean}
	 */
	void validateURL(MerchantMappingBean merchantMapping)
	{
		String url = merchantMapping.getUrl();
		
		if(isStringPresent(url))
		{
			if(url.length() <= 300)
			{
				if(!url.matches(RegexPatterns.URL.get()))
				{
					merchantMapping.appendStatus(APIPasswordConfigConstants.MERCHANT_URL.get());
					merchantMapping.appendStatus(APIPasswordConfigConstants.SHOULD_BE_URL.get());
					merchantMapping.setValidate(false);
				}
			}
			else
			{
				merchantMapping.appendStatus(APIPasswordConfigConstants.MERCHANT_URL.get());
				merchantMapping.appendStatus(APIPasswordConfigConstants.MERCHANT_URL_MAX_LENGTH.get());
				merchantMapping.setValidate(false);
			}
		}
	}
	
	/**This method is use to validate "classPath" field of {@link MerchantMappingBean} object
	 * This method checks that whether field is null or not.
	 * Length should be less than or equal to 150.
	 * Field value should be Alphanumeric with space without trailing or leading space.
	 * @param merchantMapping : Is the object of {@link MerchantMappingBean}
	 */
	void validateClassPath(MerchantMappingBean merchantMapping)
	{
		String classPath = merchantMapping.getClassPath();
		
		if(isStringPresent(classPath))
		{
			if(classPath.length() >= 150)
			{
				merchantMapping.appendStatus(APIPasswordConfigConstants.MERCHANT_CLASSPATH.get());
				merchantMapping.appendStatus(APIPasswordConfigConstants.MERCHANT_CLASSPATH_MAX_LENGTH.get());
				merchantMapping.setValidate(false);
			}
		}
	}
	
	
	/**
	 *  This method is basically used to call validate methods on fields of MerchantKeyBean bean.
	 *  This method is responsible to validate and set validation status for bean MerchantKeyBean bean.
	 *  @param  MerchantKeyBean : The bean which you want to validate.
	 *	@author karan.singam
	 */ 
	@Override
	public void validateMerchantKey(MerchantKeyBean merchantkey) {
		merchantkey.setValidate(true);
		merchantkey.setValidationMsg(CommonConstants.EMPTY_STRING.get());
		validateMerchantCode(merchantkey);
		validateMerchant(merchantkey);
		 	
		log.info("validation status : {}",merchantkey.isValidate());
	}
	
	/**This method is use to validate "MERCHANT CODE" field of {@link MerchantKeyBean} object
	 * This method checks that whether field is null or not.
	 * Length should be less than or equal to 20.
	 * Field value should be Alphanumeric with space without trailing or leading space.
	 * @param merchantMapping : Is the object of {@link MerchantKeyBean}
	 */
	void validateMerchantCode(MerchantKeyBean merchantkey)
	{
		String merchantCode = merchantkey.getMerchantCode();
		
		if(isStringPresent(merchantCode))
		{
			if(merchantCode.length() <= 20)
			{
				if(!merchantCode.matches(RegexPatterns.ALPHA_NUMERIC_ORIGNAL_WITH_SPACE_WITHOUT_LEADING_AND_TRAILING_SPACE.get()))
				{
					merchantkey.appendStatus(APIPasswordConfigConstants.MERCHANT_CODE.get());
					merchantkey.appendStatus(APIPasswordConfigConstants.SHOULD_BE_ALPHA_NUMERIC_WITH_SPACE.get());
					merchantkey.setValidate(false);
				}
				else {
					merchantkey.setValidate(true);
				}
			}
			else
			{
				merchantkey.appendStatus(APIPasswordConfigConstants.MERCHANT_CODE.get());
				merchantkey.appendStatus(APIPasswordConfigConstants.MERCHANT_CODE_LENGTH.get());
				merchantkey.setValidate(false);
			}
		}
	}
	
	/**This method is use to validate "MERCHANT KEY" field of {@link MerchantKeyBean} object
	 * This method checks that whether field is null or not.
	 * Length should be less than or equal to 500.
	 * Field value should be Alphanumeric with space without trailing or leading space.
	 * @param merchantMapping : Is the object of {@link MerchantKeyBean}
	 */
	void validateMerchant(MerchantKeyBean merchantkey)
	{
		String merchantKey = merchantkey.getMerchantKey();
		
		if(isStringPresent(merchantKey))
		{
			if(merchantKey.length() <= 500)
			{
				if(!merchantKey.matches(RegexPatterns.ALPHA_NUMERIC_ORIGNAL_WITH_SPACE_WITHOUT_LEADING_AND_TRAILING_SPACE.get()))
				{
					merchantkey.appendStatus(APIPasswordConfigConstants.MERCHANT_KEY.get());
					merchantkey.appendStatus(APIPasswordConfigConstants.SHOULD_BE_ALPHA_NUMERIC_WITH_SPACE.get());
					merchantkey.setValidate(false);
				}
				else {
					merchantkey.setValidate(true);
				}
			}
			else
			{
				merchantkey.appendStatus(APIPasswordConfigConstants.MERCHANT_KEY.get());
				merchantkey.appendStatus(APIPasswordConfigConstants.MERCHANT_KEY_MAX_LENGTH.get());
				merchantkey.setValidate(false);
			}
		}
	}
	
	/**
	 *  This method is basically used to call validate methods on fields of {@link MappingBulkUpload} bean.
	 *  This method is responsible to validate and set validation status for {@link MappingBulkUpload} bean.
	 *  @param  {@link MappingBulkUpload} : The bean which you want to validate.
	 *	@author karan.singam
	 */ 
	@Override
	public void validateBulkUpload(MappingBulkUpload bulkUpload) {
		bulkUpload.setValidate(true);
		bulkUpload.setStatus(CommonConstants.EMPTY_STRING.get());
		validateMerchantCode(bulkUpload);
		validateTID(bulkUpload);
		validateClassPath(bulkUpload);
		validateURL(bulkUpload);
	}
	
	/**This method is use to validate "MerchantCode" field of {@link MappingBulkUpload} object
	 * This method checks that whether field is null or not.
	 * Length should be less than or equal to 20.
	 * Field value should be Alphanumeric with space without trailing or leading space.
	 * @param midBulkUpload : Is the object of {MappingBulkUpload}
	 */
	void validateMerchantCode(MappingBulkUpload midBulkUpload)
	{
		String divisionCode = midBulkUpload.getMerchantCode();
		
		if(!isStringPresent(divisionCode))
		{
			midBulkUpload.appendStatus(APIPasswordConfigConstants.MERCHANT_CODE.get());
			midBulkUpload.appendStatus(APIPasswordConfigConstants.IS_REQUIRED.get());
			midBulkUpload.setValidate(false);
		}
		else
		{
			if(divisionCode.length() <= 20)
			{
				if(!divisionCode.matches(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE_WITHOUT_LEADING_AND_TRAILING_SPACE.get()))
				{
					midBulkUpload.appendStatus(APIPasswordConfigConstants.DIVISION_CODE.get());
					midBulkUpload.appendStatus(APIPasswordConfigConstants.SHOULD_BE_ALPHA_NUMERIC_WITH_SPACE.get());
					midBulkUpload.setValidate(false);
				}
			}
			else
			{
				midBulkUpload.appendStatus(APIPasswordConfigConstants.MERCHANT_CODE.get());
				midBulkUpload.appendStatus(APIPasswordConfigConstants.MERCHANT_CODE_LENGTH.get());
				midBulkUpload.setValidate(false);
			}
		}

	}
	
	
	/**This method is use to validate "TID" field of {@link MIDBulkUpload} object
	 * This method checks that whether field is null or not.
	 * Length should be less than or equal to 30 and greater than equal to 8.
	 * Field value should be Alphanumeric with space without trailing or leading space.
	 * @param midBulkUpload : Is the object of {@MIDBulkUpload}
	 */
	void validateTID(MappingBulkUpload midBulkUpload)
	{
		String tid = midBulkUpload.getTerminalId();
		
		if(!isStringPresent(tid))
		{
			midBulkUpload.appendStatus(APIPasswordConfigConstants.TID.get());
			midBulkUpload.appendStatus(APIPasswordConfigConstants.IS_REQUIRED.get());
			midBulkUpload.setValidate(false);
		}
		else
		{
			if(tid.length() <= 32 && tid.length() >= 8)
			{
				if(!tid.matches(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE_WITHOUT_LEADING_AND_TRAILING_SPACE.get()))
				{
					midBulkUpload.appendStatus(APIPasswordConfigConstants.TID.get());
					midBulkUpload.appendStatus(APIPasswordConfigConstants.SHOULD_BE_ALPHA_NUMERIC_WITH_SPACE.get());
					midBulkUpload.setValidate(false);
				}
			}
			else
			{
				midBulkUpload.appendStatus(APIPasswordConfigConstants.TID.get());
				midBulkUpload.appendStatus(APIPasswordConfigConstants.TID_MIN_MAX_LENGTH.get());
				midBulkUpload.setValidate(false);
			}
		}
	}
	
	/**This method is use to validate "URL" field of {@link MappingBulkUpload} object
	 * This method checks that whether field is null or not.
	 * Length should be less than or equal to 300.
	 * Field value should be URL.
	 * @param MappingBulkUpload : Is the object of {@link MappingBulkUpload}
	 */
	void validateURL(MappingBulkUpload merchantMapping)
	{
		String url = merchantMapping.getUrl();
		
		if(isStringPresent(url))
		{
			if(url.length() <= 300)
			{
				if(!url.matches(RegexPatterns.URL.get()))
				{
					merchantMapping.appendStatus(APIPasswordConfigConstants.MERCHANT_URL.get());
					merchantMapping.appendStatus(APIPasswordConfigConstants.SHOULD_BE_URL.get());
					merchantMapping.setValidate(false);
				}
			}
			else
			{
				merchantMapping.appendStatus(APIPasswordConfigConstants.MERCHANT_URL.get());
				merchantMapping.appendStatus(APIPasswordConfigConstants.MERCHANT_URL_MAX_LENGTH.get());
				merchantMapping.setValidate(false);
			}
		}
	}
	
	/**This method is use to validate "classPath" field of {@link MappingBulkUpload} object
	 * This method checks that whether field is null or not.
	 * Length should be less than or equal to 150.
	 * Field value should be Alphanumeric with space without trailing or leading space.
	 * @param MappingBulkUpload : Is the object of {@link MappingBulkUpload}
	 */
	void validateClassPath(MappingBulkUpload merchantMapping)
	{
		String classPath = merchantMapping.getClassPath();
		
		if(isStringPresent(classPath))
		{
			if(classPath.length() <= 150)
			{
				if(!classPath.matches(RegexPatterns.URL.get()))
				{
					merchantMapping.appendStatus(APIPasswordConfigConstants.MERCHANT_CLASSPATH.get());
					merchantMapping.appendStatus(APIPasswordConfigConstants.SHOULD_BE_URL.get());
					merchantMapping.setValidate(false);
				}
				else {
					merchantMapping.setValidate(true);
				}
			}
			else
			{
				merchantMapping.appendStatus(APIPasswordConfigConstants.MERCHANT_CLASSPATH.get());
				merchantMapping.appendStatus(APIPasswordConfigConstants.MERCHANT_CLASSPATH_MAX_LENGTH.get());
				merchantMapping.setValidate(false);
			}
		}
	}
	
	/**
	 *  This method is basically used to call validate methods on fields of {@link KeyBulkUploadBean} bean.
	 *  This method is responsible to validate and set validation status for {@link KeyBulkUploadBean} bean.
	 *  @param  {@link KeyBulkUploadBean} : The bean which you want to validate.
	 *	@author karan.singam
	 */ 
	@Override
	public void validateKeyBulkUpload(KeyBulkUploadBean bulkUpload) {
		bulkUpload.setValidate(true);
		bulkUpload.setStatus(CommonConstants.EMPTY_STRING.get());
		validateMerchantCode(bulkUpload);
		validateMID(bulkUpload);
		validateMerchantKey(bulkUpload);
		validateCodeNeed(bulkUpload);
	}
	
	/**This method is use to validate "MerchantCode" field of {@link KeyBulkUploadBean} object
	 * Length should be less than or equal to 20.
	 * Field value should be Alphanumeric with space without trailing or leading space.
	 * @param KeyBulkUploadBean : Is the object of {KeyBulkUploadBean}
	 */
	void validateMerchantCode(KeyBulkUploadBean midBulkUpload)
	{
		String divisionCode = midBulkUpload.getMerchantCode();
		
		if(isStringPresent(divisionCode))
		{
			if(divisionCode.length() <= 20)
			{
				if(!divisionCode.matches(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE_WITHOUT_LEADING_AND_TRAILING_SPACE.get()))
				{
					midBulkUpload.appendStatus(APIPasswordConfigConstants.MERCHANT_CODE.get());
					midBulkUpload.appendStatus(APIPasswordConfigConstants.SHOULD_BE_ALPHA_NUMERIC_WITH_SPACE.get());
					midBulkUpload.setValidate(false);
				}
			}
			else
			{
				midBulkUpload.appendStatus(APIPasswordConfigConstants.MERCHANT_CODE.get());
				midBulkUpload.appendStatus(APIPasswordConfigConstants.MERCHANT_CODE_LENGTH.get());
				midBulkUpload.setValidate(false);
			}
		}

	}
	
	
	/**This method is use to validate "MID" field of {@link KeyBulkUploadBean} object
	 * This method checks that whether field is null or not.
	 * Length should be less than or equal to 45.
	 * @param KeyBulkUploadBean : Is the object of {KeyBulkUploadBean}
	 */
	void validateMID(KeyBulkUploadBean midBulkUpload)
	{
		String mid = midBulkUpload.getMid();
		
		if(!isStringPresent(mid))
		{
			midBulkUpload.appendStatus(APIPasswordConfigConstants.MID.get());
			midBulkUpload.appendStatus(APIPasswordConfigConstants.IS_REQUIRED.get());
			midBulkUpload.setValidate(false);
		}
		else
		{
			if(mid.length() >= 45)
			{
				midBulkUpload.appendStatus(APIPasswordConfigConstants.MID.get());
				midBulkUpload.appendStatus(APIPasswordConfigConstants.MID_MAX_LENGTH.get());
				midBulkUpload.setValidate(false);
			}
		}
	}
	
	/**This method is use to validate "MerchantKey" field of {@link KeyBulkUploadBean} object
	 * Length should be less than or equal to 150.
	 * @param KeyBulkUploadBean : Is the object of {@link KeyBulkUploadBean}
	 */
	void validateMerchantKey(KeyBulkUploadBean merchantMapping)
	{
		String key = merchantMapping.getMerchantKey();
		
		if(isStringPresent(key) && key.length() >= 500)
		{
				merchantMapping.appendStatus(APIPasswordConfigConstants.MERCHANT_KEY.get());
				merchantMapping.appendStatus(APIPasswordConfigConstants.MERCHANT_KEY_MAX_LENGTH.get());
				merchantMapping.setValidate(false);
		}
	}
	
	/**This method is use to validate "codeNeed" field of {@link KeyBulkUploadBean} object
	 * @param KeyBulkUploadBean : Is the object of {@link KeyBulkUploadBean}
	 */
	void validateCodeNeed(KeyBulkUploadBean merchantMapping)
	{
		String code = merchantMapping.getCodeNeed();
		
		if(!isStringPresent(code))
		{
			merchantMapping.appendStatus(APIPasswordConfigConstants.MERCHANT_CODE_NEED.get());
			merchantMapping.appendStatus(APIPasswordConfigConstants.IS_REQUIRED.get());
			merchantMapping.setValidate(false);
		}else {
			if(code.equalsIgnoreCase("yes") || code.equalsIgnoreCase("no") || code.equalsIgnoreCase("y") || code.equalsIgnoreCase("n")) {
				if(code.equalsIgnoreCase("yes") || code.equalsIgnoreCase("y"))
				{
					merchantMapping.setCodeNeed("Y");
				}
				else {
					merchantMapping.setCodeNeed("N");
				}
			}
			else {
				merchantMapping.appendStatus(APIPasswordConfigConstants.MERCHANT_CODE_NEED.get());
				merchantMapping.appendStatus(APIPasswordConfigConstants.YES_NO.get());
				merchantMapping.setValidate(false);
			}
		}
	}
	
	/**	
	 * This method is used check whether the string "str" is "null" or "". If parameter "str" is
	 *  null or "" then it will return false otherwise return true.
	 *  This method is useful to avoid "NullPointerException", or validate string is "" or not.
	 * @param str : String to be checked.
	 * @return boolean : Return "True" if string present 
	 * 					 Return "False" is string is not present or null.
	 * @author karan.singam
	 */	
	private boolean isStringPresent(String str)
	{
		if(str == null)
		{
			return false;
		}
		else
		{
			if(str.equals(""))
			{
				return false;
			}
		}
		return true;		
	}
}
