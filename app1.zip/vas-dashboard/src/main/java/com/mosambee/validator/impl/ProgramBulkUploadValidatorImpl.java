package com.mosambee.validator.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mosambee.bean.ProgramBean;
import com.mosambee.bean.ProgramBulkUploadBean;
import com.mosambee.constants.BulkUploadMessages;
import com.mosambee.constants.DateConstants;
import com.mosambee.constants.RegexPatterns;
import com.mosambee.properties.ExcelCommonProperties;
import com.mosambee.transformer.ProgramBulkUploadTransformer;
import com.mosambee.validator.ProgramBulkUploadValidator;

/**
 * ProgramBulkUploadValidatorImpl validates the {@link ProgramBean} and returns
 * {@link ProgramBulkUploadBean} with updated status field in case of validation
 * issues.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 28-December-2019
 */
@Component("programBulkUploadValidator")
public class ProgramBulkUploadValidatorImpl implements ProgramBulkUploadValidator {

	private static final Logger log = LogManager.getLogger(ProgramBulkUploadValidatorImpl.class);

	@Autowired
	ProgramBulkUploadTransformer transformer;

	@Autowired
	ExcelCommonProperties excelCommonProperties;

	/**
	 * validateProgramBean() takes in {@link ProgramBean} as parameter & perform
	 * validation on all it's class members and returns the response in
	 * {@link ProgramBulkUploadBean} which is subclass of {@link ProgramBean} with
	 * <strong>status</strong> as extra class member with information regarding
	 * validation failures.
	 * 
	 * @param programBean
	 * @return {@link ProgramBulkUploadBean}
	 * 
	 */
	@Override
	public ProgramBulkUploadBean validateProgramBean(ProgramBean programBean) {
		log.info("bean to validate: {}", programBean);
		ProgramBulkUploadBean programBulkUploadBean = new ProgramBulkUploadBean();

		BeanUtils.copyProperties(programBean, programBulkUploadBean);
		programBulkUploadBean.setStatus("");
		programBulkUploadBean.setProgramCode("");

		validateProgramName(programBulkUploadBean);
		validateProgramDescription(programBulkUploadBean);
		validateProgramPriority(programBulkUploadBean);
		validateProgramStartDateTime(programBulkUploadBean);
		validateProgramEndDateTime(programBulkUploadBean);
		validateProgramCumulativeCount(programBulkUploadBean);
		validateProgramCumulativeCountMode(programBulkUploadBean);

		log.info("bean after validation completion: {}", programBulkUploadBean);
		return programBulkUploadBean;
	}

	/**
	 * validateProgramName(...) is responsible for validating the normalized program
	 * name field coming in bulk upload. This method is applying two levels of
	 * validation here. firstly it validates the normalized program name field
	 * against {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and then we are
	 * validating the minimum and maximum size of normalized program name. Minimum
	 * size allowed is greater than or equal to 5. Maximum size allowed is less than
	 * or equal to 45.
	 * 
	 * 
	 * @param programBulkUploadBean
	 * @return void
	 */
	private void validateProgramName(ProgramBulkUploadBean programBulkUploadBean) {

		transformer.transformProgramName(programBulkUploadBean);

		// VALIDATE THE ALPHA-NUMERIC-WITH-SPACE PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(programBulkUploadBean.getProgramName());
		if (!matcher.matches()) {
			log.info("Program name regex failed in validateProgramName(): {}, for value: {}",
					BulkUploadMessages.PROGRAM_NAME_MESSAGE_REGEX.get(), programBulkUploadBean.getProgramName());
			programBulkUploadBean.appendStatus(BulkUploadMessages.PROGRAM_NAME_MESSAGE_REGEX.get());
		}

		// VALIDATE THE MIN AND MAX SIZE
		int programNameLength = programBulkUploadBean.getProgramName().length();

		if (programNameLength < 5 && programNameLength > 45) {
			log.error(
					"Program name length & mandatory validation failed in validateProgramName(...) for value: {} & length: {}",
					programBulkUploadBean.getProgramName(), programNameLength);
			programBulkUploadBean.appendStatus(BulkUploadMessages.PROGRAM_NAME_MESSAGE_LENGTH.get());
		}
	}

	/**
	 * validateProgramDescription(...) is responsible for validating the normalized
	 * program description. Here the max size allowed for program description is
	 * 1000.
	 * 
	 * Note:- We have not applied any kind of REGEX here for pattern matching.
	 * 
	 * @param programBulkUploadBean
	 * @return void
	 */
	private void validateProgramDescription(ProgramBulkUploadBean programBulkUploadBean) {

		transformer.transformProgramDescription(programBulkUploadBean);

		// VALIDATE THE MIN AND MAX SIZE
		int programDescriptionLength = programBulkUploadBean.getProgramDescription().length();

		if (programDescriptionLength > 1000) {
			log.error("program description validation failed for size: {} & value: {}", programDescriptionLength,
					programBulkUploadBean.getProgramDescription());
			programBulkUploadBean.appendStatus(BulkUploadMessages.PROGRAM_DESCRIPTION_MESSAGE.get());
		}

	}

	/**
	 * validateProgramPriority(...) is responsible for validating the program
	 * priority. program priority must be an integer that should be greater than 0
	 * and less than 1000.
	 * 
	 * 
	 * @param programBulkUploadBean
	 * @return void
	 */
	private void validateProgramPriority(ProgramBulkUploadBean programBulkUploadBean) {
		// TRANSFORM THE VALUE OF INCOMING PRIORITY
		transformer.transformProgramPriority(programBulkUploadBean);

		// GET THE INTEGER VALUE OF PROGRAM PRIORITY FROM THE STRING
		try {
			int programPriority = Integer.parseInt(programBulkUploadBean.getProgramPriority());

			// CHECK THE RANGE FOR PROGRAM PRIORITY
			if (programPriority < 1 || programPriority > 999) {
				programBulkUploadBean.appendStatus(BulkUploadMessages.PROGRAM_PRIORITY_MESSAGE.get());
			}
		} catch (Exception e) {
			log.error("Exception occurred while getting integer value from {}, {}",
					programBulkUploadBean.getProgramPriority(), e);
			programBulkUploadBean.appendStatus(BulkUploadMessages.PROGRAM_PRIORITY_MESSAGE.get());
		}
	}

	/**
	 * validateProgramStartDateTime(...) is responsible for parsing the date from
	 * the bean and then converting it to the MySQL specific format.
	 * 
	 * @param programBulkUploadBean
	 * @return void
	 */
	private void validateProgramStartDateTime(ProgramBulkUploadBean programBulkUploadBean) {
		try {
			// PARSE THE DATE VALUE
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DateConstants.DD_MM_YY_HH_MM_SS.get());
			Date date = simpleDateFormat.parse(programBulkUploadBean.getProgramStartDateTime());

			// SET THE MySQL FORMAT SPECIFIC VALUE FROM THE DATE FIELD.
			transformer.transformProgramStartDateTime(programBulkUploadBean, date);
		} catch (ParseException e) {
			log.error("Exception occurred while validateProgramStartDateTime(): {}", e);
			programBulkUploadBean.appendStatus(BulkUploadMessages.PROGRAM_START_DATETIME_FORMAT_MESSAGE.get());
		}
	}

	/**
	 * validateProgramEndDateTime(...) is responsible for parsing the date from the
	 * bean and then converting it to the MySQL specific format.
	 * 
	 * @param programBulkUploadBean
	 * @return void
	 */
	private void validateProgramEndDateTime(ProgramBulkUploadBean programBulkUploadBean) {
		try {
			// PARSE THE DATE VALUE
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DateConstants.DD_MM_YY_HH_MM_SS.get());
			Date date = simpleDateFormat.parse(programBulkUploadBean.getProgramEndDateTime());

			// SET THE MySQL FORMAT SPECIFIC VALUE FROM THE DATE FIELD
			transformer.transformProgramEndDateTime(programBulkUploadBean, date);
		} catch (ParseException e) {
			log.error("Exception occurred while validateProgramEndDateTime(): {}", e);
			programBulkUploadBean.appendStatus(BulkUploadMessages.PROGRAM_END_DATETIME_FORMAT_MESSAGE.get());
		}
	}

	/**
	 * validateProgramCumulativeCount(...) is responsible for validating the program
	 * cumulative count. cumulative count is an integer value that must lie's between 2
	 * and 99 both inclusive.
	 * 
	 * @param programBulkUploadBean
	 * @return void
	 */
	private void validateProgramCumulativeCount(ProgramBulkUploadBean programBulkUploadBean) {
		// TRANSFORM THE VALUE OF INCOMING CUMULATIVE COUNT
		transformer.transformProgramCumulativeCount(programBulkUploadBean);

		// PARSE TO INTEGER, MAKE SURE IT LIES BETWEEN 2 AND 99, BOTH INCLUSIVE.
		try {
			int cumulativeCount = Integer.parseInt(programBulkUploadBean.getProgramCumulativeCount());
			if (cumulativeCount < 2 || cumulativeCount > 99) {
				programBulkUploadBean.appendStatus(BulkUploadMessages.PROGRAM_CUMULATIVE_COUNT.get());
			}
		} catch (NumberFormatException e) {
			log.error("Exception occurred during validateProgramCumulativeCount() {}", e);
			programBulkUploadBean.appendStatus(BulkUploadMessages.PROGRAM_CUMULATIVE_COUNT.get());
		}
	}

	/**
	 * validateProgramCumulativeCountMode(...) is responsible for validating the
	 * program cumulative count mode corresponding to the list of valid program
	 * cumulative count modes coming from properties file.
	 * 
	 * @param programBulkUploadBean
	 * @return void
	 */
	private void validateProgramCumulativeCountMode(ProgramBulkUploadBean programBulkUploadBean) {
		// TRANSFORM THE PROGRAM CUMULATIVE COUNT MODE
		transformer.transformProgramCumulativeCountMode(programBulkUploadBean);
		List<String> list = excelCommonProperties.getValidCumulativeCountModes();

		// IF IT IS PRESENT ... CHECK FROM VALID LIST, ELSE IGNORE.
		if (programBulkUploadBean.getProgramCumulativeCountMode().length() > 0
				&& !list.contains(programBulkUploadBean.getProgramCumulativeCountMode())) {
			programBulkUploadBean.appendStatus(BulkUploadMessages.PROGRAM_CUMULATIVE_COUNT_MODE.get());
		}

	}

}
