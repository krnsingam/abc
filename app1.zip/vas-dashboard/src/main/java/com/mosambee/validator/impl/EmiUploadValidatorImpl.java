package com.mosambee.validator.impl;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.mosambee.bean.EmiBean;
import com.mosambee.bean.EmiUploadBean;
import com.mosambee.constants.BulkUploadMessages;
import com.mosambee.constants.RegexPatterns;
import com.mosambee.properties.ExcelHeaderProperties;
import com.mosambee.service.ExcelService;
import com.mosambee.transformer.EmiUploadTransformer;
import com.mosambee.validator.EmiUploadValidator;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;

/**
 * This class is validating fields coming in emi upload
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
@Component("emiUploadValidator")
public class EmiUploadValidatorImpl implements EmiUploadValidator {
	private static final Logger log = LogManager.getLogger(EmiUploadValidatorImpl.class);
	private static final DataFormatter dataFormatter = new DataFormatter();

	@Autowired
	private EmiUploadTransformer emiUploadTransformer;

	@Autowired
	private ExcelService excelService;

	@Autowired
	private ExcelHeaderProperties excelHeaderProperties;

	@Override
	public EmiUploadBean validateEmiBean(EmiBean emiBean) {
		EmiUploadBean emiUploadBean = new EmiUploadBean();
		BeanUtils.copyProperties(emiBean, emiUploadBean);
		emiUploadBean.setStatus("");

		validateBaseTid(emiUploadBean);
		validateBaseMid(emiUploadBean);
		validateEmiType(emiUploadBean);
		validateEmiMatCode(emiUploadBean);
		validateEmiMid(emiUploadBean);
		validateEmiTid(emiUploadBean);
		validateMosambeeEmi(emiUploadBean);
		validateEmi(emiUploadBean);
		validateEmiEnquiry(emiUploadBean);
		validateEmiProgramEnquiry(emiUploadBean);
		validateEmiVoid(emiUploadBean);
		validateEmiSettlement(emiUploadBean);
		validateCcEmiFlag(emiUploadBean);
		validateDcEmiFlag(emiUploadBean);
		validateBrandEmiFlag(emiUploadBean);
		log.info("bean after validation completion: {}", emiUploadBean);
		return emiUploadBean;

	}

	/**
	 * validateBaseTid() is validating baseTid. It is converting BaseTid into
	 * int.and then validates min and max length.min length should be 8 and max
	 * length should be 30
	 * 
	 * @param emiUploadBean
	 */
	private void validateBaseTid(EmiUploadBean emiUploadBean) {
		emiUploadTransformer.transformBaseTid(emiUploadBean);

		Pattern pattern = Pattern.compile(RegexPatterns.NUMBER_ONLY.get());
		Matcher matcher = pattern.matcher(emiUploadBean.getBaseTid());
		log.info(emiUploadBean.getBaseTid());
		int baseTid = emiUploadBean.getBaseTid().length();
		if (!matcher.matches() || baseTid < 8 || baseTid > 30) {
			log.info("baseTid validation failed  for value {}: & for length{} :",
					BulkUploadMessages.BASETID_REGEX_ERROR.get(), emiUploadBean.getBaseTid());
			emiUploadBean.appendStatus(BulkUploadMessages.BASETID_REGEX_ERROR.get());

		}
	}

	/**
	 * validateBaseMid() is validating baseMid.Firstly it validates
	 * against{@RegexPattern ALPHA_NUMERIC_WITH_SPACE} and then it validates min and
	 * max length.min length should be 3 and max length should be 100
	 * 
	 * @param emiUploadBean
	 */
	private void validateBaseMid(EmiUploadBean emiUploadBean) {
		emiUploadTransformer.transformBaseMid(emiUploadBean);
		// VALIDATE THE ALPHA_NUMERIC_WITH_SPACE PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(emiUploadBean.getBaseMid());
		int baseMidLength = emiUploadBean.getBaseMid().length();
		if (!matcher.matches() || baseMidLength < 3 || baseMidLength > 100) {
			log.info("BaseMid regex failed in validateBaseMid(): {}, for value: {}",
					BulkUploadMessages.BASEMID_REGEX_ERROR.get(), emiUploadBean.getBaseMid());
			emiUploadBean.appendStatus(BulkUploadMessages.BASEMID_REGEX_ERROR.get());
		}
	}

	/**
	 * validateEmiType() is validating emiType.Firstly it validates
	 * against{@RegexPattern ALPHA_NUMERIC_WITH_SPACE} and then it validates min and
	 * max length.min length should be 2 and max length should be 20
	 * 
	 * @param emiUploadBean
	 */
	private void validateEmiType(EmiUploadBean emiUploadBean) {
		emiUploadTransformer.transformEmiType(emiUploadBean);
		// VALIDATE THE ALPHA_NUMERIC_WITH_SPACE PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(emiUploadBean.getEmiType());
		String emiTypeLength = emiUploadBean.getEmiType();
		if (!matcher.matches() || (!emiTypeLength.equalsIgnoreCase("ONUS") && !emiTypeLength.equalsIgnoreCase("OFFUS")
				&& !emiTypeLength.equalsIgnoreCase("NO"))) {
			log.info("EmiType regex failed in validateEmiType(): {}, for value: {}",
					BulkUploadMessages.EMITYPE_REGEX_ERROR.get(), emiUploadBean.getEmiType());
			emiUploadBean.appendStatus(BulkUploadMessages.EMITYPE_REGEX_ERROR.get());
		}

	}

	/**
	 * validateEmiMatCode() is validating emiMatCode.Firstly it validates
	 * against{@RegexPattern ALPHA_NUMERIC_WITH_SPACE} and then it validates min and
	 * max length.min length should be 1 and max length should be 15
	 * 
	 * @param emiUploadBean
	 */
	private void validateEmiMatCode(EmiUploadBean emiUploadBean) {
		emiUploadTransformer.transformEmiMatCode(emiUploadBean);
		// VALIDATE THE ALPHA_NUMERIC_WITH_SPACE PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(emiUploadBean.getEmiMatCode());
		int emiMatCode = emiUploadBean.getEmiMatCode().length();
		if (!matcher.matches() || emiMatCode < 1 || emiMatCode > 15) {
			log.info("EmiMatCode regex failed in validateEmiMatCode(): {}, for value: {}",
					BulkUploadMessages.EMIMATCODE_REGEX_ERROR.get(), emiUploadBean.getEmiMatCode());
			emiUploadBean.appendStatus(BulkUploadMessages.EMIMATCODE_REGEX_ERROR.get());
		}

	}

	/**
	 * validateEmiMid() is validating emiMid.Firstly it validates
	 * against{@RegexPattern ALPHA_NUMERIC_WITH_SPACE} and then it validates min and
	 * max length.min length should be 3 and max length should be 100
	 * 
	 * @param emiUploadBean
	 */
	private void validateEmiMid(EmiUploadBean emiUploadBean) {
		emiUploadTransformer.transformEmiMid(emiUploadBean);
		// VALIDATE THE ALPHA_NUMERIC_WITH_SPACE PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(emiUploadBean.getEmiMid());
		int emiMid = emiUploadBean.getEmiMid().length();
		if (!matcher.matches() || emiMid < 3 || emiMid > 100) {
			log.info("EMIMID regex failed in validateEmiMid(): {}, for value: {}",
					BulkUploadMessages.EMIMID_REGEX_ERROR.get(), emiUploadBean.getEmiMid());
			emiUploadBean.appendStatus(BulkUploadMessages.EMIMID_REGEX_ERROR.get());
		}
	}

	/**
	 * validateEmiTid() is validating emiTid. It is converting EMITID into int.and
	 * then validates min and max length.min length should be 8 and max length
	 * should be 30
	 * 
	 * @param emiUploadBean
	 */
	private void validateEmiTid(EmiUploadBean emiUploadBean) {
		emiUploadTransformer.transformEmiTid(emiUploadBean);

		Pattern pattern = Pattern.compile(RegexPatterns.NUMBER_ONLY.get());
		Matcher matcher = pattern.matcher(emiUploadBean.getEmiTid());
		int emiTid = emiUploadBean.getEmiTid().length();
		if (!matcher.matches() || emiTid < 8 || emiTid > 30) {
			log.info("EMITID regex failed in validateEmiTid(): {}, for value: {}",
					BulkUploadMessages.EMITID_REGEX_ERROR.get(), emiUploadBean.getEmiTid());
			emiUploadBean.appendStatus(BulkUploadMessages.EMITID_REGEX_ERROR.get());
		}
	}

	/**
	 * validateEmi() is responsible for validating emi field in emi upload.firstly
	 * it validates emi against {@REGEXPATTERN CHARACTERS_ONLY} and then validates
	 * length .emi size must be 1.
	 * 
	 * @param emiUploadBean
	 */
	private void validateEmi(EmiUploadBean emiUploadBean) {

		emiUploadTransformer.transformEmi(emiUploadBean);
		// VALIDATE THE CHARACTERS_ONLY PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.CHARACTERS_ONLY.get());
		Matcher matcher = pattern.matcher(emiUploadBean.getEmi());
		// VALIDATE THE MIN AND MAX SIZE
		int emiLength = emiUploadBean.getEmi().length();
		if (!matcher.matches() || emiLength != 1) {
			log.info("emi regex failed in validateEmi(): {}, for value: {}", BulkUploadMessages.EMI_REGEX_ERROR.get(),
					emiUploadBean.getEmi());
			emiUploadBean.appendStatus(BulkUploadMessages.EMI_REGEX_ERROR.get());
		}
	}

	/**
	 * validateMosambeeEmi() is responsible for validating emi field in emi
	 * upload.firstly it validates emi against {@REGEXPATTERN CHARACTERS_ONLY} and
	 * then validates length .emi size must be 1.
	 * 
	 * @param emiUploadBean
	 */
	private void validateMosambeeEmi(EmiUploadBean emiUploadBean) {

		emiUploadTransformer.transformMosambeeEmi(emiUploadBean);
		// VALIDATE THE CHARACTERS_ONLY PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.CHARACTERS_ONLY.get());
		Matcher matcher = pattern.matcher(emiUploadBean.getMosambeeEmi());
		// VALIDATE THE MIN AND MAX SIZE
		String emiMosambee = emiUploadBean.getMosambeeEmi();
		if (!matcher.matches() || (!emiMosambee.equalsIgnoreCase("TERMINAL")
				&& !emiMosambee.equalsIgnoreCase("MERCHANT") && !emiMosambee.equalsIgnoreCase("NO"))) {
			log.info("mosambee emi regex failed in validateMosambeeEmi(): {}, for value: {}",
					BulkUploadMessages.MOSAMBEE_EMI_ERROR.get(), emiUploadBean.getMosambeeEmi());
			emiUploadBean.appendStatus(BulkUploadMessages.MOSAMBEE_EMI_ERROR.get());
		}
	}

	/**
	 * validateEmiEnquiry() is responsible for validating emiEnquiry field in emi
	 * upload.firstly it validates emiEnquiry against
	 * {@REGEXPATTERN CHARACTERS_ONLY} and then validates length .emiEnquiry size
	 * must be 1.
	 * 
	 * @param emiUploadBean
	 */
	private void validateEmiEnquiry(EmiUploadBean emiUploadBean) {

		emiUploadTransformer.transformEmiEnquiry(emiUploadBean);
		// VALIDATE THE CHARACTERS_ONLY PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.CHARACTERS_ONLY.get());
		Matcher matcher = pattern.matcher(emiUploadBean.getEmiEnquiry());
		// VALIDATE THE MIN AND MAX SIZE
		int emiEnquiryLength = emiUploadBean.getEmiEnquiry().length();
		if (!matcher.matches() || emiEnquiryLength != 1) {
			log.info("emiEnquiry regex failed in validateEmiEnquiry(): {}, for value: {}",
					BulkUploadMessages.EMIENQUIRY_REGEX_ERROR.get(), emiUploadBean.getEmiEnquiry());
			emiUploadBean.appendStatus(BulkUploadMessages.EMIENQUIRY_REGEX_ERROR.get());
		}
	}

	/**
	 * validateEmiProgramEnquiry() is responsible for validating emiProgramEnquiry
	 * field in emi upload.firstly it validates emiProgramEnquiry against
	 * {@REGEXPATTERN CHARACTERS_ONLY} and then validates length .emiProgramEnquiry
	 * size must be 1.
	 * 
	 * @param emiUploadBean
	 */
	private void validateEmiProgramEnquiry(EmiUploadBean emiUploadBean) {

		emiUploadTransformer.transformProgramEnquiry(emiUploadBean);
		// VALIDATE THE CHARACTERS_ONLY PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.CHARACTERS_ONLY.get());
		Matcher matcher = pattern.matcher(emiUploadBean.getEmiProgramEnquiry());
		// VALIDATE THE MIN AND MAX SIZE
		int emiProgramEnquiryLength = emiUploadBean.getEmiProgramEnquiry().length();
		if (!matcher.matches() || emiProgramEnquiryLength != 1) {
			log.info("emiEnquiry regex failed in validateEmiProgramEnquiry(): {}, for value: {}",
					BulkUploadMessages.EMIPROGRAMENQUIRY_REGEX_ERROR.get(), emiUploadBean.getEmiProgramEnquiry());
			emiUploadBean.appendStatus(BulkUploadMessages.EMIPROGRAMENQUIRY_REGEX_ERROR.get());
		}
	}

	/**
	 * validateEmiVoid() is responsible for validating emiVoid field in emi
	 * upload.firstly it validates emiVoid against {@REGEXPATTERN CHARACTERS_ONLY}
	 * and then validates length .emiVoid size must be 1.
	 * 
	 * @param emiUploadBean
	 */
	private void validateEmiVoid(EmiUploadBean emiUploadBean) {

		emiUploadTransformer.transformEmiVoid(emiUploadBean);
		// VALIDATE THE CHARACTERS_ONLY PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.CHARACTERS_ONLY.get());
		Matcher matcher = pattern.matcher(emiUploadBean.getEmiVoid());
		// VALIDATE THE MIN AND MAX SIZE
		int emiVoid = emiUploadBean.getEmiVoid().length();
		if (!matcher.matches() || emiVoid != 1) {
			log.info("emiEnquiry regex failed in validateEmiVoid(): {}, for value: {}",
					BulkUploadMessages.EMIVOID_REGEX_ERROR.get(), emiUploadBean.getEmiVoid());
			emiUploadBean.appendStatus(BulkUploadMessages.EMIVOID_REGEX_ERROR.get());
		}
	}

	/**
	 * validateEmiSettlement() is responsible for validating EmiSettlement field in
	 * emi upload.firstly it validates EmiSettlement against
	 * {@REGEXPATTERN CHARACTERS_ONLY} and then validates length .EmiSettlement size
	 * must be 1.
	 * 
	 * @param emiUploadBean
	 */
	private void validateEmiSettlement(EmiUploadBean emiUploadBean) {

		emiUploadTransformer.transformEmiSettlement(emiUploadBean);
		// VALIDATE THE CHARACTERS_ONLY PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.CHARACTERS_ONLY.get());
		Matcher matcher = pattern.matcher(emiUploadBean.getEmiSettlement());
		// VALIDATE THE MIN AND MAX SIZE
		int emiSettlement = emiUploadBean.getEmiSettlement().length();
		if (!matcher.matches() || emiSettlement != 1) {
			log.info("emiSettlement regex failed in validateEmiSettlement(): {}, for value: {}",
					BulkUploadMessages.EMISETTLEMENT_REGEX_ERROR.get(), emiUploadBean.getEmiSettlement());
			emiUploadBean.appendStatus(BulkUploadMessages.EMISETTLEMENT_REGEX_ERROR.get());
		}
	}

	/**
	 * validateCcEmiFlag() is responsible for validating EMIccflag field in emi
	 * upload.firstly it validates EMIccflag against {@REGEXPATTERN CHARACTERS_ONLY}
	 * and then validates length .EMIccflag size must be 1.
	 * 
	 * @param emiUploadBean
	 */
	private void validateCcEmiFlag(EmiUploadBean emiUploadBean) {

		emiUploadTransformer.transformCcEmiFlag(emiUploadBean);
		// VALIDATE THE CHARACTERS_ONLY PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.CHARACTERS_ONLY.get());
		Matcher matcher = pattern.matcher(emiUploadBean.getCcEmiFlag());
		// VALIDATE THE MIN AND MAX SIZE
		int emiCcFlag = emiUploadBean.getCcEmiFlag().length();
		if (!matcher.matches() || emiCcFlag != 1) {
			log.info("emiCcFlag regex failed in validateCcEmiFlag(): {}, for value: {}",
					BulkUploadMessages.CCEMIFLAG_REGEX_ERROR.get(), emiUploadBean.getCcEmiFlag());
			emiUploadBean.appendStatus(BulkUploadMessages.CCEMIFLAG_REGEX_ERROR.get());
		}
	}

	/**
	 * validateDcEmiFlag() is responsible for validating EMIDcflag field in emi
	 * upload.firstly it validates EMIDcflag against {@REGEXPATTERN CHARACTERS_ONLY}
	 * and then validates length .EMIDcflag size must be 1.
	 * 
	 * @param emiUploadBean
	 */
	private void validateDcEmiFlag(EmiUploadBean emiUploadBean) {

		emiUploadTransformer.transformDcEmiFlag(emiUploadBean);
		// VALIDATE THE CHARACTERS_ONLY PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.CHARACTERS_ONLY.get());
		Matcher matcher = pattern.matcher(emiUploadBean.getDcEmiFlag());
		// VALIDATE THE MIN AND MAX SIZE
		int emiDcFlag = emiUploadBean.getDcEmiFlag().length();
		if (!matcher.matches() || emiDcFlag != 1) {
			log.info("emiDcFlag regex failed in validateDcEmiFlag(): {}, for value: {}",
					BulkUploadMessages.DCEMIFLAG_REGEX_ERROR.get(), emiUploadBean.getDcEmiFlag());
			emiUploadBean.appendStatus(BulkUploadMessages.DCEMIFLAG_REGEX_ERROR.get());
		}
	}

	/**
	 * validateBrandEmiFlag() is responsible for validating BrandEmiFlag field in
	 * emi upload.firstly it validates BrandEmiFlag against
	 * {@REGEXPATTERN CHARACTERS_ONLY} and then validates length .BrandEmiFlag size
	 * must be 1.
	 * 
	 * @param emiUploadBean
	 */
	private void validateBrandEmiFlag(EmiUploadBean emiUploadBean) {

		emiUploadTransformer.transformBrandEmiFlag(emiUploadBean);
		// VALIDATE THE CHARACTERS_ONLY PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.CHARACTERS_ONLY.get());
		Matcher matcher = pattern.matcher(emiUploadBean.getBrandEmiFlag());
		// VALIDATE THE MIN AND MAX SIZE
		int brandEmiFlag = emiUploadBean.getBrandEmiFlag().length();
		if (!matcher.matches() || brandEmiFlag != 1) {
			log.info("brandEmiFlag regex failed in validateBrandEmiFlag(): {}, for value: {}",
					BulkUploadMessages.BRANDEMIFLAG_REGEX_ERROR.get(), emiUploadBean.getBrandEmiFlag());
			emiUploadBean.appendStatus(BulkUploadMessages.BRANDEMIFLAG_REGEX_ERROR.get());
		}
	}

	/**
	 * validateHeader perform second header validation for emi upload
	 * 
	 * @param workbook
	 * @return boolean
	 */
	@Override
	public boolean validateHeader(Workbook workbook, int serialNo) {
		log.info("validating header");
		List<String> excelHeaderList = null;
		if (serialNo == 0) {
			excelHeaderList = excelHeaderProperties.getEmiFirstUploadHeaders().subList(0, 3);
		} else {
			excelHeaderList = excelHeaderProperties.getEmiUploadHeaders().subList(0, 15);
		}

		if (excelHeaderList == null) {
			log.error("Unable to get the excel header");
			return false;
		}
		if (serialNo == 0) {
			return validateHeaderContents(workbook, excelHeaderList);
		} else {
			return validateSecondHeaderContents(workbook, excelHeaderList);
		}

	}

	/**
	 * Validating the excel header contents with the contents coming from the
	 * configuration.
	 *
	 * @param workbook        Workbook instance that we are getting in emi upload.
	 * @param excelHeaderList List of excel headers that we have specified in the
	 *                        configuration file.
	 * @return boolean returns true if contents of workbook header is equal to the
	 *         excelHeaderList, else it will return false.
	 */
	public boolean validateHeaderContents(Workbook workbook, List<String> excelHeaderList) {

		// Getting the workbookHeaderList from that workbook that is coming from bulk
		// upload.
		List<String> workbookHeaderList = new ArrayList<>();
		Iterator<Row> rowIterator = workbook.getSheetAt(0).iterator();

		if (rowIterator.hasNext()) {
			Iterator<Cell> cellIterator = rowIterator.next().iterator();

			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				if (!dataFormatter.formatCellValue(cell).isEmpty()) {
					workbookHeaderList.add(dataFormatter.formatCellValue(cell));
				}
			}
		}
		log.info("excel size {}", workbookHeaderList);

		// if validation of size of excel header fails, we are returning the response as
		// false.

		if (!excelService.validateSizeOfExcelHeader(workbookHeaderList, excelHeaderList))
			return false;

		// Checking the workbook contents if they are equal or not.
		boolean flag = false;

		for (int i = 0; i < workbookHeaderList.size(); ++i) {
			if (!workbookHeaderList.get(i).trim().equals(excelHeaderList.get(i).trim())) {
				log.error("Content not equal at index: {}, workBookList content: {}, excelHeader content: {}", i,
						workbookHeaderList.get(i), excelHeaderList.get(i));
				log.error("size1: {} {}, size2: {} {}", workbookHeaderList.get(i), workbookHeaderList.get(i).length(),
						excelHeaderList.get(i), excelHeaderList.get(i).length());
				flag = true;
				break;
			}
		}
		return !flag;
	}

	/**
	 * Validating the excel header contents with the contents coming from the
	 * configuration.
	 *
	 * @param workbook        Workbook instance that we are getting in emi upload.
	 * @param excelHeaderList List of excel headers that we have specified in the
	 *                        configuration file.
	 * @return boolean returns true if contents of workbook header is equal to the
	 *         excelHeaderList, else it will return false.
	 */
	public boolean validateSecondHeaderContents(Workbook workbook, List<String> excelHeaderList) {

		// Getting the workbookHeaderList from that workbook that is coming from bulk
		// upload.
		List<String> workbookHeaderList = new ArrayList<>();

		Iterator<Row> rowIterator = workbook.getSheetAt(0).iterator();

		if (rowIterator.hasNext()) {
			rowIterator.next();
			Iterator<Cell> cellIterator = rowIterator.next().iterator();

			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				workbookHeaderList.add(dataFormatter.formatCellValue(cell));
			}
		}

		// if validation of size of excel header fails, we are returning the response as
		// false.

		if (!excelService.validateSizeOfExcelHeader(workbookHeaderList, excelHeaderList))
			return false;

		// Checking the workbook contents if they are equal or not.
		boolean flag = false;

		for (int i = 0; i < workbookHeaderList.size(); ++i) {
			if (!workbookHeaderList.get(i).equals(excelHeaderList.get(i))) {
				log.error("Content not equal at index: {}, workBookList content: {}, excelHeader content: {}", i,
						workbookHeaderList.get(i), excelHeaderList.get(i));
				log.error("size1: {}, size2: {}", workbookHeaderList.get(i).length(), excelHeaderList.get(i).length());
				flag = true;
				break;
			}
		}
		return !flag;
	}
}
