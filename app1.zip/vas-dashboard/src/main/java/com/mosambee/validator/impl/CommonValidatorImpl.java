package com.mosambee.validator.impl;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.mosambee.constants.DateConstants;
import com.mosambee.constants.RegexPatterns;
import com.mosambee.validator.CommonValidator;

/**
 * This class is used to validate some module for usual purpose like date time
 * validation and conversion, numeric validation and special char validation.
 *
 * @author karan.singam
 * @version 1.0
 * @since 20-January-2020
 */
@Component("commonValidator")
public class CommonValidatorImpl implements CommonValidator {

	private static final Logger log = LogManager.getLogger(CommonValidatorImpl.class);

	// Global formatter for date time conversion
	SimpleDateFormat formatter = new SimpleDateFormat(DateConstants.DD_MM_YY.get());
	SimpleDateFormat frpmaddappr = new SimpleDateFormat(DateConstants.YYYY_MM_DD_HH_MM_SS.get());
	SimpleDateFormat settlementDatetime = new SimpleDateFormat(DateConstants.DD_MMMM_YY_HH_MM_SS.get());
	SimpleDateFormat businessMisDate = new SimpleDateFormat(DateConstants.DD_MMM_YY.get());


	/**
	 * dateTimeConveter(...) is responsible for converting date format into datetime
	 * format giving you the result in Date Format
	 * 
	 * @param String
	 * @return Date
	 */
	@Override
	public Date dateTimeConveter(String date) {
		log.info("Date : {}", date);
		Date responseDate = new Date();
		try {

			responseDate = frpmaddappr.parse(frpmaddappr.format(formatter.parse(date)));

		} catch (ParseException e) {
			log.info(e.getMessage());
		}

		return responseDate;
	}

	/**
	 * dateTimeComparator(...) is responsible for comparing date from the date
	 * before one month and gives you eligible output
	 * 
	 * @param Date
	 * @return String
	 */
	@Override
	public String dateTimeComparator(Date date2) {
		log.info("Date to be compared : {}", date2);
		String resultDate = null;
		try {

			Date date1 = frpmaddappr
					.parse(frpmaddappr.format(Date.from(ZonedDateTime.now().minusMonths(1).toInstant())));

			if (date1.compareTo(date2) > 0) {
				resultDate = frpmaddappr.format(date1);
				log.info("From Date1 : {}", resultDate);
			} else if (date1.compareTo(date2) < 0) {
				resultDate = frpmaddappr.format(date2);
				log.info("From Date2 : {}", resultDate);
			} else {
				resultDate = frpmaddappr.format(date2);
				log.info("From Date3 : {}", resultDate);
			}

		} catch (ParseException e) {
			log.info(e.getMessage());
		}
		return resultDate;
	}

	/**
	 * dateTimeConveter(...) is responsible for converting date format into datetime
	 * format giving you the result in String
	 * 
	 * @param String
	 * @return String
	 */
	@Override
	public String dateTimeValidator(String date) {
		log.info("Date : {}", date);
		Date defaultDate = new Date();
		String responseDate = null;
		try {
			responseDate = (frpmaddappr.format(formatter.parse(date)));
			return responseDate;

		} catch (Exception e) {
			log.info(e.getMessage());
			responseDate = frpmaddappr.format(defaultDate);
			return responseDate;
		}
	}

	/**
	 * numericCheck(...) is responsible for checking if the string is numeric or not
	 * and returns empty string if the value is not numeric
	 * 
	 * @param String
	 * @return String
	 */
	@Override
	public String numericCheck(String num) {
		try {
			Double dou = Double.parseDouble(num);
			log.info("Value : {}", dou);
			return num;
		} catch (NumberFormatException e) {
			log.info(e.getMessage());
			return "";
		}
	}

	/**
	 * specialCharCheck(...) is responsible for checking if the string is having any
	 * special character or not and returns empty string if the value is having any
	 * special character.
	 * 
	 * @param String
	 * @return String
	 */
	@Override
	public String specialCharCheck(String spchar) {

		Pattern pattern = Pattern.compile(RegexPatterns.SPECIAL_CHARACTERS.get());
		Matcher matcher = pattern.matcher(spchar);
		if (matcher.matches()) {
			log.error("Special character exists in the string : {}", spchar);
			return "";
		} else {
			log.info("String {}", spchar);
			return spchar;
		}
	}

	/**
	 * charCheck(...) is responsible for checking if the string is having any
	 * Numbers or not and returns empty string if the value is having any Numbers.
	 * 
	 * @param String
	 * @return String
	 */
	@Override
	public String charCheck(String spchar) {

		Pattern pattern = Pattern.compile(RegexPatterns.NUMBER_ONLY.get());
		Matcher matcher = pattern.matcher(spchar);
		if (matcher.matches()) {
			log.error("Number exists in the string : {}", spchar);
			return "";
		} else {
			log.info("String {}", spchar);
			return spchar;
		}
	}

	/**
	 * timeValidator() is responsible for converting date time in
	 * mySqlFormate(yyyy-MM-dd 23:59:59.000)
	 *
	 */
	@Override
	public String timeValidator(String date) {
		log.info("DateTime : {}", date);
		SimpleDateFormat formateTime = new SimpleDateFormat("yyyy-MM-dd 23:59:59.000");
		String responseDate = null;
		try {

			responseDate = formateTime.format(formateTime.parse(formateTime.format(formatter.parse(date))));

		} catch (ParseException e) {
			log.info(e.getMessage());
		}

		return responseDate;
	}
	
	/**
	 * validationDecimal() is responsible for converting amount to decimal value
	 *
	 */
	public String validationDecimal(String str) {
		DecimalFormat decimal = new DecimalFormat("#0.00");
		return decimal.format(Double.parseDouble(str));
	}

	@Override
	public Date dateConverter(String date) {
		log.info("Date : {}", date);
		Date responseDate = new Date();
		try {

			responseDate = businessMisDate.parse(date);

		} catch (ParseException e) {
			log.info(e.getMessage());
		}

		return responseDate;
	}

}
