package com.mosambee.validator.impl;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mosambee.bean.SBIMidBean;
import com.mosambee.bean.SBIMidUploadBean;
import com.mosambee.constants.BulkUploadMessages;
import com.mosambee.constants.RegexPatterns;
import com.mosambee.transformer.SbiMidUploadTransformer;
import com.mosambee.validator.SbiMidUploadValidator;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component("sbiMidUploadValidator")
public class SbiMidUploadValidatorImpl implements SbiMidUploadValidator{

	@Autowired
	private SbiMidUploadTransformer sbiMidUploadTransformer;

	/**
	 * validateSBIMidBean() is responsible for validating SBIMidBean
	 * fields for SBI MID upload
	 *
	 */
	@Override
	public SBIMidUploadBean validateSBIMidBean(SBIMidBean sBIMidBean) {
		SBIMidUploadBean sBIMidUploadBean = new SBIMidUploadBean();

		BeanUtils.copyProperties(sBIMidBean, sBIMidUploadBean);
		sBIMidUploadBean.setStatus("");
		
		validateMposMid(sBIMidUploadBean);
		validateMerchantName(sBIMidUploadBean);
		validateMerchantCity(sBIMidUploadBean);
		
		log.info("bean after validation completion: {}", sBIMidUploadBean);
		return sBIMidUploadBean;
	}

	/**
	 * validateMerchantCity() is validating Merchnat City coming in SBI MID upload.First
	 * it validates Merchant city against {@RegexPattern CHARACTERS_ONLY} and then it
	 * validates min and max length. Minimum length should be 1 and maximum length should be
	 * 45.
	 * 
	 * @param sBIMidUploadBean
	 */
	private void validateMerchantCity(SBIMidUploadBean sBIMidUploadBean) {
		sbiMidUploadTransformer.transformMerchantCity(sBIMidUploadBean);

		// VALIDATE THE CHARACTERS_ONLY PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.CHARACTERS_ONLY.get());
		Matcher matcher = pattern.matcher(sBIMidUploadBean.getMerchantCity());
		int Length = sBIMidUploadBean.getMerchantCity().length();
		if (!matcher.matches() || Length < 1 || Length > 45) {
			log.info("Merchant City regex failed in validateMerchantCity(): {}, for value: {}",
					BulkUploadMessages.MERCHANT_CITY_REGEX_ERROR.get(), sBIMidUploadBean.getMerchantCity());
			sBIMidUploadBean.appendStatus(BulkUploadMessages.MERCHANT_CITY_REGEX_ERROR.get());
		}
		
	}

	/**
	 * validateMerchantName() is validating Merchnat Name coming in SBI MID upload.First
	 * it validates Merchant Name against {@RegexPattern ALPHA_NUMERIC_WITH_SPACE} and then it
	 * validates min and max length. Minimum length should be 1 and maximum length should be
	 * 45.
	 * 
	 * @param sBIMidUploadBean
	 */
	private void validateMerchantName(SBIMidUploadBean sBIMidUploadBean) {
		sbiMidUploadTransformer.transformMerchantName(sBIMidUploadBean);

		// VALIDATE THE ALPHA NUMERIC PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(sBIMidUploadBean.getMerchantName());
		int Length = sBIMidUploadBean.getMerchantName().length();
		if (!matcher.matches() || Length < 1 || Length > 45) {
			log.info("Merchant Name regex failed in validateMerchantName(): {}, for value: {}",
					BulkUploadMessages.MERCHANT_NAME_REGEX_ERROR.get(), sBIMidUploadBean.getMerchantName());
			sBIMidUploadBean.appendStatus(BulkUploadMessages.MERCHANT_NAME_REGEX_ERROR.get());
		}
		
		
	}

	/**
	 * validateMposMid() is validating MID coming in SBI MID upload.First
	 * it validates Mid against {@RegexPattern ALPHA_NUMERIC_WITHOUT_SPACE} and then it
	 * validates min and max length. Minimum length should be 1 and maximum length should be
	 * 45.
	 * 
	 * @param sBIMidUploadBean
	 */
	private void validateMposMid(SBIMidUploadBean sBIMidUploadBean) {
		sbiMidUploadTransformer.transformMposMid(sBIMidUploadBean);

		// VALIDATE THE ALPHA NUMERIC PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITHOUT_SPACE.get());
		Matcher matcher = pattern.matcher(sBIMidUploadBean.getMPosMid());
		int Length = sBIMidUploadBean.getMPosMid().length();
		if (!matcher.matches() || Length < 1 || Length > 45) {
			log.info("MposMid regex failed in validateMposMid(): {}, for value: {}",
					BulkUploadMessages.MPOS_MID_REGEX_ERROR.get(), sBIMidUploadBean.getMPosMid());
			sBIMidUploadBean.appendStatus(BulkUploadMessages.MPOS_MID_REGEX_ERROR.get());
		}
		
	}

}
