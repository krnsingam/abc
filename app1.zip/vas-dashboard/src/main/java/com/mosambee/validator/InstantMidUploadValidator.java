package com.mosambee.validator;

import com.mosambee.bean.InstantMidUploadBean;
import com.mosambee.bean.MidDownloadBean;

/**
 * This class provides specification for {@link InstantMidUploadValidatorImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 */
public interface InstantMidUploadValidator {
	InstantMidUploadBean validateMidDownloadBean(MidDownloadBean midDownloadBean);

}
