package com.mosambee.validator;


import org.apache.poi.ss.usermodel.Workbook;

import com.mosambee.bean.EmiBean;
import com.mosambee.bean.EmiUploadBean;

/**
 * This class provides specification for {@link EmiUploadValidatorImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 */

public interface EmiUploadValidator {
	EmiUploadBean validateEmiBean(EmiBean emiBean);
	boolean validateHeader(Workbook workbook, int rule);

}
