package com.mosambee.validator;

import com.mosambee.bean.MIDBulkUpload;

public interface MIDBulkUploadValidatorService {
	public void validateMIDBulkUpload(MIDBulkUpload midBulkUpload);

}
