package com.mosambee.validator;

import com.mosambee.bean.SBIMidBean;
import com.mosambee.bean.SBIMidUploadBean;

/**
 * This class provides specification for {@link SbiMidUploadValidatorImpl}
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 */
public interface SbiMidUploadValidator {
	
	SBIMidUploadBean validateSBIMidBean(SBIMidBean sBIMidBean);
}
