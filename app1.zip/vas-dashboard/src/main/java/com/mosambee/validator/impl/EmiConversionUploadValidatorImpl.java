package com.mosambee.validator.impl;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mosambee.bean.EmiConversionBean;
import com.mosambee.bean.EmiConversionUploadBean;
import com.mosambee.constants.BulkUploadMessages;
import com.mosambee.constants.RegexPatterns;
import com.mosambee.transformer.EmiConversionUploadTransformer;
import com.mosambee.validator.EmiConversionUploadValidator;

/**
 * This class is validating fields coming in emiconversion upload
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Component("emiConversionUploadValidatorImpl")
public class EmiConversionUploadValidatorImpl implements EmiConversionUploadValidator {

	private static final Logger log = LogManager.getLogger(EmiConversionUploadValidatorImpl.class);

	@Autowired
	private EmiConversionUploadTransformer emiConversionUploadTransformer;

	/**
	 * validateEmiConversionBean() is responsible for validating EmiConversionBean
	 * fields for emi conversion upload
	 *
	 */
	@Override
	public EmiConversionUploadBean validateEmiConversionBean(EmiConversionBean emiConversionBean) {
		EmiConversionUploadBean emiConversionUploadBean = new EmiConversionUploadBean();

		BeanUtils.copyProperties(emiConversionBean, emiConversionUploadBean);
		emiConversionUploadBean.setStatus("");

		validateIssuer(emiConversionUploadBean);
		validateTxnRefId(emiConversionUploadBean);
		validateStatus(emiConversionUploadBean);
		validateComment(emiConversionUploadBean);
		log.info("bean after validation completion: {}", emiConversionUploadBean);
		return emiConversionUploadBean;
	}

	/**
	 * validateIssuer() is validating issuer coming in emi conversion upload.Firsty
	 * it validate issuer against {@RegexPattern ALPHA_NUMERIC_WITH_SPACE} and
	 * validates min and max length.min length should be 1 and max length should be
	 * 45.
	 * 
	 * @param emiConversionUploadBean
	 */
	private void validateIssuer(EmiConversionUploadBean emiConversionUploadBean) {

		emiConversionUploadTransformer.transformIssuer(emiConversionUploadBean);

		// VALIDATE THE ALPHA_NUMERIC_WITH_SPACE PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(emiConversionUploadBean.getIssuer());
		int issuerLength = emiConversionUploadBean.getIssuer().length();
		if (!matcher.matches() || issuerLength < 1 || issuerLength > 45) {
			log.info("issuer regex failed in validateIssuer(): {}, for value: {}",
					BulkUploadMessages.ISSUER_REGEX_ERROR.get(), emiConversionUploadBean.getIssuer());
			emiConversionUploadBean.appendStatus(BulkUploadMessages.ISSUER_REGEX_ERROR.get());
		}
	}

	/**
	 * validateTxnRefId() is validating txnRefId .txnRefId must be integer and min
	 * size should be 1 and max size should be 20
	 * 
	 * @param emiConversionUploadBean
	 */
	private void validateTxnRefId(EmiConversionUploadBean emiConversionUploadBean) {

		emiConversionUploadTransformer.transformTxnRefId(emiConversionUploadBean);

		// VALIDATE THE CHARACTERS_ONLY PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.NUMBER_ONLY.get());
		log.info(emiConversionUploadBean.getTxnRefId());
		Matcher matcher = pattern.matcher(emiConversionUploadBean.getTxnRefId());
		int txnRefId = emiConversionUploadBean.getTxnRefId().length();
		if (!matcher.matches() || txnRefId < 1 || txnRefId > 19) {
			log.info("txnRefId regex failed in validateTxnRefId(): {}, for value: {}",
					BulkUploadMessages.TXNREFID_REGEX_ERROR.get(), emiConversionUploadBean.getTxnRefId());
			emiConversionUploadBean.appendStatus(BulkUploadMessages.TXNREFID_REGEX_ERROR.get());
		}

	}

	/**
	 * validateStatus() is responsible for validating status field in emi conversion
	 * upload.firstly it validates status against {@REGEXPATTERN CHARACTERS_ONLY}
	 * and then validates length .Status size must be 1.
	 * 
	 * @param emiConversionUploadBean
	 */
	private void validateStatus(EmiConversionUploadBean emiConversionUploadBean) {

		emiConversionUploadTransformer.transformStatus(emiConversionUploadBean);
		// VALIDATE THE CHARACTERS_ONLY PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.CHARACTERS_ONLY.get());
		Matcher matcher = pattern.matcher(emiConversionUploadBean.getMessage());
		// VALIDATE THE MIN AND MAX SIZE
		String statusLength = emiConversionUploadBean.getMessage();
		if (!matcher.matches() || (!statusLength.equalsIgnoreCase("Y") && !statusLength.equalsIgnoreCase("N"))) {
			log.info("status regex failed in validateStatus(): {}, for value: {}",
					BulkUploadMessages.STATUS_REGEX_ERROR.get(), emiConversionUploadBean.getMessage());
			emiConversionUploadBean.appendStatus(BulkUploadMessages.STATUS_REGEX_ERROR.get());
		}
	}

	/**
	 * validateComment() is validating comment field in emi conversion
	 * upload.Firstly it validates comment against
	 * {@REGEX ALPHA_NUMERIC_WITH_TWO_SPECIAL_CHARACTERS_AND_SPACE} and then
	 * validates it's size.Comment should not be greater than 500.
	 * 
	 * @param emiConversionUploadBean
	 */
	private void validateComment(EmiConversionUploadBean emiConversionUploadBean) {

		emiConversionUploadTransformer.transformComment(emiConversionUploadBean);
		// validate ALPHA_NUMERIC_WITH_TWO_SPECIAL_CHARACTERS_AND_SPACE
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_TWO_SPECIAL_CHARACTERS_AND_SPACE.get());
		Matcher matcher = pattern.matcher(emiConversionUploadBean.getComment());
		int commentLength = emiConversionUploadBean.getComment().length();
		if (!matcher.matches() || commentLength > 500) {
			log.info("status regex failed in validateStatus(): {}, for value: {}",
					BulkUploadMessages.COMMENT_REGEX_ERROR.get(), emiConversionUploadBean.getComment());
			emiConversionUploadBean.appendStatus(BulkUploadMessages.COMMENT_REGEX_ERROR.get());
		}

	}
}
