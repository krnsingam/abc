package com.mosambee.validator;

import java.util.Date;

public interface CommonValidator {

	public Date dateTimeConveter(String date);

	public String dateTimeComparator(Date date2);

	public String dateTimeValidator(String date);

	public String timeValidator(String date);

	public String numericCheck(String num);

	public String specialCharCheck(String spchar);

	public String charCheck(String spchar);
	
	public String validationDecimal(String str);
	
	public Date dateConverter(String date);
}
