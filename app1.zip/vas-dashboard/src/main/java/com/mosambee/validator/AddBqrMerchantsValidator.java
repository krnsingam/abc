package com.mosambee.validator;

import com.mosambee.bean.AddBqrMerchantsBean;

public interface AddBqrMerchantsValidator {
	void validateAddBqrMerchantsBean(AddBqrMerchantsBean addBqrMerchantsBean) ;

}
