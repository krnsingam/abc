package com.mosambee.validator.impl;

import org.springframework.stereotype.Component;

import com.mosambee.bean.CreateAPIGroup;
import com.mosambee.bean.EnterpriseBean;
import com.mosambee.constants.APIPasswordConfigConstants;
import com.mosambee.constants.CommonConstants;
import com.mosambee.service.impl.EnterpriseServiceImpl;
import com.mosambee.validator.EnterpriseValidator;

import lombok.extern.log4j.Log4j2;

/**
 * This class is used to validate all forms of 'Enterprise' module.
 * 
 * @author karan.singam
 * @version 1.0
 */
@Log4j2
@Component("enterpriseValidator")
public class EnterpriseValidatorImpl implements EnterpriseValidator{

	/**
	 * This method is basically used to call validate methods on fields of
	 * CreateAPIGroup bean. This method is responsible to validate and set
	 * validation status for bean CreateAPIGroup bean.
	 * 
	 * @param CreateAPIGroup : The bean which you want to validate.
	 * @author mandar.chaudhari
	 */
	@Override
	public void validateCreateEnterprise(EnterpriseBean enterprise) {
		enterprise.setValidate(true);
		enterprise.setValidationMsg(CommonConstants.EMPTY_STRING.get());
		//validateDivisionReference1(enterprise);

		log.info("validation status : {}", enterprise.isValidate());
	}
	
	/**
	 * This method is use to validate "DivisionReference1" field of
	 * {@link CreateAPIGroup} object This method checks that whether field is null
	 * or not. Length should be less than or equal to 45. Field value should be
	 * Alphanumeric with space without trailing or leading space.
	 * 
	 * @param createAPIGroup : Is the object of {@link CreateAPIGroup}
	 */
	/*void validateDivisionReference1(EnterpriseBean createAPIGroup) {
		String divisionReference1 = createAPIGroup.getDivisionRef1();
		divisionReference1 = divisionReference1.trim();
		createAPIGroup.setDivisionRef1(divisionReference1);

		if (isStringPresent(divisionReference1)) {
			if (divisionReference1.length() <= 45) {

				createAPIGroup.appendStatus(APIPasswordConfigConstants.DIVISION_REFERENCE_1.get());
				createAPIGroup.appendStatus(APIPasswordConfigConstants.DIVISION_REFERENCE_MAX_LENGTH.get());
				createAPIGroup.setValidate(false);
			} else {
				createAPIGroup.setValidate(true);
			}
		}
		createAPIGroup.setValidate(true);
	}*/

	
}
