package com.mosambee.validator.impl;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.mosambee.bean.InstantMidUploadBean;
import com.mosambee.bean.MidDownloadBean;
import com.mosambee.constants.BulkUploadMessages;
import com.mosambee.constants.RegexPatterns;
import com.mosambee.transformer.InstantMidUploadTransformer;
import com.mosambee.validator.InstantMidUploadValidator;;

/**
 * InstantMidUploadValidatorImpl validates the {@link MidDownloadBean} and
 * returns {@link InstantMidUploadBean} with updated status field in case of
 * validation issues.
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Component("instantMidUploadValidator")
public class InstantMidUploadValidatorImpl implements InstantMidUploadValidator {
	private static final Logger log = LogManager.getLogger(InstantMidUploadValidatorImpl.class);

	@Autowired
	InstantMidUploadTransformer transformer;

	/**
	 * validateMidDownloadBean() takes in {@link MidDownloadBean} as parameter &
	 * perform validation on all it's class members and returns the response in
	 * {@link InstantMidUploadBean} which is subclass of {@link MidDownloadBean}
	 * with <strong>status</strong> as extra class member with information regarding
	 * validation failures.
	 * 
	 * @param midDownloadBean
	 * @return {@link InstantMidUploadBean}
	 * 
	 */
	@Override
	public InstantMidUploadBean validateMidDownloadBean(MidDownloadBean midDownloadBean) {
		log.info("bean to validate: {}", midDownloadBean);
		InstantMidUploadBean instantMidUploadBean = new InstantMidUploadBean();

		BeanUtils.copyProperties(midDownloadBean, instantMidUploadBean);
		instantMidUploadBean.setStatus("");

		validatePosId(instantMidUploadBean);
		validateTempMid(instantMidUploadBean);
		validateTempTid(instantMidUploadBean);
		validateMid(instantMidUploadBean);
		validateTid(instantMidUploadBean);

		log.info("bean after validation completion: {}", instantMidUploadBean);
		return instantMidUploadBean;
	}

	/**
	 * validatePosId(...) is responsible for validating the posId field coming in
	 * mid upload.posId must be integer and we are validating the minimum and
	 * maximum size of posId. Minimum size allowed is greater than or equal to 1.
	 * Maximum size allowed is less than or equal to 30.
	 * 
	 * 
	 * @param instantMidUploadBean
	 * @return void
	 */
	private void validatePosId(InstantMidUploadBean instantMidUploadBean) {

		transformer.transformPosId(instantMidUploadBean);
		// GET THE INTEGER VALUE OF POS ID FROM THE STRING
		try {
			int posId = Integer.parseInt(instantMidUploadBean.getPosId());

			if (posId < 1 && posId > 20) {

				instantMidUploadBean.appendStatus(BulkUploadMessages.POSID_REGEX_ERROR.get());
			}
		} catch (Exception e) {
			log.error("PosId length & mandatory validation failed in validatePosId(...) for value: {} & length: {}",
					instantMidUploadBean.getPosId(), e);
			instantMidUploadBean.appendStatus(BulkUploadMessages.POSID_REGEX_ERROR.get());
		}
	}

	/**
	 * validateTempMid(...) is responsible for validating the tempMid field coming
	 * in mid upload. This method is applying two levels of validation here. firstly
	 * it validates the posId field against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and then we are validating
	 * the minimum and maximum size of tempMid. Minimum size allowed is greater than
	 * or equal to 1. Maximum size allowed is less than or equal to 30.
	 * 
	 * 
	 * @param instantMidUploadBean
	 * @return void
	 */
	private void validateTempMid(InstantMidUploadBean instantMidUploadBean) {

		transformer.transformTempMid(instantMidUploadBean);

		// VALIDATE THE ALPHA_NUMERIC_WITH_SPACE PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(instantMidUploadBean.getTempMerchantCode());
		if (!matcher.matches()) {
			log.info("TempMid regex failed in validateTempMid(): {}, for value: {}",
					BulkUploadMessages.TEMP_MID_REGEX_ERROR.get(), instantMidUploadBean.getTempMerchantCode());
			instantMidUploadBean.appendStatus(BulkUploadMessages.TEMP_MID_REGEX_ERROR.get());
		}

		// VALIDATE THE MIN AND MAX SIZE
		int tempMidLength = instantMidUploadBean.getTempMerchantCode().length();

		if (tempMidLength < 15 && tempMidLength > 32) {
			log.error("TempMid length & mandatory validation failed in validateTempMid(...) for value: {} & length: {}",
					instantMidUploadBean.getTempMerchantCode(), tempMidLength);
			instantMidUploadBean.appendStatus(BulkUploadMessages.TEMP_MID_REGEX_ERROR.get());
		}
	}

	/**
	 * validateTempTid(...) is responsible for validating the tempTid field coming
	 * in mid upload. This method is applying two levels of validation here. firstly
	 * it validates the tempTid field against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and then we are validating
	 * the minimum and maximum size of tempTid. Minimum size allowed is greater than
	 * or equal to 1. Maximum size allowed is less than or equal to 30.
	 * 
	 * @param instantMidUploadBean
	 * @return void
	 */
	private void validateTempTid(InstantMidUploadBean instantMidUploadBean) {

		transformer.transformTempTid(instantMidUploadBean);

		// VALIDATE THE ALPHA_NUMERIC_WITH_SPACE PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(instantMidUploadBean.getTempTid());
		if (!matcher.matches()) {
			log.info("tempTid regex failed in validateTempTid(): {}, for value: {}",
					BulkUploadMessages.TEMP_TID_REGEX_ERROR.get(), instantMidUploadBean.getTempTid());
			instantMidUploadBean.appendStatus(BulkUploadMessages.TEMP_TID_REGEX_ERROR.get());
		}

		// VALIDATE THE MIN AND MAX SIZE
		int tempTidLength = instantMidUploadBean.getTempTid().length();

		if (tempTidLength < 8 && tempTidLength > 30) {
			log.error("tempTid length & mandatory validation failed in validateTempTid(...) for value: {} & length: {}",
					instantMidUploadBean.getTempTid(), tempTidLength);
			instantMidUploadBean.appendStatus(BulkUploadMessages.TEMP_TID_REGEX_ERROR.get());
		}
	}

	/**
	 * validateTid(...) is responsible for validating the Tid field coming in mid
	 * upload. This method is applying two levels of validation here. firstly it
	 * validates the Tid field against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and then we are validating
	 * the minimum and maximum size of Tid. Minimum size allowed is greater than or
	 * equal to 1. Maximum size allowed is less than or equal to 30.
	 * 
	 * 
	 * @param instantMidUploadBean
	 * @return void
	 */
	private void validateTid(InstantMidUploadBean instantMidUploadBean) {

		transformer.transformTid(instantMidUploadBean);

		// VALIDATE THE ALPHA_NUMERIC_WITH_SPACE PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(instantMidUploadBean.getTid());
		if (!matcher.matches()) {
			log.info("tid regex failed in validateTid(): {}, for value: {}", BulkUploadMessages.TID_REGEX_ERROR.get(),
					instantMidUploadBean.getTid());
			instantMidUploadBean.appendStatus(BulkUploadMessages.TID_REGEX_ERROR.get());
		}

		// VALIDATE THE MIN AND MAX SIZE
		int tidLength = instantMidUploadBean.getTid().length();

		if (tidLength < 8 && tidLength > 30) {
			log.error("tid  length & mandatory validation failed in validateTid(...) for value: {} & length: {}",
					instantMidUploadBean.getTid(), tidLength);
			instantMidUploadBean.appendStatus(BulkUploadMessages.TID_REGEX_ERROR.get());
		}
	}

	/**
	 * validateMid(...) is responsible for validating the Mid field coming in mid
	 * upload. This method is applying two levels of validation here. firstly it
	 * validates the Mid field against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and then we are validating
	 * the minimum and maximum size of Mid. Minimum size allowed is greater than or
	 * equal to 1. Maximum size allowed is less than or equal to 30.
	 * 
	 * 
	 * @param instantMidUploadBean
	 * @return void
	 */
	private void validateMid(InstantMidUploadBean instantMidUploadBean) {

		transformer.transformMid(instantMidUploadBean);

		// VALIDATE THE ALPHA_NUMERIC_WITH_SPACE PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(instantMidUploadBean.getMid());
		if (!matcher.matches()) {
			log.info("mid regex failed in validateMid(): {}, for value: {}", BulkUploadMessages.MID_REGEX_ERROR.get(),
					instantMidUploadBean.getMid());
			instantMidUploadBean.appendStatus(BulkUploadMessages.MID_REGEX_ERROR.get());
		}

		// VALIDATE THE MIN AND MAX SIZE
		int midLength = instantMidUploadBean.getMid().length();

		if (midLength < 4 && midLength > 100) {
			log.error("mid  length & mandatory validation failed in validateMid(...) for value: {} & length: {}",
					instantMidUploadBean.getMid(), midLength);
			instantMidUploadBean.appendStatus(BulkUploadMessages.MID_REGEX_ERROR.get());
		}
	}

}
