package com.mosambee.validator;

import com.mosambee.bean.ApiPasswordBean;

public interface ApiPasswordValidator {

	public void validateApiPassword(ApiPasswordBean apiPassword);
	
}
