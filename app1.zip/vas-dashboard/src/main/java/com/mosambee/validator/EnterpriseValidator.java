package com.mosambee.validator;

import com.mosambee.bean.EnterpriseBean;

public interface EnterpriseValidator {

	public void validateCreateEnterprise(EnterpriseBean enterprise);
	
}
