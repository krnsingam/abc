package com.mosambee.validator;

import com.mosambee.bean.EmiBulkUploadBean;
import com.mosambee.bean.EmiMidTidBean;

/**
 * This class provides specification for {@link EmiBulkUploadValidatorImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 */
public interface EmiBulkUploadValidator {
	EmiBulkUploadBean validateEmiMidTidBean(EmiMidTidBean emiMidTidBean);

}
