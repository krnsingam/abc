package com.mosambee.validator;

import com.mosambee.bean.EmiConversionBean;
import com.mosambee.bean.EmiConversionUploadBean;

/**
 * This class provides specification for
 * {@link EmiConversionUploadValidatorImpl}
 * 
 * @author pooja.singh
 * @version 1.0
 */
public interface EmiConversionUploadValidator {

	EmiConversionUploadBean validateEmiConversionBean(EmiConversionBean emiConversionBean);
}
