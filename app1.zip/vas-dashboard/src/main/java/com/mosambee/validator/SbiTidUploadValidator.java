package com.mosambee.validator;

import com.mosambee.bean.SBITidBean;
import com.mosambee.bean.SBITidUploadBean;

/**
 * This class provides specification for {@link SbiTidUploadValidatorImpl}
 * 
 * @author saurabhkant.shukla
 *
 */
public interface SbiTidUploadValidator {

	SBITidUploadBean validateSBITidBean(SBITidBean sBITidBean);
}