package com.mosambee.validator.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.mosambee.bean.ApiPasswordBean;
import com.mosambee.bean.MIDBulkUpload;
import com.mosambee.constants.APIPasswordConfigConstants;
import com.mosambee.validator.ApiPasswordValidator;

/**
 * This class is used to validate all forms of 'API Password' module.
 * 
 * @author karan.singam
 * @version 1.0
 */
@Component("apiPasswordValidator")
public class ApiPasswordValidatorImpl implements ApiPasswordValidator{

	private static final Logger log = LogManager.getLogger(ApiPasswordValidatorImpl.class);
	
	/**
	 * This method is basically used to call validate methods on fields of
	 * {@link ApiPasswordBean} bean. This method is responsible to validate and set
	 * validation status for {@link ApiPasswordBean} bean.
	 * 
	 * @param {@link ApiPasswordBean} : The bean which you want to validate.
	 * @author karan.singam
	 */
	@Override
	public void validateApiPassword(ApiPasswordBean apiPassword) {
		apiPassword.setValidate(true);
		validatePassword(apiPassword);
	}

	/**
	 * This method is use to validate "Api Password" field of {@link ApiPasswordBean}
	 * object This method checks that whether field is null or not. Length should be
	 * less than or equal to 3.
	 * 
	 * @param ApiPasswordBean : Is the object of {ApiPasswordBean}
	 */
	void validatePassword(ApiPasswordBean apiPassword) {
		String password = apiPassword.getApiPassword();
		password = password.trim();

		if (password.isEmpty()) {
			apiPassword.appendStatus(APIPasswordConfigConstants.API_PASSWORD.get());
			apiPassword.appendStatus(APIPasswordConfigConstants.IS_REQUIRED.get());
			apiPassword.setValidate(false);
		} else {
			if (password.length() <= 3) {
				apiPassword.appendStatus(APIPasswordConfigConstants.API_PASSWORD.get());
				apiPassword.appendStatus(APIPasswordConfigConstants.API_PASSWORD_MIN_LENGTH.get());
				apiPassword.setValidate(false);
				
			} 
		}

	}

}
