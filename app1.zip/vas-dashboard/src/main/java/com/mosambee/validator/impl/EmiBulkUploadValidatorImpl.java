package com.mosambee.validator.impl;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.mosambee.bean.EmiBulkUploadBean;
import com.mosambee.bean.EmiMidTidBean;
import com.mosambee.constants.BulkUploadMessages;
import com.mosambee.constants.RegexPatterns;
import com.mosambee.transformer.EmiBulkUploadTransformer;
import com.mosambee.validator.EmiBulkUploadValidator;

/**
 * This class is using for validating the emi bulk upload fields
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Component("emiBulkUploadValidator")
public class EmiBulkUploadValidatorImpl implements EmiBulkUploadValidator {
	private static final Logger log = LogManager.getLogger(EmiBulkUploadValidatorImpl.class);

	@Autowired
	EmiBulkUploadTransformer transformer;

	/**
	 * validateEmiMidTidBean() takes in {@link EmiMidTidBean} as parameter & perform
	 * validation on all it's class members and returns the response in
	 * {@link EmiBulkUploadBean} which is subclass of {@link EmiMidTidBean} with
	 * <strong>status</strong> as extra class member with information regarding
	 * validation failures.
	 * 
	 * @param emiMidTidBean
	 * @return {@link emiBulkUploadBean}
	 * 
	 */
	@Override
	public EmiBulkUploadBean validateEmiMidTidBean(EmiMidTidBean emiMidTidBean) {
		log.info("bean to validate: {}", emiMidTidBean);
		EmiBulkUploadBean emiBulkUploadBean = new EmiBulkUploadBean();

		BeanUtils.copyProperties(emiMidTidBean, emiBulkUploadBean);
		emiBulkUploadBean.setStatus("");
		validateAcquirer(emiBulkUploadBean);
		validateMid(emiBulkUploadBean);
		validateTid(emiBulkUploadBean);
		validateCredit(emiBulkUploadBean);
		validateDebit(emiBulkUploadBean);

		log.info("bean after validation completion: {}", emiBulkUploadBean);
		return emiBulkUploadBean;

	}

	/**
	 * validateAcquirer(...) is responsible for validating the acquirer field coming
	 * in emi bulk upload. This method is applying two levels of validation here.
	 * firstly it validates the acquirer field against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and then we are validating
	 * the minimum and maximum size of debit. Minimum size allowed is greater than
	 * or equal to 1. Maximum size allowed is less than or equal to 45.
	 * 
	 * 
	 * @param emiBulkUploadBean
	 * @return void
	 */
	private void validateAcquirer(EmiBulkUploadBean emiBulkUploadBean) {
		transformer.transformAcquirer(emiBulkUploadBean);

		// VALIDATE THE ALPHA_NUMERIC_WITH_SPACE PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(emiBulkUploadBean.getAcquirer());
		int acquirerLength = emiBulkUploadBean.getAcquirer().length();
		if (!matcher.matches() || acquirerLength < 1 || acquirerLength > 45) {
			log.info("acquirer regex failed in validateDebit(): {}, for value: {}",
					BulkUploadMessages.ACQUIRER_REGEX_ERROR.get(), emiBulkUploadBean.getAcquirer());
			emiBulkUploadBean.appendStatus(BulkUploadMessages.ACQUIRER_REGEX_ERROR.get());
		}

	}

	/**
	 * validateMid(...) is responsible for validating the Mid field coming in emi
	 * bulk upload. This method is applying two levels of validation here. firstly
	 * it validates the Mid field against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and then we are validating
	 * the minimum and maximum size of Mid. Minimum size allowed is greater than or
	 * equal to 1. Maximum size allowed is less than or equal to 30.
	 * 
	 * 
	 * @param emiBulkUploadBean
	 * @return void
	 */
	private void validateMid(EmiBulkUploadBean emiBulkUploadBean) {

		transformer.transformMid(emiBulkUploadBean);

		// VALIDATE THE ALPHA_NUMERIC_WITH_SPACE PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(emiBulkUploadBean.getMid());
		int midLength = emiBulkUploadBean.getMid().length();
		if (!matcher.matches() || midLength < 4 || midLength > 100) {
			log.info("mid regex failed in validateMid(): {}, for value: {}", BulkUploadMessages.MID_REGEX_ERROR.get(),
					emiBulkUploadBean.getMid());
			emiBulkUploadBean.appendStatus(BulkUploadMessages.MID_REGEX_ERROR.get());
		}

	}

	/**
	 * validateTid(...) is responsible for validating the Tid field coming in emi
	 * bulk upload. This method is applying two levels of validation here. firstly
	 * it validates the Tid field against
	 * {@link RegexPatterns#ALPHA_NUMERIC_WITH_SPACE } and then we are validating
	 * the minimum and maximum size of Tid. Minimum size allowed is greater than or
	 * equal to 8. Maximum size allowed is less than or equal to 30.
	 * 
	 * 
	 * @param emiBulkUploadBean
	 * @return void
	 */
	private void validateTid(EmiBulkUploadBean emiBulkUploadBean) {

		transformer.transformTid(emiBulkUploadBean);

		// VALIDATE THE ALPHA_NUMERIC_WITH_SPACE PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.ALPHA_NUMERIC_WITH_SPACE.get());
		Matcher matcher = pattern.matcher(emiBulkUploadBean.getTid());
		int tidLength = emiBulkUploadBean.getTid().length();
		if (!matcher.matches() || tidLength < 8 || tidLength > 30) {
			log.info("tid regex failed in validateTid(): {}, for value: {}", BulkUploadMessages.TID_REGEX_ERROR.get(),
					emiBulkUploadBean.getTid());
			emiBulkUploadBean.appendStatus(BulkUploadMessages.TID_REGEX_ERROR.get());
		}

	}

	/**
	 * validateCredit(...) is responsible for validating the credit field coming in
	 * emi bulk upload. This method is applying two levels of validation here.
	 * firstly it validates the Credit field against
	 * {@link RegexPatterns#CHARACTERS_ONLY } and then we are validating the minimum
	 * and maximum size of credit. Minimum size allowed is greater than or equal to
	 * 1. Maximum size allowed is less than or equal to 5.
	 * 
	 * 
	 * @param emiBulkUploadBean
	 * @return void
	 */
	private void validateCredit(EmiBulkUploadBean emiBulkUploadBean) {

		transformer.transformCredit(emiBulkUploadBean);

		// VALIDATE THE ALPHA_NUMERIC_WITH_SPACE PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.CHARACTERS_ONLY.get());
		Matcher matcher = pattern.matcher(emiBulkUploadBean.getCredit());
		String creditLength = emiBulkUploadBean.getCredit();
		if (!matcher.matches() || (!creditLength.equalsIgnoreCase("Y") && !creditLength.equalsIgnoreCase("N"))) {
			log.info("credit regex failed in validateCredit(): {}, for value: {}",
					BulkUploadMessages.CREDIT_REGEX_ERROR.get(), emiBulkUploadBean.getCredit());
			emiBulkUploadBean.appendStatus(BulkUploadMessages.CREDIT_REGEX_ERROR.get());
		}
	}

	/**
	 * validateDebit(...) is responsible for validating the debit field coming in
	 * emi bulk upload. This method is applying two levels of validation here.
	 * firstly it validates the debit field against
	 * {@link RegexPatterns#CHARACTERS_ONLY } and then we are validating the minimum
	 * and maximum size of debit. Minimum size allowed is greater than or equal to
	 * 1. Maximum size allowed is less than or equal to 5.
	 * 
	 * 
	 * @param emiBulkUploadBean
	 * @return void
	 */
	private void validateDebit(EmiBulkUploadBean emiBulkUploadBean) {

		transformer.transformDebit(emiBulkUploadBean);

		// VALIDATE THE ALPHA_NUMERIC_WITH_SPACE PATTERN
		Pattern pattern = Pattern.compile(RegexPatterns.CHARACTERS_ONLY.get());
		Matcher matcher = pattern.matcher(emiBulkUploadBean.getDebit());
		String debitLength = emiBulkUploadBean.getDebit();
		if (!matcher.matches() || (!debitLength.equalsIgnoreCase("Y") && !debitLength.equalsIgnoreCase("N"))) {
			log.info("debit regex failed in validateDebit(): {}, for value: {}",
					BulkUploadMessages.DEBIT_REGEX_ERROR.get(), emiBulkUploadBean.getDebit());
			emiBulkUploadBean.appendStatus(BulkUploadMessages.DEBIT_REGEX_ERROR.get());
		}
	}

}
