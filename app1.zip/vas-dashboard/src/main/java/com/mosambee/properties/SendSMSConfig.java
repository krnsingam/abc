package com.mosambee.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
@Validated
@Component
@ConfigurationProperties(prefix = "email-sms.config")
public class SendSMSConfig {

	private String useSmsGateway;
	private String smsGateway1Url;
	private String smsGateway1SenderId;
	private String smsGateway1WorkingKey;
	private String smsGateway2Url;
	private String smsGateway2UserId;
	private String smsGateway2Password;
	private String smsGateway2Senderid;

}
