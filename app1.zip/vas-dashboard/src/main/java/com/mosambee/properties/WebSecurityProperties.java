package com.mosambee.properties;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import lombok.Data;
import lombok.ToString;

/**
 * WebSecurity common properties used in WebSecurityProperties file. Here we are
 * picking fields (prefix with web-security.props) from application.properties
 * file.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 19-December-2019
 */
@Data
@ToString
@Validated
@Component
@ConfigurationProperties(prefix = "web-security.props")
public class WebSecurityProperties {

	private String[] permitPaths;
	private String loginPage;
	private String defaultSuccessUrl;
	private String deleteCookies;
	private String invalidSessionUrl;
	private String expiredUrl;
	private String logoutUrl;
	private String logoutSuccessUrl;
	
	private List<String> origins;
	private List<String> methods;
	private List<String> headers;

}
