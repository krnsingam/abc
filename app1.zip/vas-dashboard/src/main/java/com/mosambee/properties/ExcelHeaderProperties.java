package com.mosambee.properties;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import lombok.Data;
import lombok.ToString;

/**
 * ExcelHeaderProperties is basically used to get the headers of bulk upload
 * excel files from the application environment specific properties file.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 24-December-2019
 */
@Data
@ToString
@Validated
@Component
@PropertySource("classpath:/excel-properties/excel.properties")
@ConfigurationProperties(prefix = "excel-header.props")
public class ExcelHeaderProperties {

	private List<String> programBulkUploadHeaders;

	private List<String> enquiryReportingHeaders;

	private List<String> transactionReportHeaders;
	
	private List<String> merchantMappingHeaders;
	
	private List<String> merchantKeyHeaders;

	private List<String> midBulkUploadHeaders;
	
	private List<String> mappingBulkUploadHeaders;
	
	private List<String> keyBulkUploadHeaders;

	private List<String> bankMidDownloadHeaders;

	private List<String> instantMidUploadHeaders;
	
	private List<String> acquirerListHeaders;

	private List<String> emiBulkUploadHeaders;

	private List<String> emiSearchListHeaders;

	private List<String> emiConversionUploadHeaders;
	
	private List<String> sbiMidUploadHeaders;
	
	private List<String> sbiTidUploadHeaders;

	private List<String> emiUploadHeaders;
	
	private List<String> firstEmiUploadHeaders;
	
	private List<String> emiFirstUploadHeaders;

	private List<String> networkMessagesHeaders;
	
	private List<String> businessMisDownloadHeaders;

}
