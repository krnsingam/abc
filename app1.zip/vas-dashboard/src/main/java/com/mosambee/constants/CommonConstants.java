package com.mosambee.constants;

/**
 * CommonConstants ENUM consists of commonly used constants throughout the
 * application.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 28-December-2019
 */
public enum CommonConstants {

	EXCEL_CONTENT_TYPE("application/octet-stream"), SPACE(" "), DEFAULT_PROGRAM_DOMAIN("pos"),
	DEFAULT_CARD_PAN_LENGTH("0"), NA("NA"), EMPTY_STRING(""), RECORD_INSERTION_FAILED("Record insertion failed."),
	RECORD_FETCH_FAILED("Record fetch failed."), NO_RECORD_IN_EXCEL("There are no record(s)."),
	INVALID_EMAIL_ADDRESS("Invalid email address"), SOME_ERROR_OCCURRED("Some error occurred"),
	USER_NOT_PRESENT_IN_DB("Record is not present in database"),
	CHANGE_PASSWORD_LIMIT_EXCEEDED("change password limit exceeded"),
	PASSWORD_CHANGED("Your mosambee password has been changed"), NO_REPLY_MOSAMBEE_EMAIL("noreply@mosambee.in"),
	EMAIL_SENT_SUCCESS("Sent email successfully"), EMAIL_SENT_FAILED("Failed to sent email"),
	UNABLE_TO_PERSIST_NEW_PASSWORD("Unable to persist new password"),
	DB_ERROR_OCCURED("Exception occurred in database layer"), PASSWORDS_NOT_EQUAL("Passwords not equal"),
	BOTH_TABLES_UPDATED_SUCCESSFULLY("Password changed. Please login with new password."),
	UNABLE_TO_UPDATE_USER_CHANGE_PASSWORD_TABLE("Unable to update the user_change_password table"),
	UNABLE_TO_UPDATE_USERS_TABLE("Unable to update the user table"),CSV_CONTENT_TYPE("text/csv");

	private String value;

	private CommonConstants(String value) {
		this.value = value;
	}

	public String get() {
		return value;
	}

}
