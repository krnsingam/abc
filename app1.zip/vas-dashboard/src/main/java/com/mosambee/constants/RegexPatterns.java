package com.mosambee.constants;

/**
 * Commonly used REGEX patterns throughout the application.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 28-December-2019
 */
public enum RegexPatterns {

	// COMMON REGEX
	ALPHA_NUMERIC_WITH_SPACE("^\\s*[\\da-zA-Z][\\da-zA-Z\\s]*$"),
	ALPHA_NUMERIC_WITHOUT_SPACE("^[a-zA-Z0-9]+$"),
	ALPHA_NUMERIC_WITH_SPACE_WITHOUT_LEADING_AND_TRAILING_SPACE("^[a-zA-Z\\d]+((\\s)*[a-zA-Z\\d])*$"),
	ALPHA_NUMERIC_ORIGNAL_WITH_SPACE_WITHOUT_LEADING_AND_TRAILING_SPACE("^[a-zA-Z0-9\\d]+((\\s)*[a-zA-Z0-9\\d])*$"),
	SPECIAL_CHARACTERS("^[^<>{}\"/|;:.,~!?@#$%^=&*\\]\\\\()\\[¿§«»ω⊙¤°℃℉€¥£¢¡®©0-9_+]*$"), 
	NUMBER_ONLY("^[0-9]*$"),

	URL("^(https?:\\/\\/(?:www\\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\\.[^\\s]{2,}|www\\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\\.[^\\s]{2,}|https?:\\/\\/(?:www\\.|(?!www))[a-zA-Z0-9]+\\.[^\\s]{2,}|www\\.[a-zA-Z0-9]+\\.[^\\s]{2,})$"),
	EMAIL("^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$"), CHARACTERS_ONLY("^([a-zA-Z]+\\s)*[a-zA-Z]+$"),
	// PROGRAM REGEX
	PROGRAM_CODE("program_code"), PROGRAM_PRIORITY("program_priority"), PROGRAM_START_TIME("program_start_time"),
	PROGRAM_END_TIME("program_end_time"), PROGRAM_DESCRIPTION("program_description"),
	FORGOT_PASSWORD_EMAIL("^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$"),
	RESET_PASSWORD_PATTERN("((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,15})"),
	ALPHA_NUMERIC_WITH_TWO_SPECIAL_CHARACTERS_AND_SPACE("^[a-zA-Z0-9-.,\\s]*$");

	private String value;

	private RegexPatterns(String value) {
		this.value = value;
	}

	public String get() {
		return value;
	}

}
