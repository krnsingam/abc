package com.mosambee.constants;

/**
 * ModuleName ENUM is mapping of DB column moduleName from sfn_vas.group_prefix
 * table.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 03-January-2020
 */
public enum ModuleName {

	MASTER_BIN_GROUP("Master bin group"), 
	PROGRAM_BIN_GROUP("Program bin group"), 
	PROGRAM_GROUP("Program Group"), 
	PROGRAM_RULE("Program Rule"), 
	MERCHANT_GROUP("Merchant Group");

	private String value;

	ModuleName(String value) {
		this.value = value;
	}

	public String get() {
		return value;
	}

}
