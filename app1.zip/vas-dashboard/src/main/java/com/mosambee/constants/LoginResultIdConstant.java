package com.mosambee.constants;

/**
 * LoginLogsConstants is responsible for mapping loginResultId to user login
 * status.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 11-February-2020
 */
public enum LoginResultIdConstant {

	BLOCKED("5"), WRONG_CREDENTIALS("6"), SUCCESSFUL("1");

	LoginResultIdConstant(String code) {
		this.code = code;
	}

	private String code;

	public String getCode() {
		return code;
	}

}
