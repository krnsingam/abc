package com.mosambee.constants;

public enum APIPasswordConfigConstants {
	// Create API Group form fieldname
	API_URL_1("API URL 1"), API_URL_2("API URL 2"), DIVISION_REFERENCE_1("Divison Reference 1"),
	DIVISION_REFERENCE_2("Divison Reference 2"), DIVISION_REFERENCE_3("Divison Reference 3"),
	DIVISION_REFERENCE_4("Divison Reference 4"),
	//Merchant specific
	MERCHANT_KEY("Merchant Key"),
	MERCHANT_CODE("Merchant Code"),
	MERCHANT_CODE_NEED("Merchant Code Required(Y/N)"),
	MERCHANT_URL("Merchant Url"),
	MERCHANT_CLASSPATH("Merchant Class Path"),
	YES_NO("should be yes or no"),
	MERCHANT_CODE_MAX_LENGTH("min length 3 and max length is 100 allowed."),
	MERCHANT_CODE_LENGTH("max length is 20 allowed."),
	MERCHANT_URL_MAX_LENGTH("max length is 300 allowed."),
	MERCHANT_CLASSPATH_MAX_LENGTH("max length is 150 allowed."),
	MERCHANT_KEY_MAX_LENGTH("max length is 500 allowed."),
	// Create API Group form field error msg
	API_URL_MAX_LENGTH("max length is 250 allowed."), DIVISION_REFERENCE_MAX_LENGTH("max length is 45 allowed."),

	// MID BULK upload field name
	MID("MID"), TID("TID"), DIVISION_CODE("Division Code"),

	// MID BULK upload field error msg
	DIVISION_CODE_MAX_LENGTH("min length- 3 and max length - 45 isallowed."),
	MID_MAX_LENGTH("min length - 3 and max length -45 is allowed"),
	TID_MIN_MAX_LENGTH("min length 8 and max length 30 allowed"), IS_REQUIRED("is required."),
	SHOULD_BE_ALPHA_NUMERIC_WITH_SPACE("should be Alpha Numeric without space."), SHOULD_BE_URL("should be URL."),

	// Mid call body
	BODY_BEGIN("{\"Source\" : \"Mosambee\",\"AppKeyData\" : [{\"PartnerCode\" : \"111\",\"AppKey\" : \""),
	BODY_END("\"}]}"),

	// Msg content
	MSG_SUBJECT("API Password Configuration"),
	MSG_CONTENT("Dear API User,\r\n\r\nYour API password is created or updated successfully.\r\n"),

	MSG_PASS("Your password is : "),
	MSG_REGARD("\r\n\r\nWarm Regards,\r\n"),
	MSG_NAME("Mosambee"),
	
	//response status msg
	MSG0("Success"),
	MSG1("Division Code is not present"),
	MSG2("Wrong Mid Tid"),
	MSG3("Mid Tid already present"),
	MSGD("Success"),
	
	//Api password
	API_PASSWORD("Api Password"),
	API_PASSWORD_MIN_LENGTH("min length is 3 allowed."),
	;

	private String value;

	private APIPasswordConfigConstants(String value) {
		this.value = value;
	}

	public String get() {
		return value;
	}
}
