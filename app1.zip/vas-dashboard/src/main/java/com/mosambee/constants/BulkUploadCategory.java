package com.mosambee.constants;

/**
 * BulkUploadCategory is basically used to categories various types of bulk
 * upload processes that we are having in VAS system.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 24-December-2019
 */
public class BulkUploadCategory {

	private BulkUploadCategory() {
	}

	public static final String PROGRAM = "program";
	public static final String BIN_CONFIGURATION = "bin_configuaration";
	public static final String TRANSACTION_REPORT = "transaction_report";
	public static final String MERCHANT_MAPPING = "merchant_mapping";
	public static final String MERCHANT_KEY = "merchant_key";
	public static final String ENQUIRY_REPORTING = "enquiry_reporting";
	public static final String ACQUIRER_LIST = "acquirer_list";
	public static final String MID_DOWNLOAD = "mid_download";
	public static final String MID_BULK_UPLOAD = "mid_bulk_upload";
	public static final String MAPPING_BULK_UPLOAD = "mapping_bulk_upload";
	public static final String KEY_BULK_UPLOAD = "key_bulk_upload";
	public static final String INSTANT_MID_UPLOAD = "instant_mid_upload";
	public static final String EMI_BULK_UPLOAD = "emi_mid_tid";
	public static final String EMI_SEARCH_LIST = "emi_search_list";
	public static final String EMI_CONVERSION_UPLOAD = "emi_conversion_upload";

	public static final String SBI_MID_UPLOAD = "sbi_mid_upload";
	public static final String SBI_TID_UPLOAD = "sbi_tid_upload";

	public static final String EMI_UPLOAD="emi_upload";
	public static final String EMI_FIRST_ROW_UPLOAD="emi_first_upload";
	public static final String EMI_FIRST_UPLOAD="emi_first_row_upload";

	public static final String NETWORK_MESSAGES = "network_messages";
	public static final String BUSINESS_MIS = "business_mis";

}
