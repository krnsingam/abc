package com.mosambee.constants;

/**
 * BulkUploadFileLocation ENUM is responsible for specifying the class-path
 * location for all the bulk upload formats.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 03-January-2020
 */
public enum BulkUploadFileLocation {

	PROGRAM_BULK_UPLOAD_FILE("bulk-formats/program-bulk-upload-format.xlsx"),
	MID_BULK_UPLOAD_FILE("bulk-formats/mid-bulk-upload-format.xlsx"),
	MAPPING_BULK_UPLOAD_FILE("bulk-formats/mapping-bulk-upload-format.xlsx"),
	KEY_BULK_UPLOAD_FILE("bulk-formats/key-bulk-upload-format.xlsx"),
	EMI_BULK_UPLOAD_FILE("bulk-formats/emi-bulk-upload-format.xlsx"),
	EMI_UPLOAD("bulk-formats/emi-upload-format.xlsx"),
	INSTANT_MID_UPLOAD("bulk-formats/instant-mid-upload-format.xlsx"),
	EMI_BULK_UPLOAD("bulk-formats/terminal-upload-format.xlsx"),
	EMI_CONVERSION_UPLOAD("bulk-formats/emi-conversion-upload-format.xlsx"),
	SBI_MID_UPLOAD("bulk-formats/sbi-mid-upload-format.xlsx"),
	SBI_TID_UPLOAD("bulk-formats/sbi-tid-upload-format.xlsx");
	private String value;

	private BulkUploadFileLocation(String value) {
		this.value = value;
	}

	public String get() {
		return value;
	}

}
