package com.mosambee.constants;

/**
 * ColumnNames enum is used for ordering columns.
 * Here we are mapping java enum constants to database
 * column names.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 21-December-2019
 */
public enum ColumnNames {
	
	// sfn_vas.program table
	PROGRAM_NAME("programName"),
	PROGRAM_CODE("programCode"),
	PROGRAM_PRIORITY("programPriority"),
	PROGRAM_START_TIME("programStartTime"),
	PROGRAM_END_TIME("programEndTime"),
	PROGRAM_DESCRIPTION("programDescription"),
	//sfn_vas.enquiry table
	ENQUIRY_ID("id"),
	ENQUIRY_ISSUER("issuer"),				
	ENQUIRY_MERCHANTREFNO("merchantRefNo"),
	ENQUIRY_UPDATEDTIME("updatedTime"),
	ENQUIRY_BANKREFNO("bankRefNo"),
	ENQUIRY_CARDBIN("cardBin"),
	ENQUIRY_STATUS("status"),
	ENQUIRY_AMOUNT("amount"),
	ENQUIRY_CREATEDTIME("createdTime"),
	ENQUIRY_CARDTYPEID("cardTypeId"),
	// sfn_vas.transaction report
	TRANSACTION_ID("t.id"),
	TRANSACTION_ENQUIRYID("t.emquiryId"),
	TRANSACTION_RRN("t.rrn"),
	TRANSACTION_FROM_DATE("transactionTime"),
	TRANSACTION_TO_DATE("transactionTime"),
	TRANSACTION_AUTH_CODE("authCode"),
	TRANSACTION_BIN_VALUE("e.cardBin"),
	TRANSACTION_TXN_AMOUNT("t.amount"),
	TRANSACTION_ISSUER("t.issuer"),
	TRANSACTION_STATUS("t.status"),
	TRANSACTION_CONVERSION_STATUS("e.status"),
	TRANSACTION_TIME("t.transactionTime"),
	TRANSACTION_REFERENCE_NO("t.txnRefId"),
	TRANSACTION_CARD_TYPE("e.cardTypeId"),
	//Merchant Mapping 
	MERCHANT_NAME("m.businessName"),
	MERCHANT_CLASSPATH("mss.classPath"),
	MERCHANT_URL("mss.merchantURL"),
	MERCHANT_MAPPING_ID("mss.id"),
	//Merchant key
	MERCHANT("businessName"),
	MERCHANT_KEY("merchant_key"),
	MERCHANT_KEY_ID("id"),

	TRANSACTION_EMICONVERTED("t.isEMIConverted"),
	//sfn_transaction.merchant_api_division
	ID("id"),
	API_DIVISION_NAME("apiDivisionName"),
	API_DIVISION_CODE("apiDivisionCode"),
	MPOS_API_PASSWORD("mPosApiPassword"),
	API_URL_1("apiUrl1"),
	API_URL_2("apiUrl2"),
	DIVISION_REFERENCE_1("divisionRef1"),
	DIVISION_REFERENCE_2("divisionRef2"),
	DIVISION_REFERENCE_3("divisionRef3"),
	DIVISION_REFERENCE_4("divisionRef4"),
	DIVISION_STATUS("divisionStatus"),
	//sfn_transaction.tsp_web_admin_master_AcqTg_MatCode
	ACQ_ID("mat.id"),
	ACQIRER("concat(ct.name,\"-\", a.name, \"-\", t.name,\" \",COALESCE(t.tgDescription, ''))"),
	ACQ_MAT_CODE("mat.matCode "),	
	
	//sfn_transaction.tsp_web_admin_slave_sbi_getTrxnList For MID
	SBI_ID("id"),
	MPOS_MERCHANT_ID("mposMerchantCode"),
	SBI_MERCHANT_ID("sbiMerchantCode"),
	MERCHANT_NAME_SBI("merchantName"),
	MERCHANT_CITY("merchantCity"),
	STATUS("status"),
	SETUP_FILE_STATUS("setupFileStatus"),
	
	MPOS_MID("mposMerchantId"),
	MPOS_TID("mpostTerminalId"),
	TYPE("type"),
	
	//sfn_transaction.tsp_web_admin_slave_sbi_getTrxnList For TID
	SBI_TID_ID("id"),
	MPOS_TERMINAL_ID("mposTerminalId"),
	SKU_NAME("skuName"),
	STORE_NAME("storeName"),
	STORE_CITY("storeCity"),
	TID_STATUS("tidStatus"),
	TID_SETUP_FILE_STATUS("tidSetupFileStatus"),
	SKU_STATUS("skuStatus"),
	SKU_SETUP_FILE_STATUS("skuSetupFileStatus"),
	
	
	
	//sfn_vas.acquirer
	ACQUIRER("acquirerId"),
	ACQUIRER_NAME("name"),
	//sfn_vas.mdat
	MDAT_MERCHANTCODE("merchantCode"),
	MMUT_TERMINALID("terminalID"),
	QR_MERCHANTMAPPING("qrStatus"),
	QRM_IFSCACCOUNTNO("ifscAccountNumber"),
	QRM_MERCHANTNAME("qrMerchantName"),
	//sfn_vas.merchant_group_mid_mapping
	MERCHANT_CODE("merchantCode"),
	//sfn_vas.merchant_group_mid_tid_mapping
	TID("baseTid"),
	CREDIT("creditEmiFlag"),
	DEBIT("debitEmiFlag"),
	
	//Mid-Tid
	MID_DETAIL("madc.merchantCode"),
	TID_DETAIL("madc.terminalId"),
	DIVISION_CODE_DETAIL("mad.apiDivisionCode"),
	MID_TID_ID("madc.id"),
	
	//user
	USERNAME("users.userName"),
	USR_STATUS("users.statusID"),
	USR_ROLE("basicroles.roleName"),
	WEB_BLOCKED_USERNAME("u.userName"),
	WEB_BLOCKED_FIRSTNAME("u.firstName"),
	WEB_BLOCKED_EMAIL("u.email"),
	WEB_BLOCKED_BLOCKED_DATE("ub.blockDate"),
	WEB_BLOCKED_EXPIRY_DATE("ub.ExpireDate"),
	
	SETTLEMENT_FIRSTNAME("u.firstName"),
	SETTLEMENT_REASON("msl.reason"),
	SETTLEMENT_START_TIME("msl.startTime"),
	SETTLEMENT_END_TIME("msl.endTime"),
	SETTLEMENT_TYPE("msl.settlementType"),

	//Api Password
	API_PASSWORD_ID("id"),
	API_PASSWORD("apiPassword"),
	API_PASSWORD_BUSINESS_NAME("businessName"),
	API_PASSWORD_MERCHANT_CODE("merchantCode"),

	//admin-acquirer-information
	ADMIN_ACQUIRER_FROMDATE("txnFromDate"),
	ADMIN_ACQUIRER_TODATE("txnToDate"),
	ADMIN_ACQUIRER_NAME("a.name"),
	ADMIN_ACQUIRER_MIDCOUNT("m.id"),
	ADMIN_ACQUIRER_USERSCOUNT("u.id"),
	ADMIN_ACQUIRER_SALETXN(" temptable1.count1"),
	ADMIN_ACQUIRER_SALETXNVALUE("temptable1.SaleCount"),
	ADMIN_ACQUIRER_DECLINEDTXN("temptable2.count2"),
	ADMIN_ACQUIRER_LASTTXNDATE("temptable1.time1"),
	
	//Admin Site-Acquirer List
	SITE_ACQUIRER_ID("a.id"),
	SITE_ACQUIRER_NAME("a.name"),
	SITE_ACQUIRER_ZMK("a.ZMK"),
	SITE_ACQUIRER_ZPK("a.ZPK"),
	SITE_ACQUIRER_ZEK("a.ZEK"),
	SITE_ACQUIRER_TIP_PERCENT("a.tipPercent"),
	SITE_ACQUIRER_APK("a.apkName"),
	SITE_ACQUIRER_CURRENCYCODE("currencyCode"),
	SITE_ACQUIRER_DECIMAL_AMOUNT_LENGTH("a.decimalAmountLength"),
	SITE_ACQUIRER_SERVER_TIME_IN_MIN("a.serverTimeInMin"),
	SITE_ACQUIRER_MOBILE_NO_LENGTH("a.mobileNoLength"),

	//TRANSACTION LIST	
	TXN_LIST_USER_ID("u.userName"),
	TXN_LIST_MERCHANT_NAME("m.businessName"),
	TXN_LIST_TXN_ID("t.id"),
	TXN_LIST_RRN("t.rrn"),
	TXN_LIST_AUTOCODE("t.authCode"),
	TXN_LIST_CARD_NUMBER("t.maskedCardNumber"),
	TXN_LIST_CARD_HOLDER_NAME("t.cardHolderName"),
	TXN_LIST_ACQUIRER("a.name"),
	TXN_LIST_MID("t.merchantCode"),
	TXN_LIST_TID("t.terminalID"),
	TXN_LIST_DATE_FROM("t.transactionTime"),
	TXN_LIST_DATE_TO("to_date"),
	TXN_LIST_TXN_TYPE("t.typeID"),

	//Enterprise
	ENTERPRISE_NAME("entName"),
	ENTERPRISE_ID("entId"),
	ENTERPRIS_NUMBER_TERMINAL("noOfUser"),
	ENTERPRISE_TOTAL_SALES("saleAmount"),
	ENTERPRISE_TOTAL_TRANSACTION("salCount"),
	ENTERPRISE_DECLINED_TRANSACTION("decCount"),
	ENTERPRISE_VIEW("entId"),
	ENTERPRISE_FROM_DATE("fromDate"),
	ENTERPRISE_TO_DATE("Date"),

	TXN_LIST_AMT("t.amount"),
	TXN_LIST_REASON("t.responseCode"),
	TXN_SETTLEMENT_STATUS("t.settlementStatusID"),
	
	//searchBybillNumber
	SEARCHBY_BILLNUMBER_USERNAME("u.userName"),
	SEARCHBY_BILLNUMBER_TXNTYPE("tt.name"),
	SEARCHBY_BILLNUMBER_TERMINALID("t.terminalID"),
	SEARCHBY_BILLNUMBER_CARDNUMBER("t.maskedCardNumber"),
	SEARCHBY_BILLNUMBER_RRN("t.rrn"),
	SEARCHBY_BILLNUMBER_AMOUNT("t.amount"),
	SEARCHBY_BILLNUMBER_TXNTIME("t.transactionTime"),
	SEARCHBY_BILLNUMBER_RESPONSECODE("t.responseCode"),
	SEARCHBY_BILLNUMBER_AUTHCODE("t.authCode"),
	SEARCHBY_BILLNUMBER_STATUS("ts.name"),
	SEARCHBY_BILLNUMBER_SETTLEMENTSTATUS("t.settlementStatusID"),
	
	//networkMessages
	NETWORK_MESSAGES_USERNAME("mmut.userName"),
	NETWORK_MESSAGES_TERMINALID("mmut.terminalID"),
	NETWORK_MESSAGES_PROCESSINGCODE("nmm.processingCode"),
	NETWORK_MESSAGES_MESSAGETYPE("nmm.messageType"),
	NETWORK_MESSAGES_RESPONSECODE("nmm.responseCode"),
	NETWORK_MESSAGES_HSMRESPONSECODE("nmm.hsmResponseCode"),
	NETWORK_MESSAGES_DATE("nmm.timestamp"),
	
	//offline Merchants 
	OFFLINE_MERCHANTS_MERCHANTNAME("m.businessName"),
	OFFLINE_MERCHANTS_NOOFTERMINALS("terminalCount"),
	
	OFFLINE_TERMINALS_USERNAME("mmut.userName"),
	OFFLINE_TERMINALS_TERMINALID("mmut.terminalId"),
	OFFLINE_TERMINALS_OFFLINEKEY("mmuo.offlineKey"),
	
	//tg
	TG_NAME("name"),
	TG_IPADDRESS("ipAddress"),
	TG_PORT("port"),
	TG_URL("url"),
	
	//Common
	COLUMN_NAME_NOT_FOUND("columnNameNotFound");
	

	private String value;
	
	private ColumnNames(String value) {
		this.value = value;
	}
	
	public String get() {
		return value;
	}

}