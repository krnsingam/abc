package com.mosambee.constants;

public enum CreateUser {
    
	CREATE_USER_EMAIL_SUBJECT("New User"),
	CREATE_USER_EMAIL_1("<br><b>Hi </b>"),
	CREATE_USER_EMAIL_2("<br><br>Welcome To Mosambee. -  Mobilising Transactions, Transforming Business.\r\n" + 
			"Thank you for selecting Mosambee as your preferred mobile payment POS.\r\n" + 
			"<br><br>Your user id is :"),
	CREATE_USER_EMAIL_3("<br><br>Your password is: "),
	CREATE_USER_EMAIL_4("<br><br>Please login using the above user id and password. Change the password after first login.<br><a>Visit Mosambee!</a>");
		
	private String value;
	
	private CreateUser(String value) {
		this.value = value;
	}
	
	public String get() {
		return value;
	}
}
