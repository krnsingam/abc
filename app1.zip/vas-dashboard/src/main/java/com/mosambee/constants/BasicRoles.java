package com.mosambee.constants;

/**
 * BasicRoles is same as basicRoles table in database.
 * For now we are providing support for only two types
 * of roles, i.e. Site Admin & Site User.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 11-December-2019
 */
public enum BasicRoles {
	
	SITE_ADMIN("ROLE_SITE_ADMIN"),
	SITE_USER("ROLE_SITE_USER"), 
	SITE_CP_USER("ROLE_SITE_CP_USER"); 
	
	private String value;
	
	private BasicRoles(String value) {
		this.value = value;
	}
	
	public String get() {
		return value;
	}

}
