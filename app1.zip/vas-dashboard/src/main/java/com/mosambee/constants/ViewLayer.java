package com.mosambee.constants;

/**
 * TemplateConstants is basically used to hold the view name AKA the template
 * name which we are passing to the ModelAndView constructor.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 11-December-2019
 */
public enum ViewLayer {

	CREATE_NEW("launch-program/create-new"), BULK_UPLOAD("launch-program/bulk-upload"),
	VIEW_ACTIVE("launch-program/view-active"), TRANSACTION_VIEW("launch-program/transaction-report-view"),
	ENQUIRY_LIST("enquiry-reporting/enquiry"), MID_DOWNLOAD("enquiry-reporting/download-mid"),

	
	//EMI TAB
	ADD_SBI_EMI_MID("sbi-emi/add-sbi-emi-mid"),
	ADD_SBI_EMI_TID("sbi-emi/add-sbi-emi-tid"),
	LIST_SBI_EMI_MID_TID("sbi-emi/sbi-emi-mid-tid-list"),
	EMI_MID_UPLOAD("sbi-emi/sbi-emi-mid-upload"),
	EMI_TID_UPLOAD("sbi-emi/sbi-emi-tid-upload"),


	INSTANT_MID_UPLOAD("instant-merchant-mid/mid-upload"), EMI_BULK_UPLOAD("instant-merchant-mid/emi-bulk-upload"),
	EMI_SEARCH("instant-merchant-mid/emi-search"), EMI_CONVERSION("emi-conversion/emi-conversion-upload"),
	EMI_UPLOAD("emi-conversion/emi-upload"),
	MERCHANTS("merchants/add-bqr-merchants"),
	LIST("merchants/bqr-merchnats-list"),
	EDIT("merchants/edit-bqr-merchnats"),
	
	
	
	//Acquirer
	ACQUIRER_VIEW("acquirer-bulk-upload/acquirer-view"),
	//Merchant specific view
	MERCHANT_MAPPING_VIEW("/merchant-specific/merchant-mapping-view"),
	MERCHANT_KEY_VIEW("/merchant-specific/merchant-key-view"),
	MERCHANT_CREATE_VIEW("/merchant-specific/create-merchant-mapping"),
	MERCHANT_MAPPING_ACTION("/merchant-specific/insert-merchant-mapping"),
	MERCHANT_MAPPING_UPDATE("/merchant-specific/update-merchant-mapping"),
	MERCHANT_CREATE_KEY("/merchant-specific/create-merchant-key"),
	MERCHANT_KEY_UPDATE("/merchant-specific/edit-merchant-key"),
	MERCHANT_BULK_UPLOAD("/merchant-specific/merchant-mapping-bulkUpload"),
	MERCHANT_KEY_BULK_UPLOAD("/merchant-specific/merchant-key-bulkUpload"),

	// API Password Config
	CREATE_API_GROUP_VIEW("/api-password-config/create-api-group"),
	CREATE_API_GROUP_ACTION("/api-password-config/insert-api-group"),
	UPDATE_API_GROUP_ACTION("/api-password-config/update-api-group"),
	LIST_API_GROUP_VIEW("/api-password-config/list-api-group"),
	MID_BULK_UPLOAD_VIEW("/api-password-config/mid-bulk-upload"), MID_TID_VIEW("/api-password-config/mid-tid-view"),
	
	USER_LIST("users/view-active-users"),
	CREATE_USER("users/create-user"),
	UPDATE_USER("users/edit-user"),
	
	WEB_BLOCKED_USERS("users/web-blocked-users"),
	MOBILE_BLOCKED_USERS("users/mobile-blocked-users"),
	
	SETTLEMENT_INITIATE("settlement/initiate"),
	SETTLEMENT_MERCHANT("settlement/list-merchant"),
	SETTLEMENT_USER("settlement/list-user"),
	SETTLEMENT_TIME("settlement/list-time"),
	SETTLEMENT_AUTO("settlement/list-auto"),
	
	//Api Password
	API_PASSWORD_VIEW("/api-password/api-password-view"),
	API_PASSWORD_UPDATE("/api-password/api-password-update"),
	API_PASSWORD_UPDATE_ACTION("/api-password/update"),
	//Enterprise
	ENTERPRISE_CREATE("/enterprise/create-enterprise"),
	ENTERPRISE_INSERT("/enterprise/create-insert"),
	ENTERPRISE_LIST("/enterprise/enterprise-list"),
	ENTERPRISE_UPDATE("/enterprise/update-enterprise"),
	
	TRANSACTION_SEARCH_VIEW("transaction/transaction-search-view"),
	LIST_TRANSACTION_SEARCH_VIEW("transaction/list-transactions"),
	
	FORGOT_PASSWORD("forgot-password"),

	//Admin Acquirer view
	ADMIN_ACQUIRER_VIEW("admin-acquirer/admin-acquirer-view"),
	ADD_ACQUIRER_VIEW("admin-acquirer/add-acquirer-view"),
	LIST_ACQUIRER_VIEW("admin-acquirer/list-acquirer-view"),
	
	//Searchbybillnumber view
	SEARCH_BY_BILLNUMBER_VIEW("search-by-billnumber/search-by-billnumber-view"),
	
	//Networkmessages view
	NETWORK_MESSAGES_VIEW("network-messages/network-messages-view"),
	
	//offline Merchants List view
	OFFLINE_MERCHANTS_LIST_VIEW("offline-merchants/offline-merchants-list-view"),
	
	//tg view
	TG_LIST_VIEW("tg/tg-list-view"),
	TG_ADD_VIEW("tg/tg-add-view"),
	TG_UPDATE_VIEW("tg/tg-update-view"),
	
	//Business MIS view
	BUSINESSMIS_UPDATE_VIEW("business-mis/businessmis-update-view"),
	BUSINESSMIS_DOWNLOAD_VIEW("business-mis/businessmis-download-view");
	
	private String value;

	private ViewLayer(String value) {
		this.value = value;
	}

	public String get() {
		return value;
	}

}
