package com.mosambee.constants;

/**
 * BulkUploadMessages will have all the status messages for invalid fields, when
 * matched against patterns specified in {@link RegexPatterns}
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 28-December-2019
 */
public enum BulkUploadMessages {

	// ERROR MESSAGE SPECIFIC TO PROGRAMS
	PROGRAM_NAME_MESSAGE_REGEX("Invalid Program Name. Only alpha-numeric, space, hyphen(-) & underscore(_) is allowed"),
	PROGRAM_NAME_MESSAGE_LENGTH(
			"Invalid Program Name. Program name is mandatory, minimum length is 5, maximum length is 45."),
	PROGRAM_CODE_MESSAGE("Invalid Program Code."),
	PROGRAM_PRIORITY_MESSAGE(
			"Invalid Program Priority .i.e program priority is a integer value between 1 and 999 both inclusive."),
	PROGRAM_START_DATETIME_MESSAGE("Invalid Program Start Time."),
	PROGRAM_START_DATETIME_FORMAT_MESSAGE(
			"Program start time must have following format dd-MM-yy HH:mm:ss i.e. 01-01-20 15:01:30."),
	PROGRAM_END_DATETIME_MESSAGE("Invalid Program End Time."),
	PROGRAM_END_DATETIME_FORMAT_MESSAGE(
			"Program end time must have following format dd-MM-yy HH:mm:ss i.e. 01-01-20 15:01:30."),
	PROGRAM_DESCRIPTION_MESSAGE("Invalid Program Description. Maximum allowed length for program description is 1000."),
	PROGRAM_DOMAIN_INVALID(
			"Invalid Program Domain, please use valid program domains, valid domains are wallet, upi, pos, pg, bqr"),
	PROGRAM_CUMULATIVE_COUNT_MODE("Invalid program cumulative count mode. valid modes are year, month, week, daily"),
	PROGRAM_CUMULATIVE_COUNT("Invalid program cumulative count. valid modes are integers from 2 to 99"),

	// ERROR MESSAGE SPECIFIC TO DB INSERTION
	DB_INSERTION_SUCCESS("Successful"), DB_INSERTION_FAILED("Failed - Unable to insert program"),
	EXCEPTION_OCCURED_WHILE_INSERTION("Failed - Some error occurred"),

	// ERROR MESSAGE SPECIFIC TO ENQUIRY REPORTING
	CARDBIN_ERROR_MESSAGE("Please Enter valid input(Numeric,minlength=6,maxlength=8)"),

	// ERROR SPECIFIC TO INSTANT MID UPLOAD
	POSID_REGEX_ERROR("Invalid Posid(Mandatory,Numeric,minLength=1,maxlength=20)"),
	TID_REGEX_ERROR("Invalid tid(Mandatory,AlphaNumeric,minLength=8,maxlength=30)"),
	TEMP_MID_REGEX_ERROR("Invalid tempMid(Mandatory,AlphaNumeric,minLength=16,maxlength=32)"),
	TEMP_TID_REGEX_ERROR("Invalid tempTid(Mandatory,AlphaNumeric,minLength=8,maxlength=30)"),
	MID_ERROR_MESSAGE2("Merchant is not instant registraion merchant so can not update"),
	MID_ERROR_MESSAGE1("Temp mid and Temp tid is mandatory"),
	MID_REGEX_ERROR("Invalid Mid(Mandatory,AlphaNumeric,minLength=4,maxlength=100)"),

	// ERROR SPECIFIC TO EMI BULK UPLOAD
	CREDIT_REGEX_ERROR("Invalid Credit(Mandatory,Only Characters allowed,It must be 'Y' or 'N')"),
	DEBIT_REGEX_ERROR("Invalid Debit(Mandatory,Only Characters allowed,It must be 'Y' or 'N')"),
	RESPONSE_ERROR_MESSAGE1("MID,TID and Acquirer is required"), RESPONSE_ERROR_MESSAGE2("MID-TID is already exist"),
	RESPONSE_ERROR_MESSAGE9("The credit and debit flag is updated-success"),
	RESPONSE_ERROR_MESSAGE3("Acquirer is not present"),
	RESPONSE_ERROR_MESSAGE10("Tid is already present for another Mid"),
	ACQUIRER_REGEX_ERROR("Invalid Acquirer(Mandatory,AlphaNumeric,max-length-45)"),

	// ERROR SPECIFIC TO EMI CONVERSION UPLOAD
	ISSUER_REGEX_ERROR("Issuer is invalid(Mandatory,AlphaNumeric Allowed,max-length-20)"),
	TXNREFID_REGEX_ERROR("TxnRefId is invalid(Mandatory,Numeric,No space allowed between numbers,max-length-19)"),
	STATUS_REGEX_ERROR("Status is invalid(Mandatory,Characters Only,It must be 'Y' or 'N')"),
	COMMENT_REGEX_ERROR("Comment is invalid(Alphnumeric,max-length-500)"),
	TXN_RESPONSE_ERROR("txnRefId does not exist"), TXN_RESPONSE_ERROR2("transaction is not settled"),
	TXN_RESPONSE_ERROR3("Issuer does not exist"),
	// ERROR MESSAGE SPECIFIC TO EMI SEARCH DOWNLOAD
	DOWNLOAD_MSG("Error in downloading excel file "),
	// ERROR SPECIFIC TO EMI UPLOAD
	BASETID_REGEX_ERROR("Invalid BaseTid(Mandatory,numeric,min-length=8,maxlength=30)"),
	BASEMID_REGEX_ERROR("Invalid BaseMid(Mandatory,alphanumeric,min-length=3,maxlength=100)"),
	EMITYPE_REGEX_ERROR("Invalid EmiType(Mandatory,it must be ONUS or OFFUS or NO,)"),
	EMIMATCODE_REGEX_ERROR("Invalid EmiMatCode(Mandatory,alphanumeric,max-length=15)"),
	EMIMID_REGEX_ERROR("Invalid EmiMID(Mandatory,alphanumeric,min-length=3,maxlength=100)"),
	EMITID_REGEX_ERROR("Invalid EmiTid(Mandatory,numeric,min-length=8,maxlength=30)"),
	EMI_REGEX_ERROR("Invalid Emi(Mandatory,Only(Y/N is allowed)"),
	EMIENQUIRY_REGEX_ERROR("Invalid EmiEnquiry(Mandatory,Only(Y/N is allowed)"),
	EMIPROGRAMENQUIRY_REGEX_ERROR("Invalid EmiProgramEnquiry(Mandatory,Only(Y/N is allowed)"),
	EMIVOID_REGEX_ERROR("Invalid EmiVoid(Mandatory,Only(Y/N is allowed)"),
	EMISETTLEMENT_REGEX_ERROR("Invalid EmiSettlement(Mandatory,Only(Y/N is allowed)"),
	CCEMIFLAG_REGEX_ERROR("Invalid CCEmiFlag(Mandatory,Only(Y/N is allowed)"),
	DCEMIFLAG_REGEX_ERROR("Invalid DCEmiFlag(Mandatory,Only(Y/N is allowed)"),
	BRANDEMIFLAG_REGEX_ERROR("Invalid BrandEmiFlag(Mandatory,Only(Y/N is allowed)"),
	MOSAMBEE_EMI_ERROR("Invalid Mosambee Emi(it must be merchant or terminal or no)"),
	// ERROR SPECIFIC TO EMI UPLOAD
	ERRORCODE1("Matcode does not exist"), ERRORCODE2("Wrong MatCode"),
	SECONDMETHODCODE1("Base terminal does not exist"), SECONDMETHODCODE2("Merchant does not exist"),
	SECONDMETHODCODE3("Merchant Code does not exist"), SECONDMETHODCODE4("Tg is not configured"),
	THIRDMETHOD4("Merchant Code is Mandatory"),THIRDMETHOD5("Terminal is already configured "),
	THIRDMETHOD6("Emi merchant is active for another tg"),
	//Error Specific to Add BQR Merchant
	MERCHANTID_ERROR("Invalid MerchantId(Mandatory,Alphanumeric,Min length=1 and max length=100)"),
	TERMINALID_ERROR("Invalid TermianalId(Mandatory,Alphanumeric,Min length=8 and max length=30)"),
	VISANETWORKID1("Invalid Visa Network Id 1(Mandatory,Alphanumeric,min length=1 and maxlength=45)"),
	VISANETWORKID2("Invalid Visa Network Id 2(Alphanumeric,min length=1 and maxlength=45)"),
	MASTERCARDID1("Invalid Master Card Id 1(Mandatory,Alphanumeric,min length=1 and maxlength=45)"),
	MASTERCARDID2("Invalid Master Card Id 2(Alphanumeric,min length=1 and maxlength=45)"),
	NPCIID1_ERROR("Invalid NPCI Network Id 1(Mandatory,Alphanumeric,min length=1 and maxlength=45)"),
	NPCIID2_ERROR("Invalid NPCI Network Id 2(Alphanumeric,min length=1 and maxlength=45)"),
	REFERENCETAF09_ERROR("Invalid Reference Tag 09(Alphanumeric,min length=1 and maxlength=45)"),
	REFERENCETAF10_ERROR("Invalid Reference Tag 10(Alphanumeric,min length=1 and maxlength=45)"),
	IFSC_ERROR("Invalid IFSC Account No(Mandatory,Alphanumeric,min length=1 and maxlength=45)"),
	AMEXNETWORKID1_ERROR("Invalid AMEX Network ID 1(Alphanumeric,min length=1 and maxlength=45)"),
	AMEXNETWORKID2_ERROR("Invalid AMEX Network ID 2(Alphanumeric,min length=1 and maxlength=45)"),
    MCC_ERROR("Invalid Merchant Categories Code(Mandatory,Alphanumeric,min length=2 and maxlength=4)"),
    CURRENCY_ERROR("Invalid Currency Code(Mandatory,Alphanumeric,min length=1 and maxlength=3)"),
    COUNTRY_ERROR("Invalid Country Code(Mandatory,Alphanumeric,min length=1 and maxlength=2)"),
  QRMERCHANT_ERROR("Invalid QR Merchant Name(Mandatory,Alphanumeric,min length=1 and maxlength=23)"),
  MERCHANTCITY_ERROR("Invalid Merchant City(Mandatory,Alphanumeric,min length=2 and maxlength=15)"),
  POSTALCODE_ERROR("Invalid Postal Code(Mandatory,Alphanumeric,min length=2 and maxlength=10)"),
  ACQUIRER_ERROR("Acquirer is mandatory"),
	


	// ERROR SPECIFIC TO EMI SBI MID UPLOAD
	MPOS_MID_REGEX_ERROR("MID is invalid(Mandatory,AlphaNumeric Allowed,max-length-45)"),
	MERCHANT_NAME_REGEX_ERROR("Merchant Name is invalid(Mandatory,AlphaNumeric Allowed,max-length-45)"),
	MERCHANT_CITY_REGEX_ERROR("Merchant City is invalid(Mandatory,Characters Only,max-length-45)"),

	// ERROR SPECIFIC TO EMI SBI TID UPLOAD
	MPOS_TID_REGEX_ERROR("TID is invalid(Mandatory,AlphaNumeric Allowed,max-length-45)"),
	SKU_NAME_REGEX_ERROR("SKU Name is invalid(Mandatory,AlphaNumeric Allowed,max-length-45)"),
	STORE_NAME_REGEX_ERROR("Store Name is invalid(Mandatory,AlphaNumeric Allowed,max-length-45)"),
	STORE_CITY_REGEX_ERROR("Store City is invalid(Mandatory,Characters Only,max-length-45)"),


	// SUCCESS STATUS FOR ALL BULK UPLOADS
	SUCCESS("success");

	private String value;

	private BulkUploadMessages(String value) {
		this.value = value;
	}

	public String get() {
		return value;
	}

}
