package com.mosambee.constants;

/**
 * DateConstants ENUM consists of all the date format pattern that are used
 * throughout this application.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 30-December-2019
 */
public enum DateConstants {

	DD_MM_YY_HH_MM_SS("dd-MM-yy HH:mm:ss"), // Bulk Upload Format
	DD_MMMM_YY_HH_MM_SS("dd-MMMM-yy HH:mm:ss"), //Month in words
	DD_MM_YY("dd-MM-yyyy"), // Date time converter for date picker
	YYYY_MM_DD_HH_MM_SS("yyyy-MM-dd HH:mm:ss"), // MySQL specific format
	DD_MMM_YY("dd-MMM-yy");
	private String value;

	private DateConstants(String value) {
		this.value = value;
	}

	public String get() {
		return value;
	}

}
