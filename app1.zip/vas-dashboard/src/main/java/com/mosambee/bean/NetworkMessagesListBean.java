package com.mosambee.bean;

import lombok.Builder;
import lombok.Data;
/**
 * NetworkMessagesListBean is basically used to carry response parameter for getNetworkMessagesList method of
 * {@link NetworkMessagesController} 
 * @author mariam.siddique
 * @version 1.0
 * @since 27-March-2020
 */
@Builder
@Data
public class NetworkMessagesListBean {
	
	private String userName;
	private String terminalId;
	private String processingCode;
	private int messageType;
	private String responseCode;
	private String hsmResponseCode;
	private String date;

}
