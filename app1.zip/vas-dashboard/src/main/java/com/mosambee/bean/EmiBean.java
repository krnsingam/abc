package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * This class is responsible for emi upload fields
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Data
@SuperBuilder
@NoArgsConstructor
public class EmiBean {
	private String tenure;
	private String baseTid;
	private String baseMid;
	private String emiType;
	private String emiMatCode;
	private String emiMid;
	private String emiTid;
	private String mosambeeEmi;
	private String emi;
	private String emiEnquiry;
	private String emiProgramEnquiry;
	private String emiVoid;
	private String emiSettlement;
	private String ccEmiFlag;
	private String dcEmiFlag;
	private String brandEmiFlag;
	private String acquirer;
	private String acquirerTgId;
	private String tgName;
	private String merchantCode;
	private String emiAllow;
	private long userId;
	private long merchantType;
	private int errorCode;

}
