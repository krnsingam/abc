package com.mosambee.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * This class is used to store data for updating SBI EMI Details
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 */
@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EditSbiDetailsBean {
	
	//For MID
	private String mPosMerchantId;
	private String merchantName;
	private String merchantCity;
	
	//using below fields while updating record
	private int status;
	private int setupFileStatus;
	
	//For TID
	private String mPosTerminalId;
	private String skuName;
	private String storeName;
	private String storeCity;
	
	//using below fields while updating record
	private int tidStatus;
	private int tidSetupFileStatus;
	private int skuStatus;
	private int skuSetupFileStatus;
	
	//using below fields to go to the Edit page from the List
	private long sbiId;
	private String type;
	
}
