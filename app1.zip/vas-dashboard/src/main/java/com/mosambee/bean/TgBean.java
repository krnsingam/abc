package com.mosambee.bean;

import com.mosambee.controller.TgController;

import lombok.Builder;
import lombok.Data;
/**
 * TgBean is basically used to carry response parameters for viewTgList method of
 * {@link TgController} 
 * @author mariam.siddique
 * @version 1.0
 * @since 08-April-2020
 */
@Builder
@Data
public class TgBean {

	private String tgName;
	private String ipAddress;
	private int port;
	private String url;
	private String status;
	private long tgId;
}
