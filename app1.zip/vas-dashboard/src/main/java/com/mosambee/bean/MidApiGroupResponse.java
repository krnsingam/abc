package com.mosambee.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * MidApiGroupResponse basically used to represent the parsed row data .
 * 
 * @author karan.singam
 * @version 1.0
 * @since 28-January-2020
 */
@Data
@SuperBuilder
@NoArgsConstructor
public class MidApiGroupResponse {

	@JsonProperty(value = "Status")
	private String status;
	
	@JsonProperty(value = "ErrorMsg")
	private String errorMsg;
	
	@JsonProperty(value = "PartnerCode")
	private String partnerCode;
	
}
