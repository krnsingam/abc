package com.mosambee.bean;

import com.mosambee.constants.CommonConstants;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * This class is responsible for hold data information for emi upload excel
 * response
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
public class EmiUploadBean extends EmiBean {
	private String status;

	/**
	 * Method to append status to existing status
	 * 
	 * @param status
	 */
	public void appendStatus(String status) {
		StringBuilder builder = new StringBuilder();
		builder.append(this.status);
		builder.append(CommonConstants.SPACE.get());
		builder.append(status);
		this.status = builder.toString();

	}

}
