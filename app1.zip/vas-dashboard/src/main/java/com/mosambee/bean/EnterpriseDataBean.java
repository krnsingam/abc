package com.mosambee.bean;

import com.mosambee.bean.datatables.DataTablesRequest;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * TransactionDateReportBean basically used to represent the parsed row data for Transaction Report with Data Tables.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 15-January-2020
 */
@Data
@SuperBuilder
@ToString
@NoArgsConstructor
public class EnterpriseDataBean {

	private DataTablesRequest dataTable;
	private String fromDate;
	private String toDate;
	private Long eid;
	
}
