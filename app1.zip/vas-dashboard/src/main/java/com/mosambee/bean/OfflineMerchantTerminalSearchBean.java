package com.mosambee.bean;

import javax.validation.constraints.NotNull;

import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.controller.OfflineMerchantsController;

import lombok.Data;
import lombok.ToString;
/**
 * OfflineMerchantTerminalSearchBean is basically used to carry request parameter for getOfflineMerchantTerminalList method of
 * {@link OfflineMerchantsController} 
 * @author mariam.siddique
 * @version 1.0
 * @since 01-April-2020
 */
@ToString
@Data
public class OfflineMerchantTerminalSearchBean {
	
	private DataTablesRequest dtRequest;
	
	@NotNull
	private long merchantId;

}
