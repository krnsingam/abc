package com.mosambee.bean;

import java.util.Map;

import org.springframework.validation.annotation.Validated;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * This class is using to set and get values of add bqr merchant ,edit bqr
 * merchants,update bqr merchants and display bqr merchants list
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Validated
public class AddBqrMerchantsBean {

	private String merchantId;

	private String terminalId;

	private String visaNetworkId1;

	private String visaNetworkId2;

	private String masterCardNetworkId1;

	private String masterCardNetworkId2;

	private String npciNetworkId1;

	private String npciNetworkId2;

	private String referenceTag09;

	private String referenceTag10;

	private String ifscAccountNo;

	private String amexNetworkId1;

	private String amexNetworkId2;

	private String merchantCategoriesCode;

	private String currencyCode;

	private String countryCode;

	private String qrMerchantName;
	private String merchantCity;
	private String postalCode;
	private String acquirer;
	private String status;
	private String smsFlag;
	private String tipIndicator;
	private String message;
	private String error;
	private long id;
	private String serialNo;
	Map<String, Object> data;

}
