package com.mosambee.bean;

import com.mosambee.bean.datatables.DataTablesRequest;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * MerchantKeyDataBean basically used to represent the parsed row data for Merchant Key with Data Tables.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 03-March-2020
 */
@Data
@SuperBuilder
@ToString
@NoArgsConstructor
public class MerchantKeyDataBean {

	private DataTablesRequest dataTable;
	
	private String merchant;
	
	private String merchantKey;

	private String merchantCode;
}
