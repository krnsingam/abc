package com.mosambee.bean;

import org.springframework.validation.annotation.Validated;

import com.mosambee.bean.datatables.DataTablesRequest;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * This class is Validating settlement type ,first name,type,startTime , endTime and reason role input field and this is using
 * for datatable request for view settltement list
 * @author rahul.mishra
 * @version 1.0
 */
@Validated
@SuperBuilder
@ToString
@NoArgsConstructor
@Data
public class SettlementDataTableCrudBean {
	DataTablesRequest dtRequest;
	
	private String settlementType;
	private String settlementTypeSearch;
	private String firstName;
	private String type;
	private String startTime;
	private String endTime;
	private String reason;
}
