package com.mosambee.bean;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * This class is used to store values from the incoming request
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 */
@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AddSbiDetailsTidBean {

	@NotNull(message = "mPos Merchant Id cannot be null.")
	@Size(max = 45, message = "mPos Merchant Id Length should not be exceed 45 characters.")
	@Pattern(regexp = "^[a-zA-Z\\d]+((\\s)*[a-zA-Z\\d])*$",message = "i.Special characters are not allowed \nii.Id should not start or end with space")  
	private String mPosMerchantId;
	
	@NotNull(message = "mPos Terminal Id cannot be null.")
	@Size(max = 45, message = "mPos Terminal Id Length should not be exceed 45 characters.")
	@Pattern(regexp = "^[a-zA-Z\\d]+((\\s)*[a-zA-Z\\d])*$",message = "i.Special characters are not allowed \nii.Id should not start or end with space")  
	private String mPosTerminalId;
	
	@NotNull(message = "SKU Name cannot be null.")
	@Size(max = 45, message = "SKU Name Length should not be exceed 45 characters.")
	@Pattern(regexp = "^[a-zA-Z\\d]+((\\s)*[a-zA-Z\\d])*$",message = "i.Special characters are not allowed \nii.Name should not start or end with space")
	private String skuName;
	
	@NotNull(message = "Store Name cannot be null.")
	@Size(max = 45, message = "Store Name Length should not be exceed 45 characters.")
	@Pattern(regexp = "^[a-zA-Z\\d]+((\\s)*[a-zA-Z\\d])*$",message = "i.Special characters are not allowed \nii.Name should not start or end with space")
	private String storeName;
	
	@NotNull(message = "Store City cannot be null.")
	@Size(max = 45, message = "Store City Length should not be exceed 45 characters.")
	@Pattern(regexp = "^[a-zA-Z\\d]+((\\s)*[a-zA-Z\\d])*$",message = "i.Special characters are not allowed \nii.City should not start or end with space")
	private String storeCity;
	
	//below fields are shown while updating record
	private int tidStatus;
	
	private int tidSetupFileStatus;
	
	private int skuStatus;
	
	private int skuSetupFileStatus;
	
	
}
