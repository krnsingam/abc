package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * MidApiGroupDaetailBean basically used to represent the parsed row data .
 * 
 * @author karan.singam
 * @version 1.0
 * @since 28-January-2020
 */
@Data
@SuperBuilder
@NoArgsConstructor
public class MidApiGroupDaetailBean {
	
	private String apiUrl1;
	private String apiUrl2;
	private String divRefNo1;
	private String divRefNo2;
	private String divRefNo3;
	private String mPosApiPassword;

}
