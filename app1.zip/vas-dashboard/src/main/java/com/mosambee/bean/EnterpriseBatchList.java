package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * EnterpriseBatchList is used to hold the result data of Enterprise search fields
 * @author karan.singam
 * @date 22-04-2020
 */

@Data
@SuperBuilder
@NoArgsConstructor
public class EnterpriseBatchList {

	Long id;
	Long batchNumber;
	Long sales;
	Long voidCount;
	Long refund;
	Double salesAmount;
	Double voidAmount;
	Double refundAmount;
	String tid;
	
}
