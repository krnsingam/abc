package com.mosambee.bean;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * TgCrudBean is used in tg CRUD operation to hold tg data
 * @author mariam.siddique
 * @since 08-April-2020
 */
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Data
public class TgCrudBean {

	private long id;
	
	@NotEmpty(message="Please enter Tg name")
	private String tgName;
	
	@NotEmpty(message="Please enter Ip address")
	@Pattern(regexp="^[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}$",message="Please enter valid Ip Address") 
	private String ipAddress;
	
	@NotNull(message="Please enter Port")
	private int port;
	
	@NotEmpty(message="Please enter IP address")
	@Pattern(regexp="^(http|https)?:\\/\\/[a-zA-Z0-9-\\.]+\\.[a-z]{2,4}",message="Please enter valid first name") 
	private String url;
	
	@NotEmpty(message="Please enter Test Ip address")
	@Pattern(regexp="^[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}$",message="Please enter valid first name") 
	private String testIpAddress;
	
	@NotNull(message="Please enter IP address")
	private int testPort;
	
	@Pattern(regexp="(?:^(http|https)?:\\/\\/[a-zA-Z0-9-\\.]+\\.[a-z]{2,4})?",message="Please enter valid first name") 
	private String testUrl;
	
}
