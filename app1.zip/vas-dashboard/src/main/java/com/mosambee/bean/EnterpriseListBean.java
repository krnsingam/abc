package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * EnterpriseListBean basically used to represent the parsed row data for list of enterprise.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 31-March-2020
 */
@Data
@SuperBuilder
@ToString
@NoArgsConstructor
public class EnterpriseListBean {

	private long eId;
	private String enterpriseName;
	private Long numberOfTerminals;
	private Long totalSales;
	private Long totalTransaction;
	private Long declinedTransaction;
	private String viewEnterprise;
	
}
