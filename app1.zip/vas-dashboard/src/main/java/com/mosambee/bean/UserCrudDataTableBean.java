package com.mosambee.bean;

import org.springframework.validation.annotation.Validated;

import com.mosambee.bean.datatables.DataTablesRequest;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * This class is Validating username ,status and role input field and this is using
 * for datatable request for view users list
 * 
 * @author rahul.mishra
 * @version 1.0
 */
@Validated
@SuperBuilder
@ToString
@NoArgsConstructor
@Data
public class UserCrudDataTableBean {
	DataTablesRequest dtRequest;
	
	private String username;
	private String status;
	private String role;
}
