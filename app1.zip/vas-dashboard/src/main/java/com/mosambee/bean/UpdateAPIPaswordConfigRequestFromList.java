package com.mosambee.bean;

import javax.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This bean is used in {@link APIPasswordConfigController} to fetch update request for APIPasswordConfig. 
 * @version 1.0
 * @author mandar.chaudhari
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UpdateAPIPaswordConfigRequestFromList {
	@Min(value=1,message = "Id should not be less than 1")
	long id;
}
