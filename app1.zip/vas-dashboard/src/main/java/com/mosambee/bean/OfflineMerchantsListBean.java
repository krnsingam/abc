package com.mosambee.bean;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
/**
 * OfflineMerchantsListBean is basically used to carry response parameter for getOfflineMerchantsList method of
 * {@link OfflineMerchantsController} 
 * @author mariam.siddique
 * @version 1.0
 * @since 01-April-2020
 */
public class OfflineMerchantsListBean {

	private long merchantId;
	private String merchantName;
	private long noOfTerminals;
	
	
}
