package com.mosambee.bean;

import lombok.Builder;
import lombok.Data;
/**
 * BillNumberBean is basically used to carry response parameters for viewBillNumberTransactionList method of
 * {@link SearchByBillNumberController} 
 * @author mariam.siddique
 * @version 1.0
 * @since 23-March-2020
 */
@Builder
@Data
public class BillNumberBean {
	
	private String userName;
	private String txnType;
	private String terminalId;
	private String cardNumber;
	private String rrn;
	private double amount;
	private String txnTime;
	private String responseCode;
	private String authCode;
	private String status;
	private String settlementStatus;
	private long transactionId;

}
