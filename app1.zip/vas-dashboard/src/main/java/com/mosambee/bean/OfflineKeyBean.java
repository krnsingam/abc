package com.mosambee.bean;

import lombok.Builder;
import lombok.Data;
/**
 * OfflineMerchantsSearchBean is basically used to carry request parameter for setBulkOfflineKey method of
 * {@link OfflineMerchantsController} 
 * @author mariam.siddique
 * @version 1.0
 * @since 01-April-2020
 */
@Builder
@Data
public class OfflineKeyBean {
	
	private long merchantId;
	private long tableTerminalId;

}
