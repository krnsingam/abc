package com.mosambee.bean;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@ToString
@NoArgsConstructor
public class InitiateSettlementBean {
	
	@NotNull(message="Please enter time")
	private int time;
	
    @NotEmpty(message="Please enter reason")
    @Pattern(regexp="^[a-zA-Z ]+[a-zA-Z ]+$",message="Please enter valid reason")
	private String reason;
    
    private String success;    
    
}
