package com.mosambee.bean;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PasswordBean {
	private String password;
	private String email;
	private long roleId;
	private String message;
	private long userId;
	private String userName;
	


}
