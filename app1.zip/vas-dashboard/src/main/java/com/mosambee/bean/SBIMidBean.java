package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * This class is used to upload fields in sbi emi mid upload
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 */
@Data
@SuperBuilder
@NoArgsConstructor
public class SBIMidBean {
	
	private String mPosMid;
	private String merchantName;
	private String merchantCity;
	//private String message;// "status" column in upload file
}
