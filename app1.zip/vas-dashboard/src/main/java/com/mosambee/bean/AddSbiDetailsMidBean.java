package com.mosambee.bean;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * This class is used to store values from the incoming request 
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 */
@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AddSbiDetailsMidBean {

	@NotNull(message = "mPos Merchant Id cannot be null.")
	@Size(max = 45, message = "mPos Merchant Id Length should not be exceed 45 characters.")
	@Pattern(regexp = "^[a-zA-Z\\d]+((\\s)*[a-zA-Z\\d])*$",message = "i.Special characters are not allowed \nii.Id should not start or end with space")  
	private String mPosMerchantId;
	
	@NotNull(message = "Merchant Name cannot be null.")
	@Size(max = 45, message = "Merchant Name Length should not be exceed 45 characters.")
	@Pattern(regexp = "^[a-zA-Z\\d]+((\\s)*[a-zA-Z\\d])*$",message = "i.Special characters are not allowed \nii.Name should not start or end with space")
	private String merchantName;
	
	@NotNull(message = "Merchant City cannot be null.")
	@Size(max = 45, message = "Merchant City Length should not be exceed 45 characters.")
	@Pattern(regexp = "^[a-zA-Z\\d]+((\\s)*[a-zA-Z\\d])*$",message = "i.Special characters are not allowed \nii.City should not start or end with space")
	private String merchantCity;
	
	
	//below fields are shown while updating record
	private int status;
	
	private int setupFileStatus;
	
	
}
