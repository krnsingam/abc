package com.mosambee.bean;

import javax.validation.constraints.Size;

import com.mosambee.constants.CommonConstants;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * MerchantMappingBean basically used to represent the parsed row data for Merchant specific data.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 27-February-2020
 */
@Data
@SuperBuilder
@ToString
@NoArgsConstructor
public class MerchantMappingBean {

	long merchMapId;
	
	long merchantId;
	
	@Size(max = 100, message = "Merchant name size should not be maximum 100 characters.")
	String merchantName;
	
	@Size(max = 150, message = "Class path size should not be maximum 150 characters.")
	String classPath;
	
	@Size(max = 300, message = "Url size should not be maximum 300 characters.")
	String url;
	
	private long srno;
	
	private String validationMsg;
	
	private boolean validate;
	
	/**
	 * Method to append validationMsg to existing validationMsg.
	 * @param status
	 * @return Nothing
	 */
	public void appendStatus(String validationMsg) {
		StringBuilder builder = new StringBuilder();
		builder.append(this.validationMsg);
		builder.append(CommonConstants.SPACE.get());
		builder.append(validationMsg);
		this.validationMsg = builder.toString();
	}
}
