package com.mosambee.bean;

import com.mosambee.bean.datatables.DataTablesRequest;

import lombok.Data;
import lombok.ToString;


/**
 * OfflineMerchantsSearchBean is basically used to carry request parameter for getOfflineMerchantsList method of
 * {@link OfflineMerchantsController} 
 * @author mariam.siddique
 * @version 1.0
 * @since 01-April-2020
 */
@ToString
@Data
public class OfflineMerchantsSearchBean {

	private DataTablesRequest dtRequest;
	
	private String merchantName;
	private String merchantCode;
 
}
