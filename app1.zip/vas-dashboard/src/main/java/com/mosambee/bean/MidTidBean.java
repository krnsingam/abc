package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * MidTidBean basically used to represent the parsed row data for Mid Tid.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 10-February-2020
 */
@Data
@SuperBuilder
@NoArgsConstructor
public class MidTidBean {

	private String mid;
	private String tid;
	private String divCode;
	private String serialNo;
	
}
