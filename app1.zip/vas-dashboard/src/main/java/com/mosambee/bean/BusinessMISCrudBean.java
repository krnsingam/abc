package com.mosambee.bean;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * BusinessMISCrudBean is used in business-MIS CRUD operation to hold update business-MIS data
 * @author mariam.siddique
 * @since 15-April-2020
 */
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Data
public class BusinessMISCrudBean {
	
	@NotEmpty(message="Please enter User Number")
	@Pattern(regexp="(?:^[a-zA-Z0-9]+$)?",message="Please enter validd User Number") 
	private String userNumber;
	
	@NotEmpty(message="Please select Activation request date")
	private String activationRequestDate;
	
	@NotEmpty(message="Please select Activation confirmation date")
	private String activationConfirmationDate;
}
