package com.mosambee.bean;

import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * BusinessMISCrudBean is used in business-MIS CRUD operation to hold download business-MIS data
 * @author mariam.siddique
 * @since 15-April-2020
 */
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Data
public class BusinessMISDownloadCrudBean {

	@NotEmpty(message="Please select Acquirer")
	private String acquirer;
	
	@NotEmpty(message="Please enter formDate")
	private String fromDate;
	
	@NotEmpty(message="Please enter toDate")
	private String toDate;
	
}
