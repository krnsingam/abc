package com.mosambee.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * NetworkMessagesDownloadBean basically used to represent the parsed row data for Download Business-MIS.
 * 
 * @author maria.siddique
 * @version 1.0
 * @since 15-April-2020
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BusinessMISDownloadResponseBean {
	
	private String mId;
	private String merchantName;
	private String merchantPhone;
	private String merchantContactPerson;
	private String merchantEmail;
	private String merchantAddress;
	private String merchantState;
	private String merchantCity;
	private String merchantPin;
	private String merchantUser;
	private String merchantUserName;
	private String merchantUserStatus;
	private String merchantDebitTid;
	private String merchantCreditTid;
	private String merchantAcq;

	private String month;
	private String reqDateAcq;
	private String confirmDateAcq;
	private String installReqDate;
	private String installDate;
	private String withingTAT;
	private String serialNo;
	private String deactivationDate;
	private String deactivationComment;

}
