package com.mosambee.bean.datatables;

import java.util.Collections;
import java.util.List;

import lombok.Data;
import lombok.ToString;

/**
 * Bean to represent the response corresponding to a 
 * data-tables request.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 20-December-2019
 * 
 * @param <T>
 */
@Data
@ToString
public class DataTablesResponse<T> {
	private int draw;
	private int recordsTotal;
	private int recordsFiltered;
	private List<T> data = Collections.emptyList();
}