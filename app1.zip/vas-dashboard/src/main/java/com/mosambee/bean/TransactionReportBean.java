package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * TransactionReportBean basically used to represent the parsed row data for Transaction Report.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 10-January-2020
 */
@Data
@SuperBuilder
@NoArgsConstructor
public class TransactionReportBean {

	 int id;
	 int enquiryId;
	 String txnRefNo;
	 String rrn;
	 String fromDate;
	 String toDate;
	 String authCode;
	 String binValue;
	 String txnAmount;
	 String issuer;
	 String status;
	 String emiStatus;
	 String conversionStatus;
	 String emiAmount;
	 String interestRate;
	 String tenure;
	 String cardType;
	 String txnTime;
	 private String emiConverted;
	 private String comment;
	 private String settlementStatus;

}
