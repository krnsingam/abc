package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * EmiTidBulkUploadBean is responsible for bulk upload.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 02-February-2020
 */
@SuperBuilder
@ToString
@NoArgsConstructor
@Data
public class EmiTidBulkUploadBean {

	
	private String emiTidDetail;
	private String transactioinType;

	
}
