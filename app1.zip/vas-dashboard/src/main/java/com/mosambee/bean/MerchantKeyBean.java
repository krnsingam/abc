package com.mosambee.bean;

import javax.validation.constraints.Size;

import com.mosambee.constants.CommonConstants;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * MerchantKeyBean basically used to represent the parsed row data for Merchant specific data.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 27-February-2020
 */
@Data
@SuperBuilder
@ToString
@NoArgsConstructor
public class MerchantKeyBean {

	long merchKeyId;
	
	@Size(max = 100, message = "Merchant name size should not be maximum 100 characters.")
	String merchant;
	
	@Size(max = 500, message = "Merchant key size should not be maximum 500 characters.")
	String merchantKey;
	
	@Size(max = 20, message = "Merchant code size should not be maximum 20 characters.")
	String merchantCode;
	
	private long srno;
	
	private String validationMsg;
	
	private boolean validate;
	
	/**
	 * Method to append validationMsg to existing validationMsg.
	 * @param status
	 * @return Nothing
	 */
	public void appendStatus(String validationMsg) {
		StringBuilder builder = new StringBuilder();
		builder.append(this.validationMsg);
		builder.append(CommonConstants.SPACE.get());
		builder.append(validationMsg);
		this.validationMsg = builder.toString();
	}
}
