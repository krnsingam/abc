package com.mosambee.bean;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
/**
 * UserCrudBean is used in user crud operation to hold user data 
 * @author rahul.mishra
 *
 */
public class UserCrudBean {
	private long id;
	private String username;
	private String password;
	private Role role;
    private String status;

    
    @NotEmpty(message="Please select role")
    private String roleName;
    
    @NotEmpty(message="Please enter first name")
    @Pattern(regexp="^[a-zA-Z]+[a-zA-Z]+$",message="Please enter valid first name") 
    private String firstName;
    
    @NotEmpty(message="Please enter last name")
    @Pattern(regexp="^[a-zA-Z]+[a-zA-Z]+$",message="Please enter valid last name") 
    private String lastName;
    
    @NotEmpty(message="Please enter email")
    @Email
    private String email;
	
    
    public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "UserCrudBean [id=" + id + ", username=" + username + ", password=" + password + ", role=" + role
				+ ", status=" + status + ", roleName=" + roleName + ", firstName=" + firstName + ", lastName="
				+ lastName + ", email=" + email + "]";
	}
    
    
} 
