package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * AcquirerBean is used to hold acquirer data eq. id and name
 * @author rahul.mishra
 * @date 06-03-2020
 */

@Data
@SuperBuilder
@NoArgsConstructor
public class AcquirerBean {
	private long id;
	private String name;
}
