package com.mosambee.bean.datatables;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.ToString;

/**
 * Bean to represent order in data-tables request.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 20-December-2019
 */
@Data
@ToString
public class DataTablesOrder {
	public enum Direction {
		@JsonProperty("asc") ASC, 
		@JsonProperty("desc") DESC
	}

	private int column;
	private Direction dir;
}