package com.mosambee.bean;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class Role {
	
	private int id;
	private String name;

}
