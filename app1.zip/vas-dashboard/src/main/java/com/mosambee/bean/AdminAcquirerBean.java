package com.mosambee.bean;

import lombok.Builder;
import lombok.Data;
/**
 * AdminAcquirerBean is basically used to carry response parameter for viewAdminAcquirerList method of
 * {@link AdminAcquirerController} 
 * @author mariam.siddique
 * @version 1.0
 * @since 18-March-2020
 */
@Builder
@Data
public class AdminAcquirerBean {

	private long acqId;
	private String acqName;
	private int noOfMid;
	private int noOfUsers;
	private int saleTxn;
	private String saleTxnValue;
	private int declinedTxn;
	private String lastTxnDate;
	private int serialNo;

}
