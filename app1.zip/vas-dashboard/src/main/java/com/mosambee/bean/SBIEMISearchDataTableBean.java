package com.mosambee.bean;

import com.mosambee.bean.datatables.DataTablesRequest;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * SBIEMISearchDataTableBean is basically used to represent the parsed row data for SBI EMI Listing with Data Tables.
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 * @since 30-March-2020
 */
@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class SBIEMISearchDataTableBean {
	
	private DataTablesRequest dataTableParameters;
	
	private String merchantId;
	
	private String terminalId;
	
	private String type;
}
