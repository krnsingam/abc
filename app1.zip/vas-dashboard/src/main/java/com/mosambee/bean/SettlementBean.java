package com.mosambee.bean;

import lombok.Builder;

/**
 * SettlementBean is used to hold the settlement data
 * @author rahul.mishra
 *
 */
@Builder
public class SettlementBean {
	private String receivingInstitutionCode;
	private String summary;
	private String settlementFor;
	private String initiatedBy;
	private String type;
	private String startTime;
	private String endTime;
	private String reason;
	private String settlementDate;

	public String getReceivingInstitutionCode() {
		return receivingInstitutionCode;
	}

	public void setReceivingInstitutionCode(String receivingInstitutionCode) {
		this.receivingInstitutionCode = receivingInstitutionCode;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getSettlementFor() {
		return settlementFor;
	}

	public void setSettlementFor(String settlementFor) {
		this.settlementFor = settlementFor;
	}

	public String getInitiatedBy() {
		return initiatedBy;
	}

	public void setInitiatedBy(String initiatedBy) {
		this.initiatedBy = initiatedBy;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(String settlementDate) {
		this.settlementDate = settlementDate;
	}	
}
