package com.mosambee.bean;

import com.mosambee.constants.CommonConstants;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * This class is used when we are creating ApiPasswordBean.
 * The object of this class is used in ApiPasswordController as a parameter for controller methods.  
 * This class object we send back to jsp pages to render data using "JSTL".
 * @author karan.singam
 * @version 1.0
 */

@Data
@SuperBuilder
@ToString
@NoArgsConstructor
public class ApiPasswordBean {
	
	private long id;
	
	private String businessName;
	
	private String merchantCode;
	
	private String apiPassword;
	
	private long srNumber;
	
	private byte flag;
	
	private boolean validate;
	
	private String validationMsg;
	
	/**
	 * Method to append validationMsg to existing validationMsg.
	 * @param status
	 * @return Nothing
	 */
	public void appendStatus(String validationMsg) {
		StringBuilder builder = new StringBuilder();
		builder.append(this.validationMsg);
		builder.append(CommonConstants.SPACE.get());
		builder.append(validationMsg);
		this.validationMsg = builder.toString();
	}
}
