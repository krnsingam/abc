package com.mosambee.bean;

import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.controller.SearchByBillNumberController;

import lombok.Data;
import lombok.ToString;
/**
 * BillNumberDataTablesRequestBean is basically used to carry request parameter for viewBillNumberTransactionList method of
 * {@link SearchByBillNumberController} 
 * @author mariam.siddique
 * @version 1.0
 * @since 23-March-2020
 */
@Validated
@ToString
@Data
public class BillNumberDataTablesRequestBean {
	
	private DataTablesRequest dtRequest;

	@NotNull
	private String billNumber;
	

}
