package com.mosambee.bean.datatables;

import lombok.Data;
import lombok.ToString;

/**
 * Bean to represent the search parameter in data-tables request.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 20-December-2019
 */
@Data
@ToString
public class DataTablesSearch {
	private String value;
	private boolean regex;
}