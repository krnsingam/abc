package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * EnterpriseNoOfTerminalBean is used to hold the result data of Enterprise search fields
 * @author karan.singam
 * @date 22-04-2020
 */

@Data
@SuperBuilder
@NoArgsConstructor
public class EnterpriseNoOfTerminalBean {

	Long id;
	Long userId;
	String mobileNo;
	Long noOfTransaction;
	Long batches;
	Long noOfCnpTransaction;
	Long noOfFailedTransaction;
	
}
