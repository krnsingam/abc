package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * ProgramBean basically used to represent the parsed row data from program bulk
 * upload.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 20-December-2019
 */
@Data
@SuperBuilder
@NoArgsConstructor
public class ProgramBean {

	private String programName;
	private String programDescription;
	private String programPriority;
	private String programDomain;
	private String programStartDateTime;
	private String programEndDateTime;
	private String programCumulativeCount;
	private String programCumulativeCountMode;

}
