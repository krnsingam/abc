package com.mosambee.bean.datatables;

import java.util.Collections;
import java.util.List;

import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.ToString;

/**
 * Bean to represent the data-tables request.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 20-December-2019
 */
@Data
@ToString
public class DataTablesRequest {
	@NotNull
	private int draw;

	@NotNull
	private int start;
	
    @NotNull
	private int length;

	private DataTablesSearch search;

	private List<DataTablesColumn> columns = Collections.emptyList();

	private List<DataTablesOrder> order = Collections.emptyList();
}