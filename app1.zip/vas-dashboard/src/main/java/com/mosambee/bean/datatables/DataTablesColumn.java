package com.mosambee.bean.datatables;

import lombok.Data;
import lombok.ToString;

/**
 * Bean to represent column in data-tables request body.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 20-December-2019
 */
@Data
@ToString
public class DataTablesColumn {
	private String name;
	private boolean searchable;
	private boolean orderable;
	private DataTablesSearch search;
}