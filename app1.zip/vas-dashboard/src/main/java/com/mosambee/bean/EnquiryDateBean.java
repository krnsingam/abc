package com.mosambee.bean;

import lombok.Data;


/**
 * This class is Validating cardBin and enquiryId input field and This class is
 * using for download the enquiry detail
 * 
 * @author pooja.singh
 * @version 1.0
 */

@Data
public class EnquiryDateBean {

	private String fromDate;
	private String toDate;	
	private String cardBin;
	private String id;
	private String issuer;
}