package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * BlockedUserBean is used to create to hold the blocked users data
 * @author rahul.mishra
 *
 */
@Data
@SuperBuilder
@ToString
@NoArgsConstructor
public class BlockedUserBean {
		private long id;
		private String userName;
		private String firstName;
		private String email;
		private String blockDate;
		private String expireDate;

}
