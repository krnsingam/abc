package com.mosambee.bean;

import com.mosambee.bean.datatables.DataTablesRequest;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * ApiPasswordDataBean basically used to represent the parsed row data for Transaction Report with Data Tables.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 16-March-2020
 */
@Data
@SuperBuilder
@ToString
@NoArgsConstructor
public class ApiPasswordDataBean {

	private DataTablesRequest dataTable;
	private String businessName;
	private String merchantCode;
	private String apiPassword;
	
}
