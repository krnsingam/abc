package com.mosambee.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This class is used to store values from the incoming request 
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdminAddAcquirerBean {
	
	private String name;
	private String zmk;
	private String zpk;
	private String zek;
	private double tipPercent;
	private String apkName;
	private int currencyId;
	private int decimalAmountLength;
	private int serverTimeInMin;
	private int mobileNoLength;
	
}
