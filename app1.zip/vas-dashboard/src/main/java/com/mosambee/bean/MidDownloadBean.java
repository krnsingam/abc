package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * This class is using for downloadMid and upload MID to display values
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Data
@SuperBuilder
@NoArgsConstructor
public class MidDownloadBean {
	private String fromDate;
	private String toDate;
	private String posId;
	private String tempTid;
	private String tempMerchantCode;// tempMid
	private String typeId;
	private String createdTime;
	private String acquirer;
	private String mid;// peproMid//merchantCode
	private String tid;

}
