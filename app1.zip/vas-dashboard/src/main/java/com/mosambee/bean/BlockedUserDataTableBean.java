package com.mosambee.bean;

import org.springframework.validation.annotation.Validated;
import com.mosambee.bean.datatables.DataTablesRequest;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * This class is Validating username ,firstname and email,blockdate,expirydate input field and this is using
 * for datatable request for view users list
 * 
 * @author rahul.mishra
 * @version 1.0
 */
@Validated
@SuperBuilder
@ToString
@NoArgsConstructor
@Data
public class BlockedUserDataTableBean {
	DataTablesRequest dtRequest;
	String username;
	String firstName;
	String email;
	String blockDate;
	String expiryDate;
}
