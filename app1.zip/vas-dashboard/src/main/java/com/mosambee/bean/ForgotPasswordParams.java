package com.mosambee.bean;

import lombok.Builder;
import lombok.Data;

/**
 * Represents forgot password parameters corresponding to provided email
 * address.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 03-February-2020
 */
@Data
@Builder
public class ForgotPasswordParams {

	private long userId;
	private String username;
	private int roleId;
	private String message;
	private String firstName;

}
