package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * EmiTidBulkUploadBean is responsible for bulk upload.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 11-February-2020
 */
@SuperBuilder
@ToString
@NoArgsConstructor
@Data
public class EmiTidBulkUploadSubBean {
	
	private String emiTid;
	private String emiMid;
	private String baseTid;
	private String baseMid;
	private String emiType;
	private String emiMatCode;
	private String emi;
	private String emiEnquiry;
	private String emiProgramEnquiry;
	private String emiVoid;
	private String emiSettelment;
	
}
