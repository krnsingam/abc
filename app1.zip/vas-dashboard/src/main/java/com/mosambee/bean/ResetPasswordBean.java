package com.mosambee.bean;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.mosambee.controller.ResetPasswordController;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Reset password bean is responsible mapping the incoming model attribute in
 * {@link ResetPasswordController}
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 05-February-2020
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ResetPasswordBean {

	@NotNull(message = "new password field cannot be null.")
	@Pattern(regexp = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,15})", message = "New password must have atleast 1 digit, 1 lower case character, 1 upper case character. Size must be between 8 and 5. Contains one special character from @#$%!")
	private String newPassword;

	@NotNull(message = "confirm new password field cannot be null.")
	@Pattern(regexp = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,15})", message = "Confirm password must have atleast 1 digit, 1 lower case character, 1 upper case character. Size must be between 8 and 5. Contains one special character from @#$%!")
	private String confirmNewPassword;

}
