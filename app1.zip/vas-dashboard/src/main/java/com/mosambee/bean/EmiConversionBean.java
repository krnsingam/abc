package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * This class is using for upload fields in emi conversion upload
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Data
@SuperBuilder
@NoArgsConstructor
public class EmiConversionBean {
	private String issuer;
	private String txnRefId;
	private String message;// status
	private String comment;

}
