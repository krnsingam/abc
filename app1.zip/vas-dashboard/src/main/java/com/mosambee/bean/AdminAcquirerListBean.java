package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * AdminAcquirerListBean is basically used to carry response parameter for getAcquirerList method of
 * {@link AdminAcquirerController}
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 * @since 16-April-2020
 */
@Data
@NoArgsConstructor
public class AdminAcquirerListBean {
		
		private String srNo;
	
		//To identify single record from the list
		private long acqId;
		
		//Fields
		private String name;
		private String zmk;
		private String zpk;
		private String zek;
		private String tipPercent;
		private String apkName;
		private int decimalAmountLength;
		private int serverTimeInMin;
		private int mobileNoLength;
		
		private String currencyCode;
}
