package com.mosambee.bean;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import org.springframework.validation.annotation.Validated;
import com.mosambee.bean.datatables.DataTablesRequest;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * This class is Validating cardBin and enquiryId input field and this is using
 * for datatable request for viewEnqiry list
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Validated
@SuperBuilder
@ToString
@NoArgsConstructor
@Data
public class EnquiryDataTablesRequestBean {

	DataTablesRequest dtRequest;

	@NotNull
	private String fromDate;
	@NotNull
	private String toDate;

	@Positive
	@Size(min = 6, max = 8, message = " please enter valid input")
	private int cardBin;

	@Positive
	@Size(min = 1, max = 19, message = "please enter valid input")
	private long id;

	private String issuer;

}
