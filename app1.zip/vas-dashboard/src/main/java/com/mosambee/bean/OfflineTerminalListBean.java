package com.mosambee.bean;

import lombok.Builder;
import lombok.Data;

/**
 * OfflineTerminalListBean is basically used to carry response parameter for getOfflineTerminalList and getOfflineMerchantTerminalList methods of
 * {@link OfflineMerchantsController} 
 * @author mariam.siddique
 * @version 1.0
 * @since 01-April-2020
 */
@Builder
@Data
public class OfflineTerminalListBean {
	
	private String userId;
	private String terminalId;
	private String offlineKey;

}
