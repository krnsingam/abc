package com.mosambee.bean;

import com.mosambee.constants.CommonConstants;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * EnterpriseBean basically used to represent the parsed row data for Add enterprise.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 24-March-2020
 */
@Data
@SuperBuilder
@ToString
@NoArgsConstructor
public class EnterpriseBean {

	private long eId;
	private String name;
	private String tz;
	private String address1;
	private String address2;
	private String landmark;
	private long country;
	private long state;
	private long city;
	private String pin;
	private String phone;
	private long level;
	private long recStatus;
	private long clientStatus;
	private long pentId;
	private long clientId;
	private long addressId;
	private boolean validate;	
	private String validationMsg;

	
	/**
	 * Method to append validationMsg to existing validationMsg.
	 * @param status
	 * @return Nothing
	 */
	public void appendStatus(String validationMsg) {
		StringBuilder builder = new StringBuilder();
		builder.append(this.validationMsg);
		builder.append(CommonConstants.SPACE.get());
		builder.append(validationMsg);
		this.validationMsg = builder.toString();
	}
}
