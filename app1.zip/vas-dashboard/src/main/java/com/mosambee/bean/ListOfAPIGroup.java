package com.mosambee.bean;

import lombok.Builder;
import lombok.Data;


/**
 * This bean is used for fetching records of API Password Config list from database
 * @author mandar.chaudhari
 * @version 1.0
 */
@Builder
@Data
public class ListOfAPIGroup {
	private String apiDivisionName;
	private String apiDivisionCode;
	private String apiPassword;
	private String apiURL1;
	private String divisionStatus;
	private long id;
    private String serialNo;
    private long midCount;
}
