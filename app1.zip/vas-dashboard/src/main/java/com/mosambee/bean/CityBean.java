package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * CityBean is responsible for carrying the city id and code.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 11-February-2020
 */
@SuperBuilder
@ToString
@NoArgsConstructor
@Data
public class CityBean {

	private long id;
	private String name;
}
