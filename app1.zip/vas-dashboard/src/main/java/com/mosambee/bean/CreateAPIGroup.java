package com.mosambee.bean;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.springframework.format.annotation.NumberFormat;
import org.springframework.validation.annotation.Validated;

import com.mosambee.constants.CommonConstants;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * This class is used when we are creating APIPasswordConfig.
 * The object of this class is used in APIPasswordConfigController as a parameter for controller methods.  
 * This class object we send back to jsp pages to render data using "JSTL".
 * @author mandar.chaudhari
 * @version 1.0
 */

@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Validated
public class CreateAPIGroup {
	
	@NumberFormat
	private long id;
	
	@NotNull(message = "Api Division Name cannot be null.")
	@Size(max = 150, message = "API Division Name size should not be maximum 150 characters.")
	@Pattern(regexp = "^[a-zA-Z\\d]+((\\s)*[a-zA-Z\\d])*$",message = "i.Special characters are not allowed \nii.Name should not start or end with space")
	private String apiDivisionName;
	
	private String apiDivisionCode;
	
	@Size(max = 45, message = "API Password size should not be maximum 45 characters.")
	private String apiPassword;
	
	@Size(max = 250, message = "API URL 1 size should be maximum 250 characters.")
	private String apiURL1;
	
	@Size(max = 250, message = "API URL 2 size should be maximum 250 characters.")
	private String apiURL2;
	
	@Size(max = 45, message = "Division Reference 1 size should be maximum 45 characters.")
	private String divisionRef1;
	
	@Size(max = 45, message = "Division Reference 2 size should be maximum 45 characters.")
	private String divisionRef2;
	
	@Size(max = 45, message = "Division Reference 3 size should be maximum 45 characters.")
	private String divisionRef3;
	
	@Size(max = 45, message = "Division Reference 4 size should be maximum 45 characters.")
	private String divisionRef4;
	
	@NumberFormat
	@Max(value=1,message = "Division Status could not be greater than 1")
	@Min(value=0,message = "Division Status could not be less than 0")
	private byte  divisionStatus;
	
	@NumberFormat
	@Max(value=1,message = "Division Status could not be greater than 1")
	@Min(value=0,message = "Division Status could not be less than 0")
	private byte flag;
	
	private boolean validate;
	
	private String validationMsg;
	
	private String passMpos;
	
	private boolean apiUpdateStat;
	
	/**
	 * Method to append validationMsg to existing validationMsg.
	 * @param status
	 * @return Nothing
	 */
	public void appendStatus(String validationMsg) {
		StringBuilder builder = new StringBuilder();
		builder.append(this.validationMsg);
		builder.append(CommonConstants.SPACE.get());
		builder.append(validationMsg);
		this.validationMsg = builder.toString();
	}
	
}
