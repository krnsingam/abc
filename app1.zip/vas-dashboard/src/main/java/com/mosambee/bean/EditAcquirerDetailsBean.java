package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
public class EditAcquirerDetailsBean {
	
	private long acqId;
	private String name;
	private String zmk;
	private String zpk;
	private String zek;
	private double tipPercent;
	private String apkName;
	private int currencyId;
	private int decimalAmountLength;
	private int serverTimeInMin;
	private int mobileNoLength;
}
