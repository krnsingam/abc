package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * This class using for terminal upload field and to display dcemi list
 * and download emi search list
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Data
@SuperBuilder
@NoArgsConstructor
public class EmiMidTidBean {

	private String mid;
	private String tid;
	private String credit;
	private String debit;
	private String acquirer;
	private String createdTime;
}
