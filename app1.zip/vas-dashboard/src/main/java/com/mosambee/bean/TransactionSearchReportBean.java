package com.mosambee.bean;

import java.sql.Blob;
import java.util.Map;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * TransactionSearchReportBean is used to hold the result data of transaction search fields
 * @author rahul.mishra
 * @date 06-03-2020
 */

@Data
@SuperBuilder
@NoArgsConstructor
public class TransactionSearchReportBean {
	long transactionId;
	String userName;
	String cardNumber;
	String rrn;
	double amount;
	String amt;
	String txnDate;
	String time;
	String stan;
	double netAmount;
	String status;
	String type;
	int tgId;
	String responseCode;
	int imageId;
	String authCode;
	String terminalId;
	String cardHolderName;
	String businessName;
	Blob signature;
	int batchNo;
	String invoiceNo;
	String billNumber;
	String tipAmt;
	String merchantCode;
	String cardType;
	String acuirerName;
	String latitude;
	String longitude;
	String appLabel;
	String tsi;
	String tvr;
	String aid;
	int settleStatus;
	String appVersion;
	String cityName;
	String countryName;
	String line1;
	String line2;
	int pinVerified;
	String refTransaction;
	double cashBackAmount;

	private String tgTransactionId;
	private String tgName;
	private int isTipPresent;

	private String user;

	private int totalRecordsCount;

	private String securityToken;
	private String clientId;

	private int tenure;
	private double rateOfInterest;
	private double emiAmt;
	private double emiAmtWithInterest;
	private String emiDesclaimer;
	private double cashbackPercent;
	private double processingFee;
	private double costToCust;

	private String prodCode;
	private String prodCodeDescription;
	private String prodCodeDesclaimer;
	private String custMobile;
	private String mfgName;

	private double authAmt;
	private String currencyCode;
	
	private String totalTransactionValue;
	private String totalTransation;
	private String transactionType;
	private String transactionTypeId;
	private String modeId;
	
	private Map<String, String> descList;
}
