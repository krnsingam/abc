package com.mosambee.bean;

import java.util.List;

import javax.validation.constraints.Pattern;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * TransactionSearchFormBean is used to hold the data of transaction search fields
 * @author rahul.mishra
 * @date 06-03-2020
 */

@Data
@NoArgsConstructor
public class TransactionSearchFormBean {
	
	@Pattern(regexp = "^[0-9]*$",message="Only digits are allowed")
	private String userId;
	
	@Pattern(regexp = "^[a-zA-Z0-9.' -]*$",message="Please enter valid merchant name")
	private String merchantName;
	
	@Pattern(regexp = "^[0-9]*$",message="Only digits are allowed")
	private String transactionId;
	
	@Pattern(regexp = "^[a-zA-Z0-9]*$",message="Only characters and numbers are allowed")
	private String rrn;
	
	@Pattern(regexp = "^[a-zA-Z0-9]*$",message="Only characters and numbers are allowed")
	private String authCode;

	@Pattern(regexp = "^[0-9]*$",message="Only digits are allowed")
	private String maskedCardNumber;
	
	@Pattern(regexp = "^[a-zA-Z ]*$",message="Only characters and spaces are allowed")
	private String cardHolderName;
	
	private String transactionDateFrom;
	
	private String transactionDateTo;
	
	@Pattern(regexp = "^[a-zA-Z0-9 ]*$",message="Only characters and spaces are allowed")
	private String acquirer;
	
	@Pattern(regexp = "^[a-zA-Z0-9]*$",message="Only characters and numbers are allowed")
	private String mid;
	
	@Pattern(regexp = "^[0-9]*$",message="Only digits are allowed")
	private String tid;
	
	private List<String> txnType;
		
}
