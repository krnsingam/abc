package com.mosambee.bean;

import com.mosambee.constants.CommonConstants;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * MappingBulkUploadFormat holds the row data information for bulk upload excel request and response.
 * @author karan.singam
 * @version 1.0
 */
@Data
@SuperBuilder
@NoArgsConstructor
public class MappingBulkUpload {

	long id;
	String merchantCode;
	String terminalId;
	String classPath;
	String url;
	String status;
	int errCode;
	boolean validate;
	
	/**
	 * Method to append status to existing status.
	 * @param status
	 * @return Nothing
	 */
	public void appendStatus(String status) {
		StringBuilder builder = new StringBuilder();
		builder.append(this.status);
		builder.append(CommonConstants.SPACE.get());
		builder.append(status);
		this.status = builder.toString();
	}
}
