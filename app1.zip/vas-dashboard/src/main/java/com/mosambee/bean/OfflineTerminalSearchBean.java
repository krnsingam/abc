package com.mosambee.bean;

import com.mosambee.bean.datatables.DataTablesRequest;

import lombok.Data;
import lombok.ToString;


/**
 * OfflineTerminalSearchBean is basically used to carry request parameter for getOfflineTerminalList method of
 * {@link OfflineMerchantsController} 
 * @author mariam.siddique
 * @version 1.0
 * @since 01-April-2020
 */

@ToString
@Data
public class OfflineTerminalSearchBean {
	
	private DataTablesRequest dtRequest;
	private String userId;
	private String terminalId;

}
