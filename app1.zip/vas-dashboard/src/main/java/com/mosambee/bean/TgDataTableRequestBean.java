package com.mosambee.bean;

import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.controller.TgController;

import lombok.Data;
import lombok.ToString;

/**
 * TgDataTableRequestBean is basically used to carry request parameter for viewTgList method of
 * {@link TgController} 
 * @author mariam.siddique
 * @version 1.0
 * @since 08-April-2020
 */

@ToString
@Data
public class TgDataTableRequestBean {

	private DataTablesRequest dtRequest;
}
