package com.mosambee.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * NetworkMessagesDownloadBean basically used to represent the parsed row data for NetworkMessages Report.
 * 
 * @author maria.siddique
 * @version 1.0
 * @since 27-March-2020
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NetworkMessagesDownloadBean {

	private String userId;
	private String fromDate;
	private String toDate;
	
	private String userName;
	private String terminalId;
	private String processingCode;
	private int messageType;
	private String responseCode;
	private String hsmResponseCode;
	private String date;

}
