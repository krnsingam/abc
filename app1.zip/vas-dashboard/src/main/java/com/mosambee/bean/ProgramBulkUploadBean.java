package com.mosambee.bean;

import com.mosambee.constants.CommonConstants;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * ProgramBulkUploadBean holds the row data information for 
 * program bulk upload excel response.
 * L̥
 * @author swapnil.singh
 * @version 1.0
 * @since 28-December-2019
 */
@Data
@SuperBuilder
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class ProgramBulkUploadBean extends ProgramBean{
	
	private String programCode;
	private String status;
	
	/**
	 * Method to append status to existing status.
	 * 
	 * @param status
	 * @return Nothing
	 */
	public void appendStatus(String status) {
		StringBuilder builder = new StringBuilder();
		builder.append(this.status);
		builder.append(CommonConstants.SPACE.get());
		builder.append(status);
		this.status = builder.toString();
	}
	
}
