package com.mosambee.bean;

import javax.validation.constraints.NotNull;

import com.mosambee.bean.datatables.DataTablesRequest;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * This class is using for datatable request for dcemi list
 * 
 * @author pooja.singh
 * @version 1.0
 */
@SuperBuilder
@ToString
@NoArgsConstructor
@Data
public class EmiSearchDatatablesRequestBean {
	DataTablesRequest dtRequest;

	@NotNull
	private String fromDate;
	@NotNull
	private String toDate;

	private String mid;
	private String tid;
	private String acquirer;
	private String credit;
	private String debit;

}
