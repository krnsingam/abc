package com.mosambee.bean;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import lombok.ToString;

/**
 * CustomUser is responsible for holding custom information.
 * 
 * @author rahul.mishra
 * @author swapnil.singh
 */
@ToString
public class CustomUser extends User implements UserDetails {

	private static final long serialVersionUID = 1L;
	private Map<String, String> myMap = new HashMap<>();

	public CustomUser(String username, String password, Collection<? extends GrantedAuthority> authorities,Map<String, String> myMap) {
		super(username, password, authorities);
		this.myMap = myMap;
	}

	public Map<String, String> getMyMap() {
		return myMap;
	}

	public void setMyMap(Map<String, String> myMap) {
		this.myMap = myMap;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((myMap == null) ? 0 : myMap.hashCode());
		return result;
	}

	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		CustomUser other = (CustomUser) obj;
		if (myMap == null) {
			if (other.myMap != null) {
				return false;
			}
		} else if (!myMap.equals(other.myMap)) {
			return false;
		}
		return true;
	}


}
