package com.mosambee.bean;

import javax.validation.constraints.NotNull;

import lombok.Data;

/**
 * This class is using for download dcemi list
 * 
 * @author pooja.singh
 *
 */
@Data
public class EmiDownloadBean {
	@NotNull
	private String fromDate;
	@NotNull
	private String toDate;
	private String mid;
	private String tid;
	private String credit;
	private String debit;
	private String acquirer;

}
