package com.mosambee.bean;

import com.mosambee.bean.datatables.DataTablesRequest;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * MidTidDetailBean basically used to represent the parsed row data for Mid Tid.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 10-February-2020
 */
@Data
@SuperBuilder
@NoArgsConstructor
public class MidTidDetailBean {

	DataTablesRequest dtRequest;
	String id;
}
