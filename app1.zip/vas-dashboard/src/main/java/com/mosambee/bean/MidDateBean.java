package com.mosambee.bean;

import lombok.Data;

/**
 * This class is using for Mid Download to pass fromDate and toDate.
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Data
public class MidDateBean {
	private String fromDate;
	private String toDate;
	private String tempTid;
	private String acquirer;
	private String tempMerchantCode;// tempMid
	private String mid;// peproMid//merchantCode
	private String tid;
	private String typeId;


}
