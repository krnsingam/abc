package com.mosambee.bean;

import com.mosambee.bean.datatables.DataTablesRequest;

import lombok.Data;
import lombok.ToString;

/**
 * This class is using for datatable request for BQRMerchant list
 * 
 * @author pooja.singh
 *
 */
@ToString
@Data
public class BqrListDatatablesRequestBean {
	private DataTablesRequest dtRequest;
	private String acquirer;
	private String terminalId;
	private String merchantId;
	private String status;
	private String qrMerchantName;
	private String ifscAccountNo;
	private String id;

}
