package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * This class is used to upload fields in sbi emi Tid upload
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 */
@Data
@SuperBuilder
@NoArgsConstructor
public class SBITidBean {

	private String mPosMid;
	private String mPosTid;
	private String skuName;
	private String storeName;
	private String storeCity;
}
