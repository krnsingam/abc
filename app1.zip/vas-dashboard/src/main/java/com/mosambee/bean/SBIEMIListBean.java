package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * SBIEMIListBean is responsible for carrying the data-tables request and
 * response. Mainly to display the list of Data Regarding SBI EMI MID and TID.
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 * @since 30-March-2020
 * 
 */
@SuperBuilder
@ToString
@NoArgsConstructor
@Data
public class SBIEMIListBean {
	
	private long srNo;
	private long sbiId;
	
	//Mpos MID in view
	private String mposMerchantCode;
	
	//SBI MID in view
	private String sbiMerchantCode;
	
	//Merchant Name in view
	private String merchantName;
	
	//Merchant City in view
	private String merchantCity;
	
	//Status in view
	private String status;
	
	//SetupFileStatus in view
	private String setupFileStatus;
	
	//Mpos TID in view
	private String mposTerminalId;
	
	
	private String skuName;
	
	
	private String storeName;
	
	//Store City in view
	private String storeCity;
	
	//using below fields while updating record
	//TID Status in view
	private String tidStatus;
	
	//TID SetupFile Status in view
	private String tidSetupFileStatus;
	
	//SKU Status in view
	private String skuStatus;
	
	//SKU SetupFile Status in view
	private String skuSetupFileStatus;
	
	
}
