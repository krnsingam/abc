package com.mosambee.bean;

import lombok.Builder;
import lombok.Data;

/**
 * Responsible for carrying information about user existence and is it blocked
 * or not.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 11-February-2020
 */
@Data
@Builder
public class UserExistAndNotBlockedBean {

	private boolean userExists;
	private boolean notBlocked;
	private long userId;

}
