package com.mosambee.bean;


import com.mosambee.bean.datatables.DataTablesRequest;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * TransactionSearchFormDataTableBean is used to hold the data of transaction list search fields
 * @author rahul.mishra
 * @date 06-03-2020
 */

@Data
@SuperBuilder
@NoArgsConstructor
public class TransactionSearchFormDataTableBean {
	DataTablesRequest dtRequest;
	private String userId;
	private String merchantName;
	private String transactionId;
	private String rrn;
	private String authCode;
	private String maskedCardNumber;
	private String cardHolderName;
	private String acquirer;
	private String mid;
	private String tid;
	private String txnType;
	private String transactionDateFrom;
	private String transactionDateTo;
}
