package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * MerchantMappingBean basically used to represent the parsed row data for Merchant specific data.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 02-March-2020
 */
@Data
@SuperBuilder
@ToString
@NoArgsConstructor
public class MerchantNameBean {

	long merchId;
	
	String merchantNameCode;
	
}
