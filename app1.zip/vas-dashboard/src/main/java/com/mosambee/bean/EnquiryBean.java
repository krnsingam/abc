package com.mosambee.bean;

import lombok.Builder;
import lombok.Data;

/**
 * This class is using for enquiryReportingListing for fetching enquiry detail
 * and download enquiry detail
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Builder
@Data
public class EnquiryBean {
	private long id;
	private String issuer;
	private String createdTime;
	private String updatedTime;
	private String cardTypeId;
	private String originatorCode;
	private String eligibilityStatus;
    private String checkEligibilityTime;
	private String orderConfirmationStatus;
	private String orderConfirmationRespondCode;
	private String merchantRefNo;
	private String bankRefNo;
	private String amount;
	private String status;
	private long enquiryId;
	private int cardBin;
	private int serialNo;
	private int totalRecords;

}
