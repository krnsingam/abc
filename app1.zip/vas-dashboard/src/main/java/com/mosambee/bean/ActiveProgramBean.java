package com.mosambee.bean;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;

/**
 * ActiveProgramsBean is responsible for carrying the data-tables request and
 * response. Mainly to display the list of active programs.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 03-January-2020
 */
@Data
@ToString
@Builder
public class ActiveProgramBean {

	private String programName;
	private String programCode;
	private String programPriority;
	private String programStartTime;
	private String programEndTime;
	private String programDescription;

}
