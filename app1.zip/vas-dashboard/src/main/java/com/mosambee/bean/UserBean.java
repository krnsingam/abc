package com.mosambee.bean;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class UserBean {

	private long id;
	private String username;
	private String password;
	private Role role;
    private String status;
    private String roleName;
    private String firstName;
    private String lastName;
    private String email;

}
