package com.mosambee.bean;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * StateBean is responsible for carrying the state id and code.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 11-February-2020
 */
@SuperBuilder
@ToString
@NoArgsConstructor
@Data
public class StateBean {

	private long id;
	private String name;
}
