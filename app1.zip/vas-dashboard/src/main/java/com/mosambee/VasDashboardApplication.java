package com.mosambee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = "com.mosambee")
public class VasDashboardApplication {
	public static void main(String[] args) {
		SpringApplication.run(VasDashboardApplication.class, args);
	}
}