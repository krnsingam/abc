package com.mosambee.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.EmiUploadService;

@Controller
@RequestMapping("/emi")
public class EmiUploadController {
	private static final Logger log = LogManager.getLogger(EmiUploadController.class);
	
	@Autowired
	private EmiUploadService emiUploadService;
	
	
	
	/**
	 * Api to view emi upload page
	 * 
	 * @return String
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@GetMapping("/emi-upload")
	public String emiUpload() {
		log.info("GET/emi/emi-upload");
		return ViewLayer.EMI_UPLOAD.get();

	}

	/**
	 * emiUploadFormat() is responsible for downloading emi upload format
	 * 
	 * @return Object
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@GetMapping("/emi-upload-format")
	public Object emiUploadFormat() {
		log.info("POST/emi/emi-upload-format");

		log.info("Request time: {}", System.currentTimeMillis());
		Resource resource = emiUploadService.getEmiUploadFormat();
		if (null != resource) {
			log.info("Sending  emi upload format in response.");
			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"emi-upload-format.xlsx\"")
					.body(resource);
		} else {
			log.error("Error ocurred while downloading emi upload sample file.");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.EMI_UPLOAD.get());
			modelAndView.addObject("emi_upload_format_error", true);
			return modelAndView;
		}
	}
	
	
	/**
	 * @param file MultiPartFile that will receive in the request
	 * @return Object
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@PostMapping("/emi-upload")
	public Object emiConversionUpload(@RequestParam("file") MultipartFile file) {
		log.info("POST/emi/emi-upload");

		log.info("Request Time: {}", System.currentTimeMillis());
		Resource resource = emiUploadService.processEmiUploadExcel(file);
		if (null != resource) {

			log.info("Response time: {}", System.currentTimeMillis());

			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION,
							"attachment; filename=\"EmiUploadResponse.xlsx\"")
					.body(resource);
		} else {
			ModelAndView modelAndView = new ModelAndView(ViewLayer.EMI_UPLOAD.get());
			modelAndView.addObject("invalid", true);
			return modelAndView;
		}

	}

}
