package com.mosambee.controller;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.bean.CustomUser;
import com.mosambee.bean.OfflineMerchantTerminalSearchBean;
import com.mosambee.bean.OfflineMerchantsListBean;
import com.mosambee.bean.OfflineMerchantsSearchBean;
import com.mosambee.bean.OfflineTerminalListBean;
import com.mosambee.bean.OfflineTerminalSearchBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.OfflineMerchantsService;
import com.mosambee.util.OfflineKeyGenerator;

import lombok.extern.log4j.Log4j2;

/**
 * OfflineMerchantsController is basically used to search offline Merchants.
 * We are basically using this controller to show list of offline merchants corresponding to 
 * particular merchantId or terminalId.
 * @author mariam.siddique
 * @version 1.0
 * @since 01-April-2020
 */
@Log4j2
@Controller
@RequestMapping("/offlinemerchants")
public class OfflineMerchantsController {

	@Autowired
	private OfflineMerchantsService service;
	/**
	 * API to fetch the view for OfflineMerchants
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN"})
	@GetMapping("/offline-merchants-list")
	public String offlineMerchantsSearchView() {
		log.info("GET /offline-merchants-list");
		return ViewLayer.OFFLINE_MERCHANTS_LIST_VIEW.get();
	}
	
	/**
	 * API to fetch data-tables response for Offline merchant list.
	 * 
	 * @param  OfflineMerchantsSearchBean
	 * @return ResponseEntity<DataTablesResponse<OfflineMerchantsListBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/offline-merchants-list")
	public ResponseEntity<DataTablesResponse<OfflineMerchantsListBean>> getOfflineMerchantsList(@RequestBody OfflineMerchantsSearchBean dtRequest) {
		log.info("Request of POST /offline-merchants-list {}", dtRequest);
		
		DataTablesResponse<OfflineMerchantsListBean> dtResponse = service.getOfflineMerchantsList(dtRequest);
		log.info("Response of POST /offline-merchants-list {}", dtResponse);
		dtResponse.setDraw(dtRequest.getDtRequest().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}
	
	/**
	 * API to fetch data-tables response for Offline terminal list.
	 * 
	 * @param  OfflineTerminalSearchBean
	 * @return ResponseEntity<DataTablesResponse<OfflineTerminalListBean>>
	 */
	  @RolesAllowed({ "ROLE_SITE_ADMIN"})  
	  @PostMapping(value = "/offline-terminal-list")
	  public ResponseEntity<DataTablesResponse<OfflineTerminalListBean>> getOfflineTerminalList(@RequestBody OfflineTerminalSearchBean searchBean){
	  log.info("POST/offline-terminal-list {}", searchBean);
	  
	  DataTablesResponse<OfflineTerminalListBean> dtResponse = service.getOfflineTerminalList(searchBean);
	  dtResponse.setDraw(searchBean.getDtRequest().getDraw());
	  log.info("Response of POST/offline-terminal-list {}", dtResponse);
	  return new ResponseEntity<>(dtResponse, HttpStatus.OK); 
	  }
	  
	  /**
		* API to fetch data-tables response for Offline merchant terminal list.
		* 
		* @param  OfflineMerchantTerminalSearchBean
		* @return ResponseEntity<DataTablesResponse<OfflineTerminalListBean>>
		*/
	  	@RolesAllowed({ "ROLE_SITE_ADMIN"})  
	  	@PostMapping(value = "/offline-merchant-terminal-list")
	  	public ResponseEntity<DataTablesResponse<OfflineTerminalListBean>> getOfflineMerchantTerminalList(@RequestBody OfflineMerchantTerminalSearchBean searchBean){
	  	log.info("POST/offline-merchant-terminal-list {}", searchBean);
	
	  	DataTablesResponse<OfflineTerminalListBean> dtResponse = service.getOfflineMerchantTerminalList(searchBean);
	  	dtResponse.setDraw(searchBean.getDtRequest().getDraw());
	  	log.info("Response of POST/offline-merchant-terminal-list {}", dtResponse);
	  	return new ResponseEntity<>(dtResponse, HttpStatus.OK); 
	  }
	  
	  	/**
		 * API to set offline keys in a bulk for the terminals of specified merchants.
		 * @param merchantId
		 * @return modelAndView
		 */
		@RolesAllowed({ "ROLE_SITE_ADMIN" })
		@PostMapping("/set-bulk-offline-key")
		public ModelAndView setBulkOfflineKey(@RequestParam long merchantId) {
			log.info("POST /set-bulk-offline-key");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.OFFLINE_MERCHANTS_LIST_VIEW.get());
			boolean setKey= service.getMerchantsTerminalForOfflineKeySet(merchantId);
			if(setKey) {
				modelAndView.addObject("msgsuccess","bulk offline keys are set successfully");
			}else {
				modelAndView.addObject("msgerror","some error occurred.Unable to set bulk offline keys");
			}
			return modelAndView;
		}
		
		/**
		 * API to set offline key for specified terminal.
		 * @param terminalId
		 * @return modelAndView
		 */
		@RolesAllowed({ "ROLE_SITE_ADMIN"})
		@PostMapping("/set-offline-key")
		public ModelAndView setOfflineKey(@RequestParam String terminalId) {
			log.info("POST /set-offline-key");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.OFFLINE_MERCHANTS_LIST_VIEW.get());

			CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			String userId = user.getMyMap().get("id");
			long loginUserId = Long.parseLong(userId);
			
			int count = service.updateOfflineKey(terminalId, OfflineKeyGenerator.getOfflineKey(), loginUserId);
			if(count > 0) {	
				modelAndView.addObject("msgsuccess","offline key is set successfully");
			}else {
				modelAndView.addObject("msgerror","some error occurred.Unable to set offline key");
			}
			return modelAndView;
		}
		
	
	 
}
