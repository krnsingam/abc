package com.mosambee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import com.mosambee.bean.UserExistAndNotBlockedBean;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.ForgotPasswordService;
import com.mosambee.service.UserService;

import lombok.extern.log4j.Log4j2;

/**
 * Responsible for displaying the forgot-password page and accepting the request
 * to change password for a particular email address.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 03-February-2020
 */
@Log4j2
@Controller
@RequestMapping("/forgot-password")
public class ForgotPasswordController {

	@Autowired
	private ForgotPasswordService forgotPasswordService;

	@Autowired
	private UserService userService;

	/**
	 * Responsible for returning the forgot password view.
	 * 
	 * @return Forgot password view
	 */
	@GetMapping
	public String forgotPasswordForm() {
		log.info("GET /forgot-password");
		return ViewLayer.FORGOT_PASSWORD.get();
	}

	/**
	 * forgotPassword(...) is responsible for processing forgot password request.
	 * 
	 * @param email
	 * @return
	 */
	@PostMapping
	public RedirectView forgotPassword(@RequestParam("username") String username,
			RedirectAttributes redirectAttributes) {
		// LOG THE INCOMING REQUEST
		log.info("POST /forgot-password {}", username);

		// Check if user exist and is not blocked
		UserExistAndNotBlockedBean bean = userService.checkIfUserExistsAndNotBlocked(username);

		// If user exist and is blocked, redirect to the login page with blocked message
		if (bean.isUserExists() && !bean.isNotBlocked()) {
			log.error("user exist and is blocked");
			return new RedirectView("login?blocked", true);
		}

		// PROCESS THE INCOMING EMAIL ADDRESS
		String response = forgotPasswordService.processForgotPasswordRequest(username);

		log.info("response: {}", response);

		if (CommonConstants.CHANGE_PASSWORD_LIMIT_EXCEEDED.get().equalsIgnoreCase(response)) {
			redirectAttributes.addFlashAttribute("forgot-password", "limit");
		} else {
			redirectAttributes.addFlashAttribute("forgot-password", "success");
		}

		return new RedirectView("login", true);

	}

}
