package com.mosambee.controller;

import javax.annotation.security.RolesAllowed;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.bean.AddSbiDetailsMidBean;
import com.mosambee.bean.EditSbiDetailsBean;
import com.mosambee.bean.AddSbiDetailsTidBean;
import com.mosambee.bean.CustomUser;
import com.mosambee.bean.SBIEMIListBean;
import com.mosambee.bean.SBIEMISearchDataTableBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.SBIEMIService;

import lombok.extern.log4j.Log4j2;

/**
 * SBIEMIController is basically used to view list of SBI-EMI MID and TID List
 * and to add SBI-EMI MID and TID.
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 * @since 18-March-2020
 */
@Log4j2
@Controller
@RequestMapping("/sbi-emi")
public class SBIEMIController {

	@Autowired
	SBIEMIService service;

	/**
	 * API to View the Add SBI EMI MID Page
	 * 
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@GetMapping("/add-sbi-emi-mid")
	public ModelAndView addSbiEmiMid() {
		log.info("GET /add-sbi-emi-mid");
		ModelAndView modelAndView = new ModelAndView(ViewLayer.ADD_SBI_EMI_MID.get());
		//modelAndView.addObject("beanData", new AddSbiDetailsMidBean());
		modelAndView.addObject("formValidation", "addMid");
		return modelAndView;
	}

	/**
	 * API to Add SBI EMI MID Details.
	 * 
	 * @param bean			 {@link AddSbiDetailsMidBean}
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/add-sbi-emi-mid")
	public ModelAndView addSbiEmiMid(@Valid @ModelAttribute AddSbiDetailsMidBean bean) {
		log.info("POST /sbi-emi/add-abi-emi-mid: {}", bean);
		log.info(bean.getMPosMerchantId());
		ModelAndView modelAndView = new ModelAndView(ViewLayer.ADD_SBI_EMI_MID.get());

		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Long userId = Long.parseLong(user.getMyMap().get("id"));

		String response = service.addSbiEmiDetails(bean, userId);
 
		log.info("POST /enquiry-reporting/enquiry {}", response);

		if (response.equalsIgnoreCase("SBI MID details added successfully")) {
			modelAndView.addObject("msg", true);
		} else {
			modelAndView.addObject("msg", response);
		}
		modelAndView.addObject("formValidation", "addMid");
		//modelAndView.addObject("beanData", new AddSbiDetailsMidBean());
		return modelAndView;
	}

	/**
	 * API to View the Add SBI EMI TID Page
	 * 
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@GetMapping("/add-sbi-emi-tid")
	public ModelAndView addSbiEmiTid() {
		log.info("GET /add-sbi-emi-tid");
		ModelAndView modelAndView = new ModelAndView(ViewLayer.ADD_SBI_EMI_TID.get());
		//modelAndView.addObject("addSbiDetailsMidBean", new AddSbiDetailsMidBean());
		modelAndView.addObject("formValidation", "addTid");
		return modelAndView;
	}
	
	/**
	 * API to Add SBI EMI TID Details.
	 * 
	 * @param bean 			{@link AddSbiDetailsTidBean}
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/add-sbi-emi-tid")
	public ModelAndView addSbiEmiTid(@Valid @ModelAttribute AddSbiDetailsTidBean bean) {
		log.info("POST /sbi-emi/add-abi-emi-tid: {}", bean);
		log.info(bean.getMPosMerchantId());
		ModelAndView modelAndView = new ModelAndView(ViewLayer.ADD_SBI_EMI_TID.get());

		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Long userId = Long.parseLong(user.getMyMap().get("id"));

		String response = service.addSbiEmiDetailsWithTid(bean, userId);

		log.info("POST /enquiry-reporting/enquiry {}", response);

		if (response.equalsIgnoreCase("SBI TID details added successfully")) {
			modelAndView.addObject("msg", true);
		} else {
			modelAndView.addObject("msg", response);
		}
		
		modelAndView.addObject("formValidation", "addTid");
		return modelAndView;
	}
	
	/**
	 * API to View the List of SBI EMI Details Page
	 * 
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/sbi-emi-mid-tid-list")
	public ModelAndView getSbiEmiMidTidList() {
		log.info("GET /sbi-emi-mid-tid-list");
		ModelAndView modelAndView = new ModelAndView(ViewLayer.LIST_SBI_EMI_MID_TID.get());
		return modelAndView;
	}
	
	/**
	 * API to fetch data-tables response for SBI EMI Listing.
	 * 
	 * @param dtRequest 		{@link SBIEMISearchDataTableBean}
	 * 
	 * @return ResponseEntity<DataTablesResponse<SBIEMIListBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/sbi-emi-mid-tid-list")
	public ResponseEntity<DataTablesResponse<SBIEMIListBean>> viewSBITransactions(
			@RequestBody SBIEMISearchDataTableBean dtRequest) {
		log.info("POST /sbi-emi-mid-tid-list  with dtRequest: {}", dtRequest);
		
		DataTablesResponse<SBIEMIListBean> dtResponse = service.getSBITransactionList(dtRequest);
		dtResponse.setDraw(dtRequest.getDataTableParameters().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}
	
	/**
	 * API to fetch data for editing SBI EMI Listing.
	 * 
	 * @param addBeanData 	{@link EditSbiDetailsBean}
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/sbi-emi-mid-tid-edit")
	public ModelAndView editSBITransactions(@ModelAttribute EditSbiDetailsBean addBeanData) {
		log.info("POST /sbi-emi-mid-tid-edit  with listBean as: {}", addBeanData);
		ModelAndView modelAndView = null;
		
		long type=Long.parseLong(addBeanData.getType());
		long sbiId=addBeanData.getSbiId();
		
		EditSbiDetailsBean beanData = service.getSBIDetailsToEdit(type,sbiId);
		log.info("beanData as: {}", beanData);
		
		if(type==1){
			beanData.setType("1");
			beanData.setSbiId(sbiId);
			log.info("beanData with type as: {}", beanData);
			modelAndView = new ModelAndView(ViewLayer.ADD_SBI_EMI_MID.get());
			modelAndView.addObject("beanData", beanData);
			return modelAndView;
		}
		else{
			beanData.setType("2");
			beanData.setSbiId(sbiId);
			log.info("beanData with type as: {}", beanData);
			modelAndView = new ModelAndView(ViewLayer.ADD_SBI_EMI_TID.get());
			modelAndView.addObject("beanData", beanData);
			return modelAndView;
		}
		
	}
	
	/**
	 * API to Edit the fetched data-tables response for SBI EMI Listing.
	 * 
	 * @param addBeanData {@link EditSbiDetailsBean}
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/update-sbi-emi-mid-tid")
	public ModelAndView updateSBITransactions(@ModelAttribute EditSbiDetailsBean addBeanData) {
		log.info("POST /update-sbi-emi-mid  with listBean as: {}", addBeanData);
		ModelAndView modelAndView = null;
		
		long type=Long.parseLong(addBeanData.getType());
		long sbiId=addBeanData.getSbiId();
		log.info("type and sbiId as: {} {}", type, sbiId);
		
		if (type==1) {
			modelAndView = new ModelAndView(ViewLayer.ADD_SBI_EMI_MID.get());
			String response = service.updateSBITransactionList(type, sbiId, addBeanData);
			if (response.equalsIgnoreCase("success")) {
				modelAndView.addObject("msg", "updated");
			} else {
				modelAndView.addObject("msg", response);
			}
			modelAndView.addObject("beanData", addBeanData);
			return modelAndView;
		}
		else
		{
			modelAndView = new ModelAndView(ViewLayer.ADD_SBI_EMI_TID.get());
			String response = service.updateSBITransactionList(type, sbiId, addBeanData);
			if (response.equalsIgnoreCase("success")) {
				modelAndView.addObject("msg", "updated");
			} else {
				modelAndView.addObject("msg", response);
			}
			modelAndView.addObject("beanData", addBeanData);
			return modelAndView;
		}
	}
}
