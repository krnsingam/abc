package com.mosambee.controller;

import java.util.List;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.bean.EnquiryBean;
import com.mosambee.bean.EnquiryDataTablesRequestBean;
import com.mosambee.bean.EnquiryDateBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.EnquiryReportingService;

import lombok.extern.log4j.Log4j2;

/**
 * EnquiryReprtingController is basically used to view enquiry list and
 * enquryDetail and download enquiry detail
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Log4j2
@Controller
@RequestMapping("/enquiry-reporting")
public class EnquiryReportingController {
	
	@Autowired
	EnquiryReportingService service;
	
	/**
	 * API to view enquiry list
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/enquiry")
	public String viewEnquiryList() {
		log.info("GET /enquiry");
		return ViewLayer.ENQUIRY_LIST.get();
	}

	/**
	 * API to fetch data-tables response for enquiry list.
	 * 
	 * @param EnquiryDataTablesRequestBean
	 * @return ResponseEntity<DataTablesResponse<EnquiryBean>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/enquiry")
	public ResponseEntity<DataTablesResponse<EnquiryBean>> viewEnquiryList(
			@RequestBody EnquiryDataTablesRequestBean dtRequest) {
		log.info("POST /enquiry-reporting/enquiry {}", dtRequest);
		

		DataTablesResponse<EnquiryBean> dtResponse = service.getEnquiryList(dtRequest);

		log.info("POST /enquiry-reporting/enquiry {}", dtResponse);

		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}

	/**
	 * to download enquiry reporting
	 * 
	 * @param EnquiryDateBean
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/download")
	public Object downloadEnquiryReporting(@ModelAttribute("f") EnquiryDateBean bean) {
		log.info("POST /enquiry-reporting/download");
		List<EnquiryBean> responseBean = service.downloadEnquiryReporting(bean);
		log.info("Response /enquiry-reportng/download {}", responseBean);
		if (!responseBean.isEmpty()) {
			// Get the resource from service
			Resource resource = service.processEnquiryReporting(responseBean);
			if (resource != null) {
				return ResponseEntity.ok()
						.contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
						.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"EnquiryReporting.xlsx\"")
						.body(resource);
			} else {
				log.error("Error ocurred while downloading enquiry reporting list.");
				ModelAndView modelAndView = new ModelAndView(ViewLayer.ENQUIRY_LIST.get());
				modelAndView.addObject("msg", true);
				return modelAndView;
			}
		} else {
			log.error("Error ocurred while downloading enquiry reporting list.");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.ENQUIRY_LIST.get());
			modelAndView.addObject("msg", true);
			return modelAndView;

		}
	}

	/**
	 * to view the enquiry reporting detail
	 * 
	 * @return ResponseEntity<EnquiryBean>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/view-detail")
	public ResponseEntity<EnquiryBean> viewEnquiryDetail(@RequestParam long id) {
		log.info("GET /enquiry-reportng/view-detail {}", id);
		EnquiryBean bean = service.viewEnquiryDetail(id);
		log.info(bean);
		return new ResponseEntity<>(bean, HttpStatus.OK);
	}

}
