package com.mosambee.controller;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.bean.NetworkMessagesDataTablesRequestBean;
import com.mosambee.bean.NetworkMessagesDownloadBean;
import com.mosambee.bean.NetworkMessagesListBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.NetworkMessagesService;

import lombok.extern.log4j.Log4j2;

/**
 * NetworkMessagesController is basically used to search transactions by using bill number.
 * We are basically using this controller to show list of transactions corresponding to particular bill number.
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 27-March-2020
 */

@Log4j2
@Controller
@RequestMapping("/networkmessages")
public class NetworkMessagesController {

	@Autowired
	private NetworkMessagesService service;

	/**
	 * API to fetch the view for NetworkMessages tab
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@GetMapping("/networkmessages-list")
	public String getNetworkMessagesListView() {
		log.info("GET /networkmessages-list");
		return ViewLayer.NETWORK_MESSAGES_VIEW.get();
	}
	
	/**
	 * API to fetch data-tables response for NetworkMessages list.
	 * 
	 * @param  NetworkMessageDataTablesRequestBean
	 * @return ResponseEntity<DataTablesResponse<NetworkMessagesListBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN"})
	@PostMapping("/networkmessages-list")
	public ResponseEntity<DataTablesResponse<NetworkMessagesListBean>> getNetworkMessagesList(@RequestBody NetworkMessagesDataTablesRequestBean dtRequest) {
		log.info("POST /networkmessages-list {}", dtRequest);
		
		DataTablesResponse<NetworkMessagesListBean> dtResponse = service.getNetworkMessagesList(dtRequest);
		log.info("POST /networkmessages-list {}", dtResponse);
		dtResponse.setDraw(dtRequest.getDtRequest().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}
	
	/**
	 * API for download using data tables for networkmessages.
	 * downloadNetworkMessagestList() is used for providing download file in
	 * xlsx format.
	 * 
	 * @param bean{@link NetworkMessagesDownloadBean}
	 * @return Object
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN"})
	@PostMapping("/networkmessages-list-download")
	public Object downloadNetworkMessagestList(@ModelAttribute NetworkMessagesDownloadBean bean) {
		Resource resource = service.downloadNetworkMessagesList(bean);
		if (resource != null) {

			log.info("Resource {}", resource);
			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"NetworkMessagesDetails.xlsx\"")
					.body(resource);
		} else {
			log.error("Error ocurred while downloading networkmessages list.");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.NETWORK_MESSAGES_VIEW.get());
		modelAndView.addObject("msg", true);
		return modelAndView;
		}
	}


}
