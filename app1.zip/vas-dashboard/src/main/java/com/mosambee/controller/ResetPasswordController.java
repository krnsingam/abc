package com.mosambee.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import com.mosambee.bean.ResetPasswordBean;
import com.mosambee.constants.CommonConstants;
import com.mosambee.service.ResetPasswordService;

import lombok.extern.log4j.Log4j2;

/**
 * ResetPasswordController is responsible for resetting the password.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 05-February-2020
 */
@Log4j2
@Controller
@RequestMapping("/reset-password")
public class ResetPasswordController {

	@Autowired
	private ResetPasswordService resetPasswordService;

	@RolesAllowed({ "ROLE_SITE_CP_USER" })
	@GetMapping
	public String resetPasswordForm(Model model, @ModelAttribute("errors") ArrayList<String> errors) {
		log.info("GET /reset-password");
		model.addAttribute("resetPassword", new ResetPasswordBean());
		model.addAttribute("errors", errors);
		return "reset-password";
	}

	@RolesAllowed({ "ROLE_SITE_CP_USER" })
	@PostMapping
	public RedirectView resetPassword(@Valid @ModelAttribute("resetPassword") ResetPasswordBean resetPassword,
			BindingResult bindingResult, RedirectAttributes redirectAttributes) {
		log.info("POST /reset-password bean: {}, bindingResult: {}", resetPassword, bindingResult);
		List<String> errors = new ArrayList<>();

		if (bindingResult.hasErrors()) {
			bindingResult.getAllErrors().forEach(error -> {
				errors.add(error.getDefaultMessage());
			});
			log.error("bean validation errors: {}", errors);
			redirectAttributes.addFlashAttribute("errors", errors);
			return new RedirectView("reset-password", true);
		}

		String response = resetPasswordService.processPasswords(resetPassword);
		log.info("resetPassword processing response {}", response);

		if ("success".equalsIgnoreCase(response)) {
			redirectAttributes.addFlashAttribute("reset-password", "success");
			return new RedirectView("login", true);
		}
		redirectAttributes.addFlashAttribute("errors", response);		
		return new RedirectView("reset-password", true);
	}

}
