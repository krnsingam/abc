package com.mosambee.controller;

import javax.annotation.security.RolesAllowed;
import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.bean.CustomUser;
import com.mosambee.bean.InitiateSettlementBean;
import com.mosambee.bean.SettlementBean;
import com.mosambee.bean.SettlementDataTableCrudBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.SettlementService;

import lombok.extern.log4j.Log4j2;

/**
 * SettlementController is created to handle all settlement process including listing of 
 * merchant,user,auto,time settlement and initiate settlement
 * @author rahul.mishra
 * @date 28-02-2020 
 */
@Log4j2
@Controller
@RequestMapping("/settlement")
public class SettlementController {
	
	@Autowired
	private SettlementService settlementService;
	
	
    
	/**
	 * API to fetch the view for initiate settlement.
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/initiate")
	public ModelAndView viewSettlementInitiate() {
		log.info("GET /settlement/initiate");
		return new ModelAndView(ViewLayer.SETTLEMENT_INITIATE.get());
	}
	
	/**
	 * API to fetch the view for merchant settlement.
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/merchant")
	public ModelAndView viewSettlementMechant() {
		log.info("GET /settlement/merchant");
		return new ModelAndView(ViewLayer.SETTLEMENT_MERCHANT.get());
	}
	
	/**
	 * API to fetch the view for user settlement.
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/user")
	public ModelAndView viewSettlementUser() {
		log.info("GET /settlement/user");
		return new ModelAndView(ViewLayer.SETTLEMENT_USER.get());
	}
	
	/**
	 * API to fetch the view for time settlement.
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/time")
	public ModelAndView viewSettlementTime() {
		log.info("GET /settlement/time");
		return new ModelAndView(ViewLayer.SETTLEMENT_TIME.get());
	}
	
	/**
	 * API to fetch the view for AutoSettle settlement.
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/auto")
	public ModelAndView viewSettlementAuto() {
		log.info("GET /settlement/auto");
		return new ModelAndView(ViewLayer.SETTLEMENT_AUTO.get());
	}
	
	/**
	 * API to provide data for settlement list based on its type.
	 * @param SettlementDataTableBean dtRequest
	 * @return DataTablesResponse<UserBean>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/get-settlement-data")
	public ResponseEntity<DataTablesResponse<SettlementBean>> viewActiveUsersData(@RequestBody SettlementDataTableCrudBean dtRequest) {
		log.info("POST /settlement/get-settlement-data {}", dtRequest);
		DataTablesResponse<SettlementBean> dtResponse = settlementService.getSettlementList(dtRequest);
		dtResponse.setDraw(dtRequest.getDtRequest().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}
	
	/**
     * settleTransactionByTime function initiate manual settlement by time 
     * @param int time,String reason
     * @return String 
     * 
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/initiate-settlement")
	@ResponseBody
	public ResponseEntity<InitiateSettlementBean> settleTransactionByTime(@Valid @RequestBody InitiateSettlementBean bean) {	
		log.info("POST /user/initiate-settlement time {}  reason {}", bean.getTime(),bean.getReason());
        log.info("calling settleTransactionByTime {}",bean);
        CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String createdBy = user.getMyMap().get("id");
        settlementService.settleTransactionByTime(bean.getTime(),bean.getReason(),createdBy);	
        bean.setSuccess("success");
        return new ResponseEntity<>(bean, HttpStatus.OK);
	} 
	
}
