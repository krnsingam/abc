package com.mosambee.controller;


import java.util.HashMap;
import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.bean.CityBean;
import com.mosambee.bean.CountryBean;
import com.mosambee.bean.EnterpriseBean;
import com.mosambee.bean.EnterpriseDataBean;
import com.mosambee.bean.EnterpriseListBean;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.StateBean;
import com.mosambee.bean.UpdateAPIPaswordConfigRequestFromList;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.EnterpriseService;

import lombok.extern.log4j.Log4j2;

/**
 * This class is used to fetch all request of Enterprise module.
 * 
 * @author karan.singam
 * @version 1.0
 */
@Log4j2
@Controller
@RequestMapping("/enterprise")
public class EnterpriseController {

	@Autowired
	private EnterpriseService enterpriseService;
	
	private static final String RESPONSE_BEAN = "responseBean";
	private static final String ENTERPRISE = "enterprise";
	private static final String MESSAGE = "message";
	private static final String VALIDATION_ERROR_MESSAGE = "Sorry, Request has validation error(s).";
	private static final String ID = "id";

	/**
	 * This method accept "GET" request for "/create-enterprise". This method
	 * responsible for redirect user to "create-enterprisejsp".
	 * 
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@GetMapping("/create-enterprise")
	public ModelAndView createEnterprise() {
		log.info("GET /enterprise/create-enterprise");
		ResponseBean responseBean = new ResponseBean();
		responseBean.setData(new HashMap<String, Object>());
		ModelAndView modelAndView = new ModelAndView(ViewLayer.ENTERPRISE_CREATE.get());
		responseBean.setAction(ViewLayer.ENTERPRISE_INSERT.get());
		responseBean.getData().put("recordId", 0);
		modelAndView.addObject(RESPONSE_BEAN, responseBean);
		log.info("country {}",enterpriseService.getCountry());
		modelAndView.addObject("country", enterpriseService.getCountry());
		return modelAndView;
	}

	/**
	 * This method accept "POST" request for "/insert-enterprise". This method hit
	 * when user submit form for creating "Enterprise" from
	 * "create-enterprise.jsp".
	 * 
	 * @param EnterpriseBean Expect "{@link EnterpriseBean}" object
	 * @param bindingResult  Expect "{@link BindingResult}" object
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/insert-enterprise")
	public ModelAndView insertEnterprise(@Valid EnterpriseBean enterprise, BindingResult bindingResult) {
		ModelAndView modelAndView = new ModelAndView(ViewLayer.ENTERPRISE_CREATE.get());

		log.info("POST /enterprise/insert-enterprise");
		if (!bindingResult.hasErrors()) {
			ResponseBean responseBean = new ResponseBean();
			responseBean = enterpriseService.processCreateEnterprise(enterprise, responseBean); // Send
																												// data
																												// for
																												// process.
			modelAndView.addObject(ENTERPRISE, enterprise);
			modelAndView.addObject(RESPONSE_BEAN, responseBean);
			log.info(responseBean);
			return modelAndView;
		} else {
			ResponseBean responseBean = new ResponseBean();
			responseBean.getData().put("recordId", 0);
			List<FieldError> errors = bindingResult.getFieldErrors();
			StringBuilder message = new StringBuilder();

			for (FieldError e : errors) {
				message.append(e.getField().toUpperCase() + " : " + e.getDefaultMessage());
			}
			responseBean.setMsg(VALIDATION_ERROR_MESSAGE);
			responseBean.setOperationStatus(400);
			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put(MESSAGE, message.toString());
			modelAndView.addObject(RESPONSE_BEAN, responseBean);
			log.info("request validation error : {}", message);
			return modelAndView;
		}
	}
	
	/**
	 * This accept "POST" request for "/update-enterprise". This method hit when user
	 * submit form for updating "API Password Config" from "create-api-group.jsp".
	 * 
	 * @param createAPIGroup Expect "{@link EnterpriseBean}" object
	 * @param bindingResult  Expect "{@link BindingResult}" object
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/update-enterprise")
	public ModelAndView updateAPIGroup(@Valid EnterpriseBean enterprise, BindingResult bindingResult) {
		log.info("POST /enterprise/update-enterprise");
		ModelAndView modelAndView = new ModelAndView(ViewLayer.CREATE_API_GROUP_VIEW.get());

		if (!bindingResult.hasErrors()) {
			ResponseBean responseBean = new ResponseBean();
			enterpriseService.updateEnterprise(enterprise, responseBean); // Send data for process.
			modelAndView.addObject(ENTERPRISE, enterprise);
			modelAndView.addObject(RESPONSE_BEAN, responseBean);
			return modelAndView;
		} else {
			ResponseBean responseBean = new ResponseBean();
			List<FieldError> errors = bindingResult.getFieldErrors();
			StringBuilder message = new StringBuilder();

			for (FieldError e : errors) {
				message.append(e.getField().toUpperCase() + " : " + e.getDefaultMessage());
			}
			responseBean.setMsg(VALIDATION_ERROR_MESSAGE);
			responseBean.setOperationStatus(400);
			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put(MESSAGE, message.toString());
			modelAndView.addObject(RESPONSE_BEAN, responseBean);
			return modelAndView;
		}
	}
	
	/**
	 * This accept "POST" request for "/update-enterprise-list". This method hit
	 * when user click on "edit" button of list of Enterprise from
	 * "create-enterprise.jsp".
	 * 
	 * @param updateAPIPaswordConfigRequestFromList Expect
	 *                                              "{@link UpdateAPIPaswordConfigRequestFromList}"
	 *                                              object
	 * @param bindingResult                         Expect "{@link BindingResult}"
	 *                                              object
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/update-enterprise-list")
	public ModelAndView updateEnterpriseList(
			@ModelAttribute UpdateAPIPaswordConfigRequestFromList updateAPIPaswordConfigRequestFromList,
			BindingResult bindingResult) {
		log.info("POST /enterprise/update-enterprise-list");

		if (!bindingResult.hasErrors()) {
			ModelAndView modelAndView = new ModelAndView(ViewLayer.ENTERPRISE_CREATE.get());

			ResponseBean responseBean = new ResponseBean();
			EnterpriseBean enterprise = EnterpriseBean.builder().build();
			enterpriseService.updateEnterpriseList(updateAPIPaswordConfigRequestFromList, enterprise,
					responseBean); // Send data for process.
			modelAndView.addObject(ENTERPRISE, enterprise);
			modelAndView.addObject(RESPONSE_BEAN, responseBean);
			return modelAndView;
		} else {
			ModelAndView modelAndView = new ModelAndView(ViewLayer.ENTERPRISE_LIST.get());
			ResponseBean responseBean = new ResponseBean();
			List<FieldError> errors = bindingResult.getFieldErrors();
			StringBuilder message = new StringBuilder();

			for (FieldError e : errors) {
				message.append(e.getField().toUpperCase() + " : " + e.getDefaultMessage());
			}
			responseBean.setMsg(VALIDATION_ERROR_MESSAGE);
			responseBean.setOperationStatus(400);
			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put(MESSAGE, message.toString());
			modelAndView.addObject(RESPONSE_BEAN, responseBean);
			return modelAndView;
		}

	}
	
	/**
	 * API for getting list of State
	 * 
	 * @param CountryBean
	 * @return ResponseEntity<List<StateBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/state")
	public ResponseEntity<List<StateBean>> getState(@RequestBody CountryBean country) {

		List<StateBean> data = enterpriseService.getState(country);
		log.info(data);
		return new ResponseEntity<>(data, HttpStatus.OK);
	}
	
	/**
	 * API for getting list of City.
	 * 
	 * @param StateBean
	 * @return ResponseEntity<List<CityBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/city")
	public ResponseEntity<List<CityBean>> getCity(@RequestBody StateBean State) {

		List<CityBean> data = enterpriseService.getCity(State);
		log.info(data);
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	
	/**
	 * API to fetch the view for Enterprise
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/enterprise-list")
	public String viewEnterprise() {
		log.info("GET enterprise-list");
		return ViewLayer.ENTERPRISE_LIST.get();
	}

	/**
	 * API to fetch data-tables response for enterprise.
	 * 
	 * @param DataTablesRequest
	 * @return ResponseEntity<DataTablesResponse<EnterpriseListBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/enterprise-list")
	public ResponseEntity<DataTablesResponse<EnterpriseListBean>> enterpriseList(
			@RequestBody EnterpriseDataBean dtRequest) {
		log.info("post enterprise-list{}", dtRequest);
		DataTablesResponse<EnterpriseListBean> dtResponse = enterpriseService.enterpriseList(dtRequest);
		dtResponse.setDraw(dtRequest.getDataTable().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}

	/**
	 * API for getting list of Enterprise Name.
	 * 
	 * @param EnterpriseListBean
	 * @return ResponseEntity<List<EnterpriseListBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/enterprise-name")
	public ResponseEntity<List<EnterpriseListBean>> getEnterpriseName(@RequestBody EnterpriseListBean bean) {
        log.info("enterProse bean {} ", bean);
		List<EnterpriseListBean> data = enterpriseService.getEnterpriseName(bean);
		log.info(data);
		return new ResponseEntity<>(data, HttpStatus.OK);
	}
}
