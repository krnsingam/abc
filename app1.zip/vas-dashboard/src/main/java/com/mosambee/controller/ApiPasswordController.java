package com.mosambee.controller;

import java.util.HashMap;
import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.bean.ApiPasswordBean;
import com.mosambee.bean.ApiPasswordDataBean;
import com.mosambee.bean.CreateAPIGroup;
import com.mosambee.bean.MidTidBean;
import com.mosambee.bean.MidTidDetailBean;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.UpdateAPIPaswordConfigRequestFromList;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.ApiPasswordService;

import lombok.extern.log4j.Log4j2;

/**
 * ApiPasswordController is basically used for Api Password view tab. We
 * are basically using this controller to create-view for transaction, providing
 * view-download-support for multiple Api Password at once.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 16-March-2020
 */
@Log4j2
@Controller
@RequestMapping("/api-password")
public class ApiPasswordController {

	@Autowired
	ApiPasswordService apiservice;

	private static final String RESPONSE_BEAN = "responseBean";
	private static final String UPDATE_API = "createAPIGroup";
	private static final String MESSAGE = "message";
	private static final String VALIDATION_ERROR_MESSAGE = "Sorry, Request has validation error(s).";
	private static final String ID = "id";
	
	/**
	 * API to fetch the view for Api Password
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/view")
	public String viewActiveApiPassword() {
		log.info("GET /view");
		return ViewLayer.API_PASSWORD_VIEW.get();
	}

	/**
	 * API to fetch data-tables response for active transaction.
	 * 
	 * @param DataTablesRequest
	 * @return ResponseEntity<DataTablesResponse<TransactionReportBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/view")
	public ResponseEntity<DataTablesResponse<ApiPasswordBean>> viewActiveApiPassword(
			@RequestBody ApiPasswordDataBean dtRequest) {
		log.info("post view {}", dtRequest);
		DataTablesResponse<ApiPasswordBean> dtResponse = apiservice.getActiveApiPassword(dtRequest);
		dtResponse.setDraw(dtRequest.getDataTable().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}
	
	/**
	 * This accept "POST" request for "/update". This method hit when user
	 * submit form for updating "API Password Config" from "api-password-update.jsp".
	 * 
	 * @param ApiPasswordBean Expect "{@link CreateAPIGroup}" object
	 * @param bindingResult  Expect "{@link BindingResult}" object
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/update")
	public ModelAndView updateAPIGroup(@ModelAttribute ApiPasswordBean udpdateApi, BindingResult bindingResult) {
		log.info("POST /api-password/update");
		ModelAndView modelAndView = new ModelAndView(ViewLayer.API_PASSWORD_UPDATE.get());

		if (!bindingResult.hasErrors()) {
			ResponseBean responseBean = new ResponseBean();
			apiservice.processUpdate(udpdateApi, responseBean); // Send data for process.
			modelAndView.addObject(UPDATE_API, udpdateApi);
			modelAndView.addObject(RESPONSE_BEAN, responseBean);
			return modelAndView;
		} else {
			ResponseBean responseBean = new ResponseBean();
			List<FieldError> errors = bindingResult.getFieldErrors();
			StringBuilder message = new StringBuilder();

			for (FieldError e : errors) {
				message.append(e.getField().toUpperCase() + " : " + e.getDefaultMessage());
			}
			responseBean.setMsg(VALIDATION_ERROR_MESSAGE);
			responseBean.setOperationStatus(400);
			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put(MESSAGE, message.toString());
			modelAndView.addObject(RESPONSE_BEAN, responseBean);
			return modelAndView;
		}
	}
	
	/**
	 * This accept "POST" request for "/update-api-group-from-list". This method hit
	 * when user click on "edit" button of list of APIPasswordConfig from
	 * "list-api-group.jsp".
	 * 
	 * @param updateAPIPaswordConfigRequestFromList Expect
	 *                                              "{@link UpdateAPIPaswordConfigRequestFromList}"
	 *                                              object
	 * @param bindingResult                         Expect "{@link BindingResult}"
	 *                                              object
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/api-password-update")
	public ModelAndView updateApiPassword(
			@ModelAttribute UpdateAPIPaswordConfigRequestFromList updateAPIPaswordConfigRequestFromList,
			BindingResult bindingResult) {
		log.info("POST /api-password/api-password-update");
		log.info("UpdateAPIPaswordConfigRequestFromList Id : {}",updateAPIPaswordConfigRequestFromList.getId());
		if (!bindingResult.hasErrors()) {
			ModelAndView modelAndView = new ModelAndView(ViewLayer.API_PASSWORD_UPDATE.get());

			ResponseBean responseBean = new ResponseBean();
			ApiPasswordBean createAPIGroup = ApiPasswordBean.builder().build();
			apiservice.updateApiPassword(updateAPIPaswordConfigRequestFromList, createAPIGroup,
					responseBean); // Send data for process.
			modelAndView.addObject(UPDATE_API, createAPIGroup);
			modelAndView.addObject(RESPONSE_BEAN, responseBean);
			return modelAndView;
		} else {
			ModelAndView modelAndView = new ModelAndView(ViewLayer.API_PASSWORD_VIEW.get());
			ResponseBean responseBean = new ResponseBean();
			List<FieldError> errors = bindingResult.getFieldErrors();
			StringBuilder message = new StringBuilder();

			for (FieldError e : errors) {
				message.append(e.getField().toUpperCase() + " : " + e.getDefaultMessage());
			}
			responseBean.setMsg(VALIDATION_ERROR_MESSAGE);
			responseBean.setOperationStatus(400);
			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put(MESSAGE, message.toString());
			modelAndView.addObject(RESPONSE_BEAN, responseBean);
			return modelAndView;
		}

	}
	
}
