package com.mosambee.controller;

import java.util.Map;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.bean.AddSbiDetailsMidBean;
import com.mosambee.bean.AdminAcquirerBean;
import com.mosambee.bean.AdminAcquirerDataTablesRequestBean;
import com.mosambee.bean.AdminAcquirerListBean;
import com.mosambee.bean.AdminAddAcquirerBean;
import com.mosambee.bean.CustomUser;
import com.mosambee.bean.EditAcquirerDetailsBean;
import com.mosambee.bean.EditSbiDetailsBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.AdminAcquirerService;

import lombok.extern.log4j.Log4j2;

/**
 * AdminAcquirerController is basically used to search admin acquirers by dates.
 * We are basically using this controller to show list of acquirers
 * corresponding to particular dates.
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 18-March-2020
 */
@Log4j2
@Controller
@RequestMapping("/adminacquirer")
public class AdminAcquirerController {

	@Autowired
	private AdminAcquirerService service;

	/**
	 * API to fetch the view for admin Acquirer list
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/admin-acquirer-view")
	public String viewActiveAcquirer() {
		log.info("GET admin-acquirer-view");
		return ViewLayer.ADMIN_ACQUIRER_VIEW.get();
	}

	/**
	 * API to fetch data-tables response for admin acquirer list.
	 * 
	 * @param AdminAcquirerDataTablesRequestBean
	 * @return ResponseEntity<DataTablesResponse<AdminAcquirerBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/admin-acquirer-list")
	public ResponseEntity<DataTablesResponse<AdminAcquirerBean>> viewAdminAcquirerList(
			@RequestBody AdminAcquirerDataTablesRequestBean dtRequest) {
		log.info("POST /admin-acquirer-list {}", dtRequest);

		DataTablesResponse<AdminAcquirerBean> dtResponse = service.getAdminAcquirerList(dtRequest);
		log.info("POST /admin-acquirer-list {}", dtResponse);
		dtResponse.setDraw(dtRequest.getDtRequest().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}

	/**
	 * API to view Add Acquirer page
	 * 
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/add-acquirer")
	public ModelAndView addAcquirer() {
		log.info("GET /adminacquirer/admin-acquirer");
		ModelAndView modelAndView = new ModelAndView(ViewLayer.ADD_ACQUIRER_VIEW.get());

		Map<Integer, String> currencyMap = service.getCurrencyList();

		modelAndView.addObject("currencyList", currencyMap);
		modelAndView.addObject("formValidation", "addAcquirer");
		return modelAndView;
	}

	/**
	 * API to Add Acquirer Details.
	 * 
	 * @param bean {@link AddSbiDetailsMidBean}
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/add-acquirer")
	public ModelAndView addAcquirer(@ModelAttribute AdminAddAcquirerBean bean) {
		log.info("POST /adminacquirer/add-acquirer with bean as: {}", bean);

		ModelAndView modelAndView = new ModelAndView(ViewLayer.ADD_ACQUIRER_VIEW.get());

		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		long userId = Long.parseLong(user.getMyMap().get("id"));

		String response = service.addNewAcquirer(bean, userId);

		log.info("POST /adminacquirer/add-acquirer Response: {}", response);

		if (response.equalsIgnoreCase("Acquirer Added Successfully")) {
			modelAndView.addObject("msg", true);
		} else {
			modelAndView.addObject("msg", response);
		}

		Map<Integer, String> currencyMap = service.getCurrencyList();

		modelAndView.addObject("currencyList", currencyMap);
		modelAndView.addObject("formValidation", "addAcquirer");
		return modelAndView;
	}

	/**
	 * API to View the List of Acquirers
	 * 
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/list-acquirer")
	public ModelAndView getAcquirerList() {
		log.info("GET /adminacquirer/list-acquirer");
		ModelAndView modelAndView = new ModelAndView(ViewLayer.LIST_ACQUIRER_VIEW.get());
		return modelAndView;
	}

	/**
	 * API to fetch data-tables response for Acqurier Listing.
	 * 
	 * @param dtRequest {@link DataTablesRequest}
	 * 
	 * @return ResponseEntity<DataTablesResponse<AdminAcquirerListBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/list-acquirer")
	public ResponseEntity<DataTablesResponse<AdminAcquirerListBean>> getAcquirerList(
			@RequestBody DataTablesRequest dtRequest) {

		log.info("POST /adminacquirer/list-acquirer  with dtRequest: {}", dtRequest);

		DataTablesResponse<AdminAcquirerListBean> dtResponse = service.getSiteAcquirerList(dtRequest);
		dtResponse.setDraw(dtRequest.getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}

	/**
	 * API to fetch data for editing Acquirer Listing.
	 * 
	 * @param editBeanData {@link EditAcquirerDetailsBean}
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/list-acquirer-edit")
	public ModelAndView editAcquirerDetails(@ModelAttribute EditAcquirerDetailsBean editBeanData) {
		log.info("POST /adminacquirer/list-acquirer-edit  with listBean as: {}", editBeanData);
		ModelAndView modelAndView = null;

		long acqId = editBeanData.getAcqId();

		EditAcquirerDetailsBean beanData = service.getSiteAcquirerData(acqId);
		log.info("beanData as: {}", beanData);

		modelAndView = new ModelAndView(ViewLayer.ADD_ACQUIRER_VIEW.get());

		Map<Integer, String> currencyMap = service.getCurrencyList();

		modelAndView.addObject("currencyList", currencyMap);
		modelAndView.addObject("beanData", beanData);
		return modelAndView;

	}

	/**
	 * API to Edit/Update the fetched data-tables response for Acquirer Listing.
	 * 
	 * @param addBeanData {@link EditSbiDetailsBean}
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/update-acquirer")
	public ModelAndView updateAcquirerDetails(@ModelAttribute EditAcquirerDetailsBean updateBeanData) {
		log.info("POST /adminacquirer/update-acquirer  with updateBean as: {}", updateBeanData);
		ModelAndView modelAndView = null;

		long acqId = updateBeanData.getAcqId();
		log.info("acqId as: {} {}", acqId);

		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		long userId = Long.parseLong(user.getMyMap().get("id"));

		modelAndView = new ModelAndView(ViewLayer.ADD_ACQUIRER_VIEW.get());
		
		String response = service.updateAcquirer(updateBeanData, acqId, userId);
		
		if (response.equalsIgnoreCase("success")) {
			modelAndView.addObject("msg", "updated");
		} else {
			modelAndView.addObject("msg", response);
		}
		
		Map<Integer, String> currencyMap = service.getCurrencyList();
		modelAndView.addObject("currencyList", currencyMap);
		modelAndView.addObject("beanData", updateBeanData);
		return modelAndView;

	}

}
