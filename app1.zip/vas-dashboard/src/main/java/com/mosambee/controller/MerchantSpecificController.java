package com.mosambee.controller;

import java.util.HashMap;
import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.bean.MerchantKeyBean;
import com.mosambee.bean.MerchantKeyDataBean;
import com.mosambee.bean.MerchantMappingBean;
import com.mosambee.bean.MerchantMappingDataBean;
import com.mosambee.bean.MerchantNameBean;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.UpdateAPIPaswordConfigRequestFromList;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.MerchantSpecificService;

import lombok.extern.log4j.Log4j2;
/**
 * This class is used to fetch all request of Merchant Specific module. 
 * @author karan.singam
 * @version 1.0
 */
@Log4j2
@Controller
@RequestMapping("/merchant-specific")
public class MerchantSpecificController {

	@Autowired
	private MerchantSpecificService merchantservice;
	

	private static final  String RESPONSE_BEAN = "responseBean";
	private static final  String CREATE_MERCHANT_MAPPING = "createMerchantMapping";
	private static final  String CREATE_MERCHANT_KEY = "createMerchantKey";
	private static final  String MESSAGE = "message";
	private static final  String RECORD_ID = "recordId";
	private static final  String VALIDATION_ERROR_MESSAGE = "Sorry, Request has validation error(s).";
	
	/**This method accept "GET" request for "/create-merchanat-mapping".
	 * This method responsible for redirect user to "merchanat-mapping-create.jsp".
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({"ROLE_SITE_ADMIN"})
	@GetMapping("/create-merchant-mapping")
	public ModelAndView createmerchantMapping()
	{
		log.info("GET  /merchant-specific/create-merchant-mapping");
		ResponseBean responseBean = new ResponseBean();
		responseBean.setData(new HashMap<String, Object>());
		ModelAndView modelAndView = new ModelAndView(ViewLayer.MERCHANT_CREATE_VIEW.get());
		responseBean.setAction(ViewLayer.MERCHANT_MAPPING_ACTION.get());
		responseBean.getData().put(RECORD_ID,0);
		modelAndView.addObject(RESPONSE_BEAN,responseBean);
		return modelAndView;
	}
	
	/**
	 * This method accept "POST" request for "/insert-merchanat-mapping".
	 * This method hit when user submit form for creating "Merchant Mapping" from "merchanat-mapping-create.jsp".
	 * @param  merchantMapping Expect "{@link MerchantMappingBean}" object
	 * @param  bindingResult  Expect "{@link BindingResult}" object
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({"ROLE_SITE_ADMIN"})
	@PostMapping("/insert-merchant-mapping")
	public ModelAndView insertMerchantMapping(@Valid MerchantMappingBean merchantMapping, BindingResult bindingResult)
	{
		ResponseBean responseBean = new ResponseBean();
		ModelAndView modelAndView = new ModelAndView(ViewLayer.MERCHANT_CREATE_VIEW.get());
		log.info(merchantMapping);
		log.info("POST /merchant-specific/insert-merchant-mapping");
		if(!bindingResult.hasErrors())
		{	
			responseBean = merchantservice.createMerchantMapping(merchantMapping); // Send data for process.
			modelAndView.addObject(CREATE_MERCHANT_MAPPING,merchantMapping);
			modelAndView.addObject(RESPONSE_BEAN,responseBean);
			log.info(responseBean);
			return modelAndView;
		}
		else
		{
			 responseBean.getData().put(RECORD_ID,0);
			 List<FieldError> errors = bindingResult.getFieldErrors();
			 StringBuilder message = new StringBuilder();
			 
			 for (FieldError e : errors){
		            message.append(e.getField().toUpperCase() + " : " + e.getDefaultMessage());
		     }
			 responseBean.setMsg(VALIDATION_ERROR_MESSAGE);
			 responseBean.setOperationStatus(400);
			 responseBean.setData(new HashMap<String, Object>());
			 responseBean.getData().put(MESSAGE,message.toString());
			 modelAndView.addObject(RESPONSE_BEAN,responseBean);
			 log.info("request validation error : {}",message);
			 return modelAndView;
		}
		
	}
	
	/**
	 * This accept "POST" request for "/update-merchanat-mapping".
	 * This method hit when user submit form for updating "Merchant Mapping" from "merchanat-mapping-create.jsp".
	 * @param  merchantMapping Expect "{@link MerchantMappingBean}" object
	 * @param  bindingResult  Expect "{@link BindingResult}" object
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({"ROLE_SITE_ADMIN"})
	@PostMapping("/update-merchant-mapping")
	public ModelAndView updateMerchantMapping(@Valid MerchantMappingBean merchantMapping, BindingResult bindingResult)
	{
		log.info("POST /merchant-specific/update-merchant-mapping");	
		ResponseBean responseBean = new ResponseBean();
		ModelAndView modelAndView = new ModelAndView(ViewLayer.MERCHANT_CREATE_VIEW.get());
		
		if(!bindingResult.hasErrors())
		{	
			responseBean = merchantservice.updateMerchantMapping(merchantMapping); // Send data for process.
			modelAndView.addObject(CREATE_MERCHANT_MAPPING,merchantMapping);
			modelAndView.addObject(RESPONSE_BEAN,responseBean);
			return modelAndView;
		}
		else
		{
			 List<FieldError> errors = bindingResult.getFieldErrors();
			 StringBuilder message = new StringBuilder();
			 
			 for (FieldError e : errors){
		            message.append(e.getField().toUpperCase() + " : " + e.getDefaultMessage());
		     }
			 responseBean.setMsg(VALIDATION_ERROR_MESSAGE);
			 responseBean.setOperationStatus(400);
			 responseBean.setData(new HashMap<String, Object>());
			 responseBean.getData().put(MESSAGE,message.toString());
			 modelAndView.addObject(RESPONSE_BEAN,responseBean);
			 return modelAndView;
		}
	}
	
	/**This method accept "GET" request for "/create-merchant-key".
	 * This method responsible for redirect user to "merchant-key-create.jsp".
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({"ROLE_SITE_ADMIN"})
	@GetMapping("/create-merchant-key")
	public ModelAndView createMerchantKey()
	{
		log.info("GET  /merchant-specific/create-merchant-key");
		ResponseBean responseBean = new ResponseBean();
		responseBean.setData(new HashMap<String, Object>());
		ModelAndView modelAndView = new ModelAndView(ViewLayer.MERCHANT_CREATE_KEY.get());
		responseBean.setAction(ViewLayer.MERCHANT_KEY_UPDATE.get());
		responseBean.getData().put(RECORD_ID,0);
		modelAndView.addObject(RESPONSE_BEAN,responseBean);
		return modelAndView;
	}
	
	/**
	 * This accept "POST" request for "/edit-merchanat-key".
	 * This method hit when user submit form for updating "Merchant Key" from "merchanat-key-create.jsp".
	 * @param  merchantKey Expect "{@link MerchantMappingBean}" object
	 * @param  bindingResult  Expect "{@link BindingResult}" object
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({"ROLE_SITE_ADMIN"})
	@PostMapping("/edit-merchant-key")
	public ModelAndView editMerchantKey(@Valid MerchantKeyBean merchantKey, BindingResult bindingResult)
	{
		log.info("POST /merchant-specific/edit-merchant-key");	
		ResponseBean responseBean = new ResponseBean();
		ModelAndView modelAndView = new ModelAndView(ViewLayer.MERCHANT_CREATE_KEY.get());
		
		if(!bindingResult.hasErrors())
		{	
			responseBean = merchantservice.editMerchantKey(merchantKey); // Send data for process.
			modelAndView.addObject(CREATE_MERCHANT_KEY,merchantKey);
			modelAndView.addObject(RESPONSE_BEAN,responseBean);
			return modelAndView;
		}
		else
		{
			 List<FieldError> errors = bindingResult.getFieldErrors();
			 StringBuilder message = new StringBuilder();
			 
			 for (FieldError e : errors){
		            message.append(e.getField().toUpperCase() + " : " + e.getDefaultMessage());
		     }
			 responseBean.setMsg(VALIDATION_ERROR_MESSAGE);
			 responseBean.setOperationStatus(400);
			 responseBean.setData(new HashMap<String, Object>());
			 responseBean.getData().put(MESSAGE,message.toString());
			 modelAndView.addObject(RESPONSE_BEAN,responseBean);
			 return modelAndView;
		}
	}
	
	/**
	 * This accept "POST" request for "/update-mapping-from-list".
	 * This method hit when user click on "edit" button of list of MerchantMappingBean from "merchant-mapping-view.jsp".  
	 * @param  updateMappingFromList Expect "{@link UpdateAPIPaswordConfigRequestFromList}" object
	 * @param  bindingResult  Expect "{@link BindingResult}" object
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({"ROLE_SITE_ADMIN"})
	@PostMapping("/update-mapping-from-list")
	public ModelAndView updateMappingFromList(@ModelAttribute MerchantMappingBean merchantMappingBean, BindingResult bindingResult) {
		log.info("POST /merchant-specific/update-mapping-from-list");
		log.info(merchantMappingBean);
		if(!bindingResult.hasErrors())
		{
			ModelAndView modelAndView = new ModelAndView(ViewLayer.MERCHANT_CREATE_VIEW.get());
			
			ResponseBean responseBean = new ResponseBean();
			MerchantMappingBean createMapping =  MerchantMappingBean.builder().build();
			merchantservice.processMappingById(merchantMappingBean, createMapping, responseBean); // Send data for process.
			modelAndView.addObject(CREATE_MERCHANT_MAPPING,createMapping);
			modelAndView.addObject(RESPONSE_BEAN,responseBean);
			return modelAndView;
		}
		else
		{
			ModelAndView modelAndView = new ModelAndView(ViewLayer.MERCHANT_MAPPING_VIEW.get());
			 ResponseBean responseBean = new ResponseBean();
			 List<FieldError> errors = bindingResult.getFieldErrors();
			 StringBuilder message = new StringBuilder();
			 
			 for (FieldError e : errors){
		            message.append(e.getField().toUpperCase() + " : " + e.getDefaultMessage());
		     }
			 responseBean.setMsg(VALIDATION_ERROR_MESSAGE);
			 responseBean.setOperationStatus(400);
			 responseBean.setData(new HashMap<String, Object>());
			 responseBean.getData().put(MESSAGE,message.toString());
			 modelAndView.addObject(RESPONSE_BEAN,responseBean);
			 return modelAndView;
		}
		
	}
	
	/**
	 * This accept "POST" request for "/update-key-from-list".
	 * This method hit when user click on "edit" button of list of MerchantKeyBean from "merchant-key-view.jsp".  
	 * @param  updateAPIPaswordConfigRequestFromList Expect "{@link UpdateAPIPaswordConfigRequestFromList}" object
	 * @param  bindingResult  Expect "{@link BindingResult}" object
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({"ROLE_SITE_ADMIN"})
	@PostMapping("/update-key-from-list")
	public ModelAndView updateKeyFromList(@ModelAttribute MerchantKeyBean merchantKeyBean, BindingResult bindingResult) {
		log.info("POST /merchant-specific/update-key-from-list");
		
		if(!bindingResult.hasErrors())
		{
			ModelAndView modelAndView = new ModelAndView(ViewLayer.MERCHANT_CREATE_KEY.get());
			
			ResponseBean responseBean = new ResponseBean();
			MerchantKeyBean createKey =  MerchantKeyBean.builder().build();
			merchantservice.processKeyById(merchantKeyBean, createKey, responseBean); // Send data for process.
			modelAndView.addObject(CREATE_MERCHANT_KEY,createKey);
			modelAndView.addObject(RESPONSE_BEAN,responseBean);
			return modelAndView;
		}
		else
		{
			ModelAndView modelAndView = new ModelAndView(ViewLayer.MERCHANT_KEY_VIEW.get());
			
			 ResponseBean responseBean = new ResponseBean();
			 List<FieldError> errors = bindingResult.getFieldErrors();
			 StringBuilder message = new StringBuilder();
			 
			 for (FieldError e : errors){
		            message.append(e.getField().toUpperCase() + " : " + e.getDefaultMessage());
		     }
			 responseBean.setMsg(VALIDATION_ERROR_MESSAGE);
			 responseBean.setOperationStatus(400);
			 responseBean.setData(new HashMap<String, Object>());
			 responseBean.getData().put(MESSAGE,message.toString());
			 modelAndView.addObject(RESPONSE_BEAN,responseBean);
			 return modelAndView;
		}
		
	}
	
	/**
	 * API for getting list of Merchant Name.
	 * 
	 * @param MerchantNameBean
	 * @return ResponseEntity<List<MerchantNameBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/merchant-name")
	public ResponseEntity<List<MerchantNameBean>> getMerchantName(@RequestBody MerchantNameBean merchantbean) {

		List<MerchantNameBean> data = merchantservice.getMerchantName(merchantbean);
		log.info(data);
		return new ResponseEntity<>(data, HttpStatus.OK);
	}
	
	/**
	 * API to fetch the view for Merchant Mapping
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/merchant-mapping-view")
	public String viewMerchantMapping() {
		log.info("GET merchant-mapping-view");
		return ViewLayer.MERCHANT_MAPPING_VIEW.get();
	}
	
	/**
	 * API to fetch data-tables response for active Merchant mapping.
	 * 
	 * @param DataTablesRequest
	 * @return ResponseEntity<DataTablesResponse<MerchantMappingDataBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/merchant-mapping-view")
	public ResponseEntity<DataTablesResponse<MerchantMappingBean>> merchantMappingView(
			@RequestBody MerchantMappingDataBean dtRequest) {
		log.info("post merchant-mapping-view {}", dtRequest);
		DataTablesResponse<MerchantMappingBean> dtResponse = merchantservice.getMerchantMappingView(dtRequest);
		dtResponse.setDraw(dtRequest.getDataTable().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}

	/**
	 * API for download using data tables for active  Merchant mapping.
	 * downloadMerchantMapping() is used for providing download file in
	 * xlsx format.
	 * 
	 * @param DataTablesRequest
	 * @return ResponseEntity<DataTablesResponse<MerchantMappingDataBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/merchant-mapping-download")
	public Object downloadMerchantMapping(@ModelAttribute MerchantMappingBean report) {
		Resource resource = merchantservice.downloadMerchantMapping(report);
		if(resource!=null) {
		log.info("Resource {}", resource);
		return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"MerchantMapping.xlsx\"").body(resource);
		}
		else {
			log.error("Error ocurred while downloading merchant mapping reporting list.");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.MERCHANT_MAPPING_VIEW.get());
			modelAndView.addObject("msg", true);
			return modelAndView;
		}
	}
	
	/**
	 * API to fetch the view for Merchant Mapping
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/merchant-key-view")
	public String viewMerchantKey() {
		log.info("GET merchant-key-view");
		return ViewLayer.MERCHANT_KEY_VIEW.get();
	}
	
	/**
	 * API to fetch data-tables response for active merchant Key.
	 * 
	 * @param DataTablesRequest
	 * @return ResponseEntity<DataTablesResponse<MerchantKeyBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/merchant-key-view")
	public ResponseEntity<DataTablesResponse<MerchantKeyBean>> merchantKey(
			@RequestBody MerchantKeyDataBean dtRequest) {
		log.info("post merchant-mapping-view {}", dtRequest);
		DataTablesResponse<MerchantKeyBean> dtResponse = merchantservice.getMerchantKey(dtRequest);
		dtResponse.setDraw(dtRequest.getDataTable().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}

	/**
	 * API for download using data tables for active merchant key.
	 * downloadMerchantKey() is used for providing download file in
	 * xlsx format.
	 * 
	 * @param DataTablesRequest
	 * @return ResponseEntity<DataTablesResponse<MerchantKeyDataBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/merchant-key-download")
	public Object downloadMerchantKey(@ModelAttribute MerchantKeyBean report) {
		Resource resource = merchantservice.downloadMerchantKey(report);
		if(resource!=null) {
		log.info("Resource {}", resource);
		return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"ProductDetails.xlsx\"").body(resource);
		}
		else {
			log.error("Error ocurred while downloading merchant key reporting list.");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.MERCHANT_KEY_VIEW.get());
			modelAndView.addObject("msg", true);
			return modelAndView;
		}
	}
	
	/**This method accept "GET" request for "/bulk-upload".
	 * This method responsible for redirect user to "bulk-upload.jsp".
	 * @return {@link ModelAndView}
	 */
	
	@RolesAllowed({"ROLE_SITE_ADMIN"})
	@GetMapping("/bulk-upload")
	public ModelAndView upload()
	{
		log.info("GET /merchant-specific/bulk-upload");
		return new ModelAndView(ViewLayer.MERCHANT_BULK_UPLOAD.get());
	}
	
	/**This method accept "POST" request for "/bulk-upload".
	 * @param file MultiPartFile that we will receive in the request.
	 * @return Object :	 If caught exception  or resource is null then return {@link ModelAndView}
	 *					 Otherwise return generated ".xlsx" file.					
	 */		  
	@RolesAllowed({"ROLE_SITE_ADMIN"})
	@PostMapping("/bulk-upload")
	public Object bulkUpload(@RequestParam("file") MultipartFile file) {
		log.info("POST /merchant-specific/bulk-upload");
		
		log.info("Request time: {}", System.currentTimeMillis());
		// Get the resource from service
		Resource resource = merchantservice.processBulkUploadExcel(file);
			
		if (null != resource) {
				
			log.info("Response time: {}", System.currentTimeMillis());
				
			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"BulkUpload.xlsx\"")
					.body(resource);
		} else {
			ModelAndView modelAndView = new ModelAndView(ViewLayer.MERCHANT_BULK_UPLOAD.get());
			modelAndView.addObject("invalid", true);
			return modelAndView;
		}
	}

	/**
	 * getBulkUploadFormat() is responsible for downloading the bulk upload format
	 * for bulk-upload.
	 * @return Object
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@GetMapping("/bulk-upload-format")
	public Object getBulkUploadFormat() {

		log.info("GET /merchant-specific/bulk-upload-format");

		Resource resource = merchantservice.getBulkUploadFormat();

		if (null != resource) {
			log.info("Sending bulk upload format in response.");
			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"bulk-upload-format.xlsx\"")
					.body(resource);
		} else {
			log.error("Error ocurred while downloading bulk upload sample file.");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.MERCHANT_BULK_UPLOAD.get());
			modelAndView.addObject("bulk_format_error", true);
			return modelAndView;
		}

	}
	
	/**This method accept "GET" request for "/key-bulk-upload".
	 * This method responsible for redirect user to "key-bulk-upload.jsp".
	 * @return {@link ModelAndView}
	 */
	
	@RolesAllowed({"ROLE_SITE_ADMIN"})
	@GetMapping("/key-bulk-upload")
	public ModelAndView keyUpload()
	{
		log.info("GET /merchant-specific/key-bulk-upload");
		return new ModelAndView(ViewLayer.MERCHANT_KEY_BULK_UPLOAD.get());
	}
	
	/**This method accept "POST" request for "/key-bulk-upload".
	 * @param file MultiPartFile that we will receive in the request.
	 * @return Object :	 If caught exception  or resource is null then return {@link ModelAndView}
	 *					 Otherwise return generated ".xlsx" file.					
	 */		  
	@RolesAllowed({"ROLE_SITE_ADMIN"})
	@PostMapping("/key-bulk-upload")
	public Object keyBulkUpload(@RequestParam("file") MultipartFile file) {
		log.info("POST /merchant-specific/key-bulk-upload");
		
		log.info("Request time: {}", System.currentTimeMillis());
		// Get the resource from service
		Resource resource = merchantservice.processKeyBulkUploadExcel(file);
			
		if (null != resource) {
				
			log.info("Response time: {}", System.currentTimeMillis());
				
			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"KeyBulkUpload.xlsx\"")
					.body(resource);
		} else {
			ModelAndView modelAndView = new ModelAndView(ViewLayer.MERCHANT_KEY_BULK_UPLOAD.get());
			modelAndView.addObject("invalid", true);
			return modelAndView;
		}
	}

	/**
	 * getKeyBulkUploadFormat() is responsible for downloading the bulk upload format
	 * for bulk-upload.
	 * @return Object
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@GetMapping("/key-bulk-upload-format")
	public Object getKeyBulkUploadFormat() {

		log.info("GET /merchant-specific/key-bulk-upload-format");

		Resource resource = merchantservice.getKeyBulkUploadFormat();

		if (null != resource) {
			log.info("Sending bulk upload format in response.");
			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"key-bulk-upload-format.xlsx\"")
					.body(resource);
		} else {
			log.error("Error ocurred while downloading key bulk upload sample file.");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.MERCHANT_KEY_BULK_UPLOAD.get());
			modelAndView.addObject("bulk_format_error", true);
			return modelAndView;
		}

	}
	
}
