package com.mosambee.controller;

import javax.annotation.security.RolesAllowed;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.bean.TgBean;
import com.mosambee.bean.TgCrudBean;
import com.mosambee.bean.TgDataTableRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.TgService;

import lombok.extern.log4j.Log4j2;

/**
 * TgController is basically used to describe tg related operations.
 * We are basically using this controller to show list of tgs, add new tg and also update existing tgs.
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 08-April-2020
 */
@Log4j2
@Controller
@RequestMapping("/tg")
public class TgController {

	private static final String TGCRUDBEANDATA = "tgCrudBean"; 
	
	@Autowired
	private TgService service;
	/**
	 * API to fetch the view for Tg list tab.
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/tg-list")
	public String viewTg() {
		log.info("GET /tg-list");
		return ViewLayer.TG_LIST_VIEW.get();
	}
	
	/**
	 * API to fetch data-tables response for tg list.
	 * 
	 * @param TgDataTableRequestBean
	 * @return ResponseEntity<DataTablesResponse<TgBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/tg-listing")
	public ResponseEntity<DataTablesResponse<TgBean>> viewTgList(@RequestBody TgDataTableRequestBean dtRequest) {
		log.info("POST /tg-listing {}", dtRequest);
		
		DataTablesResponse<TgBean> dtResponse = service.getTgList(dtRequest);
		log.info("POST /tg-listing {}", dtResponse);
		dtResponse.setDraw(dtRequest.getDtRequest().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}
	
	/**
	 * API to fetch the view for Tg add tab.
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/add-tg")
	public ModelAndView viewAddTg() {
		log.info("GET /tg/add-tg");
		ModelAndView modelAndView = new ModelAndView(ViewLayer.TG_ADD_VIEW.get());
		modelAndView.addObject(TGCRUDBEANDATA,new TgCrudBean());
		return modelAndView;
	}
	
	/**
	 * API to process post data of add tg.
	 * @param TgCrudBean tgCrudBean
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/add-tg")
	public ModelAndView addTg(@Valid @ModelAttribute("tgCrudBean") TgCrudBean tgCrudBean,BindingResult result) {
		log.info("POST /tg/add-tg");
		log.info("tgCrudBean  {}", tgCrudBean);
		ModelAndView modelAndView = new ModelAndView(ViewLayer.TG_ADD_VIEW.get());
		if (result.hasErrors()) {
			log.info("error occured while validating add tg");
			modelAndView.addObject(TGCRUDBEANDATA,tgCrudBean);
			return modelAndView;
	    }
		
		boolean res = service.addTg(tgCrudBean);
		
		log.info("tg created {} ",res);
		
		modelAndView.addObject(TGCRUDBEANDATA,new TgCrudBean());
		modelAndView.addObject("msg",res);
		return modelAndView;
	}

	/**
	 * editTg is used to edit the tg details here we get the tg details and send it to view
	 * @param tgId
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/edit-tg")
	public ModelAndView editTg(@RequestParam int tgId) {
		log.info("POST /tg/edit-tg");
		ModelAndView modelAndView = new ModelAndView(ViewLayer.TG_UPDATE_VIEW.get());

		TgCrudBean tgCrudBean = service.getTgDetails(tgId);
		modelAndView.addObject(TGCRUDBEANDATA,tgCrudBean);
		return modelAndView;
	}
	
	/**
	 * API to process post data of update tg.
	 * @param TgCrudBean tgCrudBean
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/update-tg")
	public ModelAndView updateUser(@Valid @ModelAttribute("tgCrudBean") TgCrudBean tgCrudBean,BindingResult result) {
		log.info("POST /tg/update-tg");
		log.info("tgCrudBean  {}", tgCrudBean);
		ModelAndView modelAndView = new ModelAndView(ViewLayer.TG_UPDATE_VIEW.get());
		if (result.hasErrors()) {
			log.info("error occured while validating update tg");
			modelAndView.addObject(TGCRUDBEANDATA,tgCrudBean);
			return modelAndView;
	    }

		boolean res = service.updateTg(tgCrudBean);
		
		log.info("tg updated {} ",res); 
		
		modelAndView.addObject(TGCRUDBEANDATA,tgCrudBean);
		modelAndView.addObject("msg",res);
		return modelAndView;
	}
	
	
}
