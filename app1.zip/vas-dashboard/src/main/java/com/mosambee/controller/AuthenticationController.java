package com.mosambee.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Controller
public class AuthenticationController {

	@GetMapping("/login")
	public String login(@RequestParam Map<String, String> allRequestParams, HttpServletRequest request,
			@ModelAttribute("forgot-password") String forgotPassword,
			@ModelAttribute("reset-password") String resetPassword, ModelMap modelMap) {

		// Log the incoming request
		log.info("GET /login allRequestParams: {}, forgotPassword: {}, resetPassword: {}", allRequestParams,
				forgotPassword, resetPassword);

		// Set the incoming attributes to the model
		modelMap.addAttribute("forgotPassword", forgotPassword);
		modelMap.addAttribute("resetPassword", resetPassword);

		// Return the login view
		return "login";
	}

	@GetMapping("/")
	public ModelAndView redirect() {
		log.info("Redirecting from the index controller");
		return new ModelAndView("redirect:/enquiry-reporting/enquiry");
	}

}
