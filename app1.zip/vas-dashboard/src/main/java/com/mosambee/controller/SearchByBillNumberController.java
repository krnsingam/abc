package com.mosambee.controller;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mosambee.bean.BillNumberBean;
import com.mosambee.bean.BillNumberDataTablesRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.SearchByBillNumberService;

import lombok.extern.log4j.Log4j2;

/**
 * SearchByBillNumberController is basically used to search transactions by using bill number.
 * We are basically using this controller to show list of transactions corresponding to particular bill number.
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 23-March-2020
 */

@Log4j2
@Controller
@RequestMapping("/searchbybillnumber")
public class SearchByBillNumberController {
	
	@Autowired
	private SearchByBillNumberService service;
	/**
	 * API to fetch the view for SearchByBillNumber
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/billnumber-transaction-list")
	public String viewSearchByBillNumber() {
		log.info("GET billnumber-transaction-list");
		return ViewLayer.SEARCH_BY_BILLNUMBER_VIEW.get();
	}
	
	/**
	 * API to fetch data-tables response for BillNumber transaction list.
	 * 
	 * @param  BillNumberDataTablesRequestBean
	 * @return ResponseEntity<DataTablesResponse<BillNumberBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/billnumber-transaction-list")
	public ResponseEntity<DataTablesResponse<BillNumberBean>> viewBillNumberTransactionList(@RequestBody BillNumberDataTablesRequestBean dtRequest) {
		log.info("POST /billnumber-transaction-list {}", dtRequest);
		
		DataTablesResponse<BillNumberBean> dtResponse = service.getBillNumberTransactionList(dtRequest);
		log.info("POST /billnumber-transaction-list {}", dtResponse);
		dtResponse.setDraw(dtRequest.getDtRequest().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}


}
