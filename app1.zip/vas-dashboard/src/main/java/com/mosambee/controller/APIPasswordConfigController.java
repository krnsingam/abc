package com.mosambee.controller;

import java.util.HashMap;
import java.util.List;
import javax.annotation.security.RolesAllowed;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import com.mosambee.bean.CreateAPIGroup;
import com.mosambee.bean.ListOfAPIGroup;
import com.mosambee.bean.MidTidBean;
import com.mosambee.bean.MidTidDetailBean;
import com.mosambee.bean.ResponseBean;
import com.mosambee.bean.UpdateAPIPaswordConfigRequestFromList;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.APIPasswordConfigService;
import com.mosambee.service.MIDBulkUploadService;

import lombok.extern.log4j.Log4j2;

/**
 * This class is used to fetch all request of APIPasswordConfig module.
 * 
 * @author mandar.chaudhari
 * @version 1.0
 */
@Log4j2
@Controller
@RequestMapping("/api-password-config")
public class APIPasswordConfigController {
	@Autowired
	APIPasswordConfigService apiPasswordConfigService;

	@Autowired
	MIDBulkUploadService midBulkUploadService;

	private static final String RESPONSE_BEAN = "responseBean";
	private static final String CREATE_API_GROUP = "createAPIGroup";
	private static final String MESSAGE = "message";
	private static final String VALIDATION_ERROR_MESSAGE = "Sorry, Request has validation error(s).";
	private static final String ID = "id";

	/**
	 * This method accept "GET" request for "/create-api-group". This method
	 * responsible for redirect user to "create-api-group.jsp".
	 * 
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@GetMapping("/create-api-group")
	public ModelAndView createAPIGroup() {
		log.info("GET /api_password_config /create_api_group");
		ResponseBean responseBean = new ResponseBean();
		responseBean.setData(new HashMap<String, Object>());
		ModelAndView modelAndView = new ModelAndView(ViewLayer.CREATE_API_GROUP_VIEW.get());
		responseBean.setAction(ViewLayer.CREATE_API_GROUP_ACTION.get());
		responseBean.getData().put("recordId", 0);
		modelAndView.addObject(RESPONSE_BEAN, responseBean);
		return modelAndView;
	}

	/**
	 * This method accept "POST" request for "/insert-api-group". This method hit
	 * when user submit form for creating "API Password Config" from
	 * "create-api-group.jsp".
	 * 
	 * @param createAPIGroup Expect "{@link CreateAPIGroup}" object
	 * @param bindingResult  Expect "{@link BindingResult}" object
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/insert-api-group")
	public ModelAndView insertAPIGroup(@Valid CreateAPIGroup createAPIGroup, BindingResult bindingResult) {
		ModelAndView modelAndView = new ModelAndView(ViewLayer.CREATE_API_GROUP_VIEW.get());

		log.info("POST /api_password_config /insert_api_group");
		if (!bindingResult.hasErrors()) {
			ResponseBean responseBean = new ResponseBean();
			responseBean = apiPasswordConfigService.processCreateAPIGroupData(createAPIGroup, responseBean); // Send
																												// data
																												// for
																												// process.
			modelAndView.addObject(CREATE_API_GROUP, createAPIGroup);
			modelAndView.addObject(RESPONSE_BEAN, responseBean);
			log.info(responseBean);
			return modelAndView;
		} else {
			ResponseBean responseBean = new ResponseBean();
			responseBean.getData().put("recordId", 0);
			List<FieldError> errors = bindingResult.getFieldErrors();
			StringBuilder message = new StringBuilder();

			for (FieldError e : errors) {
				message.append(e.getField().toUpperCase() + " : " + e.getDefaultMessage());
			}
			responseBean.setMsg(VALIDATION_ERROR_MESSAGE);
			responseBean.setOperationStatus(400);
			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put(MESSAGE, message.toString());
			modelAndView.addObject(RESPONSE_BEAN, responseBean);
			log.info("request validation error : {}", message);
			return modelAndView;
		}

	}

	/**
	 * This accept "POST" request for "/update-api-group". This method hit when user
	 * submit form for updating "API Password Config" from "create-api-group.jsp".
	 * 
	 * @param createAPIGroup Expect "{@link CreateAPIGroup}" object
	 * @param bindingResult  Expect "{@link BindingResult}" object
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/update-api-group")
	public ModelAndView updateAPIGroup(@Valid CreateAPIGroup createAPIGroup, BindingResult bindingResult) {
		log.info("POST /api_password_config /update_api_group");
		ModelAndView modelAndView = new ModelAndView(ViewLayer.CREATE_API_GROUP_VIEW.get());

		if (!bindingResult.hasErrors()) {
			ResponseBean responseBean = new ResponseBean();
			apiPasswordConfigService.processUpdateAPIGroupData(createAPIGroup, responseBean); // Send data for process.
			modelAndView.addObject(CREATE_API_GROUP, createAPIGroup);
			modelAndView.addObject(RESPONSE_BEAN, responseBean);
			return modelAndView;
		} else {
			ResponseBean responseBean = new ResponseBean();
			List<FieldError> errors = bindingResult.getFieldErrors();
			StringBuilder message = new StringBuilder();

			for (FieldError e : errors) {
				message.append(e.getField().toUpperCase() + " : " + e.getDefaultMessage());
			}
			responseBean.setMsg(VALIDATION_ERROR_MESSAGE);
			responseBean.setOperationStatus(400);
			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put(MESSAGE, message.toString());
			modelAndView.addObject(RESPONSE_BEAN, responseBean);
			return modelAndView;
		}
	}

	/**
	 * This method hit when "GET" request come for "/list-api-group". This method
	 * responsible for redirect user to "list-api-group.jsp".
	 * 
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/list-api-group")
	public ModelAndView listAPIGroup() {
		log.info("GET /api-password-config/list-api-group ");
		return new ModelAndView(ViewLayer.LIST_API_GROUP_VIEW.get());
	}

	/**
	 * This method accept "POST" request for "/list-api-group". This method hit when
	 * "DataTable" of list of APIPasswordConfig send request for fetching list of
	 * records with filters.
	 * 
	 * @param dtRequest Expect "{@link DataTablesRequest}" object
	 * @return {@link ResponseEntity}<{@link DataTablesResponse}<{@link ListOfAPIGroup}>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/list-api-group")
	public ResponseEntity<DataTablesResponse<ListOfAPIGroup>> listAPIGroup(@RequestBody DataTablesRequest dtRequest) {
		log.info("POST /api-password-config/list-api-group {}", dtRequest);

		DataTablesResponse<ListOfAPIGroup> dtResponse = apiPasswordConfigService.getListOfAPIGroup(dtRequest);

		dtResponse.setDraw(dtRequest.getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);

	}

	/**
	 * This method hit when "GET" request come for "/mid-tid". This method
	 * responsible for redirect user to "/mid-tid-view.jsp".
	 * 
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/mid-tid")
	public ModelAndView listMidTid(@RequestParam int id) {
		log.info("GET /api-password-config/mid-tid ");
		ModelAndView modelAndView = new ModelAndView(ViewLayer.MID_TID_VIEW.get());
		modelAndView.addObject(ID, id);
		return modelAndView;
	}

	/**
	 * This method accept "POST" request for "/mid-tid". This method hit when
	 * "DataTable" of list of MidTidBean send request for fetching list of records
	 * with filters.
	 * 
	 * @param dtRequest Expect "{@link DataTablesRequest}" object
	 * @param int       id
	 * @return {@link ResponseEntity}<{@link DataTablesResponse}<{@link listMidTid}>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/mid-tid-next")
	public ResponseEntity<DataTablesResponse<MidTidBean>> listMidTid(@RequestBody MidTidDetailBean midbean) {
		log.info("POST /api-password-config/mid-tid-next {}", midbean.getDtRequest());
		int id = Integer.parseInt(midbean.getId());
		DataTablesResponse<MidTidBean> dtResponse = apiPasswordConfigService.listMidTid(midbean.getDtRequest(), id);

		dtResponse.setDraw(midbean.getDtRequest().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);

	}

	/**
	 * This accept "POST" request for "/update-api-group-from-list". This method hit
	 * when user click on "edit" button of list of APIPasswordConfig from
	 * "list-api-group.jsp".
	 * 
	 * @param updateAPIPaswordConfigRequestFromList Expect
	 *                                              "{@link UpdateAPIPaswordConfigRequestFromList}"
	 *                                              object
	 * @param bindingResult                         Expect "{@link BindingResult}"
	 *                                              object
	 * @return {@link ModelAndView}
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/update-api-group-from-list")
	public ModelAndView updateAPIGroupFromList(
			@ModelAttribute UpdateAPIPaswordConfigRequestFromList updateAPIPaswordConfigRequestFromList,
			BindingResult bindingResult) {
		log.info("POST /api-password-config/update-api-group-from-list");

		if (!bindingResult.hasErrors()) {
			ModelAndView modelAndView = new ModelAndView(ViewLayer.CREATE_API_GROUP_VIEW.get());

			ResponseBean responseBean = new ResponseBean();
			CreateAPIGroup createAPIGroup = CreateAPIGroup.builder().build();
			apiPasswordConfigService.processGetAPIGroupDataById(updateAPIPaswordConfigRequestFromList, createAPIGroup,
					responseBean); // Send data for process.
			modelAndView.addObject(CREATE_API_GROUP, createAPIGroup);
			modelAndView.addObject(RESPONSE_BEAN, responseBean);
			return modelAndView;
		} else {
			ModelAndView modelAndView = new ModelAndView(ViewLayer.LIST_API_GROUP_VIEW.get());
			ResponseBean responseBean = new ResponseBean();
			List<FieldError> errors = bindingResult.getFieldErrors();
			StringBuilder message = new StringBuilder();

			for (FieldError e : errors) {
				message.append(e.getField().toUpperCase() + " : " + e.getDefaultMessage());
			}
			responseBean.setMsg(VALIDATION_ERROR_MESSAGE);
			responseBean.setOperationStatus(400);
			responseBean.setData(new HashMap<String, Object>());
			responseBean.getData().put(MESSAGE, message.toString());
			modelAndView.addObject(RESPONSE_BEAN, responseBean);
			return modelAndView;
		}

	}

	/**
	 * This method accept "GET" request for "/mid-bulk-upload". This method
	 * responsible for redirect user to "mid-bulk-upload.jsp".
	 * 
	 * @return {@link ModelAndView}
	 */

	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@GetMapping("/mid-bulk-upload")
	public ModelAndView midUpload() {
		log.info("GET /api_password_config /mid-bulk-upload");
		return new ModelAndView(ViewLayer.MID_BULK_UPLOAD_VIEW.get());
	}

	/**
	 * This method accept "POST" request for "/mid-bulk-upload".
	 * 
	 * @param file MultiPartFile that we will receive in the request.
	 * @return Object : If caught exception or resource is null then return
	 *         {@link ModelAndView} Otherwise return generated ".xlsx" file.
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/mid-bulk-upload")
	public Object bulkUpload(@RequestParam("file") MultipartFile file) {
		log.info("POST /create-api-group/mid-bulk-upload");

		log.info("Request time: {}", System.currentTimeMillis());
		// Get the resource from service
		Resource resource = midBulkUploadService.processBulkUploadExcel(file);

		if (null != resource) {

			log.info("Response time: {}", System.currentTimeMillis());

			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"UpdateMiUploadResponse.xlsx\"")
					.body(resource);
		} else {
			ModelAndView modelAndView = new ModelAndView(ViewLayer.MID_BULK_UPLOAD_VIEW.get());
			modelAndView.addObject("invalid", true);
			return modelAndView;
		}
	}

	/**
	 * getBulkUploadFormat() is responsible for downloading the bulk upload format
	 * for mid-bulk-upload.
	 * 
	 * @return Object
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@GetMapping("/mid-bulk-upload-format")
	public Object getMidBulkUploadFormat() {

		log.info("GET /api-password-config/mid-bulk-upload-format");

		Resource resource = midBulkUploadService.getMIDBulkUploadFormat();

		if (null != resource) {
			log.info("Sending bulk upload format in response.");
			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"mid-bulk-upload-format.xlsx\"")
					.body(resource);
		} else {
			log.error("Error ocurred while downloading mid bulk upload sample file.");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.MID_BULK_UPLOAD_VIEW.get());
			modelAndView.addObject("bulk_format_error", true);
			return modelAndView;
		}

	}

}
