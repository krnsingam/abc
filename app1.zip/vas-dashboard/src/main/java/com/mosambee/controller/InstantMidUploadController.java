package com.mosambee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.InstantMidUploadService;

import lombok.extern.log4j.Log4j2;

/**
 * This class is basically used for uploading file of instant merchant mid tid
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Log4j2
@Controller
@RequestMapping("/instant-mid-upload")
public class InstantMidUploadController {

	@Autowired
	InstantMidUploadService instantMidUploadService;

	/**
	 * Api to view Instant merchant Mid Upload
	 * 
	 * @return String
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@GetMapping("/merchant-mid-upload")
	public String instantMidUpload() {
		log.info("GET /instant-mid-upload/merchant-mid-upload");
		return ViewLayer.INSTANT_MID_UPLOAD.get();
	}

	/**
	 * @param file MultiPartFile that we will receive in the request.
	 * @return Object
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@PostMapping("/merchant-mid-upload")
	public Object instantMidUpload(@RequestParam("file") MultipartFile file) {
		log.info("POST /instant-mid-upload/merchant-mid-upload");

		log.info("Request time: {}", System.currentTimeMillis());

		// Get the resource from service
		Resource resource = instantMidUploadService.processInstantMidUploadExcel(file);

		if (null != resource) {

			log.info("Response time: {}", System.currentTimeMillis());

			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"ReplaceMid/TidResponse.xlsx\"")
					.body(resource);
		} else {
			ModelAndView modelAndView = new ModelAndView(ViewLayer.INSTANT_MID_UPLOAD.get());
			modelAndView.addObject("invalid", true);
			return modelAndView;
		}

	}

	/**
	 * getInstantMidUploadFormat() is responsible for downloading the instant
	 * merchant mid upload format
	 * 
	 * @return Object
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@GetMapping("/merchant-mid-upload-format")
	public Object getInstantMidUploadFormat() {

		log.info("GET /instant-mid-upload/merchant-mid-upload-format");

		Resource resource = instantMidUploadService.getInstantMidUploadFormat();

		if (null != resource) {
			log.info("Sending  instant merchant mid upload format in response.");
			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION,
							"attachment; filename=\"replace-mid/tid-upload-format.xlsx\"")
					.body(resource);
		} else {
			log.error("Error ocurred while downloading merchant mid upload sample file.");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.INSTANT_MID_UPLOAD.get());
			modelAndView.addObject("merchant_mid_upload_format_error", true);
			return modelAndView;
		}

	}

}
