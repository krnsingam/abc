package com.mosambee.controller;

import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.bean.AcquirerBean;
import com.mosambee.bean.BusinessMISCrudBean;
import com.mosambee.bean.BusinessMISDownloadCrudBean;
import com.mosambee.bean.BusinessMISDownloadResponseBean;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.MISReportService;

import lombok.extern.log4j.Log4j2;

/**
 * MISReportController is basically used to describe business MIS related operations.
 * We are basically using this controller to update existing Business MIS and also to download Business MIS for acquirers.
 * 
 * @author mariam.siddique
 * @version 1.0
 * @since 15-April-2020
 */
@Log4j2
@Controller
@RequestMapping("/businessmis")
public class MISReportController {

	@Autowired
	private MISReportService service;
	
	private static final String BUSINESSMISCRUDBEANDATA = "businessMISCrudBean"; 
	private static final String BUSINESSMISDOWNLOADCRUDBEANDATA = "businessMISDownloadCrudBean";
	private static final String AQUIRERES = "aquirers";
	/**
	 * API to fetch the view for update MIS tab.
	 * 
	 * @return modelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER"})
	@GetMapping("/businessmis-update")
	public ModelAndView viewBusinessMISUpdate() {
		log.info("GET /businessmis/abusinessmis-update");
		ModelAndView modelAndView = new ModelAndView(ViewLayer.BUSINESSMIS_UPDATE_VIEW.get());
		modelAndView.addObject(BUSINESSMISCRUDBEANDATA,new BusinessMISCrudBean());
		return modelAndView;
	}
	
	/**
	 * API to process post data of update MIS.
	 * @param BusinessMISCrudBean businessMISCrudBean
	 * @return ModelAndView
	 */

	@RolesAllowed({ "ROLE_SITE_ADMIN" , "ROLE_SITE_USER"})
	@PostMapping("/businessmis-update")
	public ModelAndView updateMIS(@Valid @ModelAttribute("businessMISCrudBean") BusinessMISCrudBean businessMISCrudBean,BindingResult result) {
		log.info("POST /businessmis/businessmis-update");
		log.info("businessMISCrudBean  {}", businessMISCrudBean);
		ModelAndView modelAndView = new ModelAndView(ViewLayer.BUSINESSMIS_UPDATE_VIEW.get());
		if (result.hasErrors()) {
			log.info("error occured while validating update business MIS");
			modelAndView.addObject(BUSINESSMISCRUDBEANDATA,businessMISCrudBean);
			return modelAndView;
	    }
		
		String res = service.updateBusinessMIS(businessMISCrudBean);
		int flag = 0; 
		if("success".equals(res)) {
			flag = 1;
		}else if("Invalid UserNumber".equals(res)) {
			flag = -1;
		}else {
			flag = 0;
		}
		
		log.info("Business mis upadted {} ",res);
		modelAndView.addObject("msg", flag);
		modelAndView.addObject(BUSINESSMISCRUDBEANDATA,businessMISCrudBean);
		return modelAndView;
	}
	
	/**
	 * API to fetch the view for download MIS tab.
	 * 
	 * @return modelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER"})
	@GetMapping("/businessmis-download")
	public ModelAndView viewBusinessMISDownload() {
		log.info("GET /businessmis/businessmis-download");
		ModelAndView modelAndView = new ModelAndView(ViewLayer.BUSINESSMIS_DOWNLOAD_VIEW.get());
		List<AcquirerBean> acquirerList = service.getListOfAcquirer();
		modelAndView.addObject(BUSINESSMISDOWNLOADCRUDBEANDATA,new BusinessMISDownloadCrudBean());
		modelAndView.addObject(AQUIRERES,acquirerList);
		return modelAndView;
	}
	
	/**
	 * API to download Business MIS for acquirers.
	 * downloadMIS() is used for providing download file in
	 * xlsx format.
	 * 
	 * @param businessMISDownloadCrudBean{@link BusinessMISDownloadCrudBean}
	 * @return Object
	 */

	@RolesAllowed({ "ROLE_SITE_ADMIN" ,"ROLE_SITE_USER"})
	@PostMapping("/businessmis-download")
	public Object downloadMIS(@Valid @ModelAttribute("businessMISDownloadCrudBean") BusinessMISDownloadCrudBean businessMISDownloadCrudBean,BindingResult result) {
		
		if (result.hasErrors()) {
			log.info("error occured while validating download business MIS");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.BUSINESSMIS_DOWNLOAD_VIEW.get());
			List<AcquirerBean> acquirerList = service.getListOfAcquirer();
			modelAndView.addObject(AQUIRERES,acquirerList);
			modelAndView.addObject(BUSINESSMISDOWNLOADCRUDBEANDATA,businessMISDownloadCrudBean);
			return modelAndView;
	    }
		List<BusinessMISDownloadResponseBean> list = service.getDataToDownloadBusinessMIS(businessMISDownloadCrudBean);
		if (!list.isEmpty()) {
			// Get the resource from service
			Resource resource = service.downloadBusinessMIS(list);
			if (resource != null) {

				log.info("Resource {}", resource);
				String filename = "Business MIS_"+businessMISDownloadCrudBean.getFromDate()+" To "+businessMISDownloadCrudBean.getToDate()+".xlsx";
			
				return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION,String.format("attachment; filename=\"%s\"",filename))
					.body(resource);
			} else {
				log.error("Error ocurred while downloading businessmis.");
				ModelAndView modelAndView = new ModelAndView(ViewLayer.BUSINESSMIS_DOWNLOAD_VIEW.get());
				List<AcquirerBean> acquirerList = service.getListOfAcquirer();
				modelAndView.addObject(AQUIRERES,acquirerList);
				modelAndView.addObject(BUSINESSMISDOWNLOADCRUDBEANDATA,businessMISDownloadCrudBean);
				modelAndView.addObject("msg", false);
				return modelAndView;
		}
		}else {
			log.error("No data available.");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.BUSINESSMIS_DOWNLOAD_VIEW.get());
			List<AcquirerBean> acquirerList = service.getListOfAcquirer();
			modelAndView.addObject(AQUIRERES,acquirerList);
			modelAndView.addObject(BUSINESSMISDOWNLOADCRUDBEANDATA,businessMISDownloadCrudBean);
			modelAndView.addObject("msg", true);
			return modelAndView;

		}
	}
}
