package com.mosambee.controller;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.bean.ActiveProgramBean;
import com.mosambee.bean.datatables.DataTablesRequest;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.LaunchProgramService;
import com.mosambee.service.ProgramBulkUploadService;

import lombok.extern.log4j.Log4j2;

/**
 * LaunchProgramController is basically used to launch programs. We are
 * basically using this controller to create-new-program, providing
 * bulk-upload-support for creating multiple program at once.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 11-December-2019
 */
@Log4j2
@Controller
@RequestMapping("/program")
public class LaunchProgramController {

	@Autowired
	LaunchProgramService service;

	@Autowired
	ProgramBulkUploadService programBulkUploadService;

	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@GetMapping("/create-new")
	public ModelAndView createNewOffer() {
		ModelAndView modelAndView = new ModelAndView(ViewLayer.CREATE_NEW.get());
		modelAndView.addObject("authority", "role");
		return modelAndView;
	}

	/**
	 * API to fetch the view for bulk upload
	 * 
	 * @return String
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@GetMapping("/bulk-upload")
	public String bulkUpload() {
		log.info("GET /program/bulk-upload");
		return ViewLayer.BULK_UPLOAD.get();
	}

	/**
	 * @param file MultiPartFile that we will receive in the request.
	 * @return
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@PostMapping("/bulk-upload")
	public Object bulkUpload(@RequestParam("file") MultipartFile file) {
		log.info("POST /program/bulk-upload");

		// Get the resource from service
		Resource resource = programBulkUploadService.processBulkUploadExcel(file);

		if (null != resource) {

			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"UpdatedProgramResponse.xlsx\"")
					.body(resource);
		} else {
			ModelAndView modelAndView = new ModelAndView(ViewLayer.BULK_UPLOAD.get());
			modelAndView.addObject("invalid", true);
			return modelAndView;
		}

	}

	/**
	 * getBulkUploadFormat() is responsible for downloading the bulk upload format
	 * for program.
	 * 
	 * @return Object
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@GetMapping("/bulk-upload-format")
	public Object getBulkUploadFormat() {

		log.info("GET /program/bulk-upload-format");

		Resource resource = programBulkUploadService.getProgramBulkUploadFormat();

		if (null != resource) {
			log.info("Sending bulk upload format in response.");
			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"program-bulk-upload-format.xlsx\"")
					.body(resource);
		} else {
			log.error("Error ocurred while downloading program bulk upload sample file.");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.BULK_UPLOAD.get());
			modelAndView.addObject("bulk_format_error", true);
			return modelAndView;
		}

	}

	/**
	 * API to fetch the view for active offers.
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/view-active")
	public String viewActivePrograms() {
		log.info("GET /view-active");
		return ViewLayer.VIEW_ACTIVE.get();
	}

	/**
	 * API to fetch data-tables response for active offers.
	 * 
	 * @param DataTablesRequest
	 * @return ResponseEntity<DataTablesResponse<ProgramBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/view-active")
	public ResponseEntity<DataTablesResponse<ActiveProgramBean>> viewActivePrograms(
			@RequestBody DataTablesRequest dtRequest) {
		log.info("POST /program/view-active {}", dtRequest);
		DataTablesResponse<ActiveProgramBean> dtResponse = service.getActiveProgramList(dtRequest);
		dtResponse.setDraw(dtRequest.getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}

}
