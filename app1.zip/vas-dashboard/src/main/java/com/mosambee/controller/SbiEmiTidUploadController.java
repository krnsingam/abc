package com.mosambee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.SbiTidUploadService;

import lombok.extern.log4j.Log4j2;

/**
 * SbiEmiTidUploadController is basically used to Upload SBI EMI TID Details in bulk.
 * 
 * @author saurabhkant.shukla
 * @version 1.0
 * @since 18-March-2020
 */
@Log4j2
@Controller
@RequestMapping("/sbi-emi-tid-upload")
public class SbiEmiTidUploadController {

	@Autowired
	private SbiTidUploadService sbiTidUploadService;
	
	/**
	 * Api to view sbi emi tid upload page
	 * 
	 * @return String
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@GetMapping("/sbi-tid-upload")
	public String sbiTidUpload() {
		log.info("GET /sbi-emi-tid-upload/sbi-tid-upload");
		return ViewLayer.EMI_TID_UPLOAD.get();
	}
	
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@PostMapping("/sbi-tid-upload")
	public Object sbiTidUpload(@RequestParam("file") MultipartFile file) {
		log.info("POST /sbi-emi-tid-upload/sbi-tid-upload");

		log.info("Request time: {}", System.currentTimeMillis());
		
		Resource resource = sbiTidUploadService.processSbiEmiUploadExcel(file);
		
		if (null != resource) {

			log.info("Response time: {}", System.currentTimeMillis());

			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"SbiTidUploadResponse.xlsx\"")
					.body(resource);
			
		} else {
			ModelAndView modelAndView = new ModelAndView(ViewLayer.EMI_TID_UPLOAD.get());
			modelAndView.addObject("invalid", true);
			return modelAndView;
		}

	}
	
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@GetMapping("/sbi-tid-upload-format")
	public Object sbiMidUploadFormat() {
		log.info("GET /sbi-emi-tid-upload/sbi-tid-upload-format");

		log.info("Request time: {}", System.currentTimeMillis());
		
		Resource resource = sbiTidUploadService.getSbiTidUploadFormat();
		
		if (null != resource) {
			log.info("Sending  SBI MID upload format in response.");
			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION,
							"attachment; filename=\"sbi-tid-upload-format.xlsx\"")
					.body(resource);
		} else {
			log.error("Error ocurred while downloading SBI TID upload sample file.");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.EMI_MID_UPLOAD.get());
			modelAndView.addObject("sbi_tid_upload_format_error", true);
			return modelAndView;
		}

	}
	
}
