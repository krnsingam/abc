package com.mosambee.controller;

import java.util.List;
import javax.annotation.security.RolesAllowed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.bean.MidDateBean;
import com.mosambee.bean.MidDownloadBean;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.MidDownloadService;

import lombok.extern.log4j.Log4j2;

/**
 * This class is basically used to download bank mid
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Log4j2
@Controller
@RequestMapping("/mid-download")
public class MidDownloadController {

	@Autowired
	MidDownloadService midDownloadService;

	/**
	 * Api to view mid download page
	 * 
	 * @return string
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/mid-download-page")
	public String viewDownloadPage() {
		log.info("GET /mid-download/mid-download-page");
		return ViewLayer.MID_DOWNLOAD.get();
	}

	/**
	 * Api to download mid
	 * 
	 * @param bean
	 * 
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/download-mid")
	public Object downloadMid(@ModelAttribute("f") MidDateBean bean) {

		log.info("POST /mid-download/download-mid");
		List<MidDownloadBean> responseBean = midDownloadService.downloadMid(bean);
		log.info("Response /mid-download/download-mid {}", responseBean);
		if (!responseBean.isEmpty()) {
			// Get the resource from service
			Resource resource = midDownloadService.processMidDownload(responseBean);
			if (resource != null) {
				return ResponseEntity.ok()
						.contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
						.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"MidDownload.xlsx\"")
						.body(resource);
			} else {
				log.error("Error while downloading MID list");
				ModelAndView modelAndView = new ModelAndView(ViewLayer.MID_DOWNLOAD.get());
				modelAndView.addObject("invalid", true);
				return modelAndView;
			}
		} else {
			log.error("Error while downloading MID list");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.MID_DOWNLOAD.get());
			modelAndView.addObject("invalid", true);
			return modelAndView;
		}
	}

}
