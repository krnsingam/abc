package com.mosambee.controller;

import java.util.Map;

import javax.annotation.security.RolesAllowed;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.bean.BlockedUserBean;
import com.mosambee.bean.BlockedUserDataTableBean;
import com.mosambee.bean.UserBean;
import com.mosambee.bean.UserCrudBean;
import com.mosambee.bean.UserCrudDataTableBean;
import com.mosambee.bean.UserExistAndNotBlockedBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.UserService;

import lombok.extern.log4j.Log4j2;

/**
 * UserController is used to show list of user data and create/update user
 * @author rahul.mishra
 * @date 24-02-2020
 */
@Log4j2
@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	UserService userService;
	
	private static final String USERCRUDBEANDATA = "userCrudBean";
	private static final String ROLES = "roles";
    
	/**
	 * API to fetch the view for list of users.
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/list")
	public ModelAndView viewActiveUsersView() {
		log.info("GET /user/list");
		
		ModelAndView modelAndView = new ModelAndView(ViewLayer.USER_LIST.get());
		Map<Integer, String> role = userService.getRoles();
		modelAndView.addObject("role",role);
		return modelAndView;
	}
	
	
	/**
	 * API to provide data for  list of users.
	 * @param UserCrudDataTableBean dtRequest
	 * @return DataTablesResponse<UserBean>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/list")
	public ResponseEntity<DataTablesResponse<UserBean>> viewActiveUsersData(@RequestBody UserCrudDataTableBean dtRequest) {
		log.info("POST /user/list {}", dtRequest);
		DataTablesResponse<UserBean> dtResponse = userService.getUsersList(dtRequest);
		dtResponse.setDraw(dtRequest.getDtRequest().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}
	
	/**
	 * API to update user status
	 * 
	 * @param status
	 * @param groupId
	 * @return boolean
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/update-user-status")
	@ResponseBody
	public boolean  updateUserStatus(@RequestParam int status, @RequestParam int userId) {
		log.info("POST /user/update-user-status");
		
		return  userService.updateUserStatus(status,userId);

	}
	
	/**
	 * API to fetch the view for create users.
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/create-user")
	public ModelAndView  createUser() {
		log.info("GET /user/create-user");
		Map<Integer, String> role = userService.getRoles();
		ModelAndView modelAndView = new ModelAndView(ViewLayer.CREATE_USER.get());
		modelAndView.addObject(USERCRUDBEANDATA,new UserCrudBean());
		modelAndView.addObject(ROLES,role);
		return modelAndView;
	}
	
	/**
	 * API to process post data of create user.
	 * @param UserCrudBean userCrudBean
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/create-user")
	public ModelAndView createUser(@Valid @ModelAttribute("userCrudBean") UserCrudBean userCrudBean,BindingResult result) {
		log.info("POST /user/create-user");
		log.info("userCrudBean  {}", userCrudBean);
		ModelAndView modelAndView = new ModelAndView(ViewLayer.CREATE_USER.get());
		Map<Integer, String> role = userService.getRoles();
		if (result.hasErrors()) {
			log.info("error occured while validating user");
			modelAndView.addObject(USERCRUDBEANDATA,userCrudBean);
		    modelAndView.addObject(ROLES,role);
			return modelAndView;
	    }
		
		UserExistAndNotBlockedBean checkUser = userService.checkIfUserExistsAndNotBlocked(userCrudBean.getEmail());
		
		if(checkUser.isUserExists()) {
			modelAndView.addObject(USERCRUDBEANDATA,new UserCrudBean());
			modelAndView.addObject(ROLES,role);
			modelAndView.addObject("userExists",true);
			return modelAndView;
		}

		boolean res = userService.createUser(userCrudBean);
		
		log.info("user created {} ",res);
		
		modelAndView.addObject(USERCRUDBEANDATA,new UserCrudBean());
		modelAndView.addObject(ROLES,role);
		modelAndView.addObject("msg",res);
		return modelAndView;
	}
	
	/**
	 * editUser is used to edit the user details here we get the user details and send it to view
	 * @param userId
	 * @return
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/edit")
	public ModelAndView editUser(@RequestParam int userId) {
		log.info("POST /user/edit");
		log.info("userid  {}", userId);
		ModelAndView modelAndView = new ModelAndView(ViewLayer.UPDATE_USER.get());
		Map<Integer, String> role = userService.getRoles();

		UserCrudBean userCrudBean = userService.getUserDetails(userId);
		modelAndView.addObject(USERCRUDBEANDATA,userCrudBean);
		modelAndView.addObject(ROLES,role);
		return modelAndView;
	}
	
	/**
	 * API to process post data of create user.
	 * @param UserCrudBean userCrudBean
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/update-user")
	public ModelAndView updateUser(@Valid @ModelAttribute("userCrudBean") UserCrudBean userCrudBean,BindingResult result) {
		log.info("POST /user/update-user");
		log.info("userCrudBean  {}", userCrudBean);
		ModelAndView modelAndView = new ModelAndView(ViewLayer.UPDATE_USER.get());
		Map<Integer, String> role = userService.getRoles();
		if (result.hasErrors()) {
			log.info("error occured while updating user");
			modelAndView.addObject(USERCRUDBEANDATA,userCrudBean);
		    modelAndView.addObject(ROLES,role);
			return modelAndView;
	    }

		int res = userService.updateUser(userCrudBean);
		
		log.info("user updated {} ",res); 
		
		modelAndView.addObject(USERCRUDBEANDATA,userCrudBean);
		modelAndView.addObject(ROLES,role);
		modelAndView.addObject("msg",res);
		return modelAndView;
	}
	
	
	/**
	 * API to fetch the view for list of web blocked users.
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/web-blocked-users")
	public ModelAndView viewWebBlockedUsers() {
		log.info("GET /user/web-blocked-users");
		
		return new ModelAndView(ViewLayer.WEB_BLOCKED_USERS.get());
	}
	
	
	/**
	 * API to provide data for  list of web blocked users.
	 * @param BlockedUserDataTableBean dtRequest
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/web-blocked-users")
	public ResponseEntity<DataTablesResponse<BlockedUserBean>> viewWebBlockedUsers(@RequestBody BlockedUserDataTableBean dtRequest) {
		log.info("POST /user/list {}", dtRequest);
		DataTablesResponse<BlockedUserBean> dtResponse = userService.getWebBlockedUsers(dtRequest);
		dtResponse.setDraw(dtRequest.getDtRequest().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}
	
	/**
	 * API to unblock  web blocked users.
	 * @param BlockedUserDataTableBean dtRequest
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/web-unblock-users")
	@ResponseBody
	public boolean unblockBlockedUsers(@RequestParam long mUserId,@RequestParam String comment) {
		log.info("POST /user/web-unblock-users {} {}", mUserId,comment );
		return userService.unblockBlockedUsers(mUserId,comment);
	}
	
	/**
	 * API to unblock  web blocked users.
	 * @param BlockedUserDataTableBean dtRequest
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/mobile-unblock-users")
	@ResponseBody
	public boolean unblockMobileBlockedUsers(@RequestParam long mUserId,@RequestParam String comment) {
		log.info("POST /user/mobile-unblock-users {} {}", mUserId,comment );
		return userService.unblockMobileBlockedUsers(mUserId,comment);
	}
	
	/**
	 * API to fetch the view for list of mobile blocked users.
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/mobile-blocked-users")
	public ModelAndView viewMobileBlockedUsers() {
		log.info("GET /user/mobile-blocked-users");
		
		return new ModelAndView(ViewLayer.MOBILE_BLOCKED_USERS.get());
	}
	
	/**
	 * API to provide data for  list of mobile blocked users.
	 * @param viewMobileBlockedUsers dtRequest
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/mobile-blocked-users")
	public ResponseEntity<DataTablesResponse<BlockedUserBean>> viewMobileBlockedUsers(@RequestBody BlockedUserDataTableBean dtRequest) {
		log.info("POST /user/mobile-blocked-users {}", dtRequest);
		DataTablesResponse<BlockedUserBean> dtResponse = userService.getMobileBlockedUsers(dtRequest);
		dtResponse.setDraw(dtRequest.getDtRequest().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}
}
