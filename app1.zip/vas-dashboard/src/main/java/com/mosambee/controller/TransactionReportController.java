package com.mosambee.controller;


import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.security.RolesAllowed;
import javax.validation.Valid;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.bean.AcquirerBean;
import com.mosambee.bean.TransactionDateReportBean;
import com.mosambee.bean.TransactionReportBean;

import com.mosambee.bean.TransactionSearchFormBean;
import com.mosambee.bean.TransactionSearchFormDataTableBean;
import com.mosambee.bean.TransactionSearchReportBean;
import com.mosambee.bean.TransactionTypeBean;

import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.TransactionReportService;

import lombok.extern.log4j.Log4j2;

/**
 * TransactionController is basically used for transaction report view tab. We
 * are basically using this controller to create-view for transaction, providing
 * view-download-support for multiple transaction at once.
 * 
 * @author karan.singam
 * @version 1.0
 * @since 10-January-2020
 */
@Log4j2
@Controller
@RequestMapping("/transaction")
public class TransactionReportController {

	
	private static final String TRANSACTION_SEARCH_FORM_BEAN = "transactionSearchFormBean";
	private static final String TXN_TYPES = "txnTypes";
	private static final String AQUIRERES = "aquirers";


	@Autowired
	TransactionReportService transactionservice;

	/**
	 * API to fetch the view for Transaction
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/transaction-report-view")
	public String viewActiveTransaction() {
		log.info("GET transaction-report-view");
		return ViewLayer.TRANSACTION_VIEW.get();
	}

	/**
	 * API to fetch data-tables response for active transaction.
	 * 
	 * @param DataTablesRequest
	 * @return ResponseEntity<DataTablesResponse<TransactionReportBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/transaction-report-view")
	public ResponseEntity<DataTablesResponse<TransactionReportBean>> viewActiveTransaction(
			@RequestBody TransactionDateReportBean dtRequest) {
		log.info("post transaction-report-view {}", dtRequest);
		DataTablesResponse<TransactionReportBean> dtResponse = transactionservice.getActiveTransactionList(dtRequest);
		dtResponse.setDraw(dtRequest.getDataTable().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}

	/**
	 * API for download using data tables for active transaction.
	 * downloadActiveTransactionReportList() is used for providing download file in
	 * xlsx format.
	 * 
	 * @param DataTablesRequest
	 * @return ResponseEntity<DataTablesResponse<TransactionReportBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/transaction-report-download")
	public Object downloadActiveTransactionReportList(@ModelAttribute TransactionReportBean report) {
		Resource resource = transactionservice.downloadActiveTransactionReportList(report);
		if (resource != null) {

			log.info("Resource {}", resource);
			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"TransactionReportDetails.xlsx\"")
					.body(resource);
		} else {
			log.error("Error ocurred while downloading transaction reporting list.");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.TRANSACTION_VIEW.get());
		modelAndView.addObject("msg", true);
		return modelAndView;
		}
	}

	/**
	 * API for getting current transaction details.
	 * 
	 * @param DataTablesRequest
	 * @return ResponseEntity<DataTablesResponse<TransactionReportBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/transaction-reportdetail")
	public ResponseEntity<TransactionReportBean> getActiveTransaction(@RequestParam int txnId) {

		log.info("id {}", txnId);
		TransactionReportBean data = transactionservice.getActiveTransaction(txnId);
		return new ResponseEntity<>(data, HttpStatus.OK);
	}
	
	
	/**
	 * API to fetch the view for Transaction Search
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/")
	public ModelAndView viewTransactionSearch() {
		log.info("GET /transaction/");
		
		List<TransactionTypeBean> transactionTypeBeanList = transactionservice.getListOfTrxnType(); 
		List<AcquirerBean> acquirerList = transactionservice.getListOfAcquirer();
		
		log.info("txn type {}",transactionTypeBeanList);
		
		ModelAndView modelAndView = new ModelAndView(ViewLayer.TRANSACTION_SEARCH_VIEW.get());
		modelAndView.addObject(TRANSACTION_SEARCH_FORM_BEAN,new TransactionSearchFormBean());
		modelAndView.addObject(TXN_TYPES,transactionTypeBeanList);
		modelAndView.addObject(AQUIRERES,acquirerList);
		return modelAndView;
	}
	
	/**
	 * API to process transaction search data
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/search")
	public ModelAndView processTransactionSearch(@Valid @ModelAttribute("transactionSearchFormBean") TransactionSearchFormBean transactionSearchFormBean,BindingResult result) {
		log.info("POST /transaction/search ");
		log.info("TransactionSearchFormBean {}",transactionSearchFormBean);
				
		ModelAndView modelAndView = new ModelAndView(ViewLayer.TRANSACTION_SEARCH_VIEW.get());
		List<TransactionTypeBean> transactionTypeBeanList = transactionservice.getListOfTrxnType();
		List<AcquirerBean> acquirerList = transactionservice.getListOfAcquirer();
		
		modelAndView.addObject(TXN_TYPES,transactionTypeBeanList);
		modelAndView.addObject(AQUIRERES,acquirerList);
		
		if (result.hasErrors()) {
			log.info("error occured while validating user");
			modelAndView.addObject(TRANSACTION_SEARCH_FORM_BEAN,transactionSearchFormBean);
			return modelAndView;
	    }
		
		List<TransactionSearchReportBean> transactionSearchReportBeanList = transactionservice.getCountOfTransactions(transactionSearchFormBean);
		
		log.info("transactionSearchReportBeanList {}",transactionSearchReportBeanList);
		
		modelAndView.addObject(TRANSACTION_SEARCH_FORM_BEAN,transactionSearchFormBean);
		modelAndView.addObject("transactionSearchReportBeanList",transactionSearchReportBeanList);
		
		return modelAndView;
	}
	
	/**
	 * API to process transaction search data for listing
	 * @return ModelAndView
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/search-view")
	public ModelAndView processTransactionSearchView(TransactionSearchFormBean transactionSearchFormBean) {
		List<TransactionTypeBean> transactionTypeBeanList = transactionservice.getListOfTrxnType(); 
		List<AcquirerBean> acquirerList = transactionservice.getListOfAcquirer();
		
		log.info("processTransactionSearchView  transactionSearchFormBean {}",transactionSearchFormBean);
		
		ModelAndView modelAndView = new ModelAndView(ViewLayer.LIST_TRANSACTION_SEARCH_VIEW.get());
		modelAndView.addObject(TRANSACTION_SEARCH_FORM_BEAN,transactionSearchFormBean);
		modelAndView.addObject(TXN_TYPES,transactionTypeBeanList);
		modelAndView.addObject(AQUIRERES,acquirerList);
		return modelAndView;
	}

	
	
	/**
	 * API to get transaction list data based on search results and txn type 
	 * @param DataTablesRequest
	 * @return ResponseEntity<DataTablesResponse<TransactionReportBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/get-transaction-list-data")
	public ResponseEntity<DataTablesResponse<TransactionSearchReportBean>> getTransactionListData(@RequestBody TransactionSearchFormDataTableBean dtRequest) {
		log.info("post transaction-report-view {}", dtRequest);
		DataTablesResponse<TransactionSearchReportBean> dtResponse = transactionservice.getTransactionListData(dtRequest);
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}
	
	
	/**
	 * API to get transaction data based on tranId 
	 * @param DataTablesRequest
	 * @return ResponseEntity<TransactionSearchReportBean>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/get-transaction-data-id")
	public ModelAndView getTransDataById(@RequestParam long tranId) {
		log.info("post get-transaction-data-id {}", tranId);
		TransactionSearchReportBean transactionSearchReportBean = transactionservice.getTransById(tranId);
		ModelAndView model = new ModelAndView("transaction/receipt");
		model.addObject("transactionForm",transactionSearchReportBean);
		return model;
	}
	
	
	/**
	 * API to process transaction search data and return excel 
	 * @return Resource
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/search-download")
	public Object processTransactionSearchDownload(@Valid @ModelAttribute("transactionSearchFormBean") TransactionSearchFormBean transactionSearchFormBean,BindingResult result) {
		log.info("POST /transaction/search-download ");
		log.info("TransactionSearchFormBean {}",transactionSearchFormBean);
		
		ModelAndView modelAndView = new ModelAndView(ViewLayer.TRANSACTION_SEARCH_VIEW.get());
		List<TransactionTypeBean> transactionTypeBeanLst = transactionservice.getListOfTrxnType();
		List<AcquirerBean> acquirerList = transactionservice.getListOfAcquirer();
		
		modelAndView.addObject(TXN_TYPES,transactionTypeBeanLst);
		modelAndView.addObject(AQUIRERES,acquirerList);
		
		if (result.hasErrors()) {
			log.info("error occured while validating TransactionSearchFormBean");
			modelAndView.addObject(TRANSACTION_SEARCH_FORM_BEAN,transactionSearchFormBean);
			return modelAndView;
	    }
		
		List<Map<Integer,String>> list = new ArrayList<>();

		if (transactionSearchFormBean != null && transactionSearchFormBean.getTxnType().get(0) != null && !transactionSearchFormBean.getTxnType().get(0).equalsIgnoreCase("")) {
			list = transactionservice.getTransactionSearchListExcelData(transactionSearchFormBean);
			log.info("processTransactionSearchDownload");
		}
		
		modelAndView.addObject(TRANSACTION_SEARCH_FORM_BEAN,new TransactionSearchFormBean());
		modelAndView.addObject("processError",true);
		
		if (list != null && list.size() < 32000) {

		
			HSSFWorkbook hwb1 = transactionservice.getTransactionSearchListExcel(list, transactionSearchFormBean);
			// obtains response's output stream
			Resource resource = transactionservice.getResourceFromWorkbook(hwb1);
	
			if (null != resource) {
	
				log.info("Response time: {}", System.currentTimeMillis());
	
				return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
						.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"Transactions.xlsx\"")
						.body(resource);
			} else {
				
				return modelAndView;
			} 
		
		}else {
		    
			log.info("Request time: {}", System.currentTimeMillis());
			
			Resource resource = transactionservice.getTransactionCSV(list);
			
			if (null != resource) {
				
				log.info("Response time: {}", System.currentTimeMillis());
	
				return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.CSV_CONTENT_TYPE.get()))
						.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"Transactions.csv\"")
						.body(resource);
			} else {

				return modelAndView;
			} 
             
		}
        
	   }
	
	/**
	 * API to process transaction search data and return excel 
	 * @return Resource
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/send-email")
	@ResponseBody
	public boolean sendTransactionEmail(@RequestParam long tranId,@RequestParam String email) {
		log.info("POST /transaction/send-email ");
		log.info("tranId {} email {} ",tranId,email);
		
		return transactionservice.sendTransactionEmail(tranId,email);

	}
	
	/**
	 * API to process transaction search data and return excel 
	 * @return Resource
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/send-sms")
	@ResponseBody
	public boolean sendTransactionSMS(@RequestParam long tranId,@RequestParam String sms) {
		log.info("POST /transaction/send-sms ");
		log.info("tranId {} sms {} ",tranId,sms);
		
		return transactionservice.sendTransactionSMS(tranId,sms);

	}
	
	
	/**
	 * API to get getMerchantByName data based on name 
	 * @param DataTablesRequest
	 * @return ResponseEntity<TransactionSearchReportBean>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/get-merchant")
	@ResponseBody
	public List<String> getMerchantByName(@RequestParam String name) {
		log.info("post get-merchant {}", name);
		return  transactionservice.getListOfMerchantName(name);
	}
	
}
