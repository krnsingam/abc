package com.mosambee.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.EmiConversionUploadService;

import lombok.extern.log4j.Log4j2;

/**
 * This class is using for emi conversion upload
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
@Log4j2
@Controller
@RequestMapping("/emi-conversion")
public class EmiConversionUploadController {
	
	@Autowired
	private EmiConversionUploadService emiConversionUploadService;

	/**
	 * Api to view emi conversion upload page
	 * 
	 * @return String
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@GetMapping("/emi-conversion-upload")
	public String emiConversionUpload() {
		log.info("GET/emi-conversion/emi-conversion-upload");
		return ViewLayer.EMI_CONVERSION.get();

	}

	/**
	 * @param file MultiPartFile that will receive in the request
	 * @return Object
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@PostMapping("/emi-conversion-upload")
	public Object emiConversionUpload(@RequestParam("file") MultipartFile file) {
		log.info("POST/emi-conversion/emi-conversion-upload");

		log.info("Request Time: {}", System.currentTimeMillis());
		Resource resource = emiConversionUploadService.processEmiConversionUploadExcel(file);
		if (null != resource) {

			log.info("Response time: {}", System.currentTimeMillis());

			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION,
							"attachment; filename=\"EmiConversionUploadResponse.xlsx\"")
					.body(resource);
		} else {
			ModelAndView modelAndView = new ModelAndView(ViewLayer.EMI_CONVERSION.get());
			modelAndView.addObject("invalid", true);
			return modelAndView;
		}

	}

	/**
	 * emiConversionUploadFormat() is responsible for downloading emi conversion
	 * upload format.
	 * 
	 * @return Object
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@GetMapping("/emi-conversion-upload-format")
	public Object emiConversionUploadFormat() {
		log.info("POST/emi-conversion/emi-conversion-upload-format");

		log.info("Request time: {}", System.currentTimeMillis());
		Resource resource = emiConversionUploadService.getEmiConversionUploadFormat();
		if (null != resource) {
			log.info("Sending  emi conversion upload format in response.");
			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION,
							"attachment; filename=\"emi-conversion-upload-format.xlsx\"")
					.body(resource);
		} else {
			log.error("Error ocurred while downloading emi conversion upload sample file.");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.EMI_CONVERSION.get());
			modelAndView.addObject("emi_conversion_upload_format_error", true);
			return modelAndView;
		}

	}

	

}
