package com.mosambee.controller;

import java.util.Map;
import javax.annotation.security.RolesAllowed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.mosambee.bean.AddBqrMerchantsBean;
import com.mosambee.bean.BqrListDatatablesRequestBean;
import com.mosambee.bean.CustomUser;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.AddBqrMerchantsService;
import lombok.extern.log4j.Log4j2;

/**
 * This classs is using for addBqrMerchants and show the list of BQRMerchant and
 * edit and update bqr merchants
 * 
 * @author pooja.singh
 * @version 1.0
 *
 */
@Log4j2
@Controller
@RequestMapping("/merchants")
public class MerchantsController {
	@Autowired
	private AddBqrMerchantsService service;

	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@GetMapping("/add-bqr-merchants")
	public String addBqrMerchants() {
		log.info("GET /add-bqr-merchants");
		return ViewLayer.MERCHANTS.get();
	}

	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/insert-bqr-merchants")
	public ModelAndView insertBqrMerchants(@ModelAttribute AddBqrMerchantsBean addBqrMerchantsBean) {
		String userId;
		CustomUser customUser = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Map<String, String> myMap = customUser.getMyMap(); // Store logged in user info into hash map.

		log.info("myMap contents: {}", myMap);

		userId = myMap.get("id");
		log.info("POST /insert-bqr-merchants");
		ModelAndView modelAndView = new ModelAndView(ViewLayer.MERCHANTS.get());
		String response = service.insertBqrMerchants(addBqrMerchantsBean, userId);
		log.info(response);
		if (response != null) {
			modelAndView.addObject("success", response);
			return modelAndView;
		} else {
			log.error("Error Occurred while adding BQR Merchant ");
			modelAndView.addObject("error", true);
			return modelAndView;
		}
	}

	/**
	 * Api to display bqr merchants list page
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/bqr-merchants-list")
	public String viewBqrMerchants() {
		log.info("GET /bqr-merchants-list");
		return ViewLayer.LIST.get();
	}

	/**
	 * API to fetch data-tables response for bqr merchant list.
	 * 
	 * @param dtRequest
	 * @return
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/bqr-merchants-list")
	public ResponseEntity<DataTablesResponse<AddBqrMerchantsBean>> viewBqrMerchantsList(
			@RequestBody BqrListDatatablesRequestBean dtRequest) {
		log.info("POST/merchants/bqr-merchants-list");
		DataTablesResponse<AddBqrMerchantsBean> dtResponse = service.getBqrMerchantsList(dtRequest);
		log.info("POST /merchants/bqr-merchants-list {}", dtResponse);
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}

	/**
	 * Api to display data of bqr merchant to edit by id.
	 * 
	 * @param id
	 * @return
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/edit-bqr-merchants")
	public ModelAndView editBqrMerchants(@RequestParam long id) {

		log.info("POST /edit-bqr-merchants {}", id);
		AddBqrMerchantsBean addBqrMerchantsBean = service.editBqrMerchants(id);
		ModelAndView modelAndView = new ModelAndView(ViewLayer.EDIT.get());
		log.info(addBqrMerchantsBean);
		modelAndView.addObject("addBqrMerchantsBean", addBqrMerchantsBean);
		return modelAndView;

	}

	/**
	 * Api to update information of bqr merchant
	 * 
	 * @param addBqrMerchantsBean
	 * @return
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN" })
	@PostMapping("/update-bqr-merchants")
	public ModelAndView updateBqrMerchants(@ModelAttribute AddBqrMerchantsBean addBqrMerchantsBean) {
		String userId;
		CustomUser customUser = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Map<String, String> myMap = customUser.getMyMap(); // Store logged in user info into hash map.

		log.info("myMap contents: {}", myMap);

		userId = myMap.get("id");
		log.info("POST /update-bqr-merchants");
		ModelAndView modelAndView = new ModelAndView(ViewLayer.EDIT.get());
		String response = service.updateBqrMerchants(addBqrMerchantsBean, userId);
		log.info(response);
		if (response != null) {
			modelAndView.addObject("success", response);
			return modelAndView;
		} else {
			log.error("Error Occurred while updating BQR Merchant ");
			modelAndView.addObject("error", true);
			return modelAndView;
		}

	}
}
