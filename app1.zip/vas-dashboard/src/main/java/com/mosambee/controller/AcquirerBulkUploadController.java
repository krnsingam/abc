package com.mosambee.controller;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mosambee.bean.AcquirerBulkDataBean;
import com.mosambee.bean.AcquirerBulkUploadBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.AcquirerBulkUploadService;

import lombok.extern.log4j.Log4j2;

/**
 * This class is used to fetch all request of AcquirerBulkUpload module. 
 * @author karan.singam
 * @version 1.0
 */
@Log4j2
@Controller
@RequestMapping("/acquirer")
public class AcquirerBulkUploadController {
	
	@Autowired
	private AcquirerBulkUploadService acqService;
	
	
	/**
	 * API to fetch the view for Acquirer
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/acquirer-view")
	public String viewActiveAcquirer() {
		log.info("GET acquirer-view");
		return ViewLayer.ACQUIRER_VIEW.get();
	}

	/**
	 * API to fetch data-tables response for active Acquirer.
	 * 
	 * @param DataTablesRequest
	 * @return ResponseEntity<DataTablesResponse<AcquirerBulkUploadBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/acquirer-view")
	public ResponseEntity<DataTablesResponse<AcquirerBulkUploadBean>> viewActiveTransaction(
			@RequestBody AcquirerBulkDataBean dtRequest) {
		log.info("post acquirer-view {}", dtRequest);
		DataTablesResponse<AcquirerBulkUploadBean> dtResponse = acqService.getListOfAcquirer(dtRequest);
		dtResponse.setDraw(dtRequest.getDataTable().getDraw());
		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}
	
	/**
	 * API for download using data tables for active acquirer.
	 * downloadActiveAcquirerList() is used for providing download file in
	 * xlsx format.
	 * 
	 * @param DataTablesRequest
	 * @return ResponseEntity<DataTablesResponse<AcquirerBulkDataBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/acquirer-list-download")
	public Object downloadActiveAcquirerList(@ModelAttribute AcquirerBulkUploadBean report) {
		Resource resource = acqService.downloadActiveAcquirerList(report);
		if(resource!=null) {
		return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"AcquirerDetails.xlsx\"").body(resource);
		}
		else {
			log.error("Error ocurred while downloading acquirer reporting list.");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.ACQUIRER_VIEW.get());
			modelAndView.addObject("msg", true);
			return modelAndView;
		}

	}	
	
}
