package com.mosambee.controller;

import java.util.List;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import com.mosambee.bean.CustomUser;
import com.mosambee.bean.EmiDownloadBean;
import com.mosambee.bean.EmiMidTidBean;
import com.mosambee.bean.EmiSearchDatatablesRequestBean;
import com.mosambee.bean.datatables.DataTablesResponse;
import com.mosambee.constants.CommonConstants;
import com.mosambee.constants.ViewLayer;
import com.mosambee.service.EmiBulkUploadService;

import lombok.extern.log4j.Log4j2;

/**
 * This class is using for DCEMI(terminal upload) file
 * 
 * @author pooja.singh
 * @version 1.0
 */
@Log4j2
@Controller
@RequestMapping("/emi-bulk-upload")
public class EmiBulkUploadController {
	
	@Autowired
	private EmiBulkUploadService emiBulkUploadService;

	/**
	 * API to emi mid tid upload page
	 * 
	 * @return String
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@GetMapping("/mid-tid-upload")
	public String emiBulkUpload() {
		log.info("GET /emi-bulk-upload/mid-tid-upload");
		return ViewLayer.EMI_BULK_UPLOAD.get();
	}

	/**
	 * @param file MultiPartFile that we will receive in the request.
	 * @return Object
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@PostMapping("/mid-tid-upload")
	public Object emiBulkUpload(@RequestParam("file") MultipartFile file) {
		log.info("POST /emi-bulk-upload/mid-tid-upload");

		log.info("Request time: {}", System.currentTimeMillis());

		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String createdBy = user.getMyMap().get("id");
		log.info(createdBy);

		// Get the resource from service
		Resource resource = emiBulkUploadService.processEmiBulkUploadExcel(file, createdBy);

		if (null != resource) {

			log.info("Response time: {}", System.currentTimeMillis());

			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"TerminalUploadResponse.xlsx\"")
					.body(resource);
		} else {
			ModelAndView modelAndView = new ModelAndView(ViewLayer.EMI_BULK_UPLOAD.get());
			modelAndView.addObject("invalid", true);
			return modelAndView;
		}

	}

	/**
	 * getEmiBulkUploadFormat() is responsible for downloading the emi bulk upload
	 * format
	 * 
	 * @return Object
	 */
	@PreAuthorize("hasRole('ROLE_SITE_ADMIN')")
	@GetMapping("/mid-tid-upload-format")
	public Object getEmiBulkUploadFormat() {

		log.info("GET /emi-bulk-upload/mid-tid-upload-format");

		Resource resource = emiBulkUploadService.getEmiBulkUploadFormat();

		if (null != resource) {
			log.info("Sending  emi bulk upload format in response.");
			return ResponseEntity.ok().contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"terminal-upload-format.xlsx\"")
					.body(resource);
		} else {
			log.error("Error ocurred while downloading emi bulk upload sample file.");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.EMI_BULK_UPLOAD.get());
			modelAndView.addObject("emi_bulk_upload_format_error", true);
			return modelAndView;
		}

	}

	/**
	 * Api to view DCEMI (LIST) page
	 * 
	 * @return String
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@GetMapping("/emi-search")
	public String viewEmiSearch() {
		log.info("GET /emi-search");
		return ViewLayer.EMI_SEARCH.get();
	}

	/**
	 * Api to fetch datatables response for Dcemi search list
	 * 
	 * @param dtRequest
	 * @return ResponseEntity<DataTablesResponse<EmiMidTidBean>>
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/emi-search")
	public ResponseEntity<DataTablesResponse<EmiMidTidBean>> viewEmiSearch(
			@RequestBody EmiSearchDatatablesRequestBean dtRequest) {
		log.info("POST /emi-bulk-upload/emi-search {}", dtRequest);

		DataTablesResponse<EmiMidTidBean> dtResponse = emiBulkUploadService.getEmiSearchList(dtRequest);

		log.info("POST /emi-search {}", dtResponse);

		return new ResponseEntity<>(dtResponse, HttpStatus.OK);
	}

	/**
	 * to download emi search list
	 * 
	 * @param
	 */
	@RolesAllowed({ "ROLE_SITE_ADMIN", "ROLE_SITE_USER" })
	@PostMapping("/download")
	public Object downloadEmiSearchList(@ModelAttribute EmiDownloadBean bean) {
		log.info("POST /emi-bulk-upload/download {}", bean);
		List<EmiMidTidBean> responseBean = emiBulkUploadService.downloadEmiSearchList(bean);
		if (!responseBean.isEmpty()) {
			log.info("Response /emi-bulk-upload/download {}", responseBean);

			Resource resource = emiBulkUploadService.processEmiSearchList(responseBean);
			// Get the resource from service
			if (resource != null) {				
				return ResponseEntity.ok()
						.contentType(MediaType.parseMediaType(CommonConstants.EXCEL_CONTENT_TYPE.get()))
						.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"EmiSearchList.xlsx\"")
						.body(resource);
			} else {
				log.error("Error while downloading DCEMI list");
				ModelAndView modelAndView = new ModelAndView(ViewLayer.EMI_SEARCH.get());
				modelAndView.addObject("msg", true);
				return modelAndView;
			}
		} else {
			log.error("Error while downloading DCEMI list");
			ModelAndView modelAndView = new ModelAndView(ViewLayer.EMI_SEARCH.get());
			modelAndView.addObject("msg", true);
			return modelAndView;
		
		}
	}

}
