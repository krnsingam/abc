package com.mosambee.config;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.mosambee.bean.CustomUser;
import com.mosambee.constants.BasicRoles;
import com.mosambee.constants.LoginResultIdConstant;
import com.mosambee.properties.WebSecurityProperties;
import com.mosambee.service.UserService;
import com.mosambee.util.CommonUtils;

import lombok.extern.log4j.Log4j2;

/**
 * CustomAuthSuccessHandler is responsible for controlling the flow of program
 * after success authentication.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 05-February-2020
 */
@Log4j2
@Component
public class CustomAuthSuccessHandler implements AuthenticationSuccessHandler {

	@Autowired
	private WebSecurityProperties webSecurityProperties;

	@Autowired
	private UserService userService;

	@Autowired
	private CommonUtils commonUtils;

	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException {
		log.info("Inside onAuthenticationSuccess method");

		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		log.info("user details: {}, authorities: {}", user, user.getAuthorities());

		// Check if user is blocked
		boolean isUserBlocked = userService.checkIfUserIsBlocked(Long.parseLong(user.getMyMap().get("id")));
		log.info("user blocked status is: {}", isUserBlocked);

		if (isUserBlocked) {
			// Add login logs
			userService.addLoginLogs(LoginResultIdConstant.BLOCKED.getCode(), request.getRemoteAddr(),
					Long.parseLong(user.getMyMap().get("id")));

			// Clear security context holder and invalidate the session
			commonUtils.clearSecurityContextHolder();

			// Set appropriate response
			response.sendRedirect(request.getContextPath().concat("/login?blocked"));
		} else {
			// Add login logs
			userService.addLoginLogs(LoginResultIdConstant.SUCCESSFUL.getCode(), request.getRemoteAddr(),
					Long.parseLong(user.getMyMap().get("id")));

			// Check if CP role is coming and set appropriate response
			user.getAuthorities().forEach(action -> {

				try {
					if (action.getAuthority().equalsIgnoreCase(BasicRoles.SITE_CP_USER.get())) {
						log.info("Redirecting to the reset-password page");
						response.sendRedirect(request.getContextPath() + "/reset-password");
					} else {
						log.info("Redirecting to the default success url {}",
								webSecurityProperties.getDefaultSuccessUrl());
						response.sendRedirect(request.getContextPath() + webSecurityProperties.getDefaultSuccessUrl());
					}
				} catch (Exception e) {
					log.error("{}", e);
				}

			});

		}

	}

}
