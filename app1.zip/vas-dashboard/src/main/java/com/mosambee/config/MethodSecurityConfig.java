package com.mosambee.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.GlobalMethodSecurityConfiguration;

/**
 * MethodSecurityConfig is defined here for enabling following functionalities.
 * 
 * <li><strong>prePostEnabled = true, enables spring security pre/post annotations.</strong></li>
 * <li><strong>securedAnnotation = true, enables the spring security {@code @Secured } annotation.</strong></li>
 * <li><strong>jsr250Enabled = true, allows us to use the {@code @RoleAllowed } annotation.</strong></li>
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 11-December-2019
 */
@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true, jsr250Enabled = true)
public class MethodSecurityConfig extends GlobalMethodSecurityConfiguration {
}
