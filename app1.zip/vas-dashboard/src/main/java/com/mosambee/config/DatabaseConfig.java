package com.mosambee.config;

import javax.sql.DataSource;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 *	DatabaseConfig is basically used to get data-source settings
 *	defined in application.properties(profile specific) file and then create 
 *	data-source from it. This is then used in connection pooling by HikariCP.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 02-December-2019
 */
@Configuration
public class DatabaseConfig {
	
	@Bean("masterSfnVasTemplate")
	public JdbcTemplate masterSfnVasTemplate(DataSource masterSfnVasDataSource) {
		return new JdbcTemplate(masterSfnVasDataSource);
	}
	
	@Bean("slaveSfnVasTemplate")
	public JdbcTemplate slaveSfnVasTemplate(DataSource slaveSfnVasDataSource) {
		return new JdbcTemplate(slaveSfnVasDataSource);
	}
	
	@Bean("masterSecurityAndLicenseTemplate")
	public JdbcTemplate masterSecurityAndLicenseTemplate(DataSource masterSecurityAndLicenseDataSource) {
		return new JdbcTemplate(masterSecurityAndLicenseDataSource);
	}
	
	@Bean("slaveSecurityAndLicenseTemplate")
	public JdbcTemplate slaveSecurityAndLicenseTemplate(DataSource slaveSecurityAndLicenseDataSource) {
		return new JdbcTemplate(slaveSecurityAndLicenseDataSource);
	}

	@Bean("masterSFNTransactionTemplate")
	public JdbcTemplate masterSFNTransaction(DataSource masterSFNTransactionDataSource) {
		return new JdbcTemplate(masterSFNTransactionDataSource);
	}

	@Bean("slaveSFNTransactionTemplate")
	public JdbcTemplate slaveSFNTransaction(DataSource slaveSFNTransactionDataSource) {
		return new JdbcTemplate(slaveSFNTransactionDataSource);
	}
	
	@Bean("masterSfnVasDataSource")
	@ConfigurationProperties(prefix = "master.sfn-vas")
	public DataSource masterSfnVasDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean("slaveSfnVasDataSource")
	@ConfigurationProperties(prefix = "slave.sfn-vas")
	public DataSource slaveSfnVasDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean("masterSecurityAndLicenseDataSource")
	@ConfigurationProperties(prefix = "master.securityandlicense")
	public DataSource masterSecurityAndLicenseDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean("slaveSecurityAndLicenseDataSource")
	@ConfigurationProperties(prefix = "slave.securityandlicense")
	public DataSource slaveSecurityAndLicenseDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean("masterSFNTransactionDataSource")
	@ConfigurationProperties(prefix = "master.sfntransaction")
	public DataSource masterSFNTransactionDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean("slaveSFNTransactionDataSource")
	@ConfigurationProperties(prefix = "slave.sfntransaction")
	public DataSource slaveSFNTransactionDataSource() {
		return DataSourceBuilder.create().build();
	}
	
}
