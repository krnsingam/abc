package com.mosambee.config;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import com.mosambee.bean.UserExistAndNotBlockedBean;
import com.mosambee.constants.LoginResultIdConstant;
import com.mosambee.service.UserService;

import lombok.extern.log4j.Log4j2;

/**
 * Responsible for calling the database updating the failed login count and
 * responsible for blocking the user if done multiple attempts.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 10-February-2020
 */
@Log4j2
@Component
public class CustomAuthFailureHandler implements AuthenticationFailureHandler {

	@Autowired
	private UserService userService;

	/**
	 * Responsible for checking if user exists and is not blocked and then set
	 * appropriate response accordingly.
	 * 
	 * @param request   HttpServletRequest
	 * @param response  HttpServletResponse
	 * @param exception AuthenticationException
	 * @exception IOException, ServletException
	 */
	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException exception) throws IOException, ServletException {

		log.error("Inside authentication failure handler, authentication failed for {}, exception: {}",
				request.getParameter("username"), exception);

		// Get user existence and not blocked parameters
		UserExistAndNotBlockedBean bean = userService.checkIfUserExistsAndNotBlocked(request.getParameter("username"));

		if (bean.isUserExists() && !bean.isNotBlocked()) { // Check if user exist and blocked
			log.info("user exist and is blocked");

			// Add login logs
			userService.addLoginLogs(LoginResultIdConstant.BLOCKED.getCode(), request.getRemoteAddr(),
					bean.getUserId());

			// Set response to blocked page
			response.sendRedirect(request.getContextPath().concat("/login?blocked"));

		} else if (bean.isUserExists() && bean.isNotBlocked()) {
			log.info("user exist and is not blocked");

			// Add login logs for wrong credentials count
			userService.addLoginLogs(LoginResultIdConstant.WRONG_CREDENTIALS.getCode(), request.getRemoteAddr(),
					bean.getUserId());

			// check wrong credentials count and see if user is getting blocked
			boolean isGettingBlocked = userService.checkWrongCredentialCount(bean.getUserId());

			if (isGettingBlocked) {
				log.error("user is getting blocked, sending response to blocking page");
				response.sendRedirect(request.getContextPath().concat("/login?blocking"));
			} else {
				log.error("sending to login error page");
				response.sendRedirect(request.getContextPath().concat("/login?error"));
			}

		} else {
			log.error("{} doesn't exist in our database", request.getParameter("username"));

			// Set appropriate response
			response.sendRedirect(request.getContextPath().concat("/login?error"));
		}

	}

}
