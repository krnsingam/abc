package com.mosambee.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.header.writers.StaticHeadersWriter;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.security.web.session.SessionInformationExpiredStrategy;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.mosambee.properties.WebSecurityProperties;
import com.mosambee.service.impl.UserServiceImpl;
import com.mosambee.util.SHAPasswordEncoder;

/**
 * WebSecurity configuration is basically used to define userDetailsService,
 * authentication provider and httpSecurity settings.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 02-December-2019
 */
@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private AccessDeniedHandler accessDeniedHandler;

	@Autowired
	private AuthenticationSuccessHandler successHandler;
	
	@Autowired 
	private AuthenticationFailureHandler failureHandler;
	
	@Autowired
	private SessionInformationExpiredStrategy expiredSessionStrategy;

	private final WebSecurityProperties webSecurityProperties;

	public WebSecurityConfig(@Autowired WebSecurityProperties webSecurityProperties) {
		this.webSecurityProperties = webSecurityProperties;
	}

	@Bean
	@Override
	protected UserDetailsService userDetailsService() {
		return new UserServiceImpl();
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return SHAPasswordEncoder.getInstance();
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(userDetailsService()).passwordEncoder(passwordEncoder());
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.cors().and()
			.authorizeRequests()
				.antMatchers(webSecurityProperties.getPermitPaths()).permitAll()
				.anyRequest().authenticated()
			.and()
			.formLogin()
				.loginPage(webSecurityProperties.getLoginPage())
				.successHandler(successHandler)
				.failureHandler(failureHandler)
				.permitAll()
			.and()
			.logout()
				.deleteCookies(webSecurityProperties.getDeleteCookies())
				.invalidateHttpSession(false)
				.logoutUrl(webSecurityProperties.getLogoutUrl())
				.logoutSuccessUrl(webSecurityProperties.getLogoutSuccessUrl())
				.permitAll()
			.and()
			.exceptionHandling()
				.accessDeniedHandler(accessDeniedHandler)
			.and()
			.sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
				.sessionFixation()
				.migrateSession()
				.invalidSessionUrl(webSecurityProperties.getInvalidSessionUrl())
				.maximumSessions(1)
					.expiredSessionStrategy(expiredSessionStrategy);
		
		http.headers().addHeaderWriter(
				new StaticHeadersWriter("Access-Control-Allow-Origin", webSecurityProperties.getOrigins().get(0)));
	}
	
	@Bean
	public CorsConfigurationSource corsConfigurationSource(WebSecurityProperties webSecurityProperties) {
		final CorsConfiguration configuration = new CorsConfiguration();

		configuration.setAllowedOrigins(webSecurityProperties.getOrigins());
		configuration.setAllowedMethods(webSecurityProperties.getMethods());
		configuration.setAllowedHeaders(webSecurityProperties.getHeaders());
		configuration.setAllowCredentials(true);
		final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", configuration);
		return source;
	}

	@Bean
	public HttpSessionEventPublisher httpSessionEventPublisher() {
		return new HttpSessionEventPublisher();
	}

}
