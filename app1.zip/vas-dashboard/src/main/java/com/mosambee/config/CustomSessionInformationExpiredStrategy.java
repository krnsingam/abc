package com.mosambee.config;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.web.session.SessionInformationExpiredEvent;
import org.springframework.security.web.session.SessionInformationExpiredStrategy;
import org.springframework.stereotype.Component;

import com.mosambee.properties.WebSecurityProperties;

import lombok.extern.log4j.Log4j2;

/**
 * Responsible for providing implementation for
 * {@link SessionInformationExpiredStrategy}. Here we are adding support for
 * expired URL.
 * 
 * @author swapnil.singh
 * @version 1.0
 * @since 11-February-2020
 */
@Log4j2
@Component
public class CustomSessionInformationExpiredStrategy implements SessionInformationExpiredStrategy {

	@Autowired
	private WebSecurityProperties webSecurityProperties;

	/**
	 * Responsible for manually invalidating the session and redirecting to the
	 * expired URL.
	 * 
	 * @param event
	 * @return void
	 */
	@Override
	public void onExpiredSessionDetected(SessionInformationExpiredEvent event) throws IOException, ServletException {
		log.info("Inside onExpiredSessionDetected method");

		HttpServletRequest request = event.getRequest();
		HttpServletResponse response = event.getResponse();
		HttpSession session = request.getSession(false);

		if (null != session) {
			session.invalidate();
			log.info("Session invalidated");
		}

		response.sendRedirect(request.getContextPath().concat(webSecurityProperties.getExpiredUrl()));
	}

}
