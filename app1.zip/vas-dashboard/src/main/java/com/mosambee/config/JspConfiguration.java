package com.mosambee.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

/**
 * JspConfiguration file is responsible for making bean for JSP view-resolver.
 * 
 * @author swapnil.singh
 * @since 1.0
 * @version 04-February-2020
 */
@Configuration
public class JspConfiguration {

	@Bean
	public ViewResolver jspViewResolver() {
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();

		viewResolver.setViewClass(JstlView.class);
		viewResolver.setPrefix("/WEB-INF/jsp/");
		viewResolver.setSuffix(".jsp");
		viewResolver.setContentType("text/html");

		viewResolver.setOrder(1000);
		return viewResolver;
	}

}
