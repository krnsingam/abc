package com.mosambee.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class MailConstant {
	
	private final String path;
	
	public MailConstant(@Value("${threadpath}") String path) {
		this.path = path;
	}
	
	Logger log = LogManager.getLogger(MailConstant.class);
	
	public static final String SUBJECT = " Bank Automated EMI Reporting Service.";
	public static final String TEXT1 = "Dear Sir/Madam,\r\n" + 
										"\r\n";
	public static final String TEXT2 = "\r\n" + 
										"\r\n" + 
										"\r\n" + 
										"Warm regards,\r\n" + 
										"Mosambee Team";

	public String mailDetail(String bank) {
		String banke = "";
		log.info("path in MailConstant is: {}", path);
		Properties prop = new Properties();
		InputStream input = null;
		try {
		    input = new FileInputStream(path);
		    prop.load(input);
		    banke = prop.getProperty("mosambee.emailto."+bank.toLowerCase());
		   
		    
		} catch (IOException ex) {
			log.info(ex.getMessage());
		}
		 log.info(banke);
		return banke;
	}
	
	
}
