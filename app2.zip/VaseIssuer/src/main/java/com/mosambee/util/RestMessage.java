package com.mosambee.util;

import lombok.Getter;

import java.util.Date;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonFormat;

@Getter
public class RestMessage {
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
    Date datetime = new Date();
	private HttpStatus status;
    private String message;

    public RestMessage(String message) {
        this.message = message;
    }
    
    public RestMessage(HttpStatus status) {
        this.status = status;
    }
    
    public RestMessage(HttpStatus status,String message) {
		super();
		 this.status = status;
		this.message = message;
	}
}