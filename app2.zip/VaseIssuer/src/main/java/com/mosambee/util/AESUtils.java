package com.mosambee.util;

import java.security.NoSuchAlgorithmException;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AESUtils {
	private static final Logger log = LogManager.getLogger(AESUtils.class);

	private AESUtils() {}

	/**
     * gets the AES encryption key.
     * @return
     * @throws Exception 
     */

    public static String getSecretEncryptionKey() throws NoSuchAlgorithmException {
        KeyGenerator generator = KeyGenerator.getInstance("AES");
        generator.init(128); // The AES key size in number of bits
        SecretKey secKey = generator.generateKey();
        return byteToHex(secKey.getEncoded());
    }

    /**
     * Encrypts plainText in AES using the secret key
     * @param plainText
     * @param secKey
     * @return
     * @throws Exception 
     */

    public static String encrypt(String plainText, String secKey) {
		try {
			// AES defaults to AES/ECB/PKCS5Padding in Java 7
	        Cipher aesCipher = Cipher.getInstance("AES");
	        SecretKeySpec skey = new SecretKeySpec(hexToByteArray(secKey), "AES");

	        aesCipher.init(Cipher.ENCRYPT_MODE, skey);
	        byte[] byteCipherText = aesCipher.doFinal(plainText.getBytes());
	        return byteToHex(byteCipherText);
		} catch (Exception e) {
			log.info("Exception occured: {}, Cause : {}",e.getMessage(),e.getCause());
			return null;
		}
    }

    /**
     * Decrypts encrypted HES String using the key used for encryption.
     * @param encHexString
     * @param secKey
     * @return
     * @throws Exception 
     */

    public static String decrypt(String encHexString, String secKey) {
		try {
			// AES defaults to AES/ECB/PKCS5Padding in Java 7
	        Cipher aesCipher = Cipher.getInstance("AES");
	        SecretKeySpec skey = new SecretKeySpec(hexToByteArray(secKey), "AES");

	        aesCipher.init(Cipher.DECRYPT_MODE, skey);
	        byte[] bytePlainText = aesCipher.doFinal(hexToByteArray(encHexString));
	        return new String(bytePlainText);
		} catch (Exception e) {			
			log.info("Exception occured: {}, Cause : {}",e.getMessage(),e.getCause());
			return null;
		}
    }

    /**
     * Convert a byte array into readable HEX form
     * @param hash
     * @return String
     */

    public static String byteToHex(byte[] hash) {
		   StringBuilder stringBuilder = new StringBuilder(hash.length*2);
		   for(byte b: hash) {
			   stringBuilder.append(String.format("%02x", b)); 
		   }		      
		   return stringBuilder.toString().toUpperCase();
	}

    /**
     * Convert HEX String to byte Array
     * @param hexString
     * @return String
     */
    
    public static byte[] hexToByteArray(String hexString) {
        int len = hexString.length();
        byte[] data = new byte[len / 2];

        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4)
                                 + Character.digit(hexString.charAt(i+1), 16));
        }

        return data;
    }

	public static String maskCardNum(String cardNumber) {
		return StringUtils.overlay(cardNumber, StringUtils.repeat("X", cardNumber.length()-10), 5, cardNumber.length() - 4);
	}
}