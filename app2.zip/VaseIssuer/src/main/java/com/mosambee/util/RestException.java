package com.mosambee.util;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class RestException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	private final String message;
    private final transient Object[] args;
    
}

