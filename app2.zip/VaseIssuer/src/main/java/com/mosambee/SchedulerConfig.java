package com.mosambee;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

@Configuration
public class SchedulerConfig implements SchedulingConfigurer {
	
	@Value("${threadpath}")
	private String path;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SchedulerConfig.class);

    @Override
    public void configureTasks(ScheduledTaskRegistrar scheduledTaskRegistrar) {
    	
    	int poolsize = 10;
    	
    	Properties prop = new Properties();
		InputStream input = null;
	
		try {
		    input = new FileInputStream(path);
		    prop.load(input);
		    poolsize = Integer.parseInt(prop.getProperty("mosambee.schedular.poolsize"));
		    
		} catch (IOException ex) {
			LOGGER.info(ex.getMessage());
		}
		

    	
        ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();

        threadPoolTaskScheduler.setPoolSize(poolsize);
        threadPoolTaskScheduler.setThreadNamePrefix("sch-thread");
        threadPoolTaskScheduler.setThreadFactory(taskExecutor());
        threadPoolTaskScheduler.initialize();

        scheduledTaskRegistrar.setTaskScheduler(threadPoolTaskScheduler);
    }
    
    public ThreadPoolTaskExecutor taskExecutor() {
    	int maxPoolSize = 4;
    	int coreSize = 2;
    	int capacity = 2000;
    	
    	Properties prop = new Properties();
		InputStream input = null;
	
		try {
		    input = new FileInputStream(path);
		    prop.load(input);
		    maxPoolSize = Integer.parseInt(prop.getProperty("mosambee.thread.maxsize"));
		    coreSize = Integer.parseInt(prop.getProperty("mosambee.thread.core"));
		    capacity = Integer.parseInt(prop.getProperty("mosambee.thread.capacity"));
		} catch (IOException ex) {
			LOGGER.info(ex.getMessage());
		}
    	
		ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
		taskExecutor.setMaxPoolSize(maxPoolSize);
		taskExecutor.setCorePoolSize(coreSize);
		taskExecutor.setQueueCapacity(capacity);
		taskExecutor.setThreadNamePrefix("main-thread");
		taskExecutor.initialize();
		return taskExecutor;
	}
}

