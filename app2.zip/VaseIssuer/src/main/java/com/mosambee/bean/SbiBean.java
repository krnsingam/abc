package com.mosambee.bean;

import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import lombok.Data;

@Data
@Validated
public class SbiBean {
	
	String recordType="DD";
	String org="801";
	String statusFlag="A";
	
	@NotNull
	String setupType="";
	String manufacturerUniqueId="";
	String manufacturerName="";
	String manufacturerAddress="";
	String merchantName="";
	String merchantCity="";
	String onUsOffUsFlag="";
	String merchantId="";
	String storeId="";
	String storeName="";
	String storeCity="";
	String startDateMid="";
	String endDateMid="";
	String emiPercAge="";
	String misType="";
	String billingType="";
	String skuId="";
	String skuName="";
	String aggeratorId="";
	String cashbackFeeFlag="";
	String processingFeeFlag="";
	String term1="";
	String term2="";
	String term3="";
	String term4="";
	String term5="";
	String term6="";
	String term7="";
	String term8="";
	String term9="";
	String term10="";
	String subventioncashbackFee1="";
	String subventioncashbackFee2="";
	String subventioncashbackFee3="";
	String subventioncashbackFee4="";
	String subventioncashbackFee5="";
	String subventioncashbackFee6="";
	String subventioncashbackFee7="";
	String subventioncashbackFee8="";
	String subventioncashbackFee9="";
	String subventioncashbackFee10="";
	String processingFee1="";
	String processingFee2="";
	String processingFee3="";
	String processingFee4="";
	String processingFee5="";
	String processingFee6="";
	String processingFee7="";
	String processingFee8="";
	String processingFee9="";
	String processingFee10="";
	String rateOfInt1="";
	String rateOfInt2="";
	String rateOfInt3="";
	String rateOfInt4="";
	String rateOfInt5="";
	String rateOfInt6="";
	String rateOfInt7="";
	String rateOfInt8="";
	String rateOfInt9="";
	String rateOfInt10="";


}
