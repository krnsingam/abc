package com.mosambee.bean;

import lombok.Data;

@Data
public class SbiCmsBean {

	String recordType="";
	String uniqueReferenceNumber="";
	String aggregatorName="";
	String cardNbr="";
	String txnAmount="";
	String totalTerms="";
	String authCode="";
	String saleDate="";
	String manufacturerName="";
	String merchId="";
	String merchantName="";
	String termId="";
	String rateOfInt="";
	String description="";
	String originalAmount="";
	String statusFlag="";
	String onUsOffUsFlag="";
	String processingFeeFlag="";
	String processingFee="";
	String skuCode="";
	String cashbackAmount="";
	String emiAmount="";

}
