package com.mosambee.bean;

import lombok.Data;

@Data
public class RblBean {

	String emiId;
	String cardPAN;
	String issuer;
	String acquirer;
	String aggregatorMerchantName;
	String manufacturer;
	String rrn;
	String authCode;
	String txAmount;
	String emiOffer;
	String emiPlanID;
	String customerName;
	String mobile;
	String address;
	String email;
	String storeName;
	String address1;
	String storeCity;
	String storeState;
	String mid;
	String tid;
	String txTime;
	String subventionPayable;	
	String subventionAmount;
	String interestRate;
	String customerProcessingFee;
	String customerProcessingAmount;
	String txStatus;
	String status;
	String description;
	String productCategory;
	String productSubCategory1;	
	String productSubCategory2;
	String modelName;
	String merchantName;
	String emiAmount;
	String loanAmount;
	String discountCashbackPercent;
	String discountCashbackAmount;
	String additionalCashback;
	String bonusRewardPoints;
	String emiModel;

}
