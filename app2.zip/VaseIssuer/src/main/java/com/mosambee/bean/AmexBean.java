package com.mosambee.bean;

import lombok.Data;

@Data
public class AmexBean {

	String loyaltyTransactionId;
	String issuer;
	String acquirer;
	String manufacturerName;
	String merchantName;
	String storeName;
	String storeCity;
	String storeState;
	String bankMid;
	String bankTid;
	String emiOffer;
	String cardPan;
	String firstName;
	String mobileNumber;
	String email;
	String bankRrn;
	String bankApprovalCode;
	String bankDatetime;
	String settlementTime;
	String transactionAmount;
	String txStatus;
	String type;
	String flag;
	String productCategory;
	String subCat1;
	String subCat2;
	String subCat3;
	String productSrNo;
	String dbaName;
	String dmsCode;
	String dealerType;
	String batchNo;
	String cardHash;
	String emiModel;
	String distributorId;
	String posId;
	String totalrate;
	String totalamount;
	String cashbackrate;
	String cashnbackamount;
	String paybackrate;
	String paybackamount;
	String total;
	String fundedrate;
	String fundedamount;
	
	
}
