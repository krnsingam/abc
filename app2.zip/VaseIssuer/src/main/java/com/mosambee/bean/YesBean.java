package com.mosambee.bean;

import lombok.Data;

@Data
public class YesBean {

	String emiId;
	String cardPan;
	String rrn;
	String authCode;
	String issuer;
	String txAmount;
	String emiOffer;
	String manufacturer;
	String merchantName;
	String address1;
	String storeCity;
	String storeState;
	String acquirer;
	String mid;
	String tid;
	String txTime;
	String settlementTime;
	String customerProcessingFee;
	String customerProcessingAmount;
	String subventionPayable;
	String subventionAmount;
	String interestRate;
	String txStatus;
	String status;
	String description;
	String productCategory;
	String productSubCategory1;
	String productSubCategory2;
	String modelName;
	String cardHash;
	String emiAmount;
	String loanAmount;
	String discountCashbackPercent;
	String discountCashbackAmount;
	String isNewModel;
	String additionalCashback;
	String rewardPoint;
}
