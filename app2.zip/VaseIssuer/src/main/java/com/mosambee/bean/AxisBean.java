package com.mosambee.bean;

import lombok.Data;

@Data
public class AxisBean {
	
	String cardNumber;	
	String transactionAmount;
	String transactionDate;
	String settlementDate;
	String authorisationId;
	String merchantName;
	String mcc;
	String tenure;
	String interestRate;
	String source;
	String emiId;


}
