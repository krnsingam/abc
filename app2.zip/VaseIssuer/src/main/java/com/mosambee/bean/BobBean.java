package com.mosambee.bean;

import lombok.Data;

@Data
public class BobBean {

	String emiId;
	String cardno;
	String issuer;
	String acquirer;
	String manufacturer;
	String merchantName;
	String rrn;
	String authCode;
	String transactionAmt;
	String emiOffer;
	String email;
	String storeName;
	String address1;
	String storeCity;
	String storeState;
	String mid;
	String tid;
	String transactionTime;
	String subvention;
	String subventionAmount;
	String interestRate;
	String customerProcessingFee;
	String customerProcessingAmt;
	String transactionStatus;
	String emiAmount;
	String transactionAmount;

}
