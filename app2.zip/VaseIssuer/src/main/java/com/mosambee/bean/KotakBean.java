package com.mosambee.bean;

import lombok.Data;

@Data
public class KotakBean {

	String emiId;	
	String cardPan;
	String issuer;
	String authCode;
	String txAmount;
	String tenure;
	String manufacturer;
	String merchantName;
	String address1;
	String acquirer;
	String mid;
	String tid;
	String txTime;
	String settlementTime;	
	String interestRate;
	String discountCashbackPercent;
	String discountCashbackAmount;

}
