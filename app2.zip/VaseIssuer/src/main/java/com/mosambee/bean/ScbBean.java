package com.mosambee.bean;

import lombok.Data;

@Data
public class ScbBean {

	String cardNumber;
	String mid;
	String merchantName;
	String trxnAmount;
	String trxnDate;
	String settlementDate;
	String authCode;
	String tenor;
	String increasingInterestRate;
	String processingFee;
	String forclouserFee;
	String minamt;
	String maxamt;
	String reducingInterestRate;

}
