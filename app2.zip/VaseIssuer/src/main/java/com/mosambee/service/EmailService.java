package com.mosambee.service;

public interface EmailService {

	public String sendPreparedMail(String bank,String path,String pass);
	
	public String sendErrorMail();
	
	public String sendSbiMail(String bank,String path);
	
}
