package com.mosambee.service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.mosambee.bean.SbiBean;
import com.mosambee.bean.SbiCmsBean;
import com.mosambee.repository.SbiRepository;
import com.mosambee.util.AESUtils;

@Service("sbiService")
public class SbiServiceImpl implements SbiService{

	Logger log = LogManager.getLogger(SbiServiceImpl.class);
	
	private static final String BLANK_SPACE=" ";
	
	File file = new File(".");	

	@Autowired
	EmailService emailService;
	
	@Autowired
	SbiRepository sbirepo;

	
	public String sbiText(List<SbiBean> sbibean) {
		
		Date dt = new Date();
	    SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyyhhmmss");  
	    String strDate= formatter.format(dt);  
		
		StringBuilder sbi = new StringBuilder("HH");
		
		sbi.append(strDate);
		
		sbi.append(StringUtils.leftPad(String.valueOf(sbibean.size()), 5, "0"));
		
		sbi.append(StringUtils.repeat(BLANK_SPACE, 579));
		
		sbi.append("\n");
		
		for(SbiBean bean : sbibean) {
			
			sbi.append("DD801A");
			
			if(bean.getSetupType()!=null) {
				sbi.append(bean.getSetupType());}
			else {
				sbi.append("M");}
			
			sbi.append("270000001");

			sbi.append(StringUtils.leftPad(String.valueOf(bean.getManufacturerName()), 40, BLANK_SPACE));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getManufacturerAddress()), 100, BLANK_SPACE));
		
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getMerchantName()), 40, BLANK_SPACE));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getMerchantCity()), 13, BLANK_SPACE));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getOnUsOffUsFlag()), 1, "0"));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getMerchantId()), 16, "0"));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getStoreId()), 8, BLANK_SPACE));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getStoreName()), 40, BLANK_SPACE));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getStoreCity()), 13, BLANK_SPACE));

			sbi.append(StringUtils.leftPad(String.valueOf(bean.getStartDateMid()), 8, "0"));

			sbi.append(StringUtils.leftPad(String.valueOf(bean.getEndDateMid()), 8, "0"));
		
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getEmiPercAge()), 3, "0"));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getMisType()), 1, BLANK_SPACE));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getBillingType()), 1, BLANK_SPACE));

			sbi.append(StringUtils.leftPad(String.valueOf(bean.getSkuId()), 20, BLANK_SPACE));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getSkuName()), 30, BLANK_SPACE));
			
			//To be looked intoWS
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getAggeratorId()), 9, "0"));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getCashbackFeeFlag()), 1, BLANK_SPACE));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getProcessingFeeFlag()), 1, BLANK_SPACE));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getTerm1()), 3, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getTerm2()), 3, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getTerm3()), 3, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getTerm4()), 3, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getTerm5()), 3, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getTerm6()), 3, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getTerm7()), 3, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getTerm8()), 3, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getTerm9()), 3, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getTerm10()), 3, "0"));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getSubventioncashbackFee1()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getSubventioncashbackFee2()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getSubventioncashbackFee3()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getSubventioncashbackFee4()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getSubventioncashbackFee5()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getSubventioncashbackFee6()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getSubventioncashbackFee7()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getSubventioncashbackFee8()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getSubventioncashbackFee9()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getSubventioncashbackFee10()), 7, "0"));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getProcessingFee1()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getProcessingFee2()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getProcessingFee3()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getProcessingFee4()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getProcessingFee5()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getProcessingFee6()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getProcessingFee7()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getProcessingFee8()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getProcessingFee9()), 7, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getProcessingFee10()), 7, "0"));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getRateOfInt1()), 4, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getRateOfInt2()), 4, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getRateOfInt3()), 4, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getRateOfInt4()), 4, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getRateOfInt5()), 4, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getRateOfInt6()), 4, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getRateOfInt7()), 4, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getRateOfInt8()), 4, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getRateOfInt9()), 4, "0"));
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getRateOfInt10()), 4, "0"));
			
			
			sbi.append(StringUtils.repeat(BLANK_SPACE, 21));
			
			sbi.append("\n");
		}
		
		File textFile = null;
		try {
			textFile = File.createTempFile("IIMBS", ".txt", file);
		
        try (Writer writer = new BufferedWriter(new FileWriter(textFile))) {
            writer.write(sbi.toString());
            emailService.sendSbiMail("Sbi",textFile.getAbsolutePath());
        }
		} catch (Exception e1) {
			log.info(e1);
		}
		
		return sbi.toString();
		
	}
	
	
	public String sbiCmsText(List<SbiCmsBean> sbicmsbean,String totamt, String tottrnx) {
		
		Date dt = new Date();
	    SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyyhhmmss");  
	    SimpleDateFormat formate = new SimpleDateFormat("ddMMyyyy");  
	    String strDate= formatter.format(dt);  
		
		StringBuilder sbi = new StringBuilder("HH");
		
		sbi.append(strDate);
		
		sbi.append(StringUtils.leftPad(String.valueOf(tottrnx), 5, "0"));
		
		sbi.append(StringUtils.leftPad(String.valueOf(totamt), 17, "0"));
		
		sbi.append("F");
		
		sbi.append(StringUtils.repeat(BLANK_SPACE, 411));
		
		sbi.append("\n");
		Date dat;
		try {
		for(SbiCmsBean bean : sbicmsbean) {
			
			sbi.append("DD");
		
			sbi.append(getSBIRefNo(Long.parseLong(bean.getUniqueReferenceNumber())));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getAggregatorName()), 40, BLANK_SPACE));
			
			sbi.append(StringUtils.rightPad(String.valueOf(AESUtils.decrypt(bean.getCardNbr(), "4CD974159A288A03909C7D958D49C090")), 19, "0"));
			
			sbi.append(StringUtils.rightPad(String.valueOf(bean.getTxnAmount()), 17, "0"));
			
			sbi.append(StringUtils.rightPad(String.valueOf(bean.getTotalTerms()), 3, "0"));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getAuthCode()), 6, BLANK_SPACE));

			dat = formate.parse(bean.getSaleDate());

			sbi.append(StringUtils.rightPad(String.valueOf(formate.format(dat)), 8, "0"));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getManufacturerName()), 40, BLANK_SPACE));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getMerchId()), 16, BLANK_SPACE));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getMerchantName()), 40, BLANK_SPACE));
		
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getTermId()), 8, BLANK_SPACE));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getRateOfInt()), 7, "0"));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getDescription()), 40, BLANK_SPACE));
			
			sbi.append(StringUtils.rightPad(String.valueOf(bean.getOriginalAmount()), 17, "0"));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getStatusFlag()), 1, BLANK_SPACE));
			
			sbi.append(StringUtils.rightPad(String.valueOf(bean.getOnUsOffUsFlag()), 1, "0"));
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getProcessingFeeFlag()), 1, BLANK_SPACE));
			
			if(bean.getProcessingFeeFlag().equals("P")) {
				
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getProcessingFee()), 7, "0"));
			
			}else {
				
				sbi.append(StringUtils.rightPad(String.valueOf(bean.getProcessingFee()), 7, "0"));
			}
			
			
			sbi.append(StringUtils.leftPad(String.valueOf(bean.getSkuCode()), 20, BLANK_SPACE));
			
			sbi.append(StringUtils.rightPad(String.valueOf(bean.getCashbackAmount()), 17, "0"));
			
			sbi.append(StringUtils.rightPad(String.valueOf(bean.getEmiAmount()), 17, "0"));

			sbi.append(StringUtils.repeat(BLANK_SPACE, 108));
			
			sbi.append("\n");
		}
		} catch (ParseException e) {
			log.info(e.getMessage());
		}
		
		File textFile = null;
		try {
			textFile = File.createTempFile("IICMS", ".txt", file);
		
        try (Writer writer = new BufferedWriter(new FileWriter(textFile))) {
            writer.write(sbi.toString());
            emailService.sendSbiMail("Sbi",textFile.getAbsolutePath());
        }
		} catch (Exception e1) {
			log.info(e1);
		}

		
		return sbi.toString();
		
	}
	
	@Async
	public void getSbiList(String type) {

		if(type.equals("C")) {

			Map<String,Object> data = sbirepo.sbiCmsReport();
			List<SbiCmsBean> cmslist = (List<SbiCmsBean>) data.get("sbilist");
			String stre = sbiCmsText(cmslist,data.get("totAmount").toString(), data.get("totTrnx").toString());
			log.info(stre);
		}else {

			List<SbiBean> list = sbirepo.sbiReport(type);
			
			String str = sbiText(list);
			
			log.info(str);
		}
	}
	
	@Async
	public void deleteSbiReport() {
		try (Stream<Path> walk = Files.walk(Paths.get(""))) {

			List<String> result = walk.map(Object::toString)
					.filter(f -> f.endsWith(".txt")).collect(Collectors.toList());

			for(String path : result) {
				File fil = new File(path);

				if( getCreateTime(fil).isBefore(LocalDateTime.now().minusMinutes(1))){
					Path del = Paths.get(path);
					Files.delete(del);
					log.info("Delete operation done ");
				}else{
					TimeUnit.MINUTES.sleep(1);
				}
			}

		} catch (Exception e) {
			log.info(e.getMessage());
		}

	}
	
	private static LocalDateTime getCreateTime(File file) throws IOException {
		
		Path path = Paths.get(file.getPath());
		BasicFileAttributeView basicfile = Files.getFileAttributeView(path, BasicFileAttributeView.class, LinkOption.NOFOLLOW_LINKS);
		BasicFileAttributes attr = basicfile.readAttributes();
		long date = attr.creationTime().toMillis();
		Instant instant = Instant.ofEpochMilli(date);
		
		return LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
	}
	
	// GENERATE TRANSACTION UNIQUE REFERENCE NO
	private static String getSBIRefNo(long emiId) {
		StringBuilder refNum = new StringBuilder();
		refNum.append("S");
		refNum.append(new SimpleDateFormat("ddMMyy").format(new Date()));

		if(String.valueOf(emiId).length() > 8) {
			refNum.append(String.valueOf(emiId).substring(0, 8));
		} else {
			String eId = StringUtils.leftPad(String.valueOf(emiId), 8, "0");
			refNum.append(eId);
		}

		return refNum.toString();
	}
	
}
