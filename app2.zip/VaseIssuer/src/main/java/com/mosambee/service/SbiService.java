package com.mosambee.service;

import java.util.List;

import com.mosambee.bean.SbiBean;

public interface SbiService {

	public String sbiText(List<SbiBean> sbibean);
	
	public void getSbiList(String type);
	
	public void deleteSbiReport();
	
}
