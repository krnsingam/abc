package com.mosambee.service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.apache.poi.poifs.crypt.CipherAlgorithm;
import org.apache.poi.poifs.crypt.EncryptionInfo;
import org.apache.poi.poifs.crypt.EncryptionMode;
import org.apache.poi.poifs.crypt.Encryptor;
import org.apache.poi.poifs.crypt.HashAlgorithm;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import java.nio.file.Files;
import java.nio.file.LinkOption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.mosambee.repository.ReportRepository;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;



@Service("reportService")
public class ReportServiceImpl implements ReportService {

	File file = new File(".");	

	@Autowired
	EmailService emailService;

	@Autowired
	ReportRepository reportepo;

	public static final  String XLSX = ".xlsx";

	Logger log = LogManager.getLogger(ReportServiceImpl.class);


	public JasperPrint generateJasperPrint(List<Object> order, String bank) throws IOException, JRException {


		StringBuilder template = new StringBuilder();
		template.append(file.getAbsolutePath())
		.append("\\jrxml\\").append(bank).append(".jrxml");

		JasperReport report = loadTemplate(template.toString());

		// Create parameters map.
		Map<String, Object> parameters = parameters();

		// Create an empty datasource.
		JRBeanCollectionDataSource dataSrc= new JRBeanCollectionDataSource(order);

		//Create a jasper print
		return JasperFillManager.fillReport(report,parameters,dataSrc);
	}

	public String getEmailReportPdf(List<Object> order, String bank) throws JRException, IOException {

		JasperPrint jp=generateJasperPrint(order, bank);

		File pdfFile = File.createTempFile(bank, ".pdf", file);
		JasperExportManager.exportReportToPdfFile(jp,pdfFile.getAbsolutePath());

		emailService.sendPreparedMail(bank, pdfFile.getAbsolutePath(),"");

		return pdfFile.getAbsolutePath();
	}

	@Async
	public byte[] getReportPdf(List<Object> order, String bank) throws JRException, IOException {
		JasperPrint jp = null;
		return JasperExportManager.exportReportToPdf(jp);
	}

	@Async
	public byte[] getReportXlsx(List<Object> order, String bank) throws JRException, IOException {
		JRXlsxExporter xlsxExporter = new JRXlsxExporter();
		final byte[] rawBytes;

		JasperPrint jp=generateJasperPrint(order, bank);

		try(ByteArrayOutputStream xlsReport = new ByteArrayOutputStream()){
			xlsxExporter.setExporterInput(new SimpleExporterInput(jp));
			xlsxExporter.setExporterOutput(new SimpleOutputStreamExporterOutput(xlsReport));
			xlsxExporter.exportReport();

			rawBytes = xlsReport.toByteArray();
		}

		return rawBytes;
	}


	public String getEmailReportXlsx(List<Object> order, String bank) throws JRException, IOException {

		log.info("Bank : {} thread : {}",bank,Thread.currentThread().getName());
		String[] name= {"Report Sample"};
		log.info("BankName : {}, Sizemain : {}",bank,order.size());

		JasperPrint jp=generateJasperPrint(order, bank);

		File xlsxFile = File.createTempFile(bank, XLSX, file);

		JRXlsxExporter xlsxExporter  = new JRXlsxExporter();
		jp.setProperty(net.sf.jasperreports.engine.JRParameter.IS_IGNORE_PAGINATION, "true");
		xlsxExporter.setExporterInput(new SimpleExporterInput(jp));
		xlsxExporter.setExporterOutput(new SimpleOutputStreamExporterOutput(xlsxFile.getAbsolutePath()));
		SimpleXlsxReportConfiguration xlsxreportConfig = new SimpleXlsxReportConfiguration();
		xlsxreportConfig.setSheetNames(new String[] { xlsxFile.toString() });
		xlsxreportConfig.setRemoveEmptySpaceBetweenRows(true);
		xlsxreportConfig.setRemoveEmptySpaceBetweenColumns(true);
		xlsxreportConfig.setForcePageBreaks(false);
		xlsxreportConfig.setAutoFitPageHeight(true);
		xlsxreportConfig.setWrapText(false);
		xlsxreportConfig.setCollapseRowSpan(true);
		xlsxreportConfig.setSheetNames(name);
		xlsxExporter.setConfiguration(xlsxreportConfig);
		xlsxExporter.exportReport(); 

		String pass = passwordProtection(xlsxFile.getAbsolutePath());

		emailService.sendPreparedMail(bank, xlsxFile.getAbsolutePath(),pass);

		return xlsxFile.getAbsolutePath();
	}

	public String getAxisEmailReportXlsx(Map<String,List<Object>> order, String bank) throws JRException, IOException {

		log.info("Bank : {}, Thread : {}, Size : {}",bank,Thread.currentThread().getName(),order.size());
		
		String[] name= {"Business Report Sample","Ops Report Sample"};
		JasperPrint jp=generateJasperPrint(order.get("Axisa"), bank);
		JasperPrint jpa =generateJasperPrint(order.get("Axisb"), "Axis1");

		jpa.addPage(jp.getPages().get(0));

		File xlsxFile = File.createTempFile("Axis", XLSX, file);

		JRXlsxExporter xlsxExporter  = new JRXlsxExporter();

		jpa.setProperty(net.sf.jasperreports.engine.JRParameter.IS_IGNORE_PAGINATION, "false");


		xlsxExporter.setExporterInput(new SimpleExporterInput(jpa));

		xlsxExporter.setExporterOutput(new SimpleOutputStreamExporterOutput(xlsxFile.getAbsolutePath()));


		SimpleXlsxReportConfiguration xlsxreportConfig = new SimpleXlsxReportConfiguration();

		xlsxreportConfig.setSheetNames(new String[] { xlsxFile.toString() });


		xlsxreportConfig.setRemoveEmptySpaceBetweenRows(true);
		xlsxreportConfig.setRemoveEmptySpaceBetweenColumns(true);
		xlsxreportConfig.setForcePageBreaks(false);
		xlsxreportConfig.setAutoFitPageHeight(true);
		xlsxreportConfig.setWrapText(false);
		xlsxreportConfig.setCollapseRowSpan(true);
		xlsxreportConfig.setSheetNames(name);
		xlsxExporter.setConfiguration(xlsxreportConfig);

		xlsxExporter.exportReport();

		String pass = passwordProtection(xlsxFile.getAbsolutePath());

		emailService.sendPreparedMail(bank, xlsxFile.getAbsolutePath(),pass);

		return xlsxFile.getAbsolutePath();
	}


	// Fill template order parametres
	private Map<String, Object> parameters() {
		final Map<String, Object> parameters = new HashMap<>();

		parameters.put("logo", getClass().getResourceAsStream("logo"));


		return parameters;
	}

	// Load invoice jrxml template
	private JasperReport loadTemplate(String invoicetemplate) throws JRException {

		final JasperDesign jasperDesign = JRXmlLoader.load(invoicetemplate);

		return JasperCompileManager.compileReport(jasperDesign);
	}

	@Override 
	@Async
	public String getTransactionReport(String issuer) {

		String path = null;

		log.info(Thread.currentThread().getName());

		try {
			if(issuer.equals("Axis")) {
				Map<String,List<Object>> bean = reportepo.getTransactionReport(issuer);
				if(bean.get("Axisa").isEmpty()) {
					return ".";
				}
				else {
					path = getAxisEmailReportXlsx(bean, issuer);
					log.info("BankName : {}, Size : {}",issuer,bean.size());
				}
			}
			else {
				Map<String,List<Object>> bean = reportepo.getTransactionReport(issuer);
				if(bean.get(issuer).isEmpty()) {
					return ".";
				}
				else {
					path = getEmailReportXlsx(bean.get(issuer), issuer);
					log.info("BankName : {}, Size : {}",issuer,bean.size());
				}
			}

		} catch (JRException | IOException e) {
			emailService.sendErrorMail();
			log.info(e.getMessage());
		}
		return path;
	}

	@Async
	public void deleteReport() {
		try (Stream<Path> walk = Files.walk(Paths.get(""))) {

			List<String> result = walk.map(Object::toString)
					.filter(f -> f.endsWith(XLSX)).collect(Collectors.toList());

			for(String path : result) {
				File fil = new File(path);

				if( getCreateTime(fil).isBefore(LocalDateTime.now().minusMinutes(1))){
					Path del = Paths.get(path);
					Files.delete(del);

					log.info("Delete operation done");
				}else{
					TimeUnit.MINUTES.sleep(1);

				}
			}

		} catch (Exception e) {
			log.info(e.getMessage());
		}

	}

	private static LocalDateTime getCreateTime(File file) throws IOException {
		
		Path path = Paths.get(file.getPath());
		BasicFileAttributeView basicfile = Files.getFileAttributeView(path, BasicFileAttributeView.class, LinkOption.NOFOLLOW_LINKS);
		BasicFileAttributes attr = basicfile.readAttributes();
		long date = attr.creationTime().toMillis();
		Instant instant = Instant.ofEpochMilli(date);
		
		return LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
	}

	public String passwordProtection(String path) {

		// Generating dynamic password here
		final String PASS = RandomStringUtils.randomAlphabetic(7);

		try{

			log.info("Password protection path {}",path);
			
			POIFSFileSystem fs = new POIFSFileSystem();
				
				EncryptionInfo info = new EncryptionInfo(EncryptionMode.agile,CipherAlgorithm.aes192, HashAlgorithm.sha384, -1, -1, null);
				Encryptor enc = info.getEncryptor();
				enc.confirmPassword(PASS); 

				try(OPCPackage opc = OPCPackage.open(new File(path), PackageAccess.READ_WRITE)){
					
					OutputStream os = enc.getDataStream(fs);
					opc.save(os);
	
				}
				FileOutputStream fos = new FileOutputStream(path);
				fs.writeFilesystem(fos);
				fos.close();
				fs.close();
			
		}
		catch (Exception ex) {

			log.info(ex.getMessage());
		}


		return PASS;
	}

}
