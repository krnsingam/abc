package com.mosambee.service;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.mosambee.util.MailConstant;

@Service("emailService")
public class EmailServiceImpl implements EmailService {

	private final Logger log = LogManager.getLogger(EmailServiceImpl.class);
	
	@Autowired(required=true)
    private JavaMailSender javaMailSender;
	
	@Autowired
	private MailConstant mails;
	
	public static final String SUCCESS="Success";
	
	@Async
	public String sendPreparedMail(String bank,String path,String pass) {
    	
		log.info("Bank : {}, Pass{}, Thread : {}",bank,pass,Thread.currentThread().getName());
		
        String res = "Not data found";
		String to = null;
		StringBuilder subject = new StringBuilder();
		StringBuilder text = new StringBuilder();
        
        final SimpleDateFormat sdf = 
    			new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        log.info("Email Details bank {}, path {} ,password {}",bank,path,pass);
        try {
        	
	        	to = mails.mailDetail(bank);
	        	log.info(to);
        	
        		subject.append(bank).append(MailConstant.SUBJECT);
        		text.append(MailConstant.TEXT1) 
        				.append("Kindly find attach ")
        				.append(bank)
        				.append(" Bank EMI transactions report on dated ")
        				.append(sdf.format(date))
        				.append(".\r\nKindly note that your password for generated file is : ")
        				.append(pass)
        				.append("\r\n")
        				.append(MailConstant.TEXT2);
	            MimeMessage mail = javaMailSender.createMimeMessage();
	            MimeMessageHelper helper = new MimeMessageHelper(mail, true);
	            helper.setFrom("noreply@mosambee.in");
	            helper.setTo(InternetAddress.parse(to));
	            helper.setSubject(subject.toString());
	            helper.setText(text.toString(), false);
	            
	            FileSystemResource file = new FileSystemResource(path);
	    		helper.addAttachment(file.getFilename(), file);
	            
	            javaMailSender.send(mail);

	    		res=SUCCESS;

        } catch (Exception e) {
    		log.info(e.getLocalizedMessage());
    		res=e.getMessage();
        }
        
        return res;
    }
	
	@Async
	public String sendSbiMail(String bank,String path) {
    	
		log.info("Bank : {}, Thread : {}",bank,Thread.currentThread().getName());
		
        String res = "Not data found";
		String to = null;
		StringBuilder subject = new StringBuilder();
		StringBuilder text = new StringBuilder();
        
        final SimpleDateFormat sdf = 
    			new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();

        try {
        	
	        	to = mails.mailDetail(bank);
	        	log.info(to);
        	
        		subject.append(bank).append(MailConstant.SUBJECT);
        		text.append(MailConstant.TEXT1) 
        				.append("Kindly find attach ")
        				.append(bank)
        				.append(" Bank EMI transactions report on dated ")
        				.append(sdf.format(date))
        				.append("\r\n")
        				.append(MailConstant.TEXT2);
	            MimeMessage mail = javaMailSender.createMimeMessage();
	            MimeMessageHelper helper = new MimeMessageHelper(mail, true);
	            helper.setFrom("noreply@mosambee.in");
	            helper.setTo(InternetAddress.parse(to));
	            helper.setSubject(subject.toString());
	            helper.setText(text.toString(), false);
	            
	            FileSystemResource file = new FileSystemResource(path);
	    		helper.addAttachment(file.getFilename(), file);

	            javaMailSender.send(mail);

	    		res=SUCCESS;

        } catch (Exception e) {
    		log.info(e.getLocalizedMessage());
    		res=e.getMessage();
        }
        
        return res;
    }
	
	@Async
	public String sendErrorMail() {
    	
        String res;
    	
        try {
            MimeMessage mail = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mail, true);
            helper.setTo(mails.mailDetail("error"));
            helper.setSubject("Error oocured in reporting process.");
            helper.setText("Error occured during proccessing batch report.", false);
            
            javaMailSender.send(mail);
            
    		
    		res=SUCCESS;
        } catch (Exception e) {
            
    		
    		res=e.getMessage();
        }
        
        return res;
    }
    
}
