package com.mosambee.service;

import java.io.IOException;
import java.util.List;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperPrint;

public interface ReportService {

	public JasperPrint generateJasperPrint(List<Object> order, String bank) throws IOException, JRException;
	
	public byte[] getReportPdf(List<Object> order, String bank) throws JRException, IOException;
	
	public byte[] getReportXlsx(List<Object> order, String bank) throws JRException, IOException;
	
	public String getEmailReportPdf(List<Object> order, String bank) throws JRException, IOException;
	
	public String getEmailReportXlsx(List<Object> order, String bank) throws JRException, IOException;
	
	public String getTransactionReport(String issuer);
	
	public void deleteReport();
}
