package com.mosambee;


import com.mosambee.util.RestException;
import com.mosambee.util.RestMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.Locale;

@ControllerAdvice
public class RestExceptionHandler{
	
	private static final Logger log = LogManager.getLogger(RestExceptionHandler.class);
    private final MessageSource messageSource;
   
    @Autowired
    public RestExceptionHandler(MessageSource messageSource) {
    	log.info("Globally rest exception handeled");
    	log.info(messageSource);
        this.messageSource = messageSource;
    }

    @ExceptionHandler(RestException.class)
    public ResponseEntity<RestMessage> handleIllegalArgument(RestException ex, Locale locale) {
        String errorMessage = messageSource.getMessage(ex.getMessage(), ex.getArgs(), locale);
        log.info("Globally exception handeled");
        log.info(errorMessage);
        return new ResponseEntity<>(new RestMessage(errorMessage), HttpStatus.BAD_REQUEST);
    }
    
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<RestMessage> handleArgumentNotValidException(MethodArgumentNotValidException ex, Locale locale) {
        BindingResult result = ex.getBindingResult();
        String errorMessage=result.getFieldError().getField();
        log.info("Globally exception at handleArgumentNotValidException handeled");
        log.info(errorMessage);
        return new ResponseEntity<>(new RestMessage(HttpStatus.NOT_ACCEPTABLE,errorMessage), HttpStatus.NOT_ACCEPTABLE);
    }
    
    @ExceptionHandler(Exception.class)
    public ResponseEntity<RestMessage> handleExceptions(Exception ex, Locale locale) {
    	String errorMessage = ex.getLocalizedMessage().substring(0, ex.getLocalizedMessage().indexOf(':'));
        log.info("Globally exception handeled");
        log.info(errorMessage);
        return new ResponseEntity<>(new RestMessage(HttpStatus.INTERNAL_SERVER_ERROR,errorMessage), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}