package com.mosambee.config;

import javax.sql.DataSource;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Configuration
public class AppConfig {
	@Bean("masterSfnTransaction")
    public JdbcTemplate masterSfnTransaction(DataSource masterSfnTransactionDataSource){
        return new JdbcTemplate(masterSfnTransactionDataSource);
    }

    @Bean("masterSecurityLicense")
    public JdbcTemplate masterSecurityLicense(DataSource masterSecurityLicenseDataSource){
        return new JdbcTemplate(masterSecurityLicenseDataSource);
    }

    @Bean("slaveSfnTransaction")
    public JdbcTemplate slaveSfnTransaction(DataSource slaveSfnTransactionDataSource){
        return new JdbcTemplate(slaveSfnTransactionDataSource);
    }

    @Bean("slaveSecurityLicense")
    public JdbcTemplate slaveSecurityLicense(DataSource slaveSecurityLicenseDataSource){
        return new JdbcTemplate(slaveSecurityLicenseDataSource);
    }

	@Bean("masterSfnTransactionDataSource")
    @ConfigurationProperties(prefix = "spring.master-sfntransaction-datasource")
    public DataSource masterSfnTransactionDataSource() {
        return DataSourceBuilder.create().build();
    }
	
	@Bean("masterSecurityLicenseDataSource")
    @ConfigurationProperties(prefix = "spring.master-securityandlicense-datasource")
    public DataSource masterSecurityLicenseDataSource() {
        return DataSourceBuilder.create().build();
    }
	
	@Bean("slaveSfnTransactionDataSource")
    @ConfigurationProperties(prefix = "spring.slave-sfntransaction-datasource")
    public DataSource slaveSfnTransactionDataSource() {
        return DataSourceBuilder.create().build();
    }
	
	@Bean("slaveSecurityLicenseDataSource")
    @ConfigurationProperties(prefix = "spring.slave-securityandlicense-datasource")
    public DataSource slaveSecurityLicenseDataSource() {
        return DataSourceBuilder.create().build();
    }
}