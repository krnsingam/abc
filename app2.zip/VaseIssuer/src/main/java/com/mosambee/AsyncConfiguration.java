package com.mosambee;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.concurrent.Executor;

@Configuration
@EnableAsync
public class AsyncConfiguration {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AsyncConfiguration.class);
	
	@Value("${threadpath}")
	private String path;
	
	int maxPoolSize;
	int coreSize;
	int capacity;

    @Bean (name = "taskExecutor")
    public Executor taskExecutor() {
    	
    	Properties prop = new Properties();
		InputStream input = null;
	
		try {
		    input = new FileInputStream(path);
		    prop.load(input);
		    maxPoolSize = Integer.parseInt(prop.getProperty("mosambee.subthread.maxsize"));
		    coreSize = Integer.parseInt(prop.getProperty("mosambee.subthread.core"));
		    capacity = Integer.parseInt(prop.getProperty("mosambee.subthread.capacity"));
		} catch (IOException ex) {
			LOGGER.info(ex.getMessage());
		}
    	
        LOGGER.debug("Creating Async Task Executor");
        final ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(coreSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setThreadNamePrefix("sub-thread");
        executor.setQueueCapacity(capacity);
        executor.initialize();
        return executor;
    }
}