package com.mosambee.repository;

import java.util.List;
import java.util.Map;

import com.mosambee.bean.SbiBean;

public interface SbiRepository {

	public List<SbiBean> sbiReport(String type);
	
	public Map<String,Object> sbiCmsReport();
}
