package com.mosambee.repository;

import java.util.List;
import java.util.Map;

public interface ReportRepository {

	public Map<String, List<Object>> getTransactionReport(String issuer);
	
}
