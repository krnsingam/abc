package com.mosambee.repository;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.SbiBean;
import com.mosambee.bean.SbiCmsBean;


@Repository(value="sbiRpository")
public class SbiRepositoryImpl implements SbiRepository{
	
	private static final Logger log = LogManager.getLogger(SbiRepositoryImpl.class);

	@Autowired @Qualifier("masterSfnTransaction")
	private JdbcTemplate jdbcTemplate;

	@Autowired @Qualifier("masterSecurityLicense")
	private JdbcTemplate jdbcTemplate1;
	
	@Autowired @Qualifier("slaveSfnTransaction")
	private JdbcTemplate jdbcTemplate2;
	
	@Autowired @Qualifier("slaveSecurityLicense")
	private JdbcTemplate jdbcTemplate3;
	
	
	public List<SbiBean> sbiReport(String type){
		
		List<SbiBean> sbilist = new ArrayList();
		String sql = "";
		if(type.equals("M")) {
			 sql = "{call tsp_getSBIMIDReport(?)}";
		}
		else if(type.equals("T")) {
			 sql = "{call tsp_getSBITIDReport(?)}";
		}
		else if(type.equals("S")) {
			 sql = "{call tsp_getSBISKUReport(?)}";
		}
		
		ResultSet resultSet = null;
		try (Connection connection = this.jdbcTemplate.getDataSource().getConnection();
				 CallableStatement callableStatement = connection.prepareCall(sql);) {
				
				callableStatement.registerOutParameter(1, java.sql.Types.BIGINT);
				
				resultSet = callableStatement.executeQuery();
				
				log.info("{}", callableStatement);

				while (resultSet.next()) {
					if(type.equals("M")) {
						SbiBean sbibean =  new SbiBean();
						sbibean = setSbiBeanM(resultSet);
						sbilist.add(sbibean);
					}
					else if(type.equals("T")) {
						SbiBean sbibean =  new SbiBean();
						sbibean = setSbiBeanT(resultSet);
						sbilist.add(sbibean);
					}
					else if(type.equals("S")) {
						SbiBean sbibean =  new SbiBean();
						sbibean = setSbiBeanS(resultSet);
						sbilist.add(sbibean);
					}
				}

			} catch (SQLException e) {
				
				log.error(e.getMessage());
			}
		finally {
			try {
				if(resultSet!=null) {
				resultSet.close();}
			} catch (SQLException e) {
				
				log.info(e.getMessage());
			}
		}
		return sbilist;
	}
	
	public Map<String,Object> sbiCmsReport(){
		Map<String,Object> data = new HashMap();
		List<SbiCmsBean> sbilist = new ArrayList();
		String sql = "{call tsp_getSBITransactionReport(?,?)}";
		ResultSet resultSet = null;
		try (Connection connection = this.jdbcTemplate.getDataSource().getConnection();
				 CallableStatement callableStatement = connection.prepareCall(sql);) {
				
			callableStatement.registerOutParameter(1, java.sql.Types.BIGINT);
			callableStatement.registerOutParameter(2, java.sql.Types.BIGINT);
				
				resultSet = callableStatement.executeQuery();
				
				data.put("totAmount", callableStatement.getLong(1));
				data.put("totTrnx", callableStatement.getLong(2));
				log.info("{}", callableStatement);

				while (resultSet.next()) {
					
						SbiCmsBean sbibean =  new SbiCmsBean();
						sbibean=setSbiCms(resultSet);
						sbilist.add(sbibean);
				
				}

			} catch (SQLException e) {
				
				log.error(e.getMessage());
			}
		finally {
			try {
				if(resultSet!=null) {
				resultSet.close();}
			} catch (SQLException e) {
				
				log.info(e.getMessage());
			}
		}
		data.put("sbilist", sbilist);
		return data;
	}
	
	public SbiCmsBean setSbiCms(ResultSet resultSet) throws SQLException {

		SbiCmsBean sbibean=setSbiCms1(resultSet);
		
		sbibean.setAggregatorName("Synergistic Financial Networks Pvt Ltd");
		sbibean.setRecordType("DD");
		if(resultSet.getString(1)!=null) {
			sbibean.setUniqueReferenceNumber(resultSet.getString(1));
		}else {
			sbibean.setUniqueReferenceNumber("0");
		}
		if(resultSet.getString(3)!=null) {
			sbibean.setCardNbr(resultSet.getString(3));
		}else {
			sbibean.setCardNbr("");
		}
		if(resultSet.getString(5)!=null) {
			sbibean.setTxnAmount(resultSet.getString(5));
		}else {
			sbibean.setTxnAmount("");
		}
		if(resultSet.getString(8)!=null) {
			sbibean.setTotalTerms(resultSet.getString(8));
		}else {
			sbibean.setTotalTerms("");
		}
		if(resultSet.getString(4)!=null) {
			sbibean.setAuthCode(resultSet.getString(4));
		}else {
			sbibean.setAuthCode("");
		}
		if(resultSet.getString(11)!=null) {
			sbibean.setSaleDate(resultSet.getString(11));
		}else {
			sbibean.setSaleDate("");
		}
		if(resultSet.getString(12)!=null) {
			sbibean.setMerchId(resultSet.getString(12));
		}else {
			sbibean.setMerchId("");
		}
		sbibean.setManufacturerName("Synergistic Financial Networks Pvt Ltd");
		sbibean.setStatusFlag("F");
		sbibean.setOnUsOffUsFlag("1");
		sbibean.setProcessingFeeFlag("");
		sbibean.setProcessingFee("0");
		sbibean.setCashbackAmount("0");
		
		return sbibean;
	}
	
	public SbiCmsBean setSbiCms1(ResultSet resultSet) throws SQLException {
		SbiCmsBean sbibean =  new SbiCmsBean();
		if(resultSet.getString(14)!=null) {
			sbibean.setMerchantName(resultSet.getString(14));
		}else {
			sbibean.setMerchantName("");
		}
		if(resultSet.getString(7)!=null) {
			sbibean.setTermId(resultSet.getString(7));
		}else {
			sbibean.setTermId("");
		}
		if(resultSet.getString(9)!=null) {
			sbibean.setRateOfInt(resultSet.getString(9));
		}else {
			sbibean.setRateOfInt("");
		}
		sbibean.setDescription("");
		if(resultSet.getString(5)!=null) {
			sbibean.setOriginalAmount(resultSet.getString(5));
		}else {
			sbibean.setOriginalAmount("");
		}
		if(resultSet.getString(13)!=null) {
			sbibean.setSkuCode(resultSet.getString(13));
		}else {
			sbibean.setSkuCode("");
		}
		if(resultSet.getString(6)!=null) {
			sbibean.setEmiAmount(resultSet.getString(6));
		}else {
			sbibean.setEmiAmount("");
		}
		return sbibean;
	}
	
	public SbiBean setSbiBeanM(ResultSet resultSet) throws SQLException {
			
		   SbiBean sbibean=setSbiBeanM1(resultSet);
			
			if(resultSet.getString(2)!=null && resultSet.getString(2).length()<10) {
				sbibean.setAggeratorId(resultSet.getString(2));
			}else {
				sbibean.setAggeratorId("");
			}
			if(resultSet.getString(4)!=null && resultSet.getString(4).length()<17) {
				sbibean.setMerchantId(resultSet.getString(4));
			}else {
				sbibean.setMerchantId("");
			}
			if(resultSet.getString(5)!=null && resultSet.getString(5).length()<41) {
				sbibean.setMerchantName(resultSet.getString(5));
			}else {
				sbibean.setMerchantName("");
			}
			
			sbibean.setSetupType("M");

		return sbibean;
		
	}
	
	public SbiBean setSbiBeanM1(ResultSet resultSet) throws SQLException {
		SbiBean sbibean =  new SbiBean();
		if(resultSet.getString(6)!=null && resultSet.getString(6).length()<14) {
			sbibean.setMerchantCity(resultSet.getString(6));
		}else {
			sbibean.setMerchantCity("");
		}
		if(resultSet.getString(7)!=null && resultSet.getString(7).length()<9) {
			sbibean.setStartDateMid(resultSet.getString(7));
		}else {
			sbibean.setStartDateMid("");
		}
		if(resultSet.getString(8)!=null && resultSet.getString(8).length()<9) {
			sbibean.setEndDateMid(resultSet.getString(8));
		}else {
			sbibean.setEndDateMid("");
		}
		return sbibean;
		
	}

	public SbiBean setSbiBeanT(ResultSet resultSet) throws SQLException {
		 
		 	SbiBean sbibean=setSbiBeanT1(resultSet);
		 	
			if(resultSet.getString(2)!=null && resultSet.getString(2).length()<10) {
				sbibean.setAggeratorId(resultSet.getString(2));
			}else {
				sbibean.setAggeratorId("");
			}
			if(resultSet.getString(4)!=null && resultSet.getString(4).length()<41) {
				sbibean.setMerchantName(resultSet.getString(4));
			}else {
				sbibean.setMerchantName("");
			}
			if(resultSet.getString(5)!=null && resultSet.getString(5).length()<17) {
				sbibean.setMerchantId(resultSet.getString(5));
			}else {
				sbibean.setMerchantId("");
			}
			
			sbibean.setSetupType("T");
		return sbibean;
	}
	
	public SbiBean setSbiBeanT1(ResultSet resultSet) throws SQLException {
		SbiBean sbibean =  new SbiBean();
		
		if(resultSet.getString(6)!=null && resultSet.getString(6).length()<9) {
			sbibean.setStoreId(resultSet.getString(6));
		}else {
			sbibean.setStoreId("");
		}
		if(resultSet.getString(7)!=null && resultSet.getString(7).length()<41) {
			sbibean.setStoreName(resultSet.getString(7));
		}else {
			sbibean.setStoreName("");
		}
		if(resultSet.getString(8)!=null && resultSet.getString(8).length()<14) {
			sbibean.setStoreCity(resultSet.getString(8));
		}else {
			sbibean.setStoreCity("");
		}
		return sbibean;
	}
	
	public SbiBean setSbiBeanS(ResultSet resultSet) throws SQLException {
		SbiBean sbibean =  new SbiBean();

			if(resultSet.getString(2)!=null && resultSet.getString(2).length()<10) {
				sbibean.setAggeratorId(resultSet.getString(2));
			}
			else {
				sbibean.setAggeratorId("");
			}
			if(resultSet.getString(3)!=null && resultSet.getString(3).length()<41) {
				sbibean.setMerchantName(resultSet.getString(3));
			}
			else {
				sbibean.setMerchantName("");
			}
			if(resultSet.getString(4)!=null && resultSet.getString(4).length()<17) {
				sbibean.setMerchantId(resultSet.getString(4));
			}
			else {
				sbibean.setMerchantId("");
			}
			if(resultSet.getString(5)!=null && resultSet.getString(5).length()<21) {
				sbibean.setSkuId(resultSet.getString(5));
			}
			else {
				sbibean.setSkuId("");
			}
			if(resultSet.getString(6)!=null && resultSet.getString(6).length()<31) {
				sbibean.setSkuName(resultSet.getString(6));
			}else {
				sbibean.setSkuName("");
			}
			sbibean.setSetupType("S");

		return sbibean;
		
	}

}
