package com.mosambee.repository;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mosambee.bean.AmexBean;
import com.mosambee.bean.Axis1Bean;
import com.mosambee.bean.AxisBean;
import com.mosambee.bean.BobBean;
import com.mosambee.bean.KotakBean;
import com.mosambee.bean.RblBean;
import com.mosambee.bean.ScbBean;
import com.mosambee.bean.YesBean;

@Repository(value = "reportRepository")
public class ReportRepositoryImpl implements ReportRepository{

	private static final Logger log = LogManager.getLogger(ReportRepositoryImpl.class);

	@Autowired @Qualifier("masterSfnTransaction")
	private JdbcTemplate jdbcTemplate;

	@Autowired @Qualifier("masterSecurityLicense")
	private JdbcTemplate jdbcTemplate1;
	
	@Autowired @Qualifier("slaveSfnTransaction")
	private JdbcTemplate jdbcTemplate2;
	
	@Autowired @Qualifier("slaveSecurityLicense")
	private JdbcTemplate jdbcTemplate3;
	
	public static final String MOSAMBEE = "MOSAMBEE";
	public static final String SETTLED = "SETTLED";
	
	
	public Map<String,List<Object>> getTransactionReport(String issuer) {

		String sql = "{call tsp_getTransactionReport(?) }";
		ResultSet resultSet = null;
		Map<String,List<Object>> data = new HashMap();
		List<Object> list = new ArrayList<>();
		List<Object> axis = new ArrayList<>();
		List<Object> axis1 = new ArrayList<>();
		try (Connection connection = this.jdbcTemplate.getDataSource().getConnection();
			 CallableStatement callableStatement = connection.prepareCall(sql);) {
			
			callableStatement.setString(1, issuer.toUpperCase());
			
			resultSet = callableStatement.executeQuery();
			
			log.info("{}", callableStatement);

			while (resultSet.next()) {
				
				if(issuer.equals("Axis")) {
					AxisBean bean = new AxisBean();
					bean=setAxisBean(resultSet);
					axis.add(bean);
					
					Axis1Bean beans = new Axis1Bean();
					beans=setAxis1Bean(resultSet);
					axis1.add(beans);
				}
				else if(issuer.equals("Amex")) {
					AmexBean bean = new AmexBean();
					bean=setAmexBean(resultSet);
					list.add(bean);
				}
				else if(issuer.equals("Bob")) {
					BobBean bean = new BobBean();
					bean=setBobBean(resultSet);
					list.add(bean);
				}
				else if(issuer.equals("Kotak")) {
					KotakBean bean = new KotakBean();
					bean=setKotakBean(resultSet);
					list.add(bean);
				}
				else if(issuer.equals("Rbl")) {
					RblBean bean = new RblBean();
					bean=setRblBean(resultSet);
					list.add(bean);
				}
				else if(issuer.equals("Scb")) {
					ScbBean bean = new ScbBean();
					bean=setScbBean(resultSet);
					list.add(bean);
				}
				else if(issuer.equals("Yes")) {
					YesBean bean = new YesBean();
					bean=setYesBean(resultSet);
					list.add(bean);
				}
				else if(issuer.equals("Axis1")) {
					Axis1Bean bean = new Axis1Bean();
					bean=setAxis1Bean(resultSet);
					list.add(bean);
				}
				else {
					String e = "Improper issuer name";
					list.add(e);
				}
			}

		} catch (SQLException e) {
			
			log.error(e.getMessage());
		}
		finally {
			try {
				resultSet.close();
			} catch (SQLException e) {
				
				log.info(e.getMessage());
			}
		}
		
		if(issuer.equals("Axis")) {
			data.put("Axisa", axis);
			data.put("Axisb", axis1);
		}else {
			data.put(issuer, list);
		}
		return data;

	}
	
	public AxisBean setAxisBean(ResultSet res) {
		
		AxisBean bean = new AxisBean();
		
		try {
			bean.setEmiId(res.getString(1));
			bean.setCardNumber(res.getString(2));
			bean.setMcc(res.getString(14));
			bean.setSource(MOSAMBEE);
			bean.setTransactionAmount(res.getString(5));
			bean.setTransactionDate(res.getString(23));
			bean.setSettlementDate(res.getString(20));
			bean.setAuthorisationId(res.getString(4));
			bean.setMerchantName(res.getString(16));
			bean.setTenure(res.getString(9));
			bean.setInterestRate(res.getString(10));
			
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
		return bean;
	}
	
	public AmexBean setAmexBean(ResultSet res) {
		
		AmexBean bean = new AmexBean();
		
		try {
			bean.setEmiModel(res.getString(1));
			bean.setCardPan(res.getString(2));
			bean.setBankRrn(res.getString(3));
			bean.setBankApprovalCode(res.getString(4));
			
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
		return bean;
	}
	
	public BobBean setBobBean(ResultSet res) {
		
		BobBean bean = new BobBean();
		
		try {
			bean.setEmiId(res.getString(1));
			bean.setCardno(res.getString(2));
			bean.setRrn(res.getString(3));
			bean.setAuthCode(res.getString(4));
			bean.setIssuer(res.getString(12));
			bean.setAcquirer(res.getString(13));
			bean.setMerchantName(res.getString(16));
			bean.setManufacturer(MOSAMBEE);
			bean.setTransactionAmount(res.getString(5));
			bean.setTransactionAmt(res.getString(5));
			bean.setEmiOffer("");
			bean.setTransactionAmt("");
			bean.setStoreName("");
			bean.setAddress1(res.getString(17));
			bean.setStoreCity(res.getString(18));
			bean.setStoreState(res.getString(19));
			bean.setMid(res.getString(7));
			bean.setTid(res.getString(8));
			bean.setTransactionTime(res.getString(23));
			bean.setSubvention("");
			bean.setSubventionAmount("");
			bean.setInterestRate(res.getString(21));
			bean.setCustomerProcessingFee("0");
			bean.setCustomerProcessingAmt("0");
			bean.setTransactionStatus(res.getString(11));
			bean.setEmiAmount(res.getString(6));
			
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
		return bean;
	}
	
	public KotakBean setKotakBean(ResultSet res) {
		
		KotakBean bean = new KotakBean();
		
		try {
			bean.setEmiId(res.getString(1));
			bean.setCardPan(res.getString(2));
			bean.setMid(res.getString(7));
			bean.setAuthCode(res.getString(4));
			bean.setIssuer(res.getString(12));
			bean.setTxAmount(res.getString(5));
			bean.setTenure(res.getString(9));
			bean.setManufacturer("Synergistic Financial Networks Pvt. Ltd.");
			bean.setMerchantName(res.getString(16));
			bean.setAddress1(res.getString(17));
			bean.setAcquirer(res.getString(13));
			bean.setTid(res.getString(8));
			bean.setTxTime(res.getString(23));
			bean.setSettlementTime(res.getString(20));
			bean.setInterestRate(res.getString(10));
			bean.setDiscountCashbackPercent(res.getString(21));
			bean.setDiscountCashbackAmount(res.getString(22));
			
			
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
		return bean;
	}
	
	public RblBean setRblBean(ResultSet res) {
		
		
		
		RblBean bean = new RblBean();	
		
		try {
			bean.setEmiId(res.getString(1));
			bean.setCardPAN(res.getString(2));
			bean.setRrn(res.getString(3));
			bean.setAuthCode(res.getString(4));
			bean.setIssuer(res.getString(12));
			bean.setAcquirer(res.getString(13));
			bean.setAggregatorMerchantName(MOSAMBEE);
			bean.setManufacturer("Synergistic Financial Networks Pvt. Ltd.");
			bean.setTxAmount(res.getString(5));
			bean.setEmiOffer(res.getString(9));
			bean.setEmiPlanID(getPlanId(res.getString(9)));
			bean.setCustomerName("");
			bean.setMobile("");
			bean.setAddress("");
			bean.setEmail("");
			bean.setStoreName("");
			bean.setStoreCity(res.getString(18));
			bean.setStoreState(res.getString(19));
			bean.setMid(res.getString(7));
			bean.setTid(res.getString(8));
			bean.setTxTime(res.getString(23));
			bean.setSubventionPayable("0");
			bean.setSubventionAmount("0");
			bean.setInterestRate(res.getString(10));
			bean.setCustomerProcessingFee("0");
			bean.setCustomerProcessingAmount("0");
			bean.setTxStatus(SETTLED);
			bean.setStatus(res.getString(11));
			bean.setProductCategory("");
			bean.setProductSubCategory1("");
			bean.setProductSubCategory2("");
			bean.setModelName("");
			bean.setMerchantName(res.getString(16));
			bean.setEmiAmount(res.getString(6));
			bean.setLoanAmount(res.getString(5));
			bean.setDiscountCashbackPercent(res.getString(21));
			bean.setDiscountCashbackAmount(res.getString(22));
			bean.setAdditionalCashback("");
			bean.setBonusRewardPoints("");
			bean.setEmiModel("");
			
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
		return bean;
	}
	
	private String getPlanId(String tenure) {
		String planId = "";
		switch (tenure) {
			case "3":
				planId = "85003";
				break;
			case "6":
				planId = "85006";
				break;
			case "9":
				planId = "85009";
				break;
			case "12":
				planId = "85012";
				break;
			case "18":
				planId = "85018";
				break;
			case "24":
				planId = "85024";
				break;
			default:
				break;
			}
			return planId;
	  }
	public ScbBean setScbBean(ResultSet res) {
		
		ScbBean bean = new ScbBean();
		
		try {
			bean.setTenor(res.getString(9));
			bean.setCardNumber(res.getString(2));
			bean.setAuthCode(res.getString(4));
			bean.setMid(res.getString(7));
			bean.setMerchantName(res.getString(16));
			bean.setTrxnAmount(res.getString(5));
			bean.setTrxnDate(res.getString(23));
			bean.setSettlementDate(res.getString(20));
			bean.setIncreasingInterestRate(res.getString(10));
			bean.setProcessingFee("0");
			bean.setForclouserFee("0");
			bean.setMinamt("");
			bean.setMaxamt("");
			
			
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
		return bean;
	}
	
	public YesBean setYesBean(ResultSet res) {
		
		YesBean bean = new YesBean();
		
		try {
			bean.setEmiId(res.getString(1));
			bean.setCardPan(res.getString(2));
			bean.setRrn(res.getString(3));
			bean.setAuthCode(res.getString(4));
			bean.setIssuer(res.getString(12));
			bean.setTxAmount(res.getString(5));
			bean.setEmiOffer(res.getString(9));
			bean.setManufacturer(MOSAMBEE);
			bean.setMerchantName(res.getString(16));
			bean.setAddress1(res.getString(17));
			bean.setStoreCity(res.getString(18));
			bean.setStoreState(res.getString(19));
			bean.setAcquirer(res.getString(13));
			bean.setMid(res.getString(7));
			bean.setTid(res.getString(8));
			bean.setTxTime(res.getString(23));
			bean.setSettlementTime(res.getString(20));
			bean.setCustomerProcessingFee("0");
			bean.setCustomerProcessingAmount("0");
			bean.setSubventionPayable("0");
			bean.setSubventionAmount("0");
			bean.setInterestRate(res.getString(10));
			bean.setTxStatus(SETTLED);
			bean.setStatus(res.getString(11));
			bean.setDescription(res.getString(15));
			bean.setProductCategory("");
			bean.setProductSubCategory1("");
			bean.setProductSubCategory2("");
			bean.setModelName("");
			bean.setCardHash("");
			bean.setEmiAmount(res.getString(6));
			bean.setLoanAmount(res.getString(5));
			bean.setDiscountCashbackPercent(res.getString(21));
			bean.setDiscountCashbackAmount(res.getString(22));
			bean.setIsNewModel("");
			bean.setAdditionalCashback("");
			bean.setRewardPoint("");
			
			
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
		return bean;
	}
	
public Axis1Bean setAxis1Bean(ResultSet res) {
		
		Axis1Bean bean = new Axis1Bean();
		
		try {
			bean.setEmiId(res.getString(1));
			bean.setCardPan(res.getString(2));
			bean.setRrn(res.getString(3));
			bean.setAuthCode(res.getString(4));
			bean.setIssuer(res.getString(12));
			bean.setTxAmount(res.getString(5));
			bean.setEmiOffer(res.getString(9));
			bean.setManufacturer(MOSAMBEE);
			bean.setMerchantName(res.getString(16));
			bean.setAddress1(res.getString(17));
			bean.setStoreCity(res.getString(18));
			bean.setStoreState(res.getString(19));
			bean.setAcquirer(res.getString(13));
			bean.setMid(res.getString(7));
			bean.setTid(res.getString(8));
			bean.setTxTime(res.getString(23));
			bean.setSettlementTime(res.getString(20));
			bean.setCustomerProcessingFee("0");
			bean.setCustomerProcessingAmount("0");
			bean.setSubventionPayable("0");
			bean.setSubventionAmount("0");
			bean.setInterestRate(res.getString(10));
			bean.setTxStatus(SETTLED);
			bean.setStatus(res.getString(11));
			bean.setDescription(res.getString(15));
			bean.setProductCategory("");
			bean.setProductSubCategory1("");
			bean.setProductSubCategory2("");
			bean.setModelName("");
			bean.setCardHash("");
			bean.setEmiAmount(res.getString(6));
			bean.setLoanAmount(res.getString(5));
			bean.setDiscountCashbackPercent(res.getString(21));
			bean.setDiscountCashbackAmount(res.getString(22));
			bean.setIsNewModel("");
			bean.setAdditionalCashback("");
			bean.setRewardPoint("");
			bean.setSource("");
			
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
		return bean;
	}
}
