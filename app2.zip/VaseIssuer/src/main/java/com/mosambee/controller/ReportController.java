package com.mosambee.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.Properties;

import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mosambee.service.EmailService;
import com.mosambee.service.ReportService;
import com.mosambee.service.SbiService;

@Controller
@RequestMapping("/")
public class ReportController {
	
	 Logger log = LogManager.getLogger(ReportController.class);

	@Autowired
	ReportService reportService;
	
	@Autowired
	EmailService emailService;
	
	@Autowired
	SbiService sbiservice;
	
	@Value("${threadpath}")
	private String path;

	String cron;
	
	@Bean
    public String cron(@Value("${threadpath}") String path){
		Properties prop = new Properties();
		InputStream input = null;
		try {
			log.info(path);
		    input = new FileInputStream(path);
		    prop.load(input);
		    this.cron = prop.getProperty("mosambee.schedular.cron");
		   
		    
		} catch (IOException ex) {
			log.info(ex.getMessage());
		}
        return cron;
    }

	@Async
	public void getEmailReportPdf(final HttpServletResponse response,@RequestParam("issuer") String issuer) {
		
		String res="The requested data is sent to you on your registered email id";
		
		try {
			
			res = reportService.getTransactionReport(issuer);
			log.info(res);
			
		} catch (Exception e) {
			
			log.info(e.getMessage());
		}

	}
	
	@Scheduled(cron = "#{@cron}")
	public void sbiReport() {
		String[] type = {"M","T","S","C"};
		try {
			for(String sbi : type) {
				sbiservice.getSbiList(sbi);
			}
		} catch (Exception e) {
			log.info(e.getMessage());
		}
	}
	
	@Scheduled(cron = "#{@cron}")
	public void deleteSbiReport() {
		
		try {
			
			sbiservice.deleteSbiReport();
			
		} catch (Exception e) {
			log.info(e.getMessage());
		}
	}
	

	@Scheduled(cron = "#{@cron}")
	public void deleteReport() {
		try {
			reportService.deleteReport();
		} catch (Exception e) {
			log.info(e.getMessage());
		}
	}


	@Scheduled(cron = "#{@cron}")
	public void getEmailReportXlsx() {
		
		Properties prop = new Properties();
		InputStream input = null;
		String[] isuer = {""};
		try {
		    input = new FileInputStream(path);
		    prop.load(input);
		    isuer = prop.getProperty("mosambee.string.bank").split(",");
		    
		} catch (IOException ex) {
			log.info(ex.getMessage());
		}
		
		for(String issuer : isuer) {

			try {
				log.info("Fixed Delay Task :: Execution Time - {}", LocalDateTime.now());
				log.info(Thread.currentThread().getName());
				reportService.getTransactionReport(issuer);

			} catch (Exception e) {
				
				log.info(e.getMessage());
			}
		}

	}
	
}
