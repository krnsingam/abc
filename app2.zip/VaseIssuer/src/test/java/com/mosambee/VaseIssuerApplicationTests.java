package com.mosambee;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaseIssuerApplicationTests {

	Logger log = LogManager.getLogger(VaseIssuerApplicationTests.class);
	
	@Test
	void contextLoads() {
		log.info("Test Cases are all success");
	}

}
